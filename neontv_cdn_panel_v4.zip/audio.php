<?php
declare(strict_types=1);
// Herkese açık (dosya adresleri gibi tahmin edilemez kodlarla çalışır); Nginx /f/<kod>?audio=tür isteğini buraya yönlendirir.
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/store.php';   // cdnTypeOfExt
require __DIR__ . '/lib/media.php';   // cdnBin
require __DIR__ . '/lib/audio.php';
cdnAudioServe((string)($_GET['f'] ?? ''), (string)($_GET['t'] ?? ''));
