-- NeonTV CDN paneli tabloları (RLS açık; yalnızca service_role erişir)
create extension if not exists pgcrypto;

create table if not exists public.cdn_items (
  id          uuid primary key default gen_random_uuid(),
  parent_id   uuid references public.cdn_items(id) on delete cascade,
  root        text not null check (root in ('kalici','gecici')),
  kind        text not null check (kind in ('folder','file')),
  name        text not null check (char_length(name) between 1 and 120),
  stored_name text,
  ext         text,
  mime        text,
  size        bigint not null default 0,
  duration    real,
  has_thumb   boolean not null default false,
  created_at  timestamptz not null default now(),
  expires_at  timestamptz,
  check ((kind = 'file' and stored_name is not null) or kind = 'folder')
);

-- Aynı klasörde aynı isim (ve uzantı) tekrar edemez
create unique index if not exists cdn_items_unique_name
  on public.cdn_items (root, coalesce(parent_id, '00000000-0000-0000-0000-000000000000'::uuid), lower(name), coalesce(lower(ext), ''));
create index if not exists cdn_items_list_idx on public.cdn_items (root, parent_id, kind, name);
create index if not exists cdn_items_parent_idx on public.cdn_items (parent_id);
create index if not exists cdn_items_expiry_idx on public.cdn_items (expires_at) where expires_at is not null;

alter table public.cdn_items enable row level security;
revoke all on public.cdn_items from anon, authenticated;
grant all on public.cdn_items to service_role;

-- Bir öğe ve tüm alt öğeleri (kendisi dahil)
create or replace function public.cdn_descendants(p uuid)
returns setof public.cdn_items
language sql stable security definer set search_path = public as $$
  with recursive t as (
    select * from public.cdn_items where id = p
    union all
    select c.* from public.cdn_items c join t on c.parent_id = t.id
  )
  select * from t;
$$;

-- Kök başına dosya sayısı / boyut / klasör sayısı
create or replace function public.cdn_stats()
returns table(root text, files bigint, bytes bigint, folders bigint)
language sql stable security definer set search_path = public as $$
  select i.root,
         count(*) filter (where i.kind = 'file'),
         coalesce(sum(i.size) filter (where i.kind = 'file'), 0)::bigint,
         count(*) filter (where i.kind = 'folder')
  from public.cdn_items i group by i.root;
$$;

revoke all on function public.cdn_descendants(uuid) from public, anon, authenticated;
revoke all on function public.cdn_stats() from public, anon, authenticated;
grant execute on function public.cdn_descendants(uuid) to service_role;
grant execute on function public.cdn_stats() to service_role;
