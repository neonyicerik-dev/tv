# CDN panelini yeni VPS'e taşıma

Veri iki yerde: **Supabase `cdn_items` tablosu** (klasör/isim/süre; taşınmaz, aynı kalır) ve **diskteki dosyalar** (`/srv/cdn/data`: files, thumbs, audio). Yalnızca diskteki dosyaları kopyalamak yeterli.

## 1) Yeni VPS'te kurulum
README.md "Kurulum" 1-2 ve 5-7. adımları uygula (paketler, `/var/www/cdn`, Nginx, PHP ayarı, cron). SQL'i tekrar çalıştırma.
`secrets.php` dosyasını eski sunucudan aynen kopyala (`scp eski:/var/www/cdn/secrets.php /var/www/cdn/`) ve `chown www-data`, `chmod 640` yap.

## 2) Veriyi kopyala (eski sunucu çalışırken, ilk geçiş)
Yeni sunucuda:
    rsync -aH --info=progress2 -e ssh root@ESKI_IP:/srv/cdn/data/ /srv/cdn/data/
    chown -R www-data:www-data /srv/cdn/data
Aynı komutu geçiş anında bir kez daha çalıştır (yalnızca farkı kopyalar). `audio/` klasörü önbellektir; istersen `--exclude audio/` ile atla, gerekince yeniden üretilir.

## 3) Doğrula
    find /srv/cdn/data/files -type f | wc -l       # eski sunucuyla aynı olmalı
    curl -I --resolve cdn.alanadi.com:80:YENI_IP http://cdn.alanadi.com/f/<bir_kod>.mp4   # 200 ve Accept-Ranges: bytes

## 4) Geçiş
1. Eski sunucuda panel yüklemesini durdur (veya kısa süre bekle), son `rsync`i çalıştır.
2. DNS / Cloudflare'de `cdn` kaydını YENİ_IP'ye çevir (TTL düşükse dakikalar içinde geçer).
3. Eski sunucuyu birkaç gün açık tut, sonra kapat.
Not: Aynı alan adı kullanıldığı sürece sitedeki video adresleri değişmez. Alan adı değişirse sitedeki `video_url` değerlerini güncellemek gerekir.

## 5) Sonrası
- `php tools/cleanup.php` elle bir kez çalıştırıp hata olmadığını gör, cron'un kurulu olduğundan emin ol.
- Disk yedeği: `/srv/cdn/data/files` içindeki dosyalar tek kopyadır; düzenli yedek (rsync/snapshot) al.
