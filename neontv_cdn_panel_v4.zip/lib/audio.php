<?php
declare(strict_types=1);

/**
 * /f/<kod>.mp4?audio=mp3  → videonun yalnızca sesi (konuşma analizi/altyazı için küçük, mono, 16 kHz).
 * İlk istekte ffmpeg ile üretilir, sonra önbellekten (Nginx X-Accel-Redirect) sunulur.
 */
const CDN_AUDIO_FORMATS = [
    // tür => [uzantı, mime, ffmpeg çıkış parametreleri]
    'mp3'  => ['mp3', 'audio/mpeg', '-c:a libmp3lame -b:a 48k -f mp3'],
    'aac'  => ['m4a', 'audio/mp4', '-c:a aac -b:a 48k -movflags +faststart -f ipod'],
    'opus' => ['opus', 'audio/ogg', '-c:a libopus -b:a 24k -application voip -f ogg'],
    'wav'  => ['wav', 'audio/wav', '-c:a pcm_s16le -f wav'],
];
const CDN_AUDIO_ALIAS = ['m4a' => 'aac', 'ogg' => 'opus'];

function cdnAudioDir(): string {
    $d = DATA_DIR . '/audio';
    if (!is_dir($d)) @mkdir($d, 0750, true);
    return $d;
}

function audioFail(int $code, string $msg, array $hdr = []): void {
    http_response_code($code);
    foreach ($hdr as $h) header($h);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    echo $msg;
    exit;
}

/** Üretilmiş ses dosyalarının adı: <video kodu>.<tür>.<uzantı>  */
function cdnAudioServe(string $stored, string $type): void {
    $type = strtolower($type);
    $type = CDN_AUDIO_ALIAS[$type] ?? $type;
    if (!isset(CDN_AUDIO_FORMATS[$type])) audioFail(400, 'Desteklenen türler: mp3, aac, opus, wav');
    if (!preg_match('/^([a-f0-9]{32})\.([a-z0-9]{1,5})$/', $stored, $m)) audioFail(404, 'Bulunamadı');
    [$base, $srcExt] = [$m[1], $m[2]];
    if (!in_array(cdnTypeOfExt($srcExt), ['video', 'audio'], true)) audioFail(400, 'Bu dosyadan ses çıkarılamaz');
    $src = FILES_DIR . '/' . $stored;
    if (!is_file($src)) audioFail(404, 'Bulunamadı');

    [$ext, $mime, $args] = CDN_AUDIO_FORMATS[$type];
    $name = $base . '.' . $type . '.' . $ext;
    $out = cdnAudioDir() . '/' . $name;

    if (!(is_file($out) && filesize($out) > 0 && filemtime($out) >= filemtime($src))) {
        $ffmpeg = cdnBin('ffmpeg');
        if (!$ffmpeg) audioFail(500, 'ffmpeg kurulu değil');
        ignore_user_abort(true);
        @set_time_limit(900);

        // aynı dosya için tek üretim: diğer istekler bekler ve hazır sonucu kullanır
        $lock = fopen(TMP_DIR . '/audio_' . $base . '.' . $type . '.lock', 'c');
        if (!$lock || !flock($lock, LOCK_EX)) audioFail(503, 'Meşgul, tekrar deneyin', ['Retry-After: 5']);
        clearstatcache(true, $out);
        if (!(is_file($out) && filesize($out) > 0 && filemtime($out) >= filemtime($src))) {
            // en fazla 2 eşzamanlı ffmpeg (2 çekirdekli sunucuyu boğmamak için)
            $slot = null;
            for ($i = 1; $i <= 2 && !$slot; $i++) {
                $f = fopen(TMP_DIR . '/audio_slot_' . $i . '.lock', 'c');
                if ($f && flock($f, LOCK_EX | LOCK_NB)) $slot = $f;
            }
            if (!$slot) { flock($lock, LOCK_UN); audioFail(503, 'Sunucu meşgul, tekrar deneyin', ['Retry-After: 10']); }

            $tmp = $out . '.' . bin2hex(random_bytes(4)) . '.part';
            $prefix = (cdnBin('nice') ? 'nice -n 10 ' : '') . (cdnBin('ionice') ? 'ionice -c3 ' : '') . (cdnBin('timeout') ? 'timeout 900 ' : '');
            $cmd = $prefix . escapeshellarg($ffmpeg) . ' -nostdin -hide_banner -loglevel error -i ' . escapeshellarg($src)
                 . ' -vn -map 0:a:0 -ac 1 -ar 16000 ' . $args . ' -y ' . escapeshellarg($tmp) . ' 2>&1';
            @exec($cmd, $o, $rc);
            flock($slot, LOCK_UN); fclose($slot);
            if ($rc !== 0 || !is_file($tmp) || filesize($tmp) === 0) {
                @unlink($tmp);
                error_log('[cdn-audio] ffmpeg rc=' . $rc . ' ' . substr(implode(' ', $o), 0, 300));
                flock($lock, LOCK_UN);
                audioFail(422, 'Bu dosyada ses yok veya dönüştürülemedi');
            }
            rename($tmp, $out);
        }
        flock($lock, LOCK_UN); fclose($lock);
    }
    @touch($out); // son kullanım zamanı (cleanup eski önbelleği buna göre siler)

    header('Content-Type: ' . $mime);
    header('Cache-Control: public, max-age=86400');
    header('X-Content-Type-Options: nosniff');
    if (stripos((string)($_SERVER['SERVER_SOFTWARE'] ?? ''), 'nginx') !== false) {
        header('X-Accel-Redirect: /_audio/' . $name); // Range/önbellek Nginx'e devredilir, PHP işçisi serbest kalır
        exit;
    }
    header('Content-Length: ' . filesize($out));
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'HEAD') readfile($out);
    exit;
}
