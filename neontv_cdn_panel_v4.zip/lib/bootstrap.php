<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// Gizli ayarlar: secrets.php (git'e eklenmez) veya gerçek ortam değişkenleri
$__secrets = __DIR__ . '/../secrets.php';
if (is_file($__secrets)) require_once $__secrets;

function cfg(string $key, $default = null) {
    $v = getenv($key);
    return ($v === false || $v === '') ? $default : $v;
}

define('DATA_DIR', rtrim((string)cfg('CDN_DATA_DIR', '/srv/cdn/data'), '/'));
define('FILES_DIR', DATA_DIR . '/files');
define('THUMBS_DIR', DATA_DIR . '/thumbs');
define('TMP_DIR', DATA_DIR . '/tmp');
define('PUBLIC_URL', rtrim((string)cfg('CDN_PUBLIC_URL', ''), '/'));
define('TTL_DAYS', (int)cfg('CDN_TTL_DAYS', 60));
define('CHUNK_SIZE', 8 * 1024 * 1024);
define('MAX_UPLOAD', (int)cfg('CDN_MAX_UPLOAD_MB', 4096) * 1048576);
define('MIN_FREE', (int)cfg('CDN_MIN_FREE_MB', 2048) * 1048576);
define('SESSION_IDLE', 43200); // 12 saat

foreach ([FILES_DIR, THUMBS_DIR, TMP_DIR] as $__d) {
    if (!is_dir($__d)) @mkdir($__d, 0750, true);
}

function isHttps(): bool {
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') return true;
    if (strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https') return true;
    if (stripos((string)($_SERVER['HTTP_CF_VISITOR'] ?? ''), '"scheme":"https"') !== false) return true;
    return (string)($_SERVER['SERVER_PORT'] ?? '') === '443';
}

function clientIp(): string {
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    $cf = (string)($_SERVER['HTTP_CF_CONNECTING_IP'] ?? '');
    // CF başlığına yalnızca istek özel/yerel bir vekilden (Nginx/Cloudflare tüneli) geldiyse güven
    $public = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
    if (!$public && $cf !== '' && filter_var($cf, FILTER_VALIDATE_IP)) return $cf;
    return $ip;
}

function securityHeaders(): void {
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('X-Robots-Tag: noindex, nofollow');
    header('Cache-Control: no-store');
}

function startSession(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    ini_set('session.use_strict_mode', '1');
    ini_set('session.gc_maxlifetime', (string)SESSION_IDLE);
    session_name('cdnsid');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => isHttps(), 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
    if (!empty($_SESSION['ok']) && time() - (int)($_SESSION['last'] ?? 0) > SESSION_IDLE) {
        $_SESSION = [];
        session_regenerate_id(true);
    }
    if (!empty($_SESSION['ok'])) $_SESSION['last'] = time();
}

function csrfToken(): string {
    startSession();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return (string)$_SESSION['csrf'];
}

function csrfValid(?string $given): bool {
    return $given !== null && $given !== '' && hash_equals(csrfToken(), $given);
}

function jsonOut(array $data, int $code = 200, bool $exit = true): void {
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode($data + ['ok' => $code < 400], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($exit) exit;
}

function jsonFail(int $code, string $msg, array $extra = []): void {
    jsonOut(['error' => $msg] + $extra, $code);
}

function requireAuth(bool $api): void {
    startSession();
    securityHeaders();
    if (empty($_SESSION['ok'])) {
        if ($api) jsonFail(401, 'Oturum süresi doldu.');
        header('Location: login.php');
        exit;
    }
}

function e($s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function fmtBytes(int $b): string {
    $u = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    $v = (float)$b;
    while ($v >= 1024 && $i < 4) { $v /= 1024; $i++; }
    return ($i === 0 ? (string)(int)$v : number_format($v, $v >= 100 ? 0 : 1, ',', '.')) . ' ' . $u[$i];
}

function pageHead(string $title, string $bodyAttrs = ''): void {
    securityHeaders();
    $v = (string)@filemtime(__DIR__ . '/../assets/style.css');
    echo '<!doctype html><html lang="tr"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
       . '<meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#0b0b12">'
       . '<title>' . e($title) . '</title><link rel="stylesheet" href="assets/style.css?v=' . e($v) . '"></head>'
       . '<body ' . $bodyAttrs . '>';
}
