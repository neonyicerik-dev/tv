<?php
declare(strict_types=1);
// Bağlantıdan (URL) sunucuya indirip CDN'e yükleme. SSRF korumalı: yalnızca http/https, yalnızca genel IP'ler.

function cdnStPath(string $id): string { return TMP_DIR . '/' . $id . '.st'; }
function cdnStSet(string $id, array $st): void {
    @file_put_contents(cdnStPath($id), json_encode($st), LOCK_EX);
}
function cdnStGet(string $id): array {
    if (!preg_match('/^[a-f0-9]{32}$/', $id)) throw new CdnError('Geçersiz yükleme.', 400);
    $s = is_file(cdnStPath($id)) ? json_decode((string)file_get_contents(cdnStPath($id)), true) : null;
    if (!is_array($s)) throw new CdnError('İndirme bulunamadı veya süresi doldu.', 404);
    return $s;
}

function cdnIsPublicIp(string $ip): bool {
    return (bool)filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
}

/** URL'yi doğrular; [host, port, ip] döner (DNS sabitleme için). */
function cdnCheckUrl(string $url): array {
    $p = parse_url($url);
    if (!$p || empty($p['host']) || !in_array(strtolower($p['scheme'] ?? ''), ['http', 'https'], true)) throw new CdnError('Yalnızca http/https bağlantıları desteklenir.', 400);
    if (isset($p['user']) || isset($p['pass'])) throw new CdnError('Kullanıcı bilgili bağlantılar desteklenmez.', 400);
    $host = trim($p['host'], '[]');
    $port = (int)($p['port'] ?? (strtolower($p['scheme']) === 'https' ? 443 : 80));
    if (!in_array($port, [80, 443, 8080, 8443], true)) throw new CdnError('Bu bağlantı noktası desteklenmiyor.', 400);
    $ips = [];
    if (filter_var($host, FILTER_VALIDATE_IP)) $ips = [$host];
    else {
        $ips = gethostbynamel($host) ?: [];
        foreach (@dns_get_record($host, DNS_AAAA) ?: [] as $r) if (!empty($r['ipv6'])) $ips[] = $r['ipv6'];
    }
    if (!$ips) throw new CdnError('Alan adı çözümlenemedi.', 400);
    foreach ($ips as $ip) if (!cdnIsPublicIp($ip)) throw new CdnError('Bu adrese erişim izni yok.', 400);
    return [$host, $port, $ips[0]];
}

function cdnFetchStart(string $root, ?string $parent, string $url): array {
    $p = cdnParent($root, $parent);
    $url = trim($url);
    if (strlen($url) > 2000) throw new CdnError('Bağlantı çok uzun.', 400);
    cdnCheckUrl($url);
    $free = @disk_free_space(DATA_DIR);
    if ($free !== false && $free < MIN_FREE) throw new CdnError('Diskte yeterli boş alan yok.', 507);
    if (!is_writable(TMP_DIR) || !is_writable(FILES_DIR)) throw new CdnError('Depolama klasörü yazılamıyor.', 500);
    $id = bin2hex(random_bytes(16));
    $meta = ['root' => $root, 'parent' => $p['id'] ?? null, 'ext' => '', 'size' => 0, 'orig' => '', 'created' => time(), 'url' => $url];
    if (file_put_contents(TMP_DIR . '/' . $id . '.json', json_encode($meta)) === false || file_put_contents(TMP_DIR . '/' . $id . '.part', '') === false) throw new CdnError('Geçici dosya oluşturulamadı.', 500);
    cdnStSet($id, ['state' => 'run', 'got' => 0, 'total' => 0]);
    return ['upload_id' => $id];
}

/** İndirmeyi yapar (CLI işçisi veya istek sonrası). Durum .st dosyasına yazılır. */
function cdnFetchRun(string $id): void {
    @set_time_limit(0);
    $metaF = TMP_DIR . '/' . $id . '.json';
    $part = TMP_DIR . '/' . $id . '.part';
    $m = is_file($metaF) ? json_decode((string)file_get_contents($metaF), true) : null;
    if (!is_array($m) || empty($m['url'])) return;
    $fail = function (string $msg) use ($id, $part, $metaF) {
        @unlink($part); @unlink($metaF);
        cdnStSet($id, ['state' => 'error', 'msg' => $msg]);
    };
    $url = (string)$m['url'];
    $fh = fopen($part, 'wb');
    if (!$fh) { $fail('Geçici dosya yazılamadı.'); return; }
    $got = 0; $total = 0; $lastW = 0; $ext = ''; $disp = ''; $ctype = ''; $problem = '';
    try {
        for ($hop = 0; $hop <= 5; $hop++) {
            [$host, $port, $ip] = cdnCheckUrl($url);
            $loc = ''; $status = 0; $decided = false; $disp = ''; $ctype = ''; $total = 0;
            ftruncate($fh, 0); rewind($fh); $got = 0;
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RESOLVE => [$host . ':' . $port . ':' . $ip],
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
                CURLOPT_CONNECTTIMEOUT => 15,
                CURLOPT_LOW_SPEED_LIMIT => 1024, CURLOPT_LOW_SPEED_TIME => 60,
                CURLOPT_USERAGENT => 'Mozilla/5.0 NeonTV-CDN',
                CURLOPT_ENCODING => '',
                CURLOPT_HEADERFUNCTION => function ($c, $line) use (&$status, &$loc, &$disp, &$ctype, &$total) {
                    if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $mm)) { $status = (int)$mm[1]; $loc = ''; $disp = ''; $ctype = ''; $total = 0; }
                    elseif (stripos($line, 'location:') === 0) $loc = trim(substr($line, 9));
                    elseif (stripos($line, 'content-disposition:') === 0) $disp = trim(substr($line, 20));
                    elseif (stripos($line, 'content-type:') === 0) $ctype = strtolower(trim(explode(';', substr($line, 13))[0]));
                    elseif (stripos($line, 'content-length:') === 0) $total = (int)trim(substr($line, 15));
                    return strlen($line);
                },
                CURLOPT_WRITEFUNCTION => function ($c, $data) use (&$status, &$decided, &$ext, &$disp, &$ctype, &$total, &$got, &$lastW, &$problem, $fh, $id, $url) {
                    if ($status >= 300 && $status < 400) return strlen($data); // yönlendirme gövdesini yok say
                    if ($status !== 200) { $problem = 'Sunucu HTTP ' . $status . ' döndürdü.'; return 0; }
                    if (!$decided) {
                        $decided = true;
                        $name = '';
                        if (preg_match('/filename\*\s*=\s*[^\']*\'[^\']*\'([^;]+)/i', $disp, $mm)) $name = rawurldecode(trim($mm[1], " \"'"));
                        elseif (preg_match('/filename\s*=\s*"?([^";]+)"?/i', $disp, $mm)) $name = trim($mm[1]);
                        if ($name === '') $name = rawurldecode(basename((string)parse_url($url, PHP_URL_PATH)));
                        $ext = strtolower((string)pathinfo($name, PATHINFO_EXTENSION));
                        if (!cdnExtInfo($ext)) {
                            $ext = '';
                            foreach (CDN_TYPES as $map) foreach ($map as $e => $mime) if ($mime === $ctype && $ext === '') $ext = $e;
                        }
                        if ($ext === '' || !cdnExtInfo($ext)) { $problem = 'Bu dosya türü desteklenmiyor.'; return 0; }
                        if ($total > MAX_UPLOAD) { $problem = 'Dosya çok büyük (en fazla ' . intdiv(MAX_UPLOAD, 1048576) . ' MB).'; return 0; }
                        if ($total > 0) { $fr = @disk_free_space(DATA_DIR); if ($fr !== false && $fr - $total < MIN_FREE) { $problem = 'Diskte yeterli boş alan yok.'; return 0; } }
                        $GLOBALS['cdn_fetch_name'] = $name;
                    }
                    $n = fwrite($fh, $data);
                    if ($n === false || $n < strlen($data)) { $problem = 'Disk yazma hatası.'; return 0; }
                    $got += $n;
                    if ($got > MAX_UPLOAD) { $problem = 'Dosya çok büyük.'; return 0; }
                    if (microtime(true) - $lastW > 1) { $lastW = microtime(true); cdnStSet($id, ['state' => 'run', 'got' => $got, 'total' => $total]); }
                    return $n;
                },
            ]);
            $ok = curl_exec($ch);
            $err = curl_error($ch);
            curl_close($ch);
            if ($status >= 300 && $status < 400 && $loc !== '') {
                $next = $loc;
                if (!preg_match('#^https?://#i', $next)) {
                    $b = parse_url($url);
                    $base = $b['scheme'] . '://' . $b['host'] . (isset($b['port']) ? ':' . $b['port'] : '');
                    $next = $next[0] === '/' ? $base . $next : $base . rtrim(dirname($b['path'] ?? '/'), '/') . '/' . $next;
                }
                $url = $next;
                continue;
            }
            if ($problem !== '') { $fail($problem); return; }
            if ($ok === false) { $fail('İndirme başarısız: ' . ($err !== '' ? $err : 'bağlantı hatası')); return; }
            if ($status !== 200) { $fail('Sunucu HTTP ' . $status . ' döndürdü.'); return; }
            break;
        }
        fclose($fh);
        if ($got <= 0) { $fail('Dosya boş.'); return; }
        $name = (string)($GLOBALS['cdn_fetch_name'] ?? 'dosya.' . $ext);
        $m['ext'] = $ext; $m['size'] = $got; $m['orig'] = $name;
        file_put_contents($metaF, json_encode($m));
        $base = trim((string)pathinfo($name, PATHINFO_FILENAME));
        try { $suggest = cdnCleanName($base); } catch (CdnError $e) { $suggest = 'dosya'; }
        cdnStSet($id, ['state' => 'done', 'got' => $got, 'total' => $got, 'suggest' => $suggest, 'ext' => $ext]);
    } catch (CdnError $e) {
        $fail($e->getMessage());
    } catch (Throwable $e) {
        error_log('[cdn] fetch: ' . get_class($e) . ': ' . $e->getMessage());
        $fail('İndirme sırasında hata oluştu.');
    }
}

/** İşçiyi arka planda başlatır; olmazsa false döner (çağıran isteğin sonunda kendisi çalıştırır). */
function cdnFetchSpawn(string $id): bool {
    $php = cdnBin('php');
    if (!$php || !function_exists('exec')) return false;
    $cmd = 'nohup ' . escapeshellarg($php) . ' ' . escapeshellarg(dirname(__DIR__) . '/tools/fetch.php') . ' ' . escapeshellarg($id) . ' >/dev/null 2>&1 &';
    @exec($cmd);
    return true;
}
