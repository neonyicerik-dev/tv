<?php
declare(strict_types=1);

function cdnBin(string $name): ?string {
    static $cache = [];
    if (array_key_exists($name, $cache)) return $cache[$name];
    $p = function_exists('shell_exec') ? trim((string)@shell_exec('command -v ' . escapeshellarg($name) . ' 2>/dev/null')) : '';
    return $cache[$name] = ($p !== '' ? $p : null);
}

/**
 * Videonun ortasından tek kare (veya resmin küçük hali) üretir.
 * Sunucuyu yormamak için: hızlı arama (-ss girişten önce), tek iş parçacığı, nice/ionice, zaman aşımı.
 */
function cdnMakeThumb(array $row): void {
    $type = cdnTypeOfExt($row['ext'] ?? null);
    if (!in_array($type, ['video', 'image'], true)) return;
    $ffmpeg = cdnBin('ffmpeg');
    if (!$ffmpeg) return;
    $src = FILES_DIR . '/' . $row['stored_name'];
    $dst = THUMBS_DIR . '/' . $row['id'] . '.jpg';
    if (!is_file($src)) return;

    $prefix = (cdnBin('nice') ? 'nice -n 19 ' : '') . (cdnBin('ionice') ? 'ionice -c3 ' : '') . (cdnBin('timeout') ? 'timeout 40 ' : '');
    $dur = null;
    $seeks = [''];
    if ($type === 'video') {
        $probe = cdnBin('ffprobe');
        if ($probe) {
            $o = trim((string)@shell_exec($prefix . escapeshellarg($probe) . ' -v error -show_entries format=duration -of csv=p=0 ' . escapeshellarg($src) . ' 2>/dev/null'));
            if (is_numeric($o) && (float)$o > 0) $dur = (float)$o;
        }
        $seeks = $dur ? [sprintf(' -ss %.2f', $dur / 2), ' -ss 0'] : [' -ss 1', ' -ss 0'];
    }
    $ok = false;
    foreach ($seeks as $seek) {
        $cmd = $prefix . escapeshellarg($ffmpeg) . ' -nostdin -hide_banner -loglevel error -threads 1' . $seek
             . ' -i ' . escapeshellarg($src) . ' -frames:v 1 -vf scale=480:-2 -q:v 6 -y ' . escapeshellarg($dst) . ' 2>&1';
        @exec($cmd, $out, $rc);
        $ok = is_file($dst) && filesize($dst) > 0;
        if ($ok) break;
        @unlink($dst);
    }
    $upd = [];
    if ($ok) $upd['has_thumb'] = true;
    if ($dur) $upd['duration'] = round($dur, 2);
    if ($upd) {
        try { db()->update('cdn_items', ['id' => 'eq.' . $row['id']], $upd); } catch (Throwable $e) { error_log('[cdn] thumb update: ' . get_class($e)); }
    }
}
