<?php
declare(strict_types=1);

class DbError extends RuntimeException {
    public string $pg = '';
    public int $http = 0;
}

/** Supabase (PostgREST) istemcisi – yalnızca sunucu tarafı service anahtarı ile */
class Rest {
    private $ch = null;
    private string $url;

    public function __construct(string $url, private string $key) {
        $this->url = rtrim($url, '/');
    }

    private function call(string $method, string $path, array $query = [], $body = null, array $prefer = []) {
        if ($this->url === '' || $this->key === '') throw new DbError('Veritabanı yapılandırılmamış.');
        if ($this->ch === null) $this->ch = curl_init();
        curl_reset($this->ch);
        $u = $this->url . '/rest/v1/' . $path . ($query ? '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986) : '');
        $hdr = ['apikey: ' . $this->key, 'Authorization: Bearer ' . $this->key, 'Accept: application/json'];
        $opt = [
            CURLOPT_URL => $u, CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_ENCODING => '',
        ];
        if ($body !== null) {
            $hdr[] = 'Content-Type: application/json';
            $opt[CURLOPT_POSTFIELDS] = json_encode($body, JSON_UNESCAPED_UNICODE);
        }
        if ($prefer) $hdr[] = 'Prefer: ' . implode(',', $prefer);
        $opt[CURLOPT_HTTPHEADER] = $hdr;
        curl_setopt_array($this->ch, $opt);
        $raw = curl_exec($this->ch);
        $http = (int)curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
        if ($raw === false) {
            error_log('[cdn-db] curl#' . curl_errno($this->ch) . ' ' . curl_error($this->ch));
            $e = new DbError('Veritabanına ulaşılamadı.');
            throw $e;
        }
        $j = $raw === '' ? [] : json_decode((string)$raw, true);
        if ($http >= 400) {
            $e = new DbError('Veritabanı hatası.');
            $e->http = $http;
            $e->pg = is_array($j) ? (string)($j['code'] ?? '') : '';
            error_log('[cdn-db] HTTP ' . $http . ' ' . $method . ' ' . $path . ' ' . (is_array($j) ? (string)($j['message'] ?? '') : ''));
            throw $e;
        }
        return is_array($j) ? $j : [];
    }

    public function select(string $table, array $params = []): array {
        return $this->call('GET', $table, $params);
    }

    public function insert(string $table, array $row): array {
        $r = $this->call('POST', $table, [], $row, ['return=representation']);
        return $r[0] ?? [];
    }

    public function update(string $table, array $filters, array $data): array {
        return $this->call('PATCH', $table, $filters, $data, ['return=representation']);
    }

    public function delete(string $table, array $filters): array {
        return $this->call('DELETE', $table, $filters, null, ['return=representation']);
    }

    public function rpc(string $fn, array $args = []): array {
        return $this->call('POST', 'rpc/' . $fn, [], (object)$args);
    }
}
