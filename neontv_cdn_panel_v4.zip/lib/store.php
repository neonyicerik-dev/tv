<?php
declare(strict_types=1);

class CdnError extends RuntimeException {
    public array $extra = [];
}

const CDN_ROOTS = ['kalici' => 'Kalıcı', 'gecici' => 'Geçici'];
const CDN_TYPES = [
    'video' => ['mp4' => 'video/mp4', 'webm' => 'video/webm', 'mkv' => 'video/x-matroska', 'mov' => 'video/quicktime', 'm4v' => 'video/x-m4v', 'avi' => 'video/x-msvideo', 'ts' => 'video/mp2t'],
    'audio' => ['mp3' => 'audio/mpeg', 'm4a' => 'audio/mp4', 'aac' => 'audio/aac', 'opus' => 'audio/ogg', 'ogg' => 'audio/ogg', 'wav' => 'audio/wav', 'flac' => 'audio/flac'],
    'image' => ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif'],
    'other' => ['vtt' => 'text/vtt', 'srt' => 'text/plain', 'txt' => 'text/plain'],
];

function db() {
    return $GLOBALS['cdn_db'] ??= new Rest((string)cfg('SUPABASE_URL', ''), (string)cfg('SUPABASE_SERVICE_KEY', ''));
}

function cdnUuid(string $s): bool {
    return (bool)preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $s);
}

function cdnExtInfo(string $ext): ?array {
    foreach (CDN_TYPES as $type => $map) if (isset($map[$ext])) return [$type, $map[$ext]];
    return null;
}

function cdnTypeOfExt(?string $ext): string {
    return $ext ? (cdnExtInfo($ext)[0] ?? 'other') : 'other';
}

/** Veritabanı benzersizlik hatasını anlaşılır mesaja çevirir */
function cdnGuard(callable $fn) {
    try {
        return $fn();
    } catch (DbError $e) {
        if ($e->pg === '23505') throw new CdnError('Bu isimde bir öğe zaten var.', 409);
        throw $e;
    }
}

function cdnCleanName(string $n): string {
    $n = preg_replace('/[\x00-\x1F\x7F\/\\\\]+/u', ' ', $n) ?? '';
    $n = trim(preg_replace('/\s+/u', ' ', $n) ?? '');
    $n = trim($n, " .");
    if (mb_strlen($n) > 120) $n = trim(mb_substr($n, 0, 120), " .");
    if ($n === '') throw new CdnError('İsim boş olamaz.', 400);
    return $n;
}

function cdnStripExt(string $name, ?string $ext): string {
    $name = trim($name);
    if ($ext && preg_match('/^(.+)\.' . preg_quote($ext, '/') . '$/iu', $name, $m)) return $m[1];
    return $name;
}

function cdnExpiry(): string {
    return date('c', time() + TTL_DAYS * 86400);
}

function cdnGet(string $id): ?array {
    if (!cdnUuid($id)) return null;
    $r = db()->select('cdn_items', ['id' => 'eq.' . $id, 'limit' => 1]);
    return $r[0] ?? null;
}

function cdnMustGet(string $id): array {
    $r = cdnGet($id);
    if (!$r) throw new CdnError('Öğe bulunamadı.', 404);
    return $r;
}

/** Kök (kalici/gecici) + isteğe bağlı üst klasörü doğrular; üst klasör satırını (veya null) döndürür */
function cdnParent(string $root, ?string $parent): ?array {
    if (!isset(CDN_ROOTS[$root])) throw new CdnError('Geçersiz klasör.', 400);
    if ($parent === null || $parent === '') return null;
    $p = cdnGet($parent);
    if (!$p || $p['kind'] !== 'folder' || $p['root'] !== $root) throw new CdnError('Hedef klasör bulunamadı.', 404);
    return $p;
}

function cdnItemOut(array $r): array {
    $ext = $r['ext'] ?? null;
    $o = [
        'id' => $r['id'], 'kind' => $r['kind'], 'name' => $r['name'], 'ext' => $ext,
        'full' => $r['name'] . ($ext ? '.' . $ext : ''),
        'size' => (int)($r['size'] ?? 0), 'created_at' => $r['created_at'] ?? null,
        'expires_at' => $r['expires_at'] ?? null, 'days_left' => null,
    ];
    if (!empty($r['expires_at'])) {
        $o['days_left'] = max(0, (int)ceil((strtotime((string)$r['expires_at']) - time()) / 86400));
    }
    if ($r['kind'] === 'file') {
        $type = cdnTypeOfExt($ext);
        $o['type'] = $type;
        $o['url'] = '/f/' . $r['stored_name'];
        $o['thumb'] = in_array($type, ['video', 'image'], true) ? '/t/' . $r['id'] . '.jpg' : null;
        $o['has_thumb'] = !empty($r['has_thumb']);
        $o['duration'] = isset($r['duration']) ? (float)$r['duration'] : null;
    }
    return $o;
}

function cdnList(string $root, ?string $parent, int $offset, int $limit): array {
    $q = [
        'root' => 'eq.' . $root,
        'parent_id' => $parent === null ? 'is.null' : 'eq.' . $parent,
        'order' => 'kind.desc,name.asc,id.asc',
        'limit' => $limit, 'offset' => $offset,
    ];
    return array_map('cdnItemOut', db()->select('cdn_items', $q));
}

/** Bir kökteki tüm klasörler (taşıma penceresi için), düz liste */
function cdnFolders(string $root): array {
    if (!isset(CDN_ROOTS[$root])) throw new CdnError('Geçersiz klasör.', 400);
    $all = [];
    for ($off = 0; $off < 5000; $off += 1000) {
        $rows = db()->select('cdn_items', [
            'select' => 'id,parent_id,name', 'root' => 'eq.' . $root, 'kind' => 'eq.folder',
            'order' => 'name.asc,id.asc', 'limit' => 1000, 'offset' => $off,
        ]);
        foreach ($rows as $r) $all[] = ['id' => $r['id'], 'parent_id' => $r['parent_id'] ?? null, 'name' => $r['name']];
        if (count($rows) < 1000) break;
    }
    return $all;
}

function cdnMkdir(string $root, ?string $parent, string $name): array {
    $p = cdnParent($root, $parent);
    $name = cdnCleanName($name);
    $row = cdnGuard(fn() => db()->insert('cdn_items', [
        'parent_id' => $p['id'] ?? null, 'root' => $root, 'kind' => 'folder', 'name' => $name, 'size' => 0,
    ]));
    return cdnItemOut($row);
}

function cdnRename(string $id, string $name): array {
    $it = cdnMustGet($id);
    $name = cdnCleanName(cdnStripExt($name, $it['ext'] ?? null));
    cdnGuard(fn() => db()->update('cdn_items', ['id' => 'eq.' . $id], ['name' => $name]));
    return cdnItemOut(cdnMustGet($id));
}

function cdnUpdateIn(array $ids, array $data): void {
    foreach (array_chunk(array_values($ids), 80) as $c) {
        db()->update('cdn_items', ['id' => 'in.(' . implode(',', $c) . ')'], $data);
    }
}

function cdnMove(string $id, string $root, ?string $parent): array {
    $it = cdnMustGet($id);
    $target = cdnParent($root, $parent);
    $sub = $it['kind'] === 'folder' ? db()->rpc('cdn_descendants', ['p' => $id]) : [$it];
    if ($target) {
        foreach ($sub as $s) if ($s['id'] === $target['id']) throw new CdnError('Klasör kendi içine taşınamaz.', 400);
    }
    $newParent = $target['id'] ?? null;
    if (($it['parent_id'] ?? null) === $newParent && $it['root'] === $root) return cdnItemOut($it);

    cdnGuard(fn() => db()->update('cdn_items', ['id' => 'eq.' . $id], ['parent_id' => $newParent, 'root' => $root]));

    if ($it['root'] !== $root) {
        // alt öğelerin kökü ve geçici/kalıcı süre durumu güncellenir
        $others = array_values(array_diff(array_column($sub, 'id'), [$id]));
        if ($others) cdnUpdateIn($others, ['root' => $root]);
        $fileIds = [];
        foreach ($sub as $s) if ($s['kind'] === 'file') $fileIds[] = $s['id'];
        if ($fileIds) cdnUpdateIn($fileIds, ['expires_at' => $root === 'gecici' ? cdnExpiry() : null]);
    }
    return cdnItemOut(cdnMustGet($id));
}

function cdnUnlinkFiles(array $rows): int {
    $n = 0;
    foreach ($rows as $r) {
        if (($r['kind'] ?? '') !== 'file') continue;
        $sn = (string)($r['stored_name'] ?? '');
        if (preg_match('/^[a-f0-9]{32}\.[a-z0-9]{1,5}$/', $sn)) {
            if (@unlink(FILES_DIR . '/' . $sn)) $n++;
        }
        if (preg_match('/^[0-9a-f-]{36}$/i', (string)$r['id'])) @unlink(THUMBS_DIR . '/' . $r['id'] . '.jpg');
        if (preg_match('/^([a-f0-9]{32})\./', $sn, $bm)) {
            foreach (glob(DATA_DIR . '/audio/' . $bm[1] . '.*') ?: [] as $af) @unlink($af);
        }
    }
    return $n;
}

/** Dosya ya da klasörü (içindekilerle birlikte) siler */
function cdnDelete(string $id): array {
    $it = cdnMustGet($id);
    $sub = $it['kind'] === 'folder' ? db()->rpc('cdn_descendants', ['p' => $id]) : [$it];
    cdnUnlinkFiles($sub);
    db()->delete('cdn_items', ['id' => 'eq.' . $id]); // alt satırlar FK cascade ile silinir
    $files = 0;
    foreach ($sub as $s) if ($s['kind'] === 'file') $files++;
    return ['deleted' => count($sub), 'files' => $files];
}

/** Süresi dolan geçici dosyaları siler (cron) */
function cdnPurgeExpired(int $batch = 200): array {
    $files = 0;
    for ($i = 0; $i < 500; $i++) {
        $rows = db()->select('cdn_items', ['kind' => 'eq.file', 'expires_at' => 'lt.' . date('c'), 'limit' => $batch]);
        if (!$rows) break;
        cdnUnlinkFiles($rows);
        foreach (array_chunk(array_column($rows, 'id'), 80) as $c) {
            db()->delete('cdn_items', ['id' => 'in.(' . implode(',', $c) . ')']);
        }
        $files += count($rows);
        if (count($rows) < $batch) break;
    }
    return ['files' => $files];
}

function cdnCleanStaleUploads(): int {
    $n = 0;
    // 14 gündür istenmeyen ses önbelleği (gerekirse yeniden üretilir)
    foreach (glob(DATA_DIR . '/audio/*') ?: [] as $f) {
        if (is_file($f) && filemtime($f) < time() - 14 * 86400 && @unlink($f)) $n++;
    }
    foreach (glob(TMP_DIR . '/*') ?: [] as $f) {
        if (is_file($f) && filemtime($f) < time() - 86400 && @unlink($f)) $n++;
    }
    return $n;
}

function cdnStats(): array {
    $out = ['kalici' => ['files' => 0, 'bytes' => 0, 'folders' => 0], 'gecici' => ['files' => 0, 'bytes' => 0, 'folders' => 0]];
    foreach (db()->rpc('cdn_stats') as $r) {
        if (isset($out[$r['root']])) $out[$r['root']] = ['files' => (int)$r['files'], 'bytes' => (int)$r['bytes'], 'folders' => (int)$r['folders']];
    }
    return $out;
}

// ---------------------------------------------------------------- Yükleme (parçalı)

function cdnUploadMeta(string $id): array {
    if (!preg_match('/^[a-f0-9]{32}$/', $id)) throw new CdnError('Geçersiz yükleme.', 400);
    $f = TMP_DIR . '/' . $id . '.json';
    $m = is_file($f) ? json_decode((string)file_get_contents($f), true) : null;
    if (!is_array($m)) throw new CdnError('Yükleme bulunamadı veya süresi doldu.', 404);
    return $m;
}

function cdnUploadInit(string $root, ?string $parent, string $filename, int $size): array {
    $p = cdnParent($root, $parent);
    $ext = strtolower((string)pathinfo($filename, PATHINFO_EXTENSION));
    $info = cdnExtInfo($ext);
    if (!$info) throw new CdnError('Bu dosya türü desteklenmiyor (.' . $ext . ').', 400);
    if ($size <= 0) throw new CdnError('Dosya boş.', 400);
    if ($size > MAX_UPLOAD) throw new CdnError('Dosya çok büyük (en fazla ' . intdiv(MAX_UPLOAD, 1048576) . ' MB).', 413);
    $free = @disk_free_space(DATA_DIR);
    if ($free !== false && $free - $size < MIN_FREE) throw new CdnError('Diskte yeterli boş alan yok.', 507);
    if (!is_writable(TMP_DIR) || !is_writable(FILES_DIR)) throw new CdnError('Depolama klasörü yazılamıyor.', 500);

    $id = bin2hex(random_bytes(16));
    $base = trim((string)pathinfo($filename, PATHINFO_FILENAME));
    try { $suggest = cdnCleanName($base); } catch (CdnError $e) { $suggest = 'dosya'; }
    $meta = ['root' => $root, 'parent' => $p['id'] ?? null, 'ext' => $ext, 'size' => $size, 'orig' => $filename, 'created' => time()];
    if (file_put_contents(TMP_DIR . '/' . $id . '.json', json_encode($meta)) === false || file_put_contents(TMP_DIR . '/' . $id . '.part', '') === false) {
        throw new CdnError('Geçici dosya oluşturulamadı.', 500);
    }
    return ['upload_id' => $id, 'chunk' => CHUNK_SIZE, 'suggest' => $suggest, 'ext' => $ext];
}

/** @param resource|null $in test için; varsayılan php://input */
function cdnUploadChunk(string $id, int $offset, $in = null): int {
    $m = cdnUploadMeta($id);
    $part = TMP_DIR . '/' . $id . '.part';
    clearstatcache(true, $part);
    $cur = is_file($part) ? (int)filesize($part) : 0;
    if ($offset !== $cur) {
        $e = new CdnError('Parça sırası uyuşmuyor.', 409);
        $e->extra = ['offset' => $cur];
        throw $e;
    }
    $in ??= fopen('php://input', 'rb');
    $out = fopen($part, 'ab');
    if (!$in || !$out) throw new CdnError('Parça yazılamadı.', 500);
    flock($out, LOCK_EX);
    $written = 0;
    while (!feof($in)) {
        $buf = fread($in, 1048576);
        if ($buf === false || $buf === '') break;
        if ($cur + $written + strlen($buf) > (int)$m['size']) {
            ftruncate($out, $cur);
            fclose($out);
            throw new CdnError('Dosya beklenenden büyük.', 400);
        }
        fwrite($out, $buf);
        $written += strlen($buf);
    }
    fflush($out);
    flock($out, LOCK_UN);
    fclose($out);
    if ($written === 0) throw new CdnError('Boş parça.', 400);
    return $cur + $written;
}

function cdnUploadAbort(string $id): void {
    if (!preg_match('/^[a-f0-9]{32}$/', $id)) return;
    @unlink(TMP_DIR . '/' . $id . '.part');
    @unlink(TMP_DIR . '/' . $id . '.json');
    @unlink(TMP_DIR . '/' . $id . '.st');
}

/** Yükleme tamamlanır: isim verilir, kayıt eklenir, dosya yerine taşınır. [item, row] döner */
function cdnUploadFinish(string $id, string $name): array {
    $m = cdnUploadMeta($id);
    $part = TMP_DIR . '/' . $id . '.part';
    clearstatcache(true, $part);
    if (!is_file($part) || (int)filesize($part) !== (int)$m['size']) throw new CdnError('Yükleme tamamlanmadı.', 400);
    $p = cdnParent((string)$m['root'], $m['parent'] ?? null);
    $name = cdnCleanName(cdnStripExt($name, (string)$m['ext']));
    [, $mime] = cdnExtInfo((string)$m['ext']);
    $stored = bin2hex(random_bytes(16)) . '.' . $m['ext'];

    $row = cdnGuard(fn() => db()->insert('cdn_items', [
        'parent_id' => $p['id'] ?? null, 'root' => $m['root'], 'kind' => 'file', 'name' => $name,
        'stored_name' => $stored, 'ext' => $m['ext'], 'mime' => $mime, 'size' => (int)$m['size'],
        'expires_at' => $m['root'] === 'gecici' ? cdnExpiry() : null,
    ]));
    if (!@rename($part, FILES_DIR . '/' . $stored)) {
        db()->delete('cdn_items', ['id' => 'eq.' . $row['id']]);
        throw new CdnError('Dosya kaydedilemedi.', 500);
    }
    @unlink(TMP_DIR . '/' . $id . '.json');
    @unlink(TMP_DIR . '/' . $id . '.st');
    return ['item' => cdnItemOut($row), 'row' => $row];
}
