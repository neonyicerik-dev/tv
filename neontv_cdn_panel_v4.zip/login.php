<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
startSession();
securityHeaders();
if (!empty($_SESSION['ok'])) { header('Location: index.php'); exit; }

$err = '';
$lockFile = TMP_DIR . '/login_' . md5(clientIp()) . '.json';
$st = is_file($lockFile) ? (json_decode((string)file_get_contents($lockFile), true) ?: []) : [];
$locked = (int)($st['until'] ?? 0) > time();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!csrfValid($_POST['csrf'] ?? null)) {
        $err = 'Oturum süresi doldu, tekrar deneyin.';
    } elseif ($locked) {
        $err = 'Çok fazla hatalı deneme. Birkaç dakika sonra tekrar deneyin.';
    } else {
        $hash = (string)cfg('CDN_ADMIN_HASH', '');
        $pw = (string)($_POST['password'] ?? '');
        if ($hash === '') {
            $err = 'Parola yapılandırılmamış (tools/hash.php ile oluşturun).';
        } elseif (password_verify($pw, $hash)) {
            @unlink($lockFile);
            session_regenerate_id(true);
            $_SESSION['ok'] = true;
            $_SESSION['last'] = time();
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            header('Location: index.php');
            exit;
        } else {
            $cnt = (int)($st['count'] ?? 0) + 1;
            $new = ['count' => $cnt, 'until' => $cnt >= 5 ? time() + 900 : 0];
            if ($cnt >= 5) $new['count'] = 0;
            @file_put_contents($lockFile, json_encode($new), LOCK_EX);
            usleep(400000);
            $err = 'Parola hatalı.';
        }
    }
}
pageHead('CDN Paneli – Giriş', 'class="login"');
?>
<main class="loginbox">
  <h1>NeonTV <span>CDN</span></h1>
  <form method="post" autocomplete="off">
    <input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>">
    <label for="pw">Parola</label>
    <input id="pw" name="password" type="password" class="inp" autofocus required autocomplete="current-password">
    <?php if ($err): ?><div class="err"><?= e($err) ?></div><?php endif; ?>
    <button class="btn pri wide" type="submit">Giriş yap</button>
  </form>
</main>
</body></html>
