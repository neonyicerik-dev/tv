<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
startSession();
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && csrfValid($_POST['csrf'] ?? null)) {
    $_SESSION = [];
    session_destroy();
}
header('Location: login.php');
