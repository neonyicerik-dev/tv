<?php
// Bu dosyayı secrets.php olarak kopyalayıp doldurun. secrets.php git'e eklenmez ve web'den erişime kapalıdır.
putenv('SUPABASE_URL=https://PROJE.supabase.co');
putenv('SUPABASE_SERVICE_KEY=');          // service_role anahtarı (yalnızca sunucuda)
putenv('CDN_ADMIN_HASH=');                // php tools/hash.php çıktısı
putenv('CDN_DATA_DIR=/srv/cdn/data');
putenv('CDN_PUBLIC_URL=');                // boşsa panelle aynı alan adı kullanılır, örn. https://cdn.alanadi.com
putenv('CDN_TTL_DAYS=60');
putenv('CDN_MIN_FREE_MB=2048');           // bu kadar boş alan kalmazsa yükleme reddedilir
