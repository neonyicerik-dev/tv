<?php
// Yerel e2e testi için php -S yönlendiricisi (sahte DB'yi istekler arasında dosyada saklar)
$state = sys_get_temp_dir() . '/cdn_e2e_state.ser';
putenv('CDN_DATA_DIR=' . sys_get_temp_dir() . '/cdn_e2e');
putenv('CDN_ADMIN_HASH=' . password_hash('testparola123', PASSWORD_DEFAULT));
putenv('CDN_MIN_FREE_MB=10');
require __DIR__ . '/FakeDb.php';
$GLOBALS['cdn_db'] = is_file($state) ? unserialize((string)file_get_contents($state)) : new FakeDb;
register_shutdown_function(function () use ($state) { file_put_contents($state, serialize($GLOBALS['cdn_db'])); });
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$file = realpath(__DIR__ . '/..' . $path);
if ($path === '/' ) { header('Location: index.php'); return true; }
if (str_starts_with($path, '/f/') && isset($_GET['audio'])) { $_GET = ['f' => basename($path), 't' => $_GET['audio']]; chdir(__DIR__ . '/..'); require __DIR__ . '/../audio.php'; return true; }
if (str_starts_with($path, '/f/') || str_starts_with($path, '/t/')) {
    $dir = str_starts_with($path, '/f/') ? '/files/' : '/thumbs/';
    $p = sys_get_temp_dir() . '/cdn_e2e' . $dir . basename($path);
    if (is_file($p)) { header('Content-Type: ' . mime_content_type($p)); readfile($p); return true; }
    http_response_code(404); return true;
}
if ($file && is_file($file) && !str_ends_with($file, '.php')) return false;
if ($file && is_file($file) && str_ends_with($file, '.php')) { chdir(dirname($file)); require $file; return true; }
http_response_code(404);
