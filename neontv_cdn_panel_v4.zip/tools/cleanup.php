<?php
// Cron ile çalıştırın (günde 1 kez): süresi dolan geçici dosyaları ve yarım kalmış yüklemeleri siler.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/../lib/bootstrap.php';
require __DIR__ . '/../lib/rest.php';
require __DIR__ . '/../lib/store.php';
try {
    $r = cdnPurgeExpired();
    $s = cdnCleanStaleUploads();
    echo date('c') . " silinen dosya: {$r['files']}, temizlenen yarım yükleme: {$s}\n";
} catch (Throwable $e) {
    fwrite(STDERR, date('c') . ' hata: ' . get_class($e) . ' ' . $e->getMessage() . "\n");
    exit(1);
}
