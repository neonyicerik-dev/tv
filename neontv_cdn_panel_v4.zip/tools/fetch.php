<?php
// api.php tarafından arka planda çalıştırılır: php tools/fetch.php <upload_id>
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/../lib/bootstrap.php';
require __DIR__ . '/../lib/rest.php';
require __DIR__ . '/../lib/store.php';
require __DIR__ . '/../lib/media.php';
require __DIR__ . '/../lib/fetch.php';
$id = $argv[1] ?? '';
if (!preg_match('/^[a-f0-9]{32}$/', $id)) exit(1);
cdnFetchRun($id);
