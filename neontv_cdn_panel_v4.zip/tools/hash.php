<?php
// Kullanım: php tools/hash.php  → parola hash'i üretir (parolanın kendisi hiçbir yere yazılmaz)
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
fwrite(STDOUT, "Yeni panel parolası (en az 10 karakter): ");
@system('stty -echo 2>/dev/null');
$p = rtrim((string)fgets(STDIN), "\r\n");
@system('stty echo 2>/dev/null');
echo "\n";
if (mb_strlen($p) < 10) { fwrite(STDERR, "Parola en az 10 karakter olmalı.\n"); exit(1); }
echo "secrets.php içine şu satırı ekleyin:\n\nputenv('CDN_ADMIN_HASH=" . password_hash($p, PASSWORD_DEFAULT) . "');\n";
