# NeonTV CDN Paneli

Düz PHP + Supabase. Dosyalar diskte (`/srv/cdn/data/files`), klasör/isim/süre bilgisi Supabase `cdn_items` tablosunda.
Klasörler sanaldır: taşıma, yeniden adlandırma ve kalıcı↔geçici geçişi diskte dosya taşımaz (anında olur).

## Kurulum (Debian)
1. `apt install nginx php8.4-fpm php8.4-curl php8.4-mbstring ffmpeg`
2. Dosyaları `/var/www/cdn` içine kopyalayın; `mkdir -p /srv/cdn/data && chown -R www-data:www-data /srv/cdn/data /var/www/cdn/lib`
3. Supabase SQL editöründe `cdn_supabase.sql` dosyasını çalıştırın.
4. `cp secrets.example.php secrets.php` → URL ve service_role anahtarını girin. `php tools/hash.php` ile parola hash'i üretip `CDN_ADMIN_HASH` satırına yazın.
5. Nginx: `deploy/nginx-cdn.conf` (alan adını ve soketi düzenleyin), `nginx -t && systemctl reload nginx`
6. PHP: `post_max_size = 32M` (en az 16M), `upload_max_filesize` önemli değil (ham gövde kullanılır). PHP-FPM'de `session.upload_progress.enabled = 0` önerilir.
7. Cron (günlük silme): `17 4 * * * www-data php /var/www/cdn/tools/cleanup.php >> /var/log/cdn-cleanup.log 2>&1`

## Yalnızca ses (`?audio=`)
`https://cdn.alanadi.com/f/<kod>.mp4?audio=mp3` (mp3 | aac | opus | wav). Konuşma analizi için küçültülmüş: mono, 16 kHz (mp3 ≈ 0,35 MB/dk, opus ≈ 0,3 MB/dk).
İlk istekte ffmpeg ile üretilir, sonra önbellekten gelir (aynı anda en fazla 2 dönüştürme; meşgulse `503 Retry-After`).
Video silinince/süresi dolunca sesi de silinir; 14 gün istenmeyen ses önbelleği cleanup ile temizlenir.

## Taşıma
Bkz. `deploy/TASIMA.md`.

## Notlar
- Dosya adresi: `https://cdn.alanadi.com/f/<kod>.mp4`  (menüde "Bağlantıyı kopyala")
- Geçici bölüm: yükleme anından itibaren 60 gün (`CDN_TTL_DAYS`). Geçiciye taşınan dosyada süre taşıma anından başlar; kalıcıya taşınınca süre kalkar.
- Önizleme karesi yükleme bittikten sonra arka planda, düşük öncelikle üretilir (`nice`/`ionice`/tek iş parçacığı).
- Panel parolası yalnızca hash olarak saklanır; 5 hatalı denemede 15 dk kilit.

## Bağlantıdan yükleme
Klasör sayfasındaki **Bağlantıdan** butonuyla http/https bağlantısı verilir; dosyayı sunucu doğrudan indirir (cihazınızdan geçmez), ilerleme çubuğu görünür, bitince ad sorulur. İndirme `php` komutu varsa arka planda (`tools/fetch.php`), yoksa yanıttan sonra aynı istekte çalışır (bu durumda php-fpm `request_terminate_timeout` büyük olmalı). Güvenlik: yalnızca 80/443/8080/8443 portları, özel/yerel IP'lere (SSRF) erişim engelli, yönlendirmeler tek tek doğrulanır, boyut `CDN_MAX_UPLOAD_MB` ile sınırlı.

## Videodan ekran görüntüsü
Videoya sağ tık / uzun bas → **Ekran görüntüsü al…**. Açılan pencerede video oynatılıp istenen ana getirilir (±1 sn / ±1 kare düğmeleri var), kayıt klasörü (Kalıcı/Geçici + alt klasör), dosya adı ve uzantı (jpg/png/webp) seçilir. Kare, sunucuda ffmpeg ile videonun özgün çözünürlüğünde alınır (tarayıcı/CORS'tan bağımsız). Geçici klasöre kaydedilen görüntü de 60 gün sonra silinir.
