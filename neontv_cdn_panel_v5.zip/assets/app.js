(() => {
  'use strict';
  const D = document.body.dataset;
  const ROOT = D.root, DIR = D.dir || '', CSRF = D.csrf, TTL = D.ttl || '60';
  const BASE = (D.base || '').replace(/\/$/, '') || location.origin;
  const PAGE = 36, LONG = 500;
  const ROOT_NAMES = { kalici: 'Kalıcı', gecici: 'Geçici' };
  const $ = (s, r = document) => r.querySelector(s);
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ---------- küçük yardımcılar
  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat()) if (c !== null && c !== undefined && c !== false) el.append(c.nodeType ? c : document.createTextNode(c));
    return el;
  }
  const svg = (path) => { const d = document.createElement('div'); d.innerHTML = `<svg viewBox="0 0 24 24" fill="currentColor"><path d="${path}"/></svg>`; return d.firstChild; };
  const ICON = {
    folder: 'M10 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8l-2-2z',
    video: 'M4 5h11a2 2 0 0 1 2 2v2.5l4-2.5v10l-4-2.5V17a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z',
    audio: 'M9 3v10.6A4 4 0 1 0 11 17V7h6V3H9z',
    image: 'M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zm3 4a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-3 12h14l-4.5-6-3.5 4.5-2-2.5L5 19z',
    other: 'M6 2h8l6 6v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z',
  };
  function fmtBytes(b) {
    const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0, v = b;
    while (v >= 1024 && i < 4) { v /= 1024; i++; }
    return (i === 0 ? v : v.toFixed(v >= 100 ? 0 : 1)) + ' ' + u[i];
  }
  function fmtDur(s) {
    s = Math.round(s); const m = Math.floor(s / 60), r = s % 60, hh = Math.floor(m / 60);
    return hh ? `${hh}:${String(m % 60).padStart(2, '0')}:${String(r).padStart(2, '0')}` : `${m}:${String(r).padStart(2, '0')}`;
  }
  let toastT = null;
  function toast(msg, bad) {
    const t = $('#toast'); t.textContent = msg; t.className = 'toast' + (bad ? ' bad' : ''); t.hidden = false;
    clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, 3500);
  }

  async function api(action, { method = 'GET', query = {}, body, raw = false, headers = {} } = {}) {
    const qs = new URLSearchParams({ a: action, ...query });
    const opt = { method, headers: { 'X-CSRF-Token': CSRF, ...headers }, credentials: 'same-origin' };
    if (body !== undefined) {
      opt.body = raw ? body : JSON.stringify(body);
      if (!raw) opt.headers['Content-Type'] = 'application/json';
    }
    const r = await fetch('api.php?' + qs, opt);
    let j = null; try { j = await r.json(); } catch (e) { /* boş/geçersiz gövde */ }
    if (r.status === 401) { location.href = 'login.php'; throw new Error('Oturum süresi doldu.'); }
    if (!r.ok) { const err = new Error((j && j.error) || 'İşlem başarısız.'); err.status = r.status; err.data = j; throw err; }
    return j;
  }

  // ---------- pencere (modal / alt sayfa)
  function modal(build, { sheet = false, onClose } = {}) {
    const back = h('div', { class: 'back' + (sheet ? ' sheetwrap' : '') });
    const box = h('div', { class: sheet ? 'sheet' : 'modal', role: 'dialog' });
    back.append(box); document.body.append(back);
    let closed = false;
    const onKey = e => { if (e.key === 'Escape') close(); };
    function close() {
      if (closed) return; closed = true;
      back.remove(); document.removeEventListener('keydown', onKey);
      if (onClose) onClose();
    }
    document.addEventListener('keydown', onKey);
    back.addEventListener('pointerdown', e => { if (e.target === back) close(); });
    build(box, close);
    return close;
  }

  /** İsim sorar; run(değer) hata fırlatırsa pencere açık kalır ve hata gösterilir */
  function askName({ title, value = '', suffix = '', ok = 'Kaydet', run, max = '120' }) {
    return new Promise(resolve => {
      let done = false;
      modal((box, close) => {
        const inp = h('input', { type: 'text', value, maxlength: max, autocomplete: 'off', class: 'inp' });
        const err = h('div', { class: 'err' });
        const okb = h('button', { class: 'btn pri', type: 'button', text: ok });
        const can = h('button', { class: 'btn', type: 'button', text: 'Vazgeç' });
        box.append(h('h3', { text: title }), h('div', { class: 'inprow' }, inp, suffix ? h('span', { class: 'sfx', text: '.' + suffix }) : null), err, h('div', { class: 'btns' }, can, okb));
        const submit = async () => {
          err.textContent = ''; okb.disabled = true;
          try { await run(inp.value.trim()); done = true; close(); }
          catch (e) { err.textContent = e.message; okb.disabled = false; }
        };
        okb.onclick = submit; can.onclick = close;
        inp.onkeydown = e => { if (e.key === 'Enter') submit(); };
        setTimeout(() => { inp.focus(); inp.select(); }, 30);
      }, { onClose: () => resolve(done) });
    });
  }

  function confirmBox({ title, text, ok = 'Evet', bad = false }) {
    return new Promise(resolve => {
      let yes = false;
      modal((box, close) => {
        const okb = h('button', { class: 'btn ' + (bad ? 'bad' : 'pri'), type: 'button', text: ok, onclick: () => { yes = true; close(); } });
        box.append(h('h3', { text: title }), h('div', { class: 'msg', text }), h('div', { class: 'btns' }, h('button', { class: 'btn', type: 'button', text: 'Vazgeç', onclick: close }), okb));
      }, { onClose: () => resolve(yes) });
    });
  }

  // ---------- listeleme (sonsuz kaydırma)
  const grid = $('#grid'), sentinel = $('#sentinel'), emptyEl = $('#empty');
  let offset = 0, loading = false, done = false, gen = 0;

  function reset() { gen++; grid.textContent = ''; offset = 0; done = false; loading = false; sentinel.classList.remove('done'); emptyEl.hidden = true; loadMore(); }

  async function loadMore() {
    if (loading || done) return;
    loading = true; const my = gen;
    try {
      const j = await api('list', { query: { root: ROOT, parent: DIR, offset, limit: PAGE } });
      if (my !== gen) return;
      j.items.forEach(addCard);
      offset += j.items.length;
      if (j.items.length < PAGE) { done = true; sentinel.classList.add('done'); }
      emptyEl.hidden = !(done && grid.children.length === 0);
    } catch (e) {
      if (my === gen) { toast(e.message, true); done = true; sentinel.classList.add('done'); }
    } finally {
      if (my === gen) {
        loading = false;
        // ekran hâlâ doluysa (kısa liste) bir sonraki sayfayı iste
        requestAnimationFrame(() => { if (!done && sentinel.getBoundingClientRect().top < innerHeight + 600) loadMore(); });
      }
    }
  }
  new IntersectionObserver(es => { if (es[0].isIntersecting) loadMore(); }, { rootMargin: '600px' }).observe(sentinel);

  function loadThumb(img, box, it, tries) {
    img.onerror = () => {
      if (tries >= 6) { img.remove(); box.prepend(svg(ICON[it.type] || ICON.other)); return; }
      setTimeout(() => loadThumb(img, box, it, tries + 1), 2500 + tries * 1500);
    };
    img.src = BASE + it.thumb + (tries ? '?r=' + tries : '');
  }

  function addCard(it) {
    const isFolder = it.kind === 'folder';
    const href = isFolder ? `folder.php?root=${encodeURIComponent(ROOT)}&dir=${encodeURIComponent(it.id)}` : BASE + it.url;
    const thumb = h('div', { class: 'thumb' });
    if (isFolder) thumb.append(svg(ICON.folder));
    else if (it.thumb) {
      const img = h('img', { alt: '', loading: 'lazy', draggable: 'false' });
      thumb.append(img);
      loadThumb(img, thumb, it, it.has_thumb ? 0 : 4);
    } else thumb.append(svg(ICON[it.type] || ICON.other));
    if (!isFolder && it.duration) thumb.append(h('span', { class: 'badge', text: fmtDur(it.duration) }));

    const sub = h('div', { class: 'sub' });
    if (isFolder) sub.append('Klasör');
    else {
      sub.append(fmtBytes(it.size));
      if (it.days_left !== null) {
        const d = it.days_left;
        sub.append(h('span', { class: 'chip ' + (d <= 3 ? 'bad' : d <= 14 ? 'warn' : ''), text: d === 0 ? 'bugün silinecek' : d + ' gün kaldı' }));
      } else sub.append(h('span', { class: 'chip ok', text: 'Kalıcı' }));
    }
    const card = h('a', { class: 'card ' + (isFolder ? 'folder' : 'file'), href, draggable: 'false', target: isFolder ? null : '_blank', rel: isFolder ? null : 'noopener' },
      thumb, h('div', { class: 'meta' }, h('div', { class: 'nm', text: it.full, title: it.full }), sub));
    bindPress(card, it);
    grid.append(card);
  }

  // ---------- uzun basma / sağ tık menüsü
  function bindPress(el, it) {
    let t = null, sx = 0, sy = 0, fired = false;
    const cancel = () => { clearTimeout(t); t = null; };
    el.addEventListener('pointerdown', e => {
      if (e.button > 0) return;
      fired = false; sx = e.clientX; sy = e.clientY;
      t = setTimeout(() => { fired = true; t = null; if (navigator.vibrate) navigator.vibrate(15); openSheet(it); }, LONG);
    });
    el.addEventListener('pointermove', e => { if (t && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) cancel(); });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => el.addEventListener(ev, cancel));
    el.addEventListener('click', e => { if (fired) { e.preventDefault(); e.stopPropagation(); fired = false; } });
    el.addEventListener('contextmenu', e => {
      e.preventDefault();
      if (!fired) { fired = true; openSheet(it); setTimeout(() => { fired = false; }, 400); }
    });
  }

  function openSheet(it) {
    modal((box, close) => {
      const act = (label, fn, cls) => h('button', { type: 'button', class: cls, text: label, onclick: () => { close(); fn(); } });
      box.append(h('h3', { text: it.full }));
      if (it.kind === 'file') {
        box.append(act('Aç', () => window.open(BASE + it.url, '_blank', 'noopener')));
        box.append(act('Bağlantıyı kopyala', () => copyLink(BASE + it.url)));
        if (it.type === 'video') box.append(act('Ses bağlantısını kopyala (mp3)', () => copyLink(BASE + it.url + '?audio=mp3')));
        if (it.type === 'video') box.append(act('Ekran görüntüsü al…', () => doSnap(it)));
      }
      box.append(act('Yeniden adlandır', () => doRename(it)));
      box.append(act('Taşı', () => doMove(it)));
      box.append(act('Sil', () => doDelete(it), 'bad'));
    }, { sheet: true });
  }

  async function copyLink(url) {
    try { await navigator.clipboard.writeText(url); toast('Bağlantı kopyalandı'); }
    catch (e) {
      const ta = h('textarea', { style: 'position:fixed;opacity:0' }); ta.value = url; document.body.append(ta); ta.select();
      try { document.execCommand('copy'); toast('Bağlantı kopyalandı'); } catch (e2) { toast(url); }
      ta.remove();
    }
  }

  function doRename(it) {
    askName({
      title: 'Yeniden adlandır', value: it.name, suffix: it.ext || '', ok: 'Kaydet',
      run: async name => { await api('rename', { method: 'POST', body: { id: it.id, name } }); },
    }).then(ok => { if (ok) { toast('Ad değiştirildi'); reset(); } });
  }

  async function doDelete(it) {
    const folder = it.kind === 'folder';
    const ok = await confirmBox({
      title: 'Silinsin mi?', bad: true, ok: 'Sil',
      text: folder ? `"${it.full}" klasörü ve içindeki tüm dosyalar kalıcı olarak silinecek.` : `"${it.full}" kalıcı olarak silinecek.`,
    });
    if (!ok) return;
    try { const r = await api('delete', { method: 'POST', body: { id: it.id } }); toast(folder ? `${r.files} dosya silindi` : 'Silindi'); reset(); }
    catch (e) { toast(e.message, true); }
  }


  // ---------- videodan ekran görüntüsü (seçilen an -> seçilen klasör, ad ve uzantı)
  function doSnap(it) {
    let curRoot = ROOT, target = DIR || null, folders = [];
    modal((box, close) => {
      const vid = h('video', { src: BASE + it.url, controls: true, preload: 'metadata', playsinline: true, style: 'width:100%;max-height:44vh;background:#000;border-radius:10px' });
      const tm = h('div', { class: 'msg', style: 'margin:6px 0' });
      const stepRow = h('div', { class: 'btns', style: 'justify-content:flex-start;gap:6px;margin:0 0 8px' },
        ...[['−1 sn', -1], ['−1 kare', -0.04], ['+1 kare', 0.04], ['+1 sn', 1]].map(([l, d]) => h('button', { class: 'btn sm', type: 'button', text: l, onclick: () => { vid.pause(); vid.currentTime = Math.max(0, (vid.currentTime || 0) + d); } })));
      const stamp = s => fmtDur(Math.floor(s)) + '.' + String(Math.round((s % 1) * 100)).padStart(2, '0');
      const upd = () => { tm.textContent = 'Seçilen an: ' + stamp(vid.currentTime || 0); };
      vid.addEventListener('timeupdate', upd); vid.addEventListener('seeked', upd); upd();
      const tabs = h('div', { class: 'tabs' }), tree = h('div', { class: 'tree' });
      const base = (it.name || 'goruntu').slice(0, 80);
      const inp = h('input', { type: 'text', maxlength: '120', class: 'inp', value: base + '-ekran' });
      const sel = h('select', { class: 'inp', style: 'max-width:90px' }, ...['jpg', 'png', 'webp'].map(x => h('option', { value: x, text: '.' + x })));
      const err = h('div', { class: 'err' });
      const go = h('button', { class: 'btn pri', type: 'button', text: 'Ekran görüntüsünü kaydet' });
      box.append(h('h3', { text: 'Ekran görüntüsü al' }), vid, tm, stepRow, h('div', { class: 'msg' }, 'Kaydedilecek klasör:'), tabs, tree,
        h('div', { class: 'inprow', style: 'margin-top:8px' }, inp, sel), err, h('div', { class: 'btns' }, h('button', { class: 'btn', type: 'button', text: 'Vazgeç', onclick: close }), go));
      function render() {
        tabs.textContent = '';
        for (const [k, n] of Object.entries(ROOT_NAMES)) tabs.append(h('button', { class: 'btn' + (k === curRoot ? ' on' : ''), type: 'button', text: n, onclick: () => { if (k !== curRoot) { curRoot = k; target = null; load(); } } }));
        tree.textContent = '';
        tree.append(h('button', { type: 'button', class: target === null ? 'sel' : '', onclick: () => { target = null; render(); } }, '📁 ' + ROOT_NAMES[curRoot] + ' (ana klasör)'));
        const kids = {}; for (const f of folders) (kids[f.parent_id || ''] ||= []).push(f);
        (function walk(pid, d) { for (const f of kids[pid || ''] || []) { tree.append(h('button', { type: 'button', class: target === f.id ? 'sel' : '', style: `padding-left:${8 + d * 18}px`, onclick: () => { target = f.id; render(); } }, '📁 ' + f.name)); walk(f.id, d + 1); } })('', 1);
      }
      async function load() {
        tree.textContent = 'Yükleniyor…';
        try { folders = (await api('folders', { query: { root: curRoot } })).folders; render(); } catch (e) { tree.textContent = ''; err.textContent = e.message; }
      }
      go.onclick = async () => {
        err.textContent = ''; go.disabled = true;
        try {
          await api('snap', { method: 'POST', body: { id: it.id, time: vid.currentTime || 0, root: curRoot, parent: target, name: inp.value.trim(), ext: sel.value } });
          close(); toast('Ekran görüntüsü kaydedildi'); reset();
        } catch (e) { err.textContent = e.message; go.disabled = false; }
      };
      load();
    });
  }

  // ---------- taşıma
  async function doMove(it) {
    let curRoot = ROOT, target = DIR || null;
    modal(async (box, close) => {
      const tabs = h('div', { class: 'tabs' });
      const tree = h('div', { class: 'tree' });
      const note = h('div', { class: 'msg', style: 'margin-top:8px' });
      const err = h('div', { class: 'err' });
      const go = h('button', { class: 'btn pri', type: 'button', text: 'Buraya taşı' });
      box.append(h('h3', { text: `"${it.full}" nereye taşınsın?` }), tabs, tree, note, err, h('div', { class: 'btns' }, h('button', { class: 'btn', type: 'button', text: 'Vazgeç', onclick: close }), go));

      let folders = [];
      const blocked = new Set();
      function computeBlocked() {
        blocked.clear();
        if (it.kind !== 'folder') return;
        blocked.add(it.id);
        let grew = true;
        while (grew) { grew = false; for (const f of folders) if (!blocked.has(f.id) && blocked.has(f.parent_id)) { blocked.add(f.id); grew = true; } }
      }
      function render() {
        tabs.textContent = '';
        for (const [k, n] of Object.entries(ROOT_NAMES)) {
          tabs.append(h('button', { class: 'btn' + (k === curRoot ? ' on' : ''), type: 'button', text: n, onclick: () => { if (k !== curRoot) { curRoot = k; target = null; load(); } } }));
        }
        tree.textContent = '';
        const rootBtn = h('button', { type: 'button', class: target === null ? 'sel' : '', onclick: () => { target = null; render(); } }, '📁 ' + ROOT_NAMES[curRoot] + ' (ana klasör)');
        tree.append(rootBtn);
        const kids = {};
        for (const f of folders) (kids[f.parent_id || ''] ||= []).push(f);
        (function walk(pid, depth) {
          for (const f of kids[pid || ''] || []) {
            const dis = blocked.has(f.id);
            const b = h('button', { type: 'button', class: target === f.id ? 'sel' : '', disabled: dis, style: `padding-left:${8 + depth * 18}px`, onclick: () => { target = f.id; render(); } }, '📁 ' + f.name);
            tree.append(b); if (!dis) walk(f.id, depth + 1);
          }
        })('', 1);
        const toTemp = curRoot === 'gecici' && it.kind !== null && ROOT !== 'gecici';
        const toPerm = curRoot === 'kalici' && ROOT === 'gecici';
        note.textContent = toTemp ? `Geçiciye taşınan dosyalar taşıma anından itibaren ${TTL} gün sonra silinir.` : toPerm ? 'Kalıcıya taşınan dosyaların silinme süresi kalkar.' : '';
      }
      async function load() {
        tree.textContent = 'Yükleniyor…';
        try { folders = (await api('folders', { query: { root: curRoot } })).folders; computeBlocked(); render(); }
        catch (e) { tree.textContent = ''; err.textContent = e.message; }
      }
      go.onclick = async () => {
        err.textContent = ''; go.disabled = true;
        try { await api('move', { method: 'POST', body: { id: it.id, root: curRoot, parent: target } }); close(); toast('Taşındı'); reset(); }
        catch (e) { err.textContent = e.message; go.disabled = false; }
      };
      load();
    });
  }

  // ---------- yeni klasör
  $('#newFolder').onclick = () => askName({
    title: 'Yeni klasör', ok: 'Oluştur',
    run: async name => { await api('mkdir', { method: 'POST', body: { root: ROOT, parent: DIR || null, name } }); },
  }).then(ok => { if (ok) { toast('Klasör oluşturuldu'); reset(); } });

  // ---------- yükleme (parçalı, sırayla)
  const fileInput = $('#fileInput'), prog = $('#prog');
  const queue = []; let busy = false;
  $('#uploadBtn').onclick = () => fileInput.click();
  fileInput.onchange = () => { for (const f of fileInput.files) queue.push(f); fileInput.value = ''; pump(); };
  window.addEventListener('beforeunload', e => { if (busy) { e.preventDefault(); e.returnValue = ''; } });

  function showProg(name, frac, left) {
    prog.hidden = false;
    $('.progname', prog).textContent = `${name}${left ? ` (+${left} dosya sırada)` : ''} – %${Math.round(frac * 100)}`;
    $('.bar i', prog).style.width = Math.round(frac * 100) + '%';
  }

  async function pump() {
    if (busy) return; busy = true;
    while (queue.length) {
      const f = queue.shift();
      try { await uploadOne(f); } catch (e) { toast(`${f.name}: ${e.message}`, true); }
    }
    busy = false; prog.hidden = true;
  }

  async function uploadOne(file) {
    showProg(file.name, 0, queue.length);
    const init = await api('upload_init', { method: 'POST', body: { root: ROOT, parent: DIR || null, filename: file.name, size: file.size } });
    const id = init.upload_id, chunk = init.chunk;
    let off = 0;
    try {
      while (off < file.size) {
        const blob = file.slice(off, Math.min(off + chunk, file.size));
        let tries = 0;
        for (;;) {
          try {
            const r = await api('upload_chunk', { method: 'POST', query: { id, offset: off }, raw: true, body: blob, headers: { 'Content-Type': 'application/octet-stream' } });
            off = r.offset; break;
          } catch (e) {
            if (e.status === 409 && e.data && typeof e.data.offset === 'number') { off = e.data.offset; break; }
            if (e.status && e.status < 500) throw e;
            if (++tries >= 4) throw e;
            await sleep(1000 * tries);
          }
        }
        showProg(file.name, off / file.size, queue.length);
      }
    } catch (e) {
      api('upload_abort', { method: 'POST', body: { id } }).catch(() => {});
      throw e;
    }
    prog.hidden = true;
    const ok = await askName({
      title: 'Dosya adı', value: init.suggest, suffix: init.ext, ok: 'Kaydet',
      run: async name => { await api('upload_finish', { method: 'POST', body: { id, name } }); },
    });
    if (!ok) { api('upload_abort', { method: 'POST', body: { id } }).catch(() => {}); toast('Yükleme iptal edildi'); return; }
    toast('Yüklendi'); reset();
    if (queue.length) prog.hidden = false;
  }

  // ---------- bağlantıdan yükleme (sunucu indirir)
  $('#urlBtn').onclick = async () => {
    if (busy) { toast('Önce süren yükleme bitsin', true); return; }
    let id = null;
    const started = await askName({
      title: 'Bağlantıdan yükle (http/https)', value: '', ok: 'İndir',
      run: async url => { const r = await api('url_start', { method: 'POST', body: { root: ROOT, parent: DIR || null, url: url.trim() } }); id = r.upload_id; },
      max: '2000',
    });
    if (!started || !id) return;
    busy = true;
    try {
      for (;;) {
        await sleep(1200);
        const st = await api('url_status', { query: { id } });
        if (st.state === 'error') throw new Error(st.msg || 'İndirme başarısız.');
        const frac = st.total > 0 ? st.got / st.total : 0;
        prog.hidden = false;
        $('.progname', prog).textContent = `Bağlantıdan indiriliyor – ${fmtBytes(st.got)}${st.total ? ' / ' + fmtBytes(st.total) : ''}`;
        $('.bar i', prog).style.width = Math.round(frac * 100) + '%';
        if (st.state === 'done') {
          prog.hidden = true;
          const ok = await askName({
            title: 'Dosya adı', value: st.suggest, suffix: st.ext, ok: 'Kaydet',
            run: async name => { await api('upload_finish', { method: 'POST', body: { id, name } }); },
          });
          if (!ok) { api('upload_abort', { method: 'POST', body: { id } }).catch(() => {}); toast('Yükleme iptal edildi'); }
          else { toast('Yüklendi'); reset(); }
          break;
        }
      }
    } catch (e) {
      api('upload_abort', { method: 'POST', body: { id } }).catch(() => {});
      toast(e.message, true);
    }
    busy = false; prog.hidden = true;
  };

  reset();
})();
