<?php
declare(strict_types=1);

function cdnBin(string $name): ?string {
    static $cache = [];
    if (array_key_exists($name, $cache)) return $cache[$name];
    $p = function_exists('shell_exec') ? trim((string)@shell_exec('command -v ' . escapeshellarg($name) . ' 2>/dev/null')) : '';
    return $cache[$name] = ($p !== '' ? $p : null);
}

/**
 * Videonun ortasından tek kare (veya resmin küçük hali) üretir.
 * Sunucuyu yormamak için: hızlı arama (-ss girişten önce), tek iş parçacığı, nice/ionice, zaman aşımı.
 */
function cdnMakeThumb(array $row): void {
    $type = cdnTypeOfExt($row['ext'] ?? null);
    if (!in_array($type, ['video', 'image'], true)) return;
    $ffmpeg = cdnBin('ffmpeg');
    if (!$ffmpeg) return;
    $src = FILES_DIR . '/' . $row['stored_name'];
    $dst = THUMBS_DIR . '/' . $row['id'] . '.jpg';
    if (!is_file($src)) return;

    $prefix = (cdnBin('nice') ? 'nice -n 19 ' : '') . (cdnBin('ionice') ? 'ionice -c3 ' : '') . (cdnBin('timeout') ? 'timeout 40 ' : '');
    $dur = null;
    $seeks = [''];
    if ($type === 'video') {
        $probe = cdnBin('ffprobe');
        if ($probe) {
            $o = trim((string)@shell_exec($prefix . escapeshellarg($probe) . ' -v error -show_entries format=duration -of csv=p=0 ' . escapeshellarg($src) . ' 2>/dev/null'));
            if (is_numeric($o) && (float)$o > 0) $dur = (float)$o;
        }
        $seeks = $dur ? [sprintf(' -ss %.2f', $dur / 2), ' -ss 0'] : [' -ss 1', ' -ss 0'];
    }
    $ok = false;
    foreach ($seeks as $seek) {
        $cmd = $prefix . escapeshellarg($ffmpeg) . ' -nostdin -hide_banner -loglevel error -threads 1' . $seek
             . ' -i ' . escapeshellarg($src) . ' -frames:v 1 -vf scale=480:-2 -q:v 6 -y ' . escapeshellarg($dst) . ' 2>&1';
        @exec($cmd, $out, $rc);
        $ok = is_file($dst) && filesize($dst) > 0;
        if ($ok) break;
        @unlink($dst);
    }
    $upd = [];
    if ($ok) $upd['has_thumb'] = true;
    if ($dur) $upd['duration'] = round($dur, 2);
    if ($upd) {
        try { db()->update('cdn_items', ['id' => 'eq.' . $row['id']], $upd); } catch (Throwable $e) { error_log('[cdn] thumb update: ' . get_class($e)); }
    }
}

/**
 * Videonun seçilen anından tam çözünürlüklü ekran görüntüsü alır, seçilen klasöre (kalıcı/geçici) kaydeder.
 * @return array [item, row]
 */
function cdnSnap(string $id, float $t, string $root, ?string $parent, string $name, string $ext): array {
    $src = cdnMustGet($id);
    if (($src['kind'] ?? '') !== 'file' || cdnTypeOfExt($src['ext'] ?? null) !== 'video') throw new CdnError('Yalnızca videodan ekran görüntüsü alınır.', 400);
    $ext = strtolower($ext);
    if (!in_array($ext, ['jpg', 'png', 'webp'], true)) throw new CdnError('Uzantı jpg, png veya webp olmalı.', 400);
    $p = cdnParent($root, $parent);
    $name = cdnCleanName($name);
    $ffmpeg = cdnBin('ffmpeg');
    if (!$ffmpeg) throw new CdnError('Sunucuda ffmpeg yok (apt install ffmpeg).', 501);
    $in = FILES_DIR . '/' . $src['stored_name'];
    if (!is_file($in)) throw new CdnError('Video dosyası bulunamadı.', 404);
    $free = @disk_free_space(DATA_DIR);
    if ($free !== false && $free < MIN_FREE) throw new CdnError('Diskte yeterli boş alan yok.', 507);
    $dur = (float)($src['duration'] ?? 0);
    if ($t < 0) $t = 0;
    if ($dur > 0 && $t > $dur - 0.05) $t = max(0, $dur - 0.1);

    $stored = bin2hex(random_bytes(16)) . '.' . $ext;
    $dst = FILES_DIR . '/' . $stored;
    $q = $ext === 'jpg' ? ' -q:v 2' : ($ext === 'webp' ? ' -q:v 90' : '');
    $prefix = (cdnBin('nice') ? 'nice -n 10 ' : '') . (cdnBin('timeout') ? 'timeout 40 ' : '');
    $cmd = $prefix . escapeshellarg($ffmpeg) . ' -nostdin -hide_banner -loglevel error -threads 1 -ss ' . sprintf('%.3f', $t)
         . ' -i ' . escapeshellarg($in) . ' -frames:v 1' . $q . ' -y ' . escapeshellarg($dst) . ' 2>&1';
    @exec($cmd, $o, $rc);
    if (!is_file($dst) || filesize($dst) <= 0) { @unlink($dst); throw new CdnError('Kare alınamadı.', 500); }
    [, $mime] = cdnExtInfo($ext);
    try {
        $row = cdnGuard(fn() => db()->insert('cdn_items', [
            'parent_id' => $p['id'] ?? null, 'root' => $root, 'kind' => 'file', 'name' => $name,
            'stored_name' => $stored, 'ext' => $ext, 'mime' => $mime, 'size' => (int)filesize($dst),
            'expires_at' => $root === 'gecici' ? cdnExpiry() : null,
        ]));
    } catch (Throwable $e) { @unlink($dst); throw $e; }
    return ['item' => cdnItemOut($row), 'row' => $row];
}
