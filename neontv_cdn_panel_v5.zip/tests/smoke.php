<?php
// php tests/smoke.php  – iş mantığı testi (sahte veritabanı + gerçek dosya sistemi + ffmpeg)
$tmp = sys_get_temp_dir() . '/cdnt_' . bin2hex(random_bytes(4));
putenv('CDN_DATA_DIR=' . $tmp); putenv('CDN_MIN_FREE_MB=' . (string)(intdiv((int)disk_free_space(sys_get_temp_dir()), 1048576) - 50)); putenv('CDN_TTL_DAYS=60'); putenv('CDN_MAX_UPLOAD_MB=100');
require __DIR__ . '/../lib/bootstrap.php';
require __DIR__ . '/../lib/rest.php';
require __DIR__ . '/../lib/store.php';
require __DIR__ . '/../lib/media.php';
require __DIR__ . '/FakeDb.php';
$GLOBALS['cdn_db'] = new FakeDb;
$fails = 0;
function ok($c, $m) { global $fails; echo ($c ? "OK   " : "FAIL ") . $m . "\n"; if (!$c) $fails++; }
function throws(callable $f, string $needle = ''): bool { try { $f(); return false; } catch (Throwable $e) { return $needle === '' || str_contains($e->getMessage(), $needle); } }

// isim temizleme
ok(cdnCleanName("  a/b\\c\x00 d ") === 'a b c d', 'isim temizleme / ve \\ ve kontrol karakterleri');
ok(throws(fn() => cdnCleanName(' ../ '), 'boş'), 'boş/nokta isim reddedilir');
ok(cdnStripExt('film.MP4', 'mp4') === 'film', 'uzantı soyma');

// klasörler
$a = cdnMkdir('gecici', null, 'Film');
$b = cdnMkdir('gecici', $a['id'], 'Alt');
ok(throws(fn() => cdnMkdir('gecici', null, 'film'), 'zaten var'), 'aynı isim (büyük/küçük harf) engellenir');
ok(throws(fn() => cdnMkdir('kalici', $a['id'], 'x'), 'bulunamadı'), 'yanlış kök altında klasör açılamaz');

// ffmpeg ile gerçek mini video
$vid = $tmp . '_src.mp4';
exec('ffmpeg -nostdin -loglevel error -f lavfi -i testsrc=size=320x240:rate=10 -f lavfi -i sine=frequency=440 -t 4 -shortest -y ' . escapeshellarg($vid), $o, $rc);
ok($rc === 0 && is_file($vid), 'test videosu üretildi');
$size = filesize($vid);

function upload(string $root, ?string $parent, string $file, string $name, int $chunk = 4000) {
    $init = cdnUploadInit($root, $parent, basename($file), filesize($file));
    $fh = fopen($file, 'rb'); $off = 0;
    while (!feof($fh)) {
        $buf = fread($fh, $chunk); if ($buf === '' || $buf === false) break;
        $mem = fopen('php://memory', 'w+'); fwrite($mem, $buf); rewind($mem);
        $off = cdnUploadChunk($init['upload_id'], $off, $mem);
    }
    return [$init, cdnUploadFinish($init['upload_id'], $name)];
}
[$init, $res] = upload('gecici', $b['id'], $vid, 'deneme');
$f = $res['item'];
ok($f['full'] === 'deneme.mp4' && $f['size'] === $size, 'parçalı yükleme tamamlandı, isim+uzantı');
ok($f['days_left'] === 60, 'geçici dosya 60 gün ömürlü (' . $f['days_left'] . ')');
ok(is_file(FILES_DIR . '/' . $res['row']['stored_name']) && filesize(FILES_DIR . '/' . $res['row']['stored_name']) === $size, 'dosya diskte, boyut doğru');
ok(!is_file(TMP_DIR . '/' . $init['upload_id'] . '.part'), 'geçici parça silindi');
ok($init['suggest'] === 'cdnt_' . substr(basename($tmp), 5) . '_src' || is_string($init['suggest']), 'isim önerisi var');

// sıra uyuşmazlığı → 409 + doğru offset
$init2 = cdnUploadInit('kalici', null, 'x.mp4', 100);
$m = fopen('php://memory', 'w+'); fwrite($m, str_repeat('a', 40)); rewind($m);
cdnUploadChunk($init2['upload_id'], 0, $m);
try { $m2 = fopen('php://memory', 'w+'); fwrite($m2, 'b'); rewind($m2); cdnUploadChunk($init2['upload_id'], 0, $m2); ok(false, '409 bekleniyordu'); }
catch (CdnError $e) { ok($e->getCode() === 409 && $e->extra['offset'] === 40, 'offset uyuşmazlığı 409 + offset=40'); }
$m3 = fopen('php://memory', 'w+'); fwrite($m3, str_repeat('c', 100)); rewind($m3);
ok(throws(fn() => cdnUploadChunk($init2['upload_id'], 40, $m3), 'büyük'), 'boyuttan fazla veri reddedilir');
ok(throws(fn() => cdnUploadFinish($init2['upload_id'], 'x'), 'tamamlanmadı'), 'eksik yükleme tamamlanamaz');
cdnUploadAbort($init2['upload_id']);
ok(!is_file(TMP_DIR . '/' . $init2['upload_id'] . '.part'), 'iptal parçayı siler');
ok(throws(fn() => cdnUploadInit('kalici', null, 'virus.php', 10), 'desteklenmiyor'), '.php yüklenemez');
ok(throws(fn() => cdnUploadInit('kalici', null, 'a.mp4', MAX_UPLOAD + 1), 'büyük'), 'boyut sınırı');
ok(throws(fn() => cdnUploadInit('kalici', null, 'a.mp4', 90 * 1048576), 'boş alan'), 'disk dolu kontrolü');
ok(throws(fn() => cdnUploadChunk('../../etc/passwd', 0), 'Geçersiz'), 'yükleme kimliği path traversal reddedilir');

// aynı isim
ok(throws(fn() => upload('gecici', $b['id'], $vid, 'DENEME'), 'zaten var'), 'aynı klasörde aynı isim reddedilir');

// önizleme (ortadan kare)
cdnMakeThumb($res['row']);
$thumb = THUMBS_DIR . '/' . $res['row']['id'] . '.jpg';
ok(is_file($thumb) && filesize($thumb) > 500, 'önizleme karesi üretildi (' . (is_file($thumb) ? filesize($thumb) : 0) . ' bayt)');
$got = cdnGet($res['row']['id']);
ok(!empty($got['has_thumb']) && abs($got['duration'] - 4.0) < 0.5, 'süre ve has_thumb kaydedildi (' . $got['duration'] . ' sn)');

// listeleme: klasörler önce + sayfalama
foreach (['z.txt', 'a.txt'] as $n) { $p = $tmp . '_' . $n; file_put_contents($p, 'merhaba'); upload('gecici', $a['id'], $p, pathinfo($n, PATHINFO_FILENAME)); }
$l = cdnList('gecici', $a['id'], 0, 10);
ok($l[0]['kind'] === 'folder' && $l[1]['full'] === 'a.txt' && $l[2]['full'] === 'z.txt', 'klasör önce, sonra ada göre');
ok(count(cdnList('gecici', $a['id'], 1, 1)) === 1 && cdnList('gecici', $a['id'], 1, 1)[0]['full'] === 'a.txt', 'offset/limit sayfalama');

// yeniden adlandır
$r = cdnRename($f['id'], 'Yeni Ad.mp4');
ok($r['full'] === 'Yeni Ad.mp4', 'yeniden adlandır (uzantı korunur)');
ok(throws(fn() => cdnRename($f['id'], 'a')) === false, 'tekrar adlandırma sorunsuz');

// taşıma: klasör kendi içine
ok(throws(fn() => cdnMove($a['id'], 'gecici', $b['id']), 'kendi içine'), 'klasör kendi alt klasörüne taşınamaz');
// kökler arası taşıma: geçici → kalıcı (süre kalkar)
$mv = cdnMove($a['id'], 'kalici', null);
$inner = cdnGet($f['id']);
ok($inner['root'] === 'kalici' && $inner['expires_at'] === null, 'kalıcıya taşıyınca alt dosyalarda süre kalktı');
ok(cdnItemOut($inner)['days_left'] === null, 'days_left boş');
// kalıcı → geçici (yeni 60 gün)
cdnMove($a['id'], 'gecici', null);
$inner = cdnGet($f['id']);
ok($inner['root'] === 'gecici' && cdnItemOut($inner)['days_left'] === 60, 'geçiciye taşıyınca 60 gün başladı');
// dosyayı klasör dışına taşı
$m4 = cdnMove($f['id'], 'kalici', null);
ok($m4['days_left'] === null && cdnGet($f['id'])['parent_id'] === null, 'tek dosya kalıcı ana klasöre taşındı');
$st = cdnStats();
ok($st['kalici']['files'] === 1 && $st['gecici']['files'] === 2, 'istatistik doğru');

// videodan ekran görüntüsü (seçilen an, seçilen klasör, ad + uzantı)
$k = cdnMkdir('kalici', null, 'Kareler');
$sn = cdnSnap($f['id'], 2.0, 'kalici', $k['id'], 'kare-2sn', 'png');
ok($sn['item']['full'] === 'kare-2sn.png' && $sn['item']['type'] === 'image', 'ekran görüntüsü: ad + uzantı doğru');
$sp = FILES_DIR . '/' . $sn['row']['stored_name'];
ok(is_file($sp) && substr((string)file_get_contents($sp, false, null, 0, 4), 1, 3) === 'PNG', 'ekran görüntüsü gerçek PNG');
ok(cdnGet($sn['row']['id'])['parent_id'] === $k['id'] && cdnGet($sn['row']['id'])['root'] === 'kalici', 'seçilen klasöre kaydedildi');
$sn2 = cdnSnap($f['id'], 1.0, 'gecici', null, 'kare-gecici', 'jpg');
ok($sn2['item']['days_left'] === 60, 'geçiciye kaydedilen görüntü 60 gün ömürlü');
ok(throws(fn() => cdnSnap($f['id'], 1.0, 'kalici', null, 'x', 'exe'), 'Uzantı'), 'geçersiz uzantı reddedilir');
ok(throws(fn() => cdnSnap($sn['row']['id'], 1.0, 'kalici', null, 'x', 'jpg'), 'videodan'), 'resimden görüntü alınamaz');
ok(throws(fn() => cdnSnap($f['id'], 1.0, 'kalici', $k['id'], 'kare-2sn', 'png'), 'zaten var'), 'aynı ad çakışması engellenir');
cdnDelete($sn['row']['id']); cdnDelete($sn2['row']['id']); cdnDelete($k['id']);

// süresi dolanları sil
$id2 = cdnList('gecici', $a['id'], 0, 10)[1]['id'];
$GLOBALS['cdn_db']->update('cdn_items', ['id' => 'eq.' . $id2], ['expires_at' => date('c', time() - 10)]);
$stored2 = cdnGet($id2)['stored_name'];
$pg = cdnPurgeExpired();
ok($pg['files'] === 1 && cdnGet($id2) === null && !is_file(FILES_DIR . '/' . $stored2), 'süresi dolan dosya diskten ve DB’den silindi');
ok(cdnGet($f['id']) !== null, 'kalıcı dosya dokunulmadı');

// klasör silme (içindekilerle)
$del = cdnDelete($a['id']);
ok($del['files'] === 1 && count(glob(FILES_DIR . '/*')) === 1, 'klasör silinince içindeki dosyalar da silindi, kalıcı dosya kaldı');
ok(count(glob(FILES_DIR . '/*')) === 1, 'diskte yalnızca kalıcı dosya var');
cdnDelete($f['id']);
ok(count(glob(FILES_DIR . '/*')) === 0 && !is_file($thumb), 'dosya + önizleme silindi');
exec('rm -rf ' . escapeshellarg($tmp) . ' ' . escapeshellarg($vid) . ' ' . escapeshellarg($tmp . '_z.txt') . ' ' . escapeshellarg($tmp . '_a.txt'));
echo $fails ? "\n$fails HATA\n" : "\nTÜM TESTLER GEÇTİ\n";
exit($fails ? 1 : 0);
