<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/rest.php';
require __DIR__ . '/lib/store.php';
require __DIR__ . '/lib/media.php';
require __DIR__ . '/lib/fetch.php';

requireAuth(true);
$isPost = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
if ($isPost && !csrfValid($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null)) jsonFail(403, 'Güvenlik doğrulaması başarısız. Sayfayı yenileyin.');
session_write_close(); // oturum kilidi diğer istekleri bekletmesin

$a = (string)($_GET['a'] ?? '');
$in = [];
if ($isPost && $a !== 'upload_chunk') {
    $in = json_decode((string)file_get_contents('php://input'), true);
    if (!is_array($in)) $in = [];
}
$str = fn($k) => isset($in[$k]) && is_string($in[$k]) ? $in[$k] : '';
$parentOf = fn($v) => (is_string($v) && $v !== '') ? $v : null;

try {
    switch ($a) {
        case 'list':
            $root = (string)($_GET['root'] ?? '');
            cdnParent($root, null);
            $parent = $parentOf($_GET['parent'] ?? '');
            if ($parent !== null) cdnParent($root, $parent);
            $limit = max(1, min(60, (int)($_GET['limit'] ?? 36)));
            $offset = max(0, (int)($_GET['offset'] ?? 0));
            jsonOut(['items' => cdnList($root, $parent, $offset, $limit)]);

        case 'folders':
            jsonOut(['folders' => cdnFolders((string)($_GET['root'] ?? ''))]);

        case 'mkdir':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            jsonOut(['item' => cdnMkdir($str('root'), $parentOf($in['parent'] ?? null), $str('name'))]);

        case 'rename':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            jsonOut(['item' => cdnRename($str('id'), $str('name'))]);

        case 'move':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            jsonOut(['item' => cdnMove($str('id'), $str('root'), $parentOf($in['parent'] ?? null))]);

        case 'delete':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            jsonOut(cdnDelete($str('id')));

        case 'upload_init':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            jsonOut(cdnUploadInit($str('root'), $parentOf($in['parent'] ?? null), $str('filename'), (int)($in['size'] ?? 0)));

        case 'upload_chunk':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            jsonOut(['offset' => cdnUploadChunk((string)($_GET['id'] ?? ''), (int)($_GET['offset'] ?? -1))]);

        case 'bulk':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            jsonOut(cdnBulk($str('op'), is_array($in['ids'] ?? null) ? $in['ids'] : [], $str('root'), $parentOf($in['parent'] ?? null)));

        case 'search':
            $limit = max(1, min(60, (int)($_GET['limit'] ?? 36)));
            jsonOut(['items' => cdnSearch((string)($_GET['root'] ?? ''), (string)($_GET['q'] ?? ''), max(0, (int)($_GET['offset'] ?? 0)), $limit)]);

        case 'snap':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            $res = cdnSnap($str('id'), (float)($in['time'] ?? 0), $str('root'), $parentOf($in['parent'] ?? null), $str('name'), $str('ext'));
            jsonOut(['item' => $res['item']], 200, false);
            ignore_user_abort(true);
            if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();
            else { @ob_flush(); @flush(); }
            cdnMakeThumb($res['row']);
            exit;

        case 'url_start':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            $res = cdnFetchStart($str('root'), $parentOf($in['parent'] ?? null), $str('url'));
            if (cdnFetchSpawn($res['upload_id'])) jsonOut($res);
            jsonOut($res, 200, false); // CLI yoksa: yanıttan sonra aynı istekte indir
            ignore_user_abort(true);
            if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();
            else { @ob_flush(); @flush(); }
            cdnFetchRun($res['upload_id']);
            exit;

        case 'url_status':
            jsonOut(cdnStGet((string)($_GET['id'] ?? '')));

        case 'upload_abort':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            cdnUploadAbort($str('id'));
            jsonOut([]);

        case 'upload_finish':
            if (!$isPost) jsonFail(405, 'POST gerekli.');
            $res = cdnUploadFinish($str('id'), $str('name'));
            jsonOut(['item' => $res['item']], 200, false);
            // Yanıt gönderildikten sonra, düşük öncelikle önizleme karesi üretilir
            ignore_user_abort(true);
            if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();
            else { @ob_flush(); @flush(); }
            @set_time_limit(90);
            cdnMakeThumb($res['row']);
            exit;

        default:
            jsonFail(404, 'Bilinmeyen işlem.');
    }
} catch (CdnError $e) {
    jsonFail($e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 400, $e->getMessage(), $e->extra);
} catch (DbError $e) {
    jsonFail(502, 'Veritabanı hatası. Ayrıntı sunucu günlüğünde.');
} catch (Throwable $e) {
    error_log('[cdn] ' . get_class($e) . ': ' . $e->getMessage() . ' @' . basename($e->getFile()) . ':' . $e->getLine());
    jsonFail(500, 'Sunucu hatası.');
}
