<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/rest.php';
require __DIR__ . '/lib/store.php';
requireAuth(false);

$root = (string)($_GET['root'] ?? '');
if (!isset(CDN_ROOTS[$root])) { header('Location: index.php'); exit; }
$dir = (string)($_GET['dir'] ?? '');
$crumbs = [];
$cur = null;
try {
    if ($dir !== '') {
        $cur = cdnGet($dir);
        if (!$cur || $cur['kind'] !== 'folder' || $cur['root'] !== $root) { header('Location: folder.php?root=' . urlencode($root)); exit; }
        $c = $cur; $g = 0;
        while ($c && $g++ < 30) { array_unshift($crumbs, $c); $c = !empty($c['parent_id']) ? cdnGet((string)$c['parent_id']) : null; }
    }
} catch (Throwable $e) {
    error_log('[cdn] folder: ' . get_class($e));
}
$up = $cur && !empty($cur['parent_id']) ? 'folder.php?root=' . urlencode($root) . '&dir=' . urlencode((string)$cur['parent_id'])
    : ($cur ? 'folder.php?root=' . urlencode($root) : 'index.php');

pageHead(CDN_ROOTS[$root] . ' – CDN', 'class="folder" data-root="' . e($root) . '" data-dir="' . e($dir) . '" data-csrf="' . e(csrfToken()) . '" data-base="' . e(PUBLIC_URL) . '" data-ttl="' . TTL_DAYS . '"');
?>
<header class="top">
  <a class="btn sm icon" href="<?= e($up) ?>" aria-label="Geri">‹</a>
  <nav class="crumbs">
    <a href="folder.php?root=<?= e($root) ?>"><?= e(CDN_ROOTS[$root]) ?></a>
    <?php foreach ($crumbs as $c): ?> <i>›</i> <a href="folder.php?root=<?= e($root) ?>&dir=<?= e($c['id']) ?>"><?= e($c['name']) ?></a><?php endforeach; ?>
  </nav>
  <div class="actions">
    <button class="btn sm" id="selBtn" type="button">Seç</button>
    <button class="btn sm" id="newFolder" type="button">+ Klasör</button>
    <button class="btn sm" id="urlBtn" type="button">Bağlantıdan</button>
    <button class="btn sm pri" id="uploadBtn" type="button">Yükle</button>
    <input type="file" id="fileInput" multiple hidden accept="video/*,audio/*,image/*,.mkv,.ts,.srt,.vtt,.txt,.opus,.flac">
  </div>
</header>
<main class="wrap">
  <input id="q" class="inp" type="search" placeholder="Ara (en az 2 harf; bu bölümdeki tüm klasörlerde)…" autocomplete="off" style="width:100%;margin-bottom:12px">
  <?php if ($root === 'gecici'): ?><div class="info">Bu bölümdeki dosyalar yüklendikten <?= TTL_DAYS ?> gün sonra otomatik silinir.</div><?php endif; ?>
  <div id="grid" class="grid"></div>
  <div id="empty" class="empty" hidden>Bu klasör boş.</div>
  <div id="sentinel" class="sentinel"><span class="spin"></span></div>
</main>
<div id="selbar" class="selbar" hidden><span class="selcount">0 seçili</span><button class="btn sm" id="selAll" type="button">Tümü</button><button class="btn sm" id="selMove" type="button" disabled>Taşı</button><button class="btn sm bad" id="selDel" type="button" disabled>Sil</button></div>
<div id="prog" class="prog" hidden><div class="progname"></div><div class="bar"><i></i></div></div>
<div id="toast" class="toast" hidden></div>
<script src="assets/app.js?v=<?= e((string)@filemtime(__DIR__ . '/assets/app.js')) ?>"></script>
</body></html>
