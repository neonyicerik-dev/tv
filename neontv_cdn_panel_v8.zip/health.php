<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/rest.php';
require __DIR__ . '/lib/store.php';
require __DIR__ . '/lib/media.php';
require __DIR__ . '/lib/traffic.php';
requireAuth(false);

$msg = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!csrfValid($_POST['csrf'] ?? null)) { $msg = 'Güvenlik doğrulaması başarısız.'; }
    elseif (($_POST['do'] ?? '') === 'orphans') {
        try { $r = cdnCleanOrphans(); $msg = $r['removed'] . ' yetim dosya silindi (' . fmtBytes((int)$r['bytes']) . ').'; }
        catch (Throwable $e) { $msg = 'Temizlik başarısız: ' . get_class($e); }
    }
}

$checks = [];
$add = function (string $n, string $v, string $l = 'ok', string $h = '') use (&$checks) { $checks[] = [$n, $v, $l, $h]; };

// Veritabanı
$lat = []; $dbOk = true; $dbErr = '';
for ($i = 0; $i < 3; $i++) {
    $t = microtime(true);
    try { db()->select('cdn_items', ['select' => 'id', 'limit' => 1]); } catch (Throwable $e) { $dbOk = false; $dbErr = get_class($e); break; }
    $lat[] = (int)round((microtime(true) - $t) * 1000);
}
$add('Veritabanı (Supabase)', $dbOk ? 'Çalışıyor' : 'ULAŞILAMIYOR (' . $dbErr . ')', $dbOk ? 'ok' : 'bad', $dbOk ? '' : 'secrets.php: SUPABASE_URL / SUPABASE_SERVICE_KEY ve cdn_supabase.sql çalıştırıldı mı?');
if ($lat) { $avg = (int)round(array_sum($lat) / count($lat)); $add('Veritabanı gecikmesi', implode(' / ', $lat) . ' ms (ort. ' . $avg . ')', $avg > 400 ? 'bad' : ($avg > 150 ? 'warn' : 'ok'), $avg > 150 ? 'Supabase bölgesini bu sunucuya yakın seçin.' : ''); }

// Disk
$free = (int)(@disk_free_space(DATA_DIR) ?: 0); $total = (int)(@disk_total_space(DATA_DIR) ?: 0); $pct = $total ? (int)round(($total - $free) / $total * 100) : 0;
$add('Disk', fmtBytes($free) . ' boş / ' . fmtBytes($total) . ' (%' . $pct . ' dolu)', ($total && $free < MIN_FREE) || $pct >= 92 ? 'bad' : ($pct >= 80 ? 'warn' : 'ok'), $free < MIN_FREE ? 'Boş alan eşiğin altında: yeni yüklemeler reddedilir.' : '');
$ino = function_exists('disk_free_space') ? @shell_exec('df -i ' . escapeshellarg(DATA_DIR) . ' 2>/dev/null | tail -1') : '';
if (is_string($ino) && preg_match('/(\d+)%/', $ino, $im)) $add('Inode doluluğu', '%' . $im[1], (int)$im[1] >= 90 ? 'bad' : ((int)$im[1] >= 75 ? 'warn' : 'ok'));

// Klasörler
foreach (['files' => FILES_DIR, 'thumbs' => THUMBS_DIR, 'tmp' => TMP_DIR] as $n => $p) {
    if (!is_dir($p)) @mkdir($p, 0775, true);
    $w = is_writable($p);
    $add('Yazma izni: ' . $n, $w ? 'Yazılabilir' : 'YAZILAMIYOR', $w ? 'ok' : 'bad', $w ? '' : 'chown -R www-data:www-data ' . DATA_DIR . ' (dosya silme de buna bağlı)');
}
// Araçlar
foreach (['ffmpeg', 'ffprobe', 'nice'] as $b) { $ok = (bool)cdnBin($b); $add('Araç: ' . $b, $ok ? 'Var' : 'Yok', $ok ? 'ok' : ($b === 'nice' ? 'warn' : 'bad'), $ok ? '' : ($b === 'nice' ? '' : 'apt install ffmpeg')); }
$add('PHP', PHP_VERSION . ' · upload_max ' . ini_get('upload_max_filesize') . ' · post_max ' . ini_get('post_max_size'), (int)ini_get('post_max_size') >= 16 || ini_get('post_max_size') === '0' ? 'ok' : 'warn', 'Parçalı yükleme için post_max_size ≥ 16M olmalı.');
$add('exec/shell_exec', function_exists('exec') && function_exists('shell_exec') ? 'Açık' : 'KAPALI', function_exists('exec') && function_exists('shell_exec') ? 'ok' : 'bad', 'Önizleme, ses ve ekran görüntüsü için gerekli (disable_functions).');
// Günlük / trafik
$logp = cdnTrafficLogPath(); $lr = is_file($logp) && is_readable($logp);
$add('Trafik günlüğü', $lr ? 'Okunuyor (' . fmtBytes((int)filesize($logp)) . ')' : 'Okunamıyor: ' . $logp, $lr ? 'ok' : 'warn', $lr ? '' : 'nginx-cdn.conf içindeki access_log satırını ekleyin.');
// Cloudflare temizliği
$cf = cfg('CF_ZONE_ID', '') !== '' && cfg('CF_API_TOKEN', '') !== '';
$add('Cloudflare önbellek temizliği', $cf ? 'Açık (silinen dosya uçtan da kalkar)' : 'Kapalı', $cf ? 'ok' : 'warn', $cf ? '' : 'Cloudflare arkasındaysanız secrets.php: CF_ZONE_ID ve CF_API_TOKEN (yalnızca "Cache Purge" izni) tanımlayın; yoksa silinen dosya önbellekte bir süre görünebilir.');
// Öğe sayıları + yetimler
$orph = ['files' => [], 'thumbs' => []];
if ($dbOk) {
    try { $orph = cdnOrphans(); $st = cdnStats(); $add('Kayıtlar', 'Kalıcı ' . $st['kalici']['files'] . ' dosya · Geçici ' . $st['gecici']['files'] . ' dosya', 'ok'); } catch (Throwable $e) { $add('Kayıtlar', 'Okunamadı', 'warn'); }
}
$on = count($orph['files']) + count($orph['thumbs']);
$ob = 0; foreach ($orph['files'] as $f) $ob += (int)@filesize($f);
$add('Yetim dosya (kaydı olmayan)', $on ? $on . ' dosya · ' . fmtBytes($ob) : 'Yok', $on ? 'warn' : 'ok', $on ? 'Veritabanında karşılığı olmayan, diski gereksiz dolduran dosyalar. Aşağıdan silebilirsiniz.' : '');
$add('Geçici ve yarım yüklemeler', count(glob(TMP_DIR . '/*') ?: []) . ' dosya', 'ok');

$col = ['ok' => '#39ff14', 'warn' => '#ffd76a', 'bad' => '#ff4d6d'];
pageHead('Sağlık – CDN');
?>
<header class="top"><a class="btn sm icon" href="index.php" aria-label="Geri">‹</a><div class="brand">Sunucu sağlığı</div></header>
<main class="wrap">
<?php if ($msg): ?><div class="info"><?= e($msg) ?></div><?php endif; ?>
<div class="disk" style="padding:0">
<?php foreach ($checks as [$n, $v, $l, $h]): ?>
  <div style="display:flex;gap:10px;padding:10px 14px;border-bottom:1px solid var(--line);font-size:14px"><span style="margin-top:6px;width:10px;height:10px;border-radius:50%;flex:none;background:<?= $col[$l] ?>"></span>
  <div style="min-width:0"><b><?= e($n) ?></b><div style="word-break:break-word"><?= e($v) ?></div><?php if ($h): ?><div style="color:var(--mut);font-size:12px;margin-top:2px"><?= e($h) ?></div><?php endif; ?></div></div>
<?php endforeach; ?>
</div>
<?php if ($on): ?><form method="post" style="margin-top:12px" onsubmit="return confirm('Kaydı olmayan <?= (int)$on ?> dosya kalıcı olarak silinecek. Emin misiniz?')"><input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>"><input type="hidden" name="do" value="orphans"><button class="btn bad" type="submit">Yetim dosyaları sil (<?= (int)$on ?>)</button></form><?php endif; ?>
</main></body></html>
