<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/rest.php';
require __DIR__ . '/lib/store.php';
require __DIR__ . '/lib/media.php';
requireAuth(false);

$dbErr = false;
try { $stats = cdnStats(); } catch (Throwable $e) { $stats = []; $dbErr = true; error_log('[cdn] stats: ' . get_class($e)); }
$free = (int)(@disk_free_space(DATA_DIR) ?: 0);
$total = (int)(@disk_total_space(DATA_DIR) ?: 0);
$usedPct = $total > 0 ? (int)round(($total - $free) / $total * 100) : 0;
$warn = [];
if ($dbErr) $warn[] = 'Veritabanına ulaşılamıyor; SUPABASE_URL / SUPABASE_SERVICE_KEY ve tabloları kontrol edin.';
if (!is_writable(FILES_DIR)) $warn[] = 'Depolama klasörü yazılamıyor: ' . FILES_DIR;
if (!cdnBin('ffmpeg')) $warn[] = 'ffmpeg bulunamadı; video önizleme kareleri üretilemez (apt install ffmpeg).';
if ($total > 0 && $free < MIN_FREE) $warn[] = 'Boş disk alanı kritik seviyede; yeni yüklemeler reddedilir.';
$csrf = csrfToken();

pageHead('CDN Paneli', 'class="home"');
?>
<header class="top">
  <div class="brand">NeonTV <span>CDN</span></div>
  <a class="btn sm" href="traffic.php">Trafik</a> <a class="btn sm" href="health.php">Sağlık</a>
  <form method="post" action="logout.php"><input type="hidden" name="csrf" value="<?= e($csrf) ?>"><button class="btn sm" type="submit">Çıkış</button></form>
</header>
<main class="wrap">
  <?php foreach ($warn as $w): ?><div class="notice"><?= e($w) ?></div><?php endforeach; ?>

  <section class="disk">
    <div class="diskrow"><span>Disk</span><span><?= e(fmtBytes($free)) ?> boş / <?= e(fmtBytes($total)) ?></span></div>
    <div class="bar"><i style="width:<?= $usedPct ?>%" class="<?= $usedPct >= 90 ? 'hot' : '' ?>"></i></div>
  </section>

  <div class="roots">
    <?php foreach (CDN_ROOTS as $key => $label): $s = $stats[$key] ?? ['files' => 0, 'bytes' => 0, 'folders' => 0]; ?>
      <a class="rootcard <?= e($key) ?>" href="folder.php?root=<?= e($key) ?>">
        <svg viewBox="0 0 24 24" width="44" height="44" fill="currentColor"><path d="M10 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8l-2-2z"/></svg>
        <div>
          <h2><?= e($label) ?></h2>
          <p><?= (int)$s['files'] ?> dosya · <?= (int)$s['folders'] ?> klasör · <?= e(fmtBytes((int)$s['bytes'])) ?></p>
          <small><?= $key === 'gecici' ? 'Yüklendikten ' . TTL_DAYS . ' gün sonra otomatik silinir' : 'Süresiz saklanır' ?></small>
        </div>
      </a>
    <?php endforeach; ?>
  </div>
</main>
</body></html>
