<?php
declare(strict_types=1);
// Sunucudan sunucuya görsel yükleme (NeonTV -> CDN). Tarayıcı oturumu gerekmez; gizli anahtarla korunur.
// POST multipart: file=<resim>, kind=avatar|cover|logo|banner, owner=<kullanıcı/kanal id>, replace=<eski CDN adresi, ops.>
// Başlık: X-Ingest-Key: <CDN_INGEST_KEY>
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/rest.php';
require __DIR__ . '/lib/store.php';
require __DIR__ . '/lib/media.php';
securityHeaders();

$key = (string)cfg('CDN_INGEST_KEY', '');
if (strlen($key) < 24) { http_response_code(404); exit; }                       // anahtar tanımlı değilse uç nokta yok sayılır
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); exit; }
if (!hash_equals($key, (string)($_SERVER['HTTP_X_INGEST_KEY'] ?? ''))) {
    usleep(300000); error_log('[cdn] ingest: geçersiz anahtar ' . clientIp());
    jsonFail(403, 'Yetkisiz.');
}
try {
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($_FILES['file']['tmp_name'])) jsonFail(400, 'Dosya alınamadı.');
    $res = cdnIngestImage($_FILES['file']['tmp_name'], (string)($_POST['kind'] ?? ''), (string)($_POST['owner'] ?? ''));
    $old = (string)($_POST['replace'] ?? '');
    if ($old !== '') { try { cdnIngestReplace($old, $res['folder_id']); } catch (Throwable $e) { error_log('[cdn] ingest replace: ' . get_class($e)); } }
    jsonOut(['url' => $res['url']]);
} catch (CdnError $e) {
    jsonFail($e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 400, $e->getMessage());
} catch (DbError $e) {
    jsonFail(502, 'Veritabanı hatası.');
} catch (Throwable $e) {
    error_log('[cdn] ingest: ' . get_class($e) . ': ' . $e->getMessage());
    jsonFail(500, 'Sunucu hatası.');
}
