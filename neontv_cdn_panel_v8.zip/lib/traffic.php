<?php
declare(strict_types=1);
// İndirme / bant genişliği sayacı: Nginx dosya günlüğünü (/f/ istekleri) artımlı okuyup JSON'a toplar. SQL gerekmez.
// Günlük biçimi (deploy/nginx-cdn.conf): $remote_addr [$time_iso8601] "$request_uri" $status $body_bytes_sent

function cdnTrafficLogPath(): string { return (string)cfg('CDN_ACCESS_LOG', '/var/log/nginx/cdn_files.log'); }
function cdnTrafficFile(): string { return DATA_DIR . '/traffic.json'; }

/** Günlüğün yeni satırlarını işler. @return array özet durum */
function cdnTrafficSync(int $maxBytes = 25 * 1048576): array {
    $log = cdnTrafficLogPath();
    $st = ['pos' => 0, 'ino' => 0, 'days' => [], 'files' => [], 'seen' => [], 'seenDay' => ''];
    $tf = cdnTrafficFile();
    $lock = @fopen($tf . '.lock', 'c');
    if ($lock) flock($lock, LOCK_EX);
    try {
        if (is_file($tf)) { $j = json_decode((string)file_get_contents($tf), true); if (is_array($j)) $st = array_merge($st, $j); }
        $out = ['readable' => false, 'path' => $log];
        if (!is_file($log) || !is_readable($log)) return $out + ['state' => $st];
        $out['readable'] = true;
        clearstatcache(true, $log);
        $size = (int)filesize($log); $ino = (int)@fileinode($log);
        if ($ino !== (int)$st['ino'] || $size < (int)$st['pos']) { $st['pos'] = 0; $st['ino'] = $ino; }
        if ($size > $st['pos']) {
            $fh = fopen($log, 'rb'); fseek($fh, (int)$st['pos']);
            $buf = (string)fread($fh, $maxBytes); fclose($fh);
            $cut = strrpos($buf, "\n");
            if ($cut !== false) {
                $buf = substr($buf, 0, $cut + 1);
                $st['pos'] += strlen($buf);
                $seen = array_flip($st['seen']);
                foreach (explode("\n", $buf) as $ln) {
                    if ($ln === '' || !preg_match('/^(\S+) \[(\d{4}-\d{2}-\d{2})T[^\]]*\] "([^"]*)" (\d{3}) (\d+)/', $ln, $m)) continue;
                    [, $ip, $day, $uri, $code, $bytes] = $m; $code = (int)$code;
                    if (($code !== 200 && $code !== 206) || !preg_match('#^/f/([a-f0-9]{32})\.[a-z0-9]{1,5}#', $uri, $fm)) continue;
                    if ($st['seenDay'] !== $day) { $st['seenDay'] = $day; $seen = []; }
                    $k = substr(md5($ip . '|' . $fm[1]), 0, 12);
                    // İzleme sırasında çok sayıda 206 (Range) gelir: aynı IP+dosya günde bir kez "izlenme" sayılır; bayt hepsinde toplanır
                    $hit = ($code === 200) || !isset($seen[$k]);
                    $seen[$k] = 1;
                    $d = &$st['days'][$day]; $d = $d ?? [0, 0]; if ($hit) $d[0]++; $d[1] += (int)$bytes; unset($d);
                    $f = &$st['files'][$fm[1]]; $f = $f ?? [0, 0]; if ($hit) $f[0]++; $f[1] += (int)$bytes; unset($f);
                }
                $st['seen'] = array_slice(array_keys($seen), -30000);
            }
            krsort($st['days']); $st['days'] = array_slice($st['days'], 0, 90, true);
            if (count($st['files']) > 5000) { uasort($st['files'], fn($a, $b) => $b[1] <=> $a[1]); $st['files'] = array_slice($st['files'], 0, 4000, true); }
            @file_put_contents($tf, json_encode($st), LOCK_EX);
        }
        return $out + ['state' => $st];
    } finally {
        if ($lock) { flock($lock, LOCK_UN); fclose($lock); }
    }
}
