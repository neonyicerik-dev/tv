<?php
// Bu dosyayı secrets.php olarak kopyalayıp doldurun. secrets.php git'e eklenmez ve web'den erişime kapalıdır.
putenv('SUPABASE_URL=https://PROJE.supabase.co');
putenv('SUPABASE_SERVICE_KEY=');          // service_role anahtarı (yalnızca sunucuda)
putenv('CDN_ADMIN_HASH=');                // php tools/hash.php çıktısı
putenv('CDN_DATA_DIR=/srv/cdn/data');
putenv('CDN_PUBLIC_URL=');                // boşsa panelle aynı alan adı kullanılır, örn. https://cdn.neontvapp.dpdns.org
putenv('CDN_TTL_DAYS=60');
putenv('CDN_MIN_FREE_MB=2048');           // bu kadar boş alan kalmazsa yükleme reddedilir
putenv('CF_ZONE_ID=');                 // (isteğe bağlı) Cloudflare arkasındaysanız: silinen dosya uçtan da anında temizlensin
putenv('CF_API_TOKEN=');                // yalnızca "Cache Purge" izinli token
putenv('CDN_ACCESS_LOG=/var/log/nginx/cdn_files.log'); // trafik sayacının okuyacağı Nginx günlüğü
putenv('CDN_INGEST_KEY=');            // NeonTV'nin profil/kanal görseli yüklemesi için gizli anahtar (en az 24 karakter, rastgele). NeonTV'deki CDN_INGEST_KEY ile AYNI olmalı; boşsa ingest.php kapalıdır
