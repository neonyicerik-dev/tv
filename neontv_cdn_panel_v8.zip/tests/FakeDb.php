<?php
// Yalnızca yerel test için: PostgREST davranışının küçük bir taklidi (üretimde kullanılmaz)
class FakeDb {
    public array $rows = [];
    private function uuid(): string { $d = random_bytes(16); $d[6] = chr(ord($d[6]) & 0x0f | 0x40); $d[8] = chr(ord($d[8]) & 0x3f | 0x80); return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($d), 4)); }
    private function match(array $r, array $f): bool {
        foreach ($f as $k => $v) {
            if (in_array($k, ['select', 'order', 'limit', 'offset'], true)) continue;
            [$op, $arg] = explode('.', (string)$v, 2); $val = $r[$k] ?? null;
            switch ($op) {
                case 'eq': if ((string)$val !== $arg) return false; break;
                case 'in': if (!in_array((string)$val, explode(',', trim($arg, '()')), true)) return false; break;
                case 'is': if ($arg === 'null' && $val !== null) return false; break;
                case 'ilike': if (!preg_match('/^' . str_replace('\\*', '.*', preg_quote($arg, '/')) . '$/iu', (string)$val)) return false; break;
                case 'not': [$o2, $a2] = explode('.', $arg, 2); if ($o2 === 'in' && in_array((string)$val, explode(',', trim($a2, '()')), true)) return false; break;
                case 'lt': if ($val === null || strtotime((string)$val) >= strtotime($arg)) return false; break;
                default: throw new Exception("op $op");
            }
        }
        return true;
    }
    private function key(array $r): string { return $r['root'] . '|' . ($r['parent_id'] ?? '0') . '|' . strtolower($r['name']) . '|' . strtolower($r['ext'] ?? ''); }
    private function checkUnique(array $cand, ?string $selfId): void {
        foreach ($this->rows as $r) if ($r['id'] !== $selfId && $this->key($r) === $this->key($cand)) { $e = new DbError('dup'); $e->pg = '23505'; throw $e; }
    }
    public function select(string $t, array $p = []): array {
        $rows = array_values(array_filter($this->rows, fn($r) => $this->match($r, $p)));
        if (!empty($p['order'])) {
            $ord = array_map(fn($x) => explode('.', $x), explode(',', $p['order']));
            usort($rows, function ($a, $b) use ($ord) { foreach ($ord as [$c, $d]) { $x = $a[$c] ?? ''; $y = $b[$c] ?? ''; $r = strcmp((string)$x, (string)$y); if ($r) return $d === 'desc' ? -$r : $r; } return 0; });
        }
        return array_slice($rows, (int)($p['offset'] ?? 0), isset($p['limit']) ? (int)$p['limit'] : null);
    }
    public function insert(string $t, array $row): array {
        $row += ['parent_id' => null, 'stored_name' => null, 'ext' => null, 'mime' => null, 'size' => 0, 'duration' => null, 'has_thumb' => false, 'expires_at' => null];
        $row['id'] = $this->uuid(); $row['created_at'] = date('c');
        $this->checkUnique($row, null);
        $this->rows[] = $row; return $row;
    }
    public function update(string $t, array $f, array $d): array {
        $out = [];
        foreach ($this->rows as $i => $r) if ($this->match($r, $f)) { $n = array_merge($r, $d); $this->checkUnique($n, $r['id']); $this->rows[$i] = $n; $out[] = $n; }
        return $out;
    }
    public function delete(string $t, array $f): array {
        $ids = [];
        foreach ($this->rows as $r) if ($this->match($r, $f)) $ids[] = $r['id'];
        for ($c = true; $c;) { $c = false; foreach ($this->rows as $r) if (!in_array($r['id'], $ids, true) && in_array($r['parent_id'], $ids, true)) { $ids[] = $r['id']; $c = true; } }
        $this->rows = array_values(array_filter($this->rows, fn($r) => !in_array($r['id'], $ids, true)));
        return array_map(fn($i) => ['id' => $i], $ids);
    }
    public function rpc(string $fn, array $a = []): array {
        if ($fn === 'cdn_descendants') {
            $out = []; $queue = [$a['p']];
            while ($queue) { $id = array_shift($queue); foreach ($this->rows as $r) { if ($r['id'] === $id) $out[] = $r; if ($r['parent_id'] === $id) $queue[] = $r['id']; } }
            // kök satır ilk, sonra alt öğeler (sıra önemsiz)
            return $out;
        }
        if ($fn === 'cdn_stats') {
            $g = [];
            foreach ($this->rows as $r) { $x = &$g[$r['root']]; $x ??= ['root' => $r['root'], 'files' => 0, 'bytes' => 0, 'folders' => 0]; if ($r['kind'] === 'file') { $x['files']++; $x['bytes'] += $r['size']; } else $x['folders']++; unset($x); }
            return array_values($g);
        }
        throw new Exception('rpc ' . $fn);
    }
}
