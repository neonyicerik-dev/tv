<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/rest.php';
require __DIR__ . '/lib/store.php';
require __DIR__ . '/lib/traffic.php';
requireAuth(false);

$r = cdnTrafficSync(); $st = $r['state'] ?? ['days' => [], 'files' => []];
$days = $st['days']; $sum = function (int $n) use ($days) { $h = 0; $b = 0; $i = 0; foreach ($days as $d => $v) { if ($i++ >= $n) break; $h += $v[0]; $b += $v[1]; } return [$h, $b]; };
$today = date('Y-m-d'); $t0 = $days[$today] ?? [0, 0]; $w = $sum(7); $m = $sum(30);
$series = []; for ($i = 13; $i >= 0; $i--) { $d = date('Y-m-d', time() - $i * 86400); $series[$d] = $days[$d] ?? [0, 0]; }
$max = max(1, ...array_values(array_map(fn($v) => $v[1], $series)));
$files = $st['files']; uasort($files, fn($a, $b) => $b[1] <=> $a[1]); $top = array_slice($files, 0, 20, true);
$names = [];
if ($top) {
    // stored_name uzantılıdır; kodlara göre eşleştirmek için ilike önek araması yerine tüm uzantıları dene
    $cands = []; foreach (array_keys($top) as $c) foreach (array_merge(...array_values(array_map('array_keys', CDN_TYPES))) as $x) $cands[] = $c . '.' . $x;
    try {
        foreach (array_chunk($cands, 150) as $ch) foreach (db()->select('cdn_items', ['select' => 'name,ext,stored_name,root', 'stored_name' => 'in.(' . implode(',', $ch) . ')']) as $x) $names[substr((string)$x['stored_name'], 0, 32)] = $x;
    } catch (Throwable $e) { error_log('[cdn] traffic names: ' . get_class($e)); }
}
pageHead('Trafik – CDN');
?>
<header class="top"><a class="btn sm icon" href="index.php" aria-label="Geri">‹</a><div class="brand">Trafik</div></header>
<main class="wrap">
<?php if (!$r['readable']): ?><div class="notice">Nginx dosya günlüğü okunamıyor: <?= e($r['path']) ?><br>deploy/nginx-cdn.conf içindeki <code>access_log</code> satırını ekleyin ve php-fpm kullanıcısının okuyabildiğinden emin olun (<code>chmod 644</code> veya <code>setfacl -m u:www-data:r</code>). Sayaç, günlük eklendiği andan itibaren saymaya başlar.</div><?php endif; ?>
<div class="roots">
  <div class="rootcard"><div><h2>Bugün</h2><p><?= (int)$t0[0] ?> izlenme · <?= e(fmtBytes((int)$t0[1])) ?></p></div></div>
  <div class="rootcard"><div><h2>Son 7 gün</h2><p><?= (int)$w[0] ?> izlenme · <?= e(fmtBytes((int)$w[1])) ?></p></div></div>
  <div class="rootcard"><div><h2>Son 30 gün</h2><p><?= (int)$m[0] ?> izlenme · <?= e(fmtBytes((int)$m[1])) ?></p></div></div>
</div>
<section class="disk"><div class="diskrow"><span>Günlük bant genişliği (14 gün)</span><span>en yüksek <?= e(fmtBytes($max)) ?></span></div>
<div style="display:flex;align-items:flex-end;gap:4px;height:90px;margin-top:8px">
<?php foreach ($series as $d => $v): ?><div title="<?= e($d . ' · ' . fmtBytes((int)$v[1]) . ' · ' . $v[0] . ' izlenme') ?>" style="flex:1;background:linear-gradient(#7df9ff,#a78bfa);border-radius:4px 4px 0 0;height:<?= max(2, (int)round($v[1] / $max * 100)) ?>%;opacity:<?= $v[1] ? 1 : .25 ?>"></div><?php endforeach; ?>
</div></section>
<section class="disk" style="margin-top:12px"><div class="diskrow"><span>En çok veri çeken 20 dosya</span><span>toplam sayaçtan</span></div>
<?php if (!$top): ?><p style="color:var(--mut);font-size:14px">Henüz veri yok.</p><?php endif; ?>
<?php foreach ($top as $code => $v): $n = $names[$code] ?? null; ?>
<div class="diskrow" style="border-top:1px solid var(--line);padding:6px 0"><span style="word-break:break-all"><?= $n ? e($n['name'] . '.' . $n['ext']) . ' <small style="color:var(--mut)">(' . e(CDN_ROOTS[$n['root']] ?? '') . ')</small>' : '<i style="color:var(--mut)">silinmiş · ' . e(substr($code, 0, 8)) . '</i>' ?></span><span><?= (int)$v[0] ?> × · <?= e(fmtBytes((int)$v[1])) ?></span></div>
<?php endforeach; ?>
</section>
</main></body></html>
