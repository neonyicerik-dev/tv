<?php
// ============================================================
// NeonTV - 404 Bulunamadı Sayfası (Mini Oyunlu)
// ============================================================
if (!defined('APP_NAME')) {
    require_once __DIR__ . '/includes/config.php';
}
http_response_code(404);
$pageTitle = 'Sayfa Bulunamadı - 404';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Sayfa Bulunamadı | NeonTV</title>
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/tw.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; overflow: hidden; margin: 0; }
        .gradient-text { background: linear-gradient(135deg, #00f5ff, #bf00ff); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        #game-canvas { background: #0d0d1a; border: 2px solid rgba(0, 245, 255, 0.2); border-radius: 12px; box-shadow: 0 0 40px rgba(0, 245, 255, 0.1); margin-top: 20px; cursor: crosshair; }
        .stars { position: absolute; inset: 0; z-index: -1; pointer-events: none; }
    </style>
</head>
<body class="min-h-screen flex flex-col items-center justify-center p-4">

    <div class="stars" id="stars-container"></div>

    <div class="text-center z-10">
        <h1 class="text-7xl sm:text-9xl font-extrabold gradient-text tracking-tighter mb-2">404</h1>
        <h2 class="text-xl sm:text-2xl font-bold text-white mb-2">Uzay Boşluğunda Kaybolduk!</h2>
        <p class="text-sm sm:text-base text-gray-400 mb-6 max-w-md mx-auto">
            Aradığınız sayfayı veya videoyu bulamadık. Ama canınız sıkılmasın, aşağıdaki gemiyle meteorları patlatabilirsiniz!
        </p>

        <div class="flex items-center justify-center gap-4 mb-6">
            <a href="<?= APP_URL ?>/" class="px-6 py-2.5 rounded-xl text-sm font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                <i class="fa-solid fa-home mr-2"></i>Ana Sayfaya Dön
            </a>
            <button onclick="startGame()" id="start-btn" class="px-6 py-2.5 rounded-xl text-sm font-bold text-white" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);">
                <i class="fa-solid fa-gamepad mr-2"></i>Oyunu Başlat
            </button>
        </div>

        <div class="relative inline-block">
            <canvas id="game-canvas" width="600" height="300" class="max-w-full hidden"></canvas>
            <div id="game-over" class="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm rounded-xl hidden">
                <p class="text-2xl font-bold text-white mb-1">Oyun Bitti!</p>
                <p class="text-gray-400 mb-4">Skor: <span id="final-score" class="text-cyan-400 font-bold">0</span></p>
                <button onclick="startGame()" class="px-5 py-2 rounded-xl text-sm font-bold text-black bg-cyan-400 hover:bg-white transition-colors">
                    Tekrar Oyna
                </button>
            </div>
            <div id="score-display" class="absolute top-4 left-4 text-white font-mono font-bold text-lg hidden">Skor: 0</div>
        </div>
    </div>

<script>
// Arkaplan Yıldızları
const stars = document.getElementById('stars-container');
for(let i=0; i<50; i++) {
    let star = document.createElement('div');
    star.style.position = 'absolute';
    star.style.width = Math.random() * 3 + 'px';
    star.style.height = star.style.width;
    star.style.background = '#fff';
    star.style.borderRadius = '50%';
    star.style.left = Math.random() * 100 + '%';
    star.style.top = Math.random() * 100 + '%';
    star.style.opacity = Math.random();
    star.style.animation = `twinkle ${Math.random()*3 + 1}s infinite alternate`;
    stars.appendChild(star);
}

// Oyun Motoru
const canvas = document.getElementById('game-canvas');
const ctx = canvas.getContext('2d');
let reqAnimId, isPlaying = false, score = 0;
let player, bullets, enemies, particles;

const keyState = {};
window.addEventListener('keydown', e => { keyState[e.code] = true; if(e.code==='Space') e.preventDefault(); });
window.addEventListener('keyup', e => keyState[e.code] = false);

class Player {
    constructor() { this.x = 50; this.y = 150; this.size = 15; this.speed = 5; this.cooldown = 0; }
    draw() {
        ctx.fillStyle = '#00f5ff';
        ctx.beginPath();
        ctx.moveTo(this.x + this.size, this.y);
        ctx.lineTo(this.x - this.size, this.y - this.size);
        ctx.lineTo(this.x - this.size/2, this.y);
        ctx.lineTo(this.x - this.size, this.y + this.size);
        ctx.closePath();
        ctx.fill();
        // Thruster
        if(Math.random()>0.5) {
            ctx.fillStyle = '#ff007a';
            ctx.beginPath();
            ctx.arc(this.x - this.size - 5, this.y, 4, 0, Math.PI*2);
            ctx.fill();
        }
    }
    update() {
        if(keyState['ArrowUp'] || keyState['KeyW']) this.y -= this.speed;
        if(keyState['ArrowDown'] || keyState['KeyS']) this.y += this.speed;
        if(keyState['ArrowLeft'] || keyState['KeyA']) this.x -= this.speed;
        if(keyState['ArrowRight'] || keyState['KeyD']) this.x += this.speed;
        
        // Sınırlar
        if(this.y < this.size) this.y = this.size;
        if(this.y > canvas.height - this.size) this.y = canvas.height - this.size;
        if(this.x < this.size) this.x = this.size;
        if(this.x > canvas.width/2) this.x = canvas.width/2;

        if(this.cooldown > 0) this.cooldown--;
        if(keyState['Space'] && this.cooldown === 0) {
            bullets.push(new Bullet(this.x + this.size, this.y));
            this.cooldown = 10;
        }
    }
}

class Bullet {
    constructor(x,y) { this.x=x; this.y=y; this.speed=8; this.radius=3; this.markedForDeletion=false; }
    draw() { ctx.fillStyle='#bf00ff'; ctx.beginPath(); ctx.arc(this.x,this.y,this.radius,0,Math.PI*2); ctx.fill(); }
    update() { this.x += this.speed; if(this.x > canvas.width) this.markedForDeletion = true; }
}

class Enemy {
    constructor() {
        this.x = canvas.width + 20;
        this.y = Math.random() * (canvas.height - 40) + 20;
        this.radius = Math.random() * 15 + 10;
        this.speed = Math.random() * 2 + 1 + (score/1000);
        this.markedForDeletion = false;
        this.angle = 0;
        this.spin = Math.random() * 0.1 - 0.05;
        this.points = [];
        let vert = Math.floor(Math.random()*4)+5;
        for(let i=0; i<vert; i++) { this.points.push(this.radius * (0.8 + Math.random()*0.4)); }
    }
    draw() {
        ctx.save(); ctx.translate(this.x, this.y); ctx.rotate(this.angle);
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath();
        for(let i=0; i<this.points.length; i++) {
            let a = (i/this.points.length) * Math.PI*2;
            let pX = Math.cos(a) * this.points[i];
            let pY = Math.sin(a) * this.points[i];
            if(i===0) ctx.moveTo(pX,pY); else ctx.lineTo(pX,pY);
        }
        ctx.closePath(); ctx.stroke(); ctx.restore();
    }
    update() {
        this.x -= this.speed;
        this.angle += this.spin;
        if(this.x + this.radius < 0) this.markedForDeletion = true;
    }
}

class Particle {
    constructor(x,y,color) {
        this.x=x; this.y=y; this.color=color; this.radius=Math.random()*2+1;
        this.vx=(Math.random()-0.5)*5; this.vy=(Math.random()-0.5)*5; this.life=1;
    }
    draw() { ctx.fillStyle=this.color; ctx.globalAlpha=this.life; ctx.beginPath(); ctx.arc(this.x,this.y,this.radius,0,Math.PI*2); ctx.fill(); ctx.globalAlpha=1; }
    update() { this.x+=this.vx; this.y+=this.vy; this.life-=0.03; if(this.life<=0) this.markedForDeletion=true; }
}

function spawnEnemy() {
    if(!isPlaying) return;
    if(Math.random() < 0.03 + (score/20000)) enemies.push(new Enemy());
}

function checkCollisions() {
    // Kurşun ve düşman
    bullets.forEach(b => {
        enemies.forEach(e => {
            let dx=b.x-e.x, dy=b.y-e.y;
            if(Math.sqrt(dx*dx + dy*dy) < b.radius + e.radius) {
                b.markedForDeletion = true; e.markedForDeletion = true;
                score += Math.floor(e.radius);
                document.getElementById('score-display').textContent = 'Skor: ' + score;
                for(let i=0;i<8;i++) particles.push(new Particle(e.x, e.y, '#fff'));
            }
        });
    });
    // Oyuncu ve düşman
    enemies.forEach(e => {
        let dx=player.x-e.x, dy=player.y-e.y;
        if(Math.sqrt(dx*dx + dy*dy) < player.size + e.radius) gameOver();
    });
}

function gameOver() {
    isPlaying = false;
    document.getElementById('game-over').classList.remove('hidden');
    document.getElementById('final-score').textContent = score;
    cancelAnimationFrame(reqAnimId);
}

function loop() {
    if(!isPlaying) return;
    ctx.clearRect(0,0,canvas.width,canvas.height);
    
    player.update(); player.draw();
    
    bullets.forEach(b => { b.update(); b.draw(); });
    bullets = bullets.filter(b => !b.markedForDeletion);
    
    enemies.forEach(e => { e.update(); e.draw(); });
    enemies = enemies.filter(e => !e.markedForDeletion);
    
    particles.forEach(p => { p.update(); p.draw(); });
    particles = particles.filter(p => !p.markedForDeletion);
    
    spawnEnemy();
    checkCollisions();
    
    reqAnimId = requestAnimationFrame(loop);
}

function startGame() {
    canvas.classList.remove('hidden');
    document.getElementById('start-btn').classList.add('hidden');
    document.getElementById('game-over').classList.add('hidden');
    document.getElementById('score-display').classList.remove('hidden');
    
    player = new Player();
    bullets = []; enemies = []; particles = [];
    score = 0; document.getElementById('score-display').textContent = 'Skor: 0';
    isPlaying = true;
    
    // Mobil kontroller
    canvas.addEventListener('touchmove', e => {
        e.preventDefault();
        let rect = canvas.getBoundingClientRect();
        player.y = e.touches[0].clientY - rect.top;
        if(player.cooldown===0) { bullets.push(new Bullet(player.x+player.size, player.y)); player.cooldown=5; }
    }, {passive:false});
    
    loop();
}
</script>
</body>
</html>
