<?php
// ============================================================
// NeonTV - Admin Aktivite Logu
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/supabase.php';
requireAdmin();

$msg = '';
$msgType = 'success';

// === Geri Al (Undo) ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['undo_id'])) {
    $id    = trim($_POST['undo_id']);
    $entry = findActivityById($id);
    if ($entry && !empty($entry['old_data'])) {
        $db = new Supabase();
        $ok = false;
        try {
            switch ($entry['target_type']) {
                case 'video':
                    if ($entry['action'] === 'video_delete') {
                        // Silinen videoyu geri yükle
                        $res = $db->insert('videos', $entry['old_data'], true);
                        $ok  = !empty($res['data']);
                    } else {
                        // Düzenlemeyi geri al
                        $res = $db->update('videos', $entry['old_data'], 'id=eq.' . $entry['target_id'], true);
                        $ok  = ($res['status'] ?? 0) < 300;
                    }
                    break;
                case 'channel':
                    $res = $db->update('channels', $entry['old_data'], 'id=eq.' . $entry['target_id'], true);
                    $ok  = ($res['status'] ?? 0) < 300;
                    break;
                case 'comment':
                    if ($entry['action'] === 'comment_delete' && !empty($entry['old_data'])) {
                        $res = $db->insert('comments', $entry['old_data'], true);
                        $ok  = !empty($res['data']);
                    }
                    break;
            }
        } catch (Throwable $e) {
            $ok = false;
        }

        if ($ok) {
            logActivity('undo', $entry['target_type'], $entry['target_id'], [], $entry['old_data'], 'Geri alındı: ' . actionLabel($entry['action']));
            deleteActivityLog($id);
            $msg     = 'İşlem başarıyla geri alındı.';
            $msgType = 'success';
        } else {
            $msg     = 'Geri alma başarısız oldu.';
            $msgType = 'error';
        }
    } else {
        $msg     = 'Kayıt bulunamadı veya geri alınamaz.';
        $msgType = 'warning';
    }
}

// === Log Temizle ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_log']) && getAdminRole() === 'superadmin') {
    clearActivityLog();
    $msg     = 'Aktivite logu temizlendi.';
    $msgType = 'success';
}

// === Log Sil ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id']) && getAdminRole() === 'superadmin') {
    deleteActivityLog(trim($_POST['delete_id']));
    $msg     = 'Kayıt silindi.';
    $msgType = 'success';
}

// === Filtrele ===
$filterAdmin  = trim($_GET['admin']  ?? '');
$filterAction = trim($_GET['action'] ?? '');
$filterType   = trim($_GET['type']   ?? '');
$page         = max(1, (int)($_GET['page'] ?? 1));
$perPage      = 30;

$allLogs  = readActivityLog();

// Filtrele
$filtered = array_filter($allLogs, function($e) use ($filterAdmin, $filterAction, $filterType) {
    if ($filterAdmin  && ($e['admin']       ?? '') !== $filterAdmin)  return false;
    if ($filterAction && ($e['action']      ?? '') !== $filterAction) return false;
    if ($filterType   && ($e['target_type'] ?? '') !== $filterType)   return false;
    return true;
});
$filtered   = array_values($filtered);
$totalCount = count($filtered);
$totalPages = max(1, (int)ceil($totalCount / $perPage));
$page       = min($page, $totalPages);
$logs       = array_slice($filtered, ($page - 1) * $perPage, $perPage);

// Filtre seçenekleri
$admins  = array_unique(array_column($allLogs, 'admin'));
$actions = array_unique(array_column($allLogs, 'action'));
$types   = array_unique(array_column($allLogs, 'target_type'));
sort($admins); sort($actions); sort($types);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aktivite Logu | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        .panel { background: #0f0f1e; border: 1px solid rgba(255,255,255,0.07); border-radius: 1rem; overflow: hidden; }
        .panel-header { padding: 1rem 1.25rem; border-bottom: 1px solid rgba(255,255,255,0.06); }
        .log-row { border-bottom: 1px solid rgba(255,255,255,0.04); transition: background 0.15s; }
        .log-row:hover { background: rgba(255,255,255,0.025); }
        .log-row:last-child { border-bottom: none; }
        .badge { display: inline-flex; align-items: center; gap: 4px; padding: 2px 10px; border-radius: 9999px; font-size: 11px; font-weight: 600; }
        .input-field { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; transition: all 0.2s; }
        .input-field:focus { border-color: rgba(0,245,255,0.5); outline: none; box-shadow: 0 0 0 3px rgba(0,245,255,0.08); }
        .btn-undo { background: rgba(0,255,127,0.1); border: 1px solid rgba(0,255,127,0.25); color: #00ff7f; font-size: 11px; padding: 4px 10px; border-radius: 8px; cursor: pointer; transition: all 0.2s; }
        .btn-undo:hover { background: rgba(0,255,127,0.2); }
        .btn-del { background: rgba(255,68,68,0.1); border: 1px solid rgba(255,68,68,0.25); color: #ff4444; font-size: 11px; padding: 4px 10px; border-radius: 8px; cursor: pointer; transition: all 0.2s; }
        .btn-del:hover { background: rgba(255,68,68,0.2); }
        .timeline-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- Top Bar -->
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.95);backdrop-filter:blur(24px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white"
                    style="background:rgba(255,255,255,0.06);">
                <i class="fa-solid fa-bars text-sm"></i>
            </button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-clock-rotate-left text-sm" style="color:#ffd700;"></i>
                    Aktivite Logu
                </h1>
                <p class="text-xs text-gray-500 hidden sm:block">Moderatör işlemleri & geri alma</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <span class="text-xs text-gray-600"><?= $totalCount ?> kayıt</span>
            <?php if (getAdminRole() === 'superadmin' && $totalCount > 0): ?>
            <form method="POST" onsubmit="return confirm('Tüm log silinsin mi?')">
                <button type="submit" name="clear_log" value="1"
                        class="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs text-gray-400 hover:text-red-400 transition-all"
                        style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                    <i class="fa-solid fa-trash text-xs"></i>
                    <span class="hidden sm:inline">Temizle</span>
                </button>
            </form>
            <?php endif; ?>
        </div>
    </header>

    <main class="flex-1 p-4 sm:p-6 space-y-4 overflow-auto">

        <?php if ($msg): ?>
        <div class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium"
             style="background:rgba(<?= $msgType==='success'?'0,255,127':'255,68,68' ?>,0.08);border:1px solid rgba(<?= $msgType==='success'?'0,255,127':'255,68,68' ?>,0.25);color:<?= $msgType==='success'?'#00ff7f':'#ff4444' ?>;">
            <i class="fa-solid fa-<?= $msgType==='success'?'circle-check':'triangle-exclamation' ?>"></i>
            <?= e($msg) ?>
        </div>
        <?php endif; ?>

        <!-- Filtreler -->
        <div class="panel">
            <div class="panel-header">
                <h2 class="font-bold text-white text-sm flex items-center gap-2">
                    <i class="fa-solid fa-filter text-xs" style="color:#00f5ff;"></i>
                    Filtreler
                </h2>
            </div>
            <form method="GET" class="p-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
                <select name="admin" class="input-field px-3 py-2 rounded-xl text-sm">
                    <option value="">Tüm Adminler</option>
                    <?php foreach ($admins as $a): ?>
                    <option value="<?= e($a) ?>" <?= $filterAdmin===$a?'selected':'' ?>><?= e($a) ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="action" class="input-field px-3 py-2 rounded-xl text-sm">
                    <option value="">Tüm İşlemler</option>
                    <?php foreach ($actions as $ac): ?>
                    <option value="<?= e($ac) ?>" <?= $filterAction===$ac?'selected':'' ?>><?= e(actionLabel($ac)) ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="type" class="input-field px-3 py-2 rounded-xl text-sm">
                    <option value="">Tüm Tipler</option>
                    <?php foreach ($types as $t): ?>
                    <option value="<?= e($t) ?>" <?= $filterType===$t?'selected':'' ?>><?= e(targetTypeLabel($t)) ?></option>
                    <?php endforeach; ?>
                </select>
                <div class="flex gap-2">
                    <button type="submit" class="flex-1 px-3 py-2 rounded-xl text-xs font-bold text-black"
                            style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                        <i class="fa-solid fa-magnifying-glass mr-1"></i>Filtrele
                    </button>
                    <a href="activity.php" class="px-3 py-2 rounded-xl text-xs text-gray-500 hover:text-white transition-all flex items-center"
                       style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                        <i class="fa-solid fa-xmark"></i>
                    </a>
                </div>
            </form>
        </div>

        <!-- Log Tablosu -->
        <div class="panel">
            <div class="panel-header flex items-center justify-between">
                <h2 class="font-bold text-white text-sm flex items-center gap-2">
                    <i class="fa-solid fa-list-ul text-xs" style="color:#ffd700;"></i>
                    İşlem Geçmişi
                </h2>
                <span class="text-xs text-gray-600">Sayfa <?= $page ?>/<?= $totalPages ?></span>
            </div>

            <?php if (empty($logs)): ?>
            <div class="text-center py-16 text-gray-600">
                <i class="fa-solid fa-clock-rotate-left text-4xl mb-3 block opacity-20"></i>
                Henüz kayıt yok
            </div>
            <?php else: ?>
            <div>
                <?php foreach ($logs as $log): 
                    $color   = actionColor($log['action'] ?? '');
                    $canUndo = !empty($log['old_data']) && in_array($log['action'], ['video_delete','video_edit','video_status_change','comment_delete','channel_edit']);
                ?>
                <div class="log-row px-4 py-3 flex items-start gap-4">
                    <!-- Timeline dot -->
                    <div class="mt-1.5 flex-shrink-0">
                        <div class="timeline-dot" style="background:<?= $color ?>;box-shadow:0 0 6px <?= $color ?>80;"></div>
                    </div>

                    <!-- İçerik -->
                    <div class="flex-1 min-w-0">
                        <div class="flex flex-wrap items-center gap-2 mb-1">
                            <span class="badge" style="background:<?= $color ?>18;color:<?= $color ?>;border:1px solid <?= $color ?>40;">
                                <?= e(actionLabel($log['action'] ?? '')) ?>
                            </span>
                            <span class="badge" style="background:rgba(255,255,255,0.06);color:#9ca3af;">
                                <?= e(targetTypeLabel($log['target_type'] ?? '')) ?>
                            </span>
                            <?php if (!empty($log['note'])): ?>
                            <span class="text-xs text-gray-500 italic"><?= e($log['note']) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="flex flex-wrap items-center gap-3 text-xs text-gray-500 mt-1">
                            <span class="flex items-center gap-1">
                                <i class="fa-solid fa-user text-[10px]" style="color:#bf00ff;"></i>
                                <span class="font-medium text-gray-300"><?= e($log['admin'] ?? '-') ?></span>
                                <span class="text-gray-600">(<?= e($log['role'] ?? '') ?>)</span>
                            </span>
                            <?php if (!empty($log['target_id'])): ?>
                            <span class="flex items-center gap-1">
                                <i class="fa-solid fa-hashtag text-[10px]"></i>
                                <span class="font-mono text-[11px]"><?= e(substr($log['target_id'], 0, 12)) ?></span>
                            </span>
                            <?php endif; ?>
                            <span class="flex items-center gap-1">
                                <i class="fa-regular fa-clock text-[10px]"></i>
                                <?= timeAgo($log['created_at'] ?? '') ?>
                            </span>
                            <?php if (!empty($log['ip'])): ?>
                            <span class="flex items-center gap-1">
                                <i class="fa-solid fa-globe text-[10px]"></i>
                                <?= e($log['ip']) ?>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Butonlar -->
                    <div class="flex items-center gap-1.5 flex-shrink-0 mt-0.5">
                        <?php if ($canUndo): ?>
                        <form method="POST" onsubmit="return confirm('Bu işlemi geri almak istiyor musunuz?')">
                            <input type="hidden" name="undo_id" value="<?= e($log['id']) ?>">
                            <button type="submit" class="btn-undo" title="Geri Al">
                                <i class="fa-solid fa-rotate-left mr-1"></i>Geri Al
                            </button>
                        </form>
                        <?php endif; ?>
                        <?php if (getAdminRole() === 'superadmin'): ?>
                        <form method="POST" onsubmit="return confirm('Bu kaydı silmek istiyor musunuz?')">
                            <input type="hidden" name="delete_id" value="<?= e($log['id']) ?>">
                            <button type="submit" class="btn-del" title="Sil">
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <div class="flex items-center justify-center gap-2 p-4" style="border-top:1px solid rgba(255,255,255,0.06);">
                <?php if ($page > 1): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page-1])) ?>"
                   class="px-4 py-2 rounded-xl text-xs text-gray-400 hover:text-white transition-all"
                   style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                    <i class="fa-solid fa-chevron-left mr-1"></i>Önceki
                </a>
                <?php endif; ?>
                <span class="text-xs text-gray-500"><?= $page ?> / <?= $totalPages ?></span>
                <?php if ($page < $totalPages): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page+1])) ?>"
                   class="px-4 py-2 rounded-xl text-xs text-gray-400 hover:text-white transition-all"
                   style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                    Sonraki<i class="fa-solid fa-chevron-right ml-1"></i>
                </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>

    </main>
</div>
</body>
</html>
