<?php
// ============================================================
// NeonTV - Admin: Reklam Raporları (günlük gösterim/tıklama, CTR, CSV, PDF)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin('superadmin');
$db = new Supabase();

$days  = (int)($_GET['days'] ?? 30);
if (!in_array($days, [7, 30, 90], true)) $days = 30;
$since = gmdate('Y-m-d', time() - ($days - 1) * 86400);

$ads = [];
foreach (($db->select('ads', 'select=id,title,type,is_active,impressions,clicks&order=created_at.desc', true)['data'] ?? []) as $a) $ads[$a['id']] = $a;

$rows = $db->select('ad_stats_daily', 'day=gte.' . $since . '&order=day.asc&limit=20000', true)['data'] ?? [];

// Günlük toplam + reklam bazlı toplam
$daily = []; $per = [];
for ($i = 0; $i < $days; $i++) $daily[gmdate('Y-m-d', strtotime($since) + $i * 86400)] = ['i' => 0, 'c' => 0];
foreach ($rows as $r) {
    $d = $r['day']; $id = $r['ad_id'];
    if (isset($daily[$d])) { $daily[$d]['i'] += (int)$r['impressions']; $daily[$d]['c'] += (int)$r['clicks']; }
    $per[$id]['i'] = ($per[$id]['i'] ?? 0) + (int)$r['impressions'];
    $per[$id]['c'] = ($per[$id]['c'] ?? 0) + (int)$r['clicks'];
}
$ctr = fn($i, $c) => $i > 0 ? round($c / $i * 100, 2) : 0;

if (($_GET['export'] ?? '') === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="reklam_raporu_' . gmdate('Y-m-d') . '.csv"');
    echo "\xEF\xBB\xBF";
    $o = fopen('php://output', 'w');
    $esc = fn($v) => preg_match('/^[=+\-@\t\r]/', (string)$v) ? "'" . $v : $v; // CSV formül enjeksiyonu koruması
    fputcsv($o, ['Reklam', 'Tür', 'Gösterim', 'Tıklama', 'CTR %'], ';');
    foreach ($per as $id => $s) fputcsv($o, [$esc($ads[$id]['title'] ?? $id), $ads[$id]['type'] ?? '', $s['i'], $s['c'], $ctr($s['i'], $s['c'])], ';');
    fputcsv($o, [], ';');
    fputcsv($o, ['Tarih', 'Gösterim', 'Tıklama', 'CTR %'], ';');
    foreach ($daily as $d => $s) fputcsv($o, [$d, $s['i'], $s['c'], $ctr($s['i'], $s['c'])], ';');
    exit;
}

$totI = array_sum(array_column($daily, 'i')); $totC = array_sum(array_column($daily, 'c'));
$adminTitle = 'Reklam Raporları';
$adminSub   = 'Son ' . $days . ' gün · gösterim, tıklama ve CTR';
include __DIR__ . '/_top.php';
?>
<div class="flex flex-wrap items-center gap-2 no-print">
    <?php foreach ([7, 30, 90] as $d): ?>
    <a href="?days=<?= $d ?>" class="px-4 py-2 rounded-full text-sm" style="<?= $days === $d ? 'background:rgba(0,245,255,0.12);color:#00f5ff;border:1px solid rgba(0,245,255,0.4)' : 'background:rgba(255,255,255,0.06);color:#9ca3af;border:1px solid rgba(255,255,255,0.1)' ?>">Son <?= $d ?> gün</a>
    <?php endforeach; ?>
    <a href="?days=<?= $days ?>&export=csv" class="ml-auto px-4 py-2 rounded-full text-sm font-semibold text-black" style="background:#00f5ff"><i class="fa-solid fa-file-csv mr-1.5"></i>CSV</a>
    <button onclick="window.print()" class="px-4 py-2 rounded-full text-sm font-semibold text-black" style="background:#ffd76a"><i class="fa-solid fa-file-pdf mr-1.5"></i>PDF (Yazdır)</button>
</div>

<div class="grid grid-cols-3 gap-3">
    <?php foreach ([['Gösterim', number_format($totI, 0, ',', '.')], ['Tıklama', number_format($totC, 0, ',', '.')], ['CTR', '%' . $ctr($totI, $totC)]] as [$l, $v]): ?>
    <div class="print-card rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,0.08)">
        <p class="text-xs text-gray-500"><?= $l ?></p><p class="text-2xl font-bold text-white"><?= $v ?></p>
    </div>
    <?php endforeach; ?>
</div>

<div class="print-card rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,0.08)">
    <canvas id="ad-chart" height="110"></canvas>
</div>

<div class="print-card rounded-2xl overflow-x-auto" style="background:#13131f;border:1px solid rgba(255,255,255,0.08)">
    <table class="w-full text-sm">
        <thead><tr class="text-left text-gray-500 text-xs"><th class="p-3">Reklam</th><th class="p-3">Tür</th><th class="p-3 text-right">Gösterim</th><th class="p-3 text-right">Tıklama</th><th class="p-3 text-right">CTR</th></tr></thead>
        <tbody>
        <?php if (!$per): ?><tr><td colspan="5" class="p-6 text-center text-gray-500">Bu aralıkta veri yok. (SQL dosyasındaki ad_stats_daily tablosu kurulduktan sonra yeni gösterimler burada görünür.)</td></tr><?php endif; ?>
        <?php foreach ($per as $id => $s): ?>
        <tr class="border-t border-white/5">
            <td class="p-3 text-white"><?= e($ads[$id]['title'] ?? $id) ?></td>
            <td class="p-3 text-gray-400"><?= e($ads[$id]['type'] ?? '') ?></td>
            <td class="p-3 text-right"><?= number_format($s['i'], 0, ',', '.') ?></td>
            <td class="p-3 text-right"><?= number_format($s['c'], 0, ',', '.') ?></td>
            <td class="p-3 text-right text-cyan-400">%<?= $ctr($s['i'], $s['c']) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
const D = <?= json_encode(array_keys($daily)) ?>, I = <?= json_encode(array_column($daily, 'i')) ?>, C = <?= json_encode(array_column($daily, 'c')) ?>;
new Chart(document.getElementById('ad-chart'), {
  type: 'line',
  data: { labels: D.map(d => d.slice(5)), datasets: [
    { label: 'Gösterim', data: I, borderColor: '#00f5ff', backgroundColor: 'rgba(0,245,255,.1)', tension: .3, fill: true, yAxisID: 'y' },
    { label: 'Tıklama', data: C, borderColor: '#bf00ff', backgroundColor: 'rgba(191,0,255,.1)', tension: .3, yAxisID: 'y1' } ] },
  options: { interaction: { mode: 'index', intersect: false }, plugins: { legend: { labels: { color: '#9ca3af' } } },
    scales: { x: { ticks: { color: '#6b7280' }, grid: { color: 'rgba(255,255,255,.05)' } },
      y: { ticks: { color: '#00f5ff' }, grid: { color: 'rgba(255,255,255,.05)' }, beginAtZero: true },
      y1: { position: 'right', ticks: { color: '#bf00ff' }, grid: { display: false }, beginAtZero: true } } }
});
</script>
<?php include __DIR__ . '/_bottom.php'; ?>
