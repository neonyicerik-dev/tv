<?php
function clearAdCaches(): void { foreach (['ads_video','ads_banner_all','ads_banner_pick','active_popup'] as $k) Store::clearCache($k); }
// ============================================================
// NeonTV - Admin: Reklam & Popup Yönetimi
// F2: Video reklamı, banner, popup
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin('superadmin');

$db = new Supabase();

// ---- Aksiyon işle ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) {
        setFlash('error', 'Güvenlik hatası.');
        clearAdCaches(); redirect(APP_URL . '/admin/ads.php');
    }

    $action = input('action');

    // --- Reklam Oluştur ---
    if ($action === 'create_ad') {
        $type      = pgEnum(input('type'), ['video', 'banner'], 'banner');
        $title     = trim(input('title'));
        $clickUrl  = trim(input('click_url'));
        $videoUrl  = trim(input('video_url'));
        $gifUrl    = trim(input('gif_url'));
        $skipAfter = max(0, min(60, (int)input('skip_after_seconds')));
        $isActive  = isset($_POST['is_active']);

        if (!$title || !$clickUrl) {
            setFlash('error', 'Başlık ve tıklama URL\'si zorunlu.');
        } elseif (!str_starts_with($clickUrl, 'https://')) {
            setFlash('error', 'Tıklama URL\'si https:// ile başlamalı.');
        } elseif (preg_match('/\.(gif|png|jpe?g|webp|mp4)(\?.*)?$/i', $clickUrl)) {
            setFlash('error', 'Tıklama URL\'si bir resim/video dosyası gibi görünüyor. Alanları karıştırmış olabilirsin: tıklanınca açılacak SAYFA adresi buraya, GIF dosyasının adresi "Banner GIF/Resim URL" alanına yazılmalı.');
        } elseif ($type === 'banner' && (!$gifUrl || !str_starts_with($gifUrl, 'https://'))) {
            setFlash('error', 'Banner için https:// ile başlayan bir GIF/Resim URL\'si gerekli.');
        } elseif ($type === 'banner' && !preg_match('/\.(gif|png|jpe?g|webp)(\?.*)?$/i', $gifUrl)) {
            setFlash('error', 'Banner GIF/Resim URL\'si .gif, .png, .jpg veya .webp ile bitmeli. Alanları karıştırmış olabilirsin.');
        } else {
            $d = ['type' => $type, 'title' => $title, 'click_url' => $clickUrl, 'is_active' => $isActive];
            if ($videoUrl) $d['video_url']          = $videoUrl;
            if ($gifUrl)   $d['gif_url']             = $gifUrl;
            if ($type === 'video') $d['skip_after_seconds'] = $skipAfter;
            $r = $db->insert('ads', $d, true);
            if ($r['status'] < 400) {
                logActivity('ad_create', 'ad', '', [], ['title' => $title, 'type' => $type]);
                setFlash('success', 'Reklam oluşturuldu.');
            } else {
                setFlash('error', 'Hata: ' . ($r['error'] ?? ''));
            }
        }
        clearAdCaches(); redirect(APP_URL . '/admin/ads.php');
    }

    // --- Reklam Güncelle ---
    if ($action === 'toggle_ad') {
        $id = trim(input('id'));
        requireUuid($id, 'Reklam ID');
        $current = $db->first('ads', 'id=eq.' . urlencode($id), true);
        if ($current) {
            $db->update('ads', ['is_active' => !$current['is_active']], 'id=eq.' . urlencode($id), true);
        }
        clearAdCaches(); redirect(APP_URL . '/admin/ads.php');
    }

    // --- Reklam Sil ---
    if ($action === 'delete_ad') {
        $id = trim(input('id'));
        requireUuid($id, 'Reklam ID');
        $db->delete('ads', 'id=eq.' . urlencode($id), true);
        logActivity('ad_delete', 'ad', $id);
        setFlash('success', 'Reklam silindi.');
        clearAdCaches(); redirect(APP_URL . '/admin/ads.php');
    }

    // --- Popup Oluştur ---
    if ($action === 'create_popup') {
        $title    = trim(input('popup_title'));
        $imageUrl = trim(input('popup_image_url'));
        $linkUrl  = trim(input('popup_link_url'));
        $isActive = isset($_POST['popup_is_active']);

        if (!$title) {
            setFlash('error', 'Popup başlığı zorunlu.');
        } else {
            $r = $db->insert('popups', [
                'title'     => $title,
                'image_url' => $imageUrl ?: null,
                'link_url'  => $linkUrl ?: null,
                'is_active' => $isActive,
            ], true);
            if ($r['status'] < 400) {
                logActivity('popup_create', 'popup', '', [], ['title' => $title]);
                setFlash('success', 'Popup oluşturuldu.');
            } else {
                setFlash('error', 'Hata: ' . ($r['error'] ?? ''));
            }
        }
        clearAdCaches(); redirect(APP_URL . '/admin/ads.php');
    }

    // --- Popup Toggle ---
    if ($action === 'toggle_popup') {
        $id = trim(input('id'));
        requireUuid($id, 'Popup ID');

        // Aktif popup sadece bir tane olsun – önce hepsini kapat
        $db->update('popups', ['is_active' => false], 'is_active=eq.true', true);
        $current = $db->first('popups', 'id=eq.' . urlencode($id), true);
        if ($current && !$current['is_active']) {
            $db->update('popups', ['is_active' => true], 'id=eq.' . urlencode($id), true);
        }
        clearAdCaches(); redirect(APP_URL . '/admin/ads.php');
    }

    // --- Popup Sil ---
    if ($action === 'delete_popup') {
        $id = trim(input('id'));
        requireUuid($id, 'Popup ID');
        $db->delete('popups', 'id=eq.' . urlencode($id), true);
        logActivity('popup_delete', 'popup', $id);
        setFlash('success', 'Popup silindi.');
        clearAdCaches(); redirect(APP_URL . '/admin/ads.php');
    }
}

// ---- Veri çek ----
$ads    = $db->select('ads', 'order=created_at.desc', true)['data'] ?? [];
$popups = $db->select('popups', 'order=created_at.desc', true)['data'] ?? [];
?>
<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reklam Yönetimi | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>body { font-family:'Outfit',sans-serif; background:#070711; } ::-webkit-scrollbar{width:6px;} ::-webkit-scrollbar-track{background:#0d0d1a;} ::-webkit-scrollbar-thumb{background:#1e1e3a;border-radius:3px;}</style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- TOP BAR (Mobil Menü Butonu Dahil) -->
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <!-- Hamburger Menü -->
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors"
                    style="background:rgba(255,255,255,0.06);">
                <i class="fa-solid fa-bars text-sm"></i>
            </button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white">Reklam Yönetimi</h1>
                <p class="text-xs text-gray-500">Video reklamları ve karşılama popupları</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <button onclick="document.getElementById('create-popup-modal').classList.remove('hidden')"
                    class="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-white/5 hover:bg-white/10 text-cyan-400 border border-cyan-400/20 transition-all">
                <i class="fa-solid fa-window-restore"></i>
                <span class="hidden sm:inline">Yeni Popup</span>
                <span class="sm:hidden">Popup</span>
            </button>
            <button onclick="document.getElementById('create-ad-modal').classList.remove('hidden')"
                    class="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-black transition-all hover:scale-105"
                    style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                <i class="fa-solid fa-plus text-xs"></i>
                <span class="hidden sm:inline">Yeni Reklam</span>
                <span class="sm:hidden">Reklam</span>
            </button>
        </div>
    </header>

    <main class="flex-1 p-4 sm:p-6 overflow-auto">
        <div class="max-w-5xl mx-auto space-y-8">

            <?= renderFlash() ?>

            <!-- ===== REKLAMLAR ===== -->
            <section>
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-xl font-bold text-white">Video & Banner Reklamlar</h2>
                </div>
                <div class="rounded-2xl overflow-hidden" style="background:#13131f;border:1px solid rgba(255,255,255,0.06);">
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                        <thead>
                            <tr style="background:rgba(0,245,255,0.04);border-bottom:1px solid rgba(255,255,255,0.06);">
                                <th class="px-4 py-3 text-left text-gray-400 font-semibold">Başlık</th>
                                <th class="px-4 py-3 text-center text-gray-400 font-semibold">Tür</th>
                                <th class="px-4 py-3 text-center text-gray-400 font-semibold">Gösterim</th>
                                <th class="px-4 py-3 text-center text-gray-400 font-semibold">Tıklama</th>
                                <th class="px-4 py-3 text-center text-gray-400 font-semibold">Durum</th>
                                <th class="px-4 py-3 text-center text-gray-400 font-semibold">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y" style="border-color:rgba(255,255,255,0.04);">
                            <?php if (empty($ads)): ?>
                            <tr><td colspan="6" class="px-4 py-8 text-center text-gray-500">Henüz reklam eklenmedi</td></tr>
                            <?php else: ?>
                            <?php foreach ($ads as $ad): ?>
                            <tr class="hover:bg-white/[0.02] transition-colors">
                                <td class="px-4 py-3 font-medium"><?= e($ad['title']) ?></td>
                                <td class="px-4 py-3 text-center">
                                    <?php if ($ad['type'] === 'video'): ?>
                                        <span class="px-2 py-0.5 rounded-full text-xs" style="background:rgba(191,0,255,0.1);color:#bf00ff;">Video</span>
                                    <?php else: ?>
                                        <span class="px-2 py-0.5 rounded-full text-xs" style="background:rgba(0,245,255,0.1);color:#00f5ff;">Banner</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-center text-gray-400"><?= number_format((int)$ad['impressions']) ?></td>
                                <td class="px-4 py-3 text-center text-gray-400"><?= number_format((int)$ad['clicks']) ?></td>
                                <td class="px-4 py-3 text-center">
                                    <form method="POST" class="inline">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="action" value="toggle_ad">
                                        <input type="hidden" name="id" value="<?= e($ad['id']) ?>">
                                        <button type="submit" class="px-2 py-0.5 rounded-full text-xs cursor-pointer transition-all hover:scale-105"
                                                style="<?= $ad['is_active'] ? 'background:rgba(0,245,255,0.1);color:#00f5ff;border:1px solid rgba(0,245,255,0.2);' : 'background:rgba(255,255,255,0.05);color:#6b7280;border:1px solid rgba(255,255,255,0.1);' ?>">
                                            <?= $ad['is_active'] ? 'Aktif' : 'Pasif' ?>
                                        </button>
                                    </form>
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <form method="POST" class="inline" onsubmit="return confirm('Bu reklamı silmek istediğinizden emin misiniz?')">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="action" value="delete_ad">
                                        <input type="hidden" name="id" value="<?= e($ad['id']) ?>">
                                        <button type="submit" class="px-3 py-1.5 rounded-lg text-xs font-medium transition-all hover:scale-105"
                                                style="background:rgba(255,68,68,0.1);color:#ff4444;border:1px solid rgba(255,68,68,0.2);">
                                            <i class="fa-solid fa-trash mr-1"></i>Sil
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </section>

            <!-- ===== POPUP'LAR ===== -->
            <section>
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-xl font-bold text-white">Popup Yönetimi</h2>
                    <button onclick="document.getElementById('create-popup-modal').classList.remove('hidden')"
                            class="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold bg-white/5 hover:bg-white/10 transition-all">
                        <i class="fa-solid fa-plus"></i> Yeni Popup
                    </button>
                </div>
                <p class="text-xs text-gray-500 mb-3">⚠️ Sadece bir popup aynı anda aktif olabilir. Etkinleştirme diğer tüm popup'ları devre dışı bırakır.</p>
                <div class="rounded-2xl overflow-hidden" style="background:#13131f;border:1px solid rgba(255,255,255,0.06);">
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                        <thead>
                            <tr style="background:rgba(0,245,255,0.04);border-bottom:1px solid rgba(255,255,255,0.06);">
                                <th class="px-4 py-3 text-left text-gray-400 font-semibold">Başlık</th>
                                <th class="px-4 py-3 text-left text-gray-400 font-semibold">Link</th>
                                <th class="px-4 py-3 text-center text-gray-400 font-semibold">Durum</th>
                                <th class="px-4 py-3 text-center text-gray-400 font-semibold">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y" style="border-color:rgba(255,255,255,0.04);">
                            <?php if (empty($popups)): ?>
                            <tr><td colspan="4" class="px-4 py-8 text-center text-gray-500">Henüz popup eklenmedi</td></tr>
                            <?php else: ?>
                            <?php foreach ($popups as $popup): ?>
                            <tr class="hover:bg-white/[0.02] transition-colors">
                                <td class="px-4 py-3 font-medium"><?= e($popup['title']) ?></td>
                                <td class="px-4 py-3 text-gray-400 text-xs max-w-xs truncate">
                                    <?= $popup['link_url'] ? '<a href="' . e($popup['link_url']) . '" target="_blank" class="text-cyan-400 hover:underline">' . e($popup['link_url']) . '</a>' : '—' ?>
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <form method="POST" class="inline">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="action" value="toggle_popup">
                                        <input type="hidden" name="id" value="<?= e($popup['id']) ?>">
                                        <button type="submit" class="px-2 py-0.5 rounded-full text-xs cursor-pointer transition-all hover:scale-105"
                                                style="<?= $popup['is_active'] ? 'background:rgba(0,245,255,0.1);color:#00f5ff;border:1px solid rgba(0,245,255,0.2);' : 'background:rgba(255,255,255,0.05);color:#6b7280;border:1px solid rgba(255,255,255,0.1);' ?>">
                                            <?= $popup['is_active'] ? 'Aktif' : 'Pasif' ?>
                                        </button>
                                    </form>
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <form method="POST" class="inline" onsubmit="return confirm('Bu popup\'ı silmek istediğinizden emin misiniz?')">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="action" value="delete_popup">
                                        <input type="hidden" name="id" value="<?= e($popup['id']) ?>">
                                        <button type="submit" class="px-3 py-1.5 rounded-lg text-xs font-medium transition-all hover:scale-105"
                                                style="background:rgba(255,68,68,0.1);color:#ff4444;border:1px solid rgba(255,68,68,0.2);">
                                            <i class="fa-solid fa-trash mr-1"></i>Sil
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </section>
        </div>
    </main>
</div>

<!-- Yeni Reklam Modal -->
<div id="create-ad-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,0.7);">
    <div class="w-full max-w-lg rounded-2xl p-6 overflow-y-auto max-h-[90vh]" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h2 class="text-lg font-bold mb-5">Yeni Reklam Ekle</h2>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="create_ad">
            <div class="space-y-4">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-gray-400 mb-1.5">Tür *</label>
                        <select name="type" id="ad-type" onchange="toggleAdFields()"
                                class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none">
                            <option value="video">Video Reklam</option>
                            <option value="banner">Banner Reklam</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-gray-400 mb-1.5">Başlık *</label>
                        <input type="text" name="title" required
                               class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5">Tıklama URL (https://) *</label>
                    <input type="url" name="click_url" required placeholder="https://example.com"
                           class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                </div>
                <div id="ad-video-fields">
                    <div>
                        <label class="block text-xs font-semibold text-gray-400 mb-1.5">Video URL (VAST)</label>
                        <input type="url" name="video_url" placeholder="https://..."
                               class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                    </div>
                    <div class="mt-3">
                        <label class="block text-xs font-semibold text-gray-400 mb-1.5">Atlanabilir (saniye sonra)</label>
                        <input type="number" name="skip_after_seconds" value="5" min="0" max="60"
                               class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                        <p class="text-xs text-gray-500 mt-1">0 = atlanamaz</p>
                    </div>
                </div>
                <div id="ad-banner-fields" class="hidden">
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5">Banner GIF/Resim URL</label>
                    <input type="url" name="gif_url" placeholder="https://..."
                           class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                </div>
                <div class="flex items-center gap-2">
                    <input type="checkbox" name="is_active" id="ad-active" class="w-4 h-4 accent-cyan-400" checked>
                    <label for="ad-active" class="text-sm text-gray-300">Hemen aktifleştir</label>
                </div>
            </div>
            <div class="flex gap-3 mt-6">
                <button type="button" onclick="document.getElementById('create-ad-modal').classList.add('hidden')"
                        class="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-white/5 hover:bg-white/10 transition-colors">İptal</button>
                <button type="submit"
                        class="flex-1 py-2.5 rounded-xl text-sm font-bold text-black transition-all hover:scale-[1.02]"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Oluştur</button>
            </div>
        </form>
    </div>
</div>

<!-- Yeni Popup Modal -->
<div id="create-popup-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,0.7);">
    <div class="w-full max-w-md rounded-2xl p-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h2 class="text-lg font-bold mb-5">Yeni Popup Ekle</h2>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="create_popup">
            <div class="space-y-4">
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5">Başlık *</label>
                    <input type="text" name="popup_title" required
                           class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5">Resim URL</label>
                    <input type="url" name="popup_image_url" placeholder="https://..."
                           class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5">Tıklama Linki</label>
                    <input type="url" name="popup_link_url" placeholder="https://..."
                           class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                </div>
                <div class="flex items-center gap-2">
                    <input type="checkbox" name="popup_is_active" id="popup-active" class="w-4 h-4 accent-cyan-400">
                    <label for="popup-active" class="text-sm text-gray-300">Hemen aktifleştir</label>
                </div>
            </div>
            <div class="flex gap-3 mt-6">
                <button type="button" onclick="document.getElementById('create-popup-modal').classList.add('hidden')"
                        class="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-white/5 hover:bg-white/10 transition-colors">İptal</button>
                <button type="submit"
                        class="flex-1 py-2.5 rounded-xl text-sm font-bold text-black transition-all hover:scale-[1.02]"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Oluştur</button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleAdFields() {
    const t = document.getElementById('ad-type').value;
    document.getElementById('ad-video-fields').classList.toggle('hidden', t !== 'video');
    document.getElementById('ad-banner-fields').classList.toggle('hidden', t !== 'banner');
}
['create-ad-modal','create-popup-modal'].forEach(id => {
    document.getElementById(id).addEventListener('click', function(e) {
        if (e.target === this) this.classList.add('hidden');
    });
});
</script>
</body>
</html>
