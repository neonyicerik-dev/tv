<?php
// ============================================================
// NeonTV - Admin: Uygulama İndirme Ayarları (app.php sayfası)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin('superadmin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) {
        setFlash('error', 'Güvenlik doğrulaması başarısız.');
        redirect(APP_URL . '/admin/app.php');
    }
    $url = trim(input('app_download_url'));
    if ($url !== '' && !preg_match('#^https://#i', $url)) {
        setFlash('error', 'İndirme linki https:// ile başlamalı.');
        redirect(APP_URL . '/admin/app.php');
    }
    Store::setSettings([
        'app_download_url' => $url,
        'app_version'      => mb_substr(trim(input('app_version')), 0, 20),
        'app_size'         => mb_substr(trim(input('app_size')), 0, 20),
        'app_changelog'    => mb_substr(trim(input('app_changelog')), 0, 1000),
        'app_enabled'      => isset($_POST['app_enabled']),
    ]);
    logActivity('settings_edit', 'app_download', '', [], ['url' => $url]);
    setFlash('success', 'Uygulama ayarları kaydedildi.');
    redirect(APP_URL . '/admin/app.php');
}

$cfg = [
    'url'       => (string)Store::getSetting('app_download_url', ''),
    'version'   => (string)Store::getSetting('app_version', '1.0'),
    'size'      => (string)Store::getSetting('app_size', ''),
    'changelog' => (string)Store::getSetting('app_changelog', ''),
    'enabled'   => (bool)Store::getSetting('app_enabled', true),
    'count'     => (int)Store::getSetting('app_download_count', 0),
];
$pageTitle = 'Uygulama';
?>
<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uygulama | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }</style>
</head>
<body class="min-h-screen lg:flex">
<?php include __DIR__ . '/sidebar.php'; ?>
<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">
    <header class="flex items-center gap-3 px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white" style="background:rgba(255,255,255,0.06);">
            <i class="fa-solid fa-bars text-sm"></i>
        </button>
        <div>
            <h1 class="text-lg sm:text-xl font-bold text-white">Uygulama İndirme</h1>
            <p class="text-xs text-gray-500">/app.php sayfasındaki indirme butonu · <?= number_format($cfg['count'], 0, ',', '.') ?> indirme tıklaması</p>
        </div>
    </header>
    <main class="flex-1 p-4 sm:p-6">
        <div class="max-w-2xl mx-auto space-y-4">
            <?= renderFlash() ?>
            <form method="POST" class="rounded-2xl p-5 space-y-4" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                <?= csrfField() ?>
                <div>
                    <label class="block text-sm text-gray-400 mb-1.5">APK indirme linki (https://)</label>
                    <input type="url" name="app_download_url" value="<?= e($cfg['url']) ?>" placeholder="https://github.com/KULLANICI/DEPO/releases/download/v1.0/NeonTV.apk"
                           class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 px-4 text-white text-sm focus:outline-none focus:border-cyan-500">
                    <p class="text-xs text-gray-600 mt-1">Dosya sitenin sunucusunda değil, ücretsiz bir depolamada durur (GitHub Releases önerilir).</p>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm text-gray-400 mb-1.5">Sürüm</label>
                        <input type="text" name="app_version" value="<?= e($cfg['version']) ?>" maxlength="20" placeholder="1.0"
                               class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 px-4 text-white text-sm focus:outline-none focus:border-cyan-500">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-400 mb-1.5">Boyut</label>
                        <input type="text" name="app_size" value="<?= e($cfg['size']) ?>" maxlength="20" placeholder="70 MB"
                               class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 px-4 text-white text-sm focus:outline-none focus:border-cyan-500">
                    </div>
                </div>
                <div>
                    <label class="block text-sm text-gray-400 mb-1.5">Yenilikler (isteğe bağlı)</label>
                    <textarea name="app_changelog" rows="3" maxlength="1000"
                              class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 px-4 text-white text-sm focus:outline-none focus:border-cyan-500"><?= e($cfg['changelog']) ?></textarea>
                </div>
                <label class="flex items-center gap-2 text-sm text-gray-300">
                    <input type="checkbox" name="app_enabled" class="w-4 h-4 accent-cyan-400" <?= $cfg['enabled'] ? 'checked' : '' ?>>
                    İndirme butonunu aktif et
                </label>
                <button class="px-6 py-3 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Kaydet</button>
            </form>
        </div>
    </main>
</div>
</body>
</html>
