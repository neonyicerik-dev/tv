<?php
// ============================================================
// NeonTV - Admin: Veritabanı Yedeği (elle indirme) + geri yükleme rehberi
// Otomatik/zamanlanmış çalışmaz; yalnızca superadmin butona basınca indirir.
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin('superadmin');

// Yedeklenebilir tablolar (admin_users parolaları içerdiği için varsayılan olarak yok)
$TABLES = ['channels','videos','subtitles','chapters','categories','video_categories','profiles','comments','likes',
           'subscriptions','views_log','ads','popups','ad_stats_daily','user_premium','site_settings','playlists',
           'playlist_videos','watch_later','watch_history','contact_messages','ai_usage'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/backup.php'); }
    $chosen = array_values(array_intersect($TABLES, (array)($_POST['tables'] ?? [])));
    if (!$chosen) { setFlash('error', 'En az bir tablo seçin.'); redirect(APP_URL . '/admin/backup.php'); }

    @set_time_limit(300);
    $db = new Supabase();
    $dump = ['app' => 'NeonTV', 'created_at' => gmdate('c'), 'format' => 1, 'tables' => []];
    foreach ($chosen as $t) {
        $all = []; $off = 0;
        while ($off < 200000) {
            $r = $db->select($t, 'select=*&limit=1000&offset=' . $off, true);
            if (($r['status'] ?? 500) >= 400) break; // tablo yoksa atla
            $chunk = $r['data'] ?? [];
            $all = array_merge($all, $chunk);
            if (count($chunk) < 1000) break;
            $off += 1000;
        }
        $dump['tables'][$t] = $all;
    }
    logActivity('settings_edit', 'db_backup', '', [], ['tables' => implode(',', $chosen)]);
    $json = json_encode($dump, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    $name = 'neontv_yedek_' . gmdate('Y-m-d_His');
    header('Cache-Control: no-store');
    if (function_exists('gzencode')) {
        header('Content-Type: application/gzip');
        header('Content-Disposition: attachment; filename="' . $name . '.json.gz"');
        echo gzencode($json, 6);
    } else {
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="' . $name . '.json"');
        echo $json;
    }
    exit;
}

$adminTitle = 'Veritabanı Yedeği';
$adminSub   = 'Elle indirilir · otomatik çalışmaz';
include __DIR__ . '/_top.php';
?>
<form method="POST" class="rounded-2xl p-5 space-y-4" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <?= csrfField() ?>
    <p class="text-sm text-gray-400">Seçtiğin tabloların içeriği tek bir <b>.json.gz</b> dosyası olarak bilgisayarına iner. Şifre içeren <code>admin_users</code> tablosu bilerek yedeğe dahil edilmez.</p>
    <div class="grid grid-cols-2 sm:grid-cols-3 gap-2 text-sm">
        <?php foreach ($TABLES as $t): ?>
        <label class="flex items-center gap-2 text-gray-300"><input type="checkbox" name="tables[]" value="<?= $t ?>" checked class="w-4 h-4 accent-cyan-400"> <?= $t ?></label>
        <?php endforeach; ?>
    </div>
    <button class="px-6 py-3 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);"><i class="fa-solid fa-download mr-2"></i>Yedeği İndir</button>
</form>

<div class="rounded-2xl p-5 text-sm text-gray-300 space-y-3 leading-relaxed" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <h2 class="text-base font-bold text-white">Geri yükleme rehberi</h2>
    <ol class="list-decimal ml-5 space-y-2">
        <li><b>Önce mevcut durumu yedekle.</b> Geri yüklemeden önce yukarıdan güncel bir yedek indir.</li>
        <li><b>Yöntem A – Supabase panelinden (önerilen, en güvenli):</b> Supabase → Database → Backups bölümünde Supabase'in kendi günlük yedeklerini (Pro planda) tek tıkla geri yükleyebilirsin. Ücretsiz planda <code>Settings → Database → Backup</code> ile <code>.backup</code> dosyası indirip <code>psql</code> / <code>pg_restore</code> ile yüklenir.</li>
        <li><b>Yöntem B – Bu JSON yedeğinden tek tablo:</b> .gz dosyasını aç, istediğin tablonun dizisini al. Supabase → Table Editor → ilgili tablo → <i>Insert → Import data from CSV</i> ile (JSON'u önce CSV'ye çevir) ya da SQL Editor'de:
            <pre class="mt-2 p-3 rounded-lg overflow-x-auto text-xs" style="background:#0a0a14">INSERT INTO public.categories
SELECT * FROM json_populate_recordset(null::public.categories, '[ ...tablonun JSON dizisi... ]')
ON CONFLICT DO NOTHING;</pre></li>
        <li><b>Sıra önemli:</b> önce <code>channels, categories, profiles</code>, sonra <code>videos</code>, en son <code>comments, likes, subscriptions, video_categories, chapters, subtitles…</code> (yabancı anahtar bağımlılığı).</li>
        <li><b>Kullanıcılar (auth.users)</b> bu yedeğe dahil değildir; Supabase kendi yedeğiyle gelir. Kullanıcı hesapları olmadan <code>comments/likes/watch_*</code> geri yüklenemez.</li>
        <li>Yüklemeden sonra siteyi aç, ana sayfa/video/yorum akışını kontrol et.</li>
    </ol>
    <p class="text-xs text-gray-500">İpucu: Yedeği ayda en az bir kez ve büyük değişikliklerden (toplu video ekleme, SQL güncellemesi) önce al; dosyayı sunucuda değil kendi bilgisayarında/bulutunda sakla.</p>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
