<?php
// ============================================================
// NeonTV - Admin: Kanal Topluluk Gönderileri (duyuru panosu)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin(['editor', 'moderator', 'superadmin']);
$db = new Supabase();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/channel_posts.php'); }
    if (input('action') === 'create') {
        $ch = trim(input('channel_id')); requireUuid($ch, 'Kanal');
        $txt = mb_substr(trim(input('content')), 0, 2000);
        if ($txt === '') { setFlash('error', 'Metin boş olamaz.'); redirect(APP_URL . '/admin/channel_posts.php'); }
        $row = ['channel_id' => $ch, 'content' => $txt];
        // Resim: dosya yükleme (yeniden kodlanır) veya https adresi
        $imgUrl = trim(input('image_url'));
        if (!empty($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $f = $_FILES['image'];
            $info = @getimagesize($f['tmp_name']);
            if ($f['size'] > 5 * 1024 * 1024 || !$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, IMAGETYPE_WEBP], true) || !function_exists('imagecreatefromstring')) {
                setFlash('error', 'Resim geçersiz (JPG/PNG/GIF/WEBP, en fazla 5 MB).'); redirect(APP_URL . '/admin/channel_posts.php');
            }
            $src = @imagecreatefromstring(file_get_contents($f['tmp_name']));
            if ($src) {
                $w = imagesx($src); $h = imagesy($src); $mw = 1280;
                if ($w > $mw) { $nh = (int)round($h * $mw / $w); $dst = imagecreatetruecolor($mw, $nh); imagecopyresampled($dst, $src, 0, 0, 0, 0, $mw, $nh, $w, $h); imagedestroy($src); $src = $dst; }
                $dir = dirname(__DIR__) . '/assets/posts'; if (!is_dir($dir)) @mkdir($dir, 0755, true);
                $name = 'p_' . bin2hex(random_bytes(8)) . '.jpg';
                $bg = imagecreatetruecolor(imagesx($src), imagesy($src)); imagefill($bg, 0, 0, imagecolorallocate($bg, 7, 7, 17)); imagecopy($bg, $src, 0, 0, 0, 0, imagesx($src), imagesy($src));
                if (@imagejpeg($bg, $dir . '/' . $name, 85)) $row['image_url'] = 'assets/posts/' . $name;
            }
        } elseif ($imgUrl !== '' && preg_match('#^https://#i', $imgUrl)) {
            $row['image_url'] = mb_substr($imgUrl, 0, 500);
        }
        // Anket: her satır bir seçenek (2–6)
        $opts = array_values(array_filter(array_map(fn($l) => mb_substr(trim($l), 0, 60), preg_split('/\R/u', (string)input('poll_options'))), fn($l) => $l !== ''));
        if (count($opts) >= 2) {
            $row['poll'] = array_slice($opts, 0, 6);
            if (trim(input('poll_ends'))) $row['poll_ends_at'] = date('c', strtotime(input('poll_ends')));
        }
        $r = $db->insert('channel_posts', $row, true);
        setFlash(($r['status'] ?? 500) < 400 ? 'success' : 'error', ($r['status'] ?? 500) < 400 ? 'Gönderi yayınlandı.' : 'Kaydedilemedi (SQL çalıştırıldı mı?).');
    } elseif (input('action') === 'delete') {
        $id = trim(input('id')); requireUuid($id, 'Gönderi');
        $db->delete('channel_posts', 'id=eq.' . $id, true);
        setFlash('success', 'Gönderi silindi.');
    }
    redirect(APP_URL . '/admin/channel_posts.php');
}

$channels = $db->select('channels', 'select=id,name&order=name.asc&limit=300', true)['data'] ?? [];
$names = array_column($channels, 'name', 'id');
$posts = $db->select('channel_posts', 'order=created_at.desc&limit=100', true)['data'] ?? [];

$adminTitle = 'Kanal Duyuruları';
$adminSub   = 'Kanal sayfasındaki "Topluluk" sekmesi';
include __DIR__ . '/_top.php';
$inp = 'bg-black/30 border border-gray-800 rounded-xl py-2.5 px-3 text-white text-sm focus:outline-none focus:border-cyan-500';
?>
<form method="POST" enctype="multipart/form-data" class="rounded-2xl p-5 space-y-3" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <?= csrfField() ?><input type="hidden" name="action" value="create">
    <select name="channel_id" required class="<?= $inp ?> w-full"><option value="">Kanal seç</option><?php foreach ($channels as $c): ?><option value="<?= e($c['id']) ?>"><?= e($c['name']) ?></option><?php endforeach; ?></select>
    <textarea name="content" required maxlength="2000" rows="4" placeholder="Duyuru metni (en fazla 2000 karakter)" class="<?= $inp ?> w-full"></textarea>
    <div class="grid sm:grid-cols-2 gap-3">
        <div><label class="block text-xs text-gray-400 mb-1">Resim yükle (isteğe bağlı)</label><input type="file" name="image" accept="image/*" class="<?= $inp ?> w-full"></div>
        <div><label class="block text-xs text-gray-400 mb-1">veya resim adresi (https://…)</label><input type="text" name="image_url" class="<?= $inp ?> w-full" placeholder="https://..."></div>
    </div>
    <div class="grid sm:grid-cols-2 gap-3">
        <div><label class="block text-xs text-gray-400 mb-1">Anket seçenekleri (isteğe bağlı, her satıra bir seçenek, 2–6 adet)</label><textarea name="poll_options" rows="3" class="<?= $inp ?> w-full" placeholder="Seçenek 1&#10;Seçenek 2"></textarea></div>
        <div><label class="block text-xs text-gray-400 mb-1">Anket bitişi (boşsa süresiz)</label><input type="datetime-local" name="poll_ends" class="<?= $inp ?> w-full"></div>
    </div>
    <button class="px-6 py-2.5 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Yayınla</button>
</form>
<?php foreach ($posts as $p): ?>
<div class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <div class="flex items-center gap-2 text-xs text-gray-500 mb-2"><span class="text-cyan-400 font-semibold"><?= e($names[$p['channel_id']] ?? 'Kanal') ?></span> · <?= e(date('d.m.Y H:i', strtotime($p['created_at']))) ?>
        <form method="POST" class="ml-auto" onsubmit="return confirm('Gönderi silinsin mi?')"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e($p['id']) ?>"><button class="text-red-400"><i class="fa-solid fa-trash"></i></button></form></div>
    <p class="text-sm text-gray-200 whitespace-pre-wrap"><?= e($p['content']) ?></p>
    <?php if (!empty($p['image_url'])): ?><p class="text-[11px] text-gray-500 mt-1"><i class="fa-regular fa-image"></i> resimli</p><?php endif; ?><?php if (!empty($p['poll'])): ?><p class="text-[11px] text-gray-500"><i class="fa-solid fa-square-poll-vertical"></i> anketli</p><?php endif; ?>
</div>
<?php endforeach; if (!$posts): ?><p class="text-center text-gray-500 py-6">Henüz gönderi yok.</p><?php endif; ?>
<?php include __DIR__ . '/_bottom.php'; ?>
