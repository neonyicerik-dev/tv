<?php
// ============================================================
// NeonTV - Admin: Hata Günlüğü (PHP hataları ve istisnalar)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
requireAdmin('superadmin');

$path = dirname(__DIR__) . '/logs/app_errors.log';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/error_log.php'); }
    if (input('action') === 'clear') { @file_put_contents($path, ''); @unlink($path . '.1'); setFlash('success', 'Günlük temizlendi.'); }
    redirect(APP_URL . '/admin/error_log.php');
}

$rows = [];
if (is_file($path)) {
    $lines = [];
    $fp = @fopen($path, 'r');
    if ($fp) { $size = filesize($path); if ($size > 400000) fseek($fp, -400000, SEEK_END); while (($l = fgets($fp)) !== false) $lines[] = $l; fclose($fp); }
    foreach (array_reverse(array_slice($lines, -1000)) as $l) { $r = json_decode($l, true); if (is_array($r)) $rows[] = $r; }
}
$filter = pgEnum($_GET['lv'] ?? '', ['WARNING', 'ERROR', 'EXCEPTION', 'FATAL'], '');
if ($filter) $rows = array_values(array_filter($rows, fn($r) => ($r['lv'] ?? '') === $filter));
$rows = array_slice($rows, 0, 200);

$adminTitle = 'Hata Günlüğü';
$adminSub   = 'Son hatalar · en yeni üstte';
include __DIR__ . '/_top.php';
$col = ['WARNING' => '#ffd76a', 'ERROR' => '#ff7a7a', 'EXCEPTION' => '#ff5fa8', 'FATAL' => '#ff3b3b'];
?>
<div class="flex flex-wrap items-center gap-2">
    <a href="?" class="px-3 py-1.5 rounded-full text-xs <?= !$filter ? 'text-cyan-400' : 'text-gray-400' ?>" style="background:rgba(255,255,255,0.06)">Tümü</a>
    <?php foreach (array_keys($col) as $lv): ?><a href="?lv=<?= $lv ?>" class="px-3 py-1.5 rounded-full text-xs <?= $filter === $lv ? 'text-cyan-400' : 'text-gray-400' ?>" style="background:rgba(255,255,255,0.06)"><?= $lv ?></a><?php endforeach; ?>
    <form method="POST" class="ml-auto" onsubmit="return confirm('Tüm günlük silinsin mi?')"><?= csrfField() ?><input type="hidden" name="action" value="clear"><button class="px-3 py-1.5 rounded-full text-xs text-red-400" style="background:rgba(255,255,255,0.06)">Temizle</button></form>
</div>
<div class="rounded-2xl overflow-x-auto" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <table class="w-full text-xs">
        <thead><tr class="text-left text-gray-500"><th class="p-3">Zaman</th><th class="p-3">Tür</th><th class="p-3">Mesaj</th><th class="p-3">Dosya</th><th class="p-3">İstek</th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="5" class="p-8 text-center text-gray-500">Kayıtlı hata yok. 🎉</td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
        <tr class="border-t border-white/5 align-top">
            <td class="p-3 text-gray-400 whitespace-nowrap"><?= e($r['t'] ?? '') ?></td>
            <td class="p-3 font-bold" style="color:<?= $col[$r['lv'] ?? ''] ?? '#fff' ?>"><?= e($r['lv'] ?? '') ?></td>
            <td class="p-3 text-gray-200 break-words max-w-md"><?= e($r['msg'] ?? '') ?></td>
            <td class="p-3 text-gray-500 whitespace-nowrap"><?= e($r['at'] ?? '') ?></td>
            <td class="p-3 text-gray-500 break-all"><?= e($r['url'] ?? '') ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
