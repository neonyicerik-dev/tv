<?php
// ============================================================
// NeonTV - Admin: Kırık Bağlantı Tarayıcısı (video + küçük resim)
// Elle başlatılır; sunucudan HEAD/Range isteğiyle adresleri dener.
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin(['editor', 'moderator', 'superadmin']);
$db = new Supabase();

/** Adres güvenli mi? (yalnızca https, özel/yerel IP'lere istek yok) */
function safeUrl(string $u): bool {
    $p = parse_url($u);
    if (!$p || ($p['scheme'] ?? '') !== 'https' || empty($p['host'])) return false;
    $ips = @gethostbynamel($p['host']) ?: [];
    if (!$ips) return false;
    foreach ($ips as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return false;
    }
    return true;
}
function probe(string $url): array {
    if (!safeUrl($url)) return ['ok' => false, 'code' => 0, 'err' => 'Geçersiz veya erişilemeyen adres'];
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_HEADER => false, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3,
        CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
        CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_HTTPHEADER => ['Range: bytes=0-0'], CURLOPT_USERAGENT => 'NeonTV-LinkCheck/1.0',
        CURLOPT_WRITEFUNCTION => function ($c, $d) { return 0; }, // gövdeyi indirme
    ]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    $ok = $code >= 200 && $code < 400;
    return ['ok' => $ok, 'code' => $code, 'err' => $ok ? '' : ($code ? 'HTTP ' . $code : ($err && stripos($err, 'callback') === false ? $err : 'Yanıt yok'))];
}

// AJAX: tek video kontrolü
if (isset($_GET['check'])) {
    $id = trim($_GET['check']);
    requireUuid($id, 'Video ID');
    $v = $db->first('videos', 'id=eq.' . $id . '&select=id,video_url,thumbnail_url', true);
    if (!$v) jsonError('Video yok', 404);
    $res = ['video' => probe((string)$v['video_url'])];
    if (!empty($v['thumbnail_url'])) $res['thumb'] = probe((string)$v['thumbnail_url']);
    jsonSuccess($res);
}

$videos = $db->select('videos', 'select=id,title,status&order=created_at.desc&limit=1000', true)['data'] ?? [];
$adminTitle = 'Kırık Bağlantı Tarayıcısı';
$adminSub   = 'Video ve küçük resim adreslerini sırayla dener';
include __DIR__ . '/_top.php';
?>
<div class="rounded-2xl p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <p class="text-sm text-gray-400 mb-3"><b class="text-white"><?= count($videos) ?></b> video taranacak. Tarama sayfa açıkken sürer; her video için video ve küçük resim adresi sunucudan denenir.</p>
    <div class="flex items-center gap-3 flex-wrap">
        <button id="lc-start" class="px-5 py-2.5 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);"><i class="fa-solid fa-magnifying-glass mr-2"></i>Taramayı Başlat</button>
        <button id="lc-draft" class="hidden px-4 py-2.5 rounded-xl text-sm font-semibold text-black" style="background:#ffd76a">Kırıkları taslağa al</button>
        <span id="lc-status" class="text-sm text-gray-400"></span>
    </div>
    <div class="h-1.5 rounded-full mt-4 overflow-hidden" style="background:rgba(255,255,255,0.08)"><div id="lc-bar" class="h-full" style="width:0;background:linear-gradient(90deg,#00f5ff,#bf00ff)"></div></div>
</div>
<div class="rounded-2xl overflow-x-auto" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <table class="w-full text-sm"><thead><tr class="text-left text-gray-500 text-xs"><th class="p-3">Video</th><th class="p-3">Sorun</th><th class="p-3"></th></tr></thead>
        <tbody id="lc-body"><tr><td colspan="3" class="p-6 text-center text-gray-500">Henüz tarama yapılmadı.</td></tr></tbody></table>
</div>
<script>
const LC = <?= json_encode(array_map(fn($v) => ['id' => $v['id'], 'title' => $v['title'], 'status' => $v['status']], $videos), JSON_UNESCAPED_UNICODE) ?>;
const APP = '<?= APP_URL ?>';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let broken = [];
document.getElementById('lc-start').onclick = async function () {
    this.disabled = true; broken = [];
    const body = document.getElementById('lc-body'), st = document.getElementById('lc-status'), bar = document.getElementById('lc-bar');
    body.innerHTML = ''; let done = 0, idx = 0;
    async function worker() {
        while (idx < LC.length) {
            const v = LC[idx++];
            try {
                const j = await (await fetch('?check=' + v.id, { headers: { 'Accept': 'application/json' } })).json();
                const d = j.data || {}; const probs = [];
                if (d.video && !d.video.ok) probs.push('Video: ' + d.video.err);
                if (d.thumb && !d.thumb.ok) probs.push('Küçük resim: ' + d.thumb.err);
                if (probs.length) {
                    broken.push(v);
                    body.insertAdjacentHTML('beforeend', '<tr class="border-t border-white/5"><td class="p-3 text-white">' + esc(v.title) + ' <span class="text-xs text-gray-500">(' + esc(v.status) + ')</span></td><td class="p-3 text-red-400 text-xs">' + probs.map(esc).join('<br>') + '</td><td class="p-3 text-right"><a class="text-cyan-400 text-xs" href="' + APP + '/admin/videos.php?q=' + encodeURIComponent(v.title) + '">Düzenle</a></td></tr>');
                }
            } catch (e) {}
            done++; bar.style.width = (done / LC.length * 100) + '%'; st.textContent = done + ' / ' + LC.length + ' tarandı · ' + broken.length + ' sorunlu';
        }
    }
    await Promise.all([worker(), worker(), worker()]);
    st.textContent = 'Bitti: ' + LC.length + ' video tarandı, ' + broken.length + ' sorunlu.';
    if (!broken.length) body.innerHTML = '<tr><td colspan="3" class="p-6 text-center text-green-400">Tüm bağlantılar çalışıyor.</td></tr>';
    else document.getElementById('lc-draft').classList.remove('hidden');
    this.disabled = false;
};
document.getElementById('lc-draft').onclick = async function () {
    const ids = broken.filter(v => v.status === 'published').map(v => v.id);
    if (!ids.length) { alert('Yayındaki sorunlu video yok.'); return; }
    if (!confirm(ids.length + ' yayındaki sorunlu video taslağa alınsın mı?')) return;
    const r = await fetch(APP + '/api/videos.php', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ bulk_ids: ids, status: 'draft' }) }).then(r => r.json());
    alert(r.success ? 'Taslağa alındı.' : (r.message || 'Hata'));
};
</script>
<?php include __DIR__ . '/_bottom.php'; ?>
