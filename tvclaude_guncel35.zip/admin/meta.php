<?php
// ============================================================
// NeonTV - Admin Meta Etiket Yönetimi
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
requireAdmin('superadmin');

require_once __DIR__ . '/../includes/store.php';
$settings    = loadSettingsCompat();
$settingsOld = $settings;

$saved   = false;
$saveErr = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Genel site meta
    $settings['site_og_image']    = trim($_POST['site_og_image'] ?? '');
    $settings['site_meta_robots'] = in_array(
        $_POST['site_meta_robots'] ?? 'index,follow',
        ['index,follow', 'noindex,nofollow', 'index,nofollow', 'noindex,follow']
    ) ? $_POST['site_meta_robots'] : 'index,follow';
    $settings['sitemap_changefreq'] = in_array(
        $_POST['sitemap_changefreq'] ?? 'weekly',
        ['always', 'hourly', 'daily', 'weekly', 'monthly', 'yearly', 'never']
    ) ? $_POST['sitemap_changefreq'] : 'weekly';

    // Sayfa meta
    $settings['page_meta']['index']['title']        = trim($_POST['index_title'] ?? '');
    $settings['page_meta']['index']['description']  = trim($_POST['index_description'] ?? '');
    $settings['page_meta']['index']['og_image']     = trim($_POST['index_og_image'] ?? '');

    $settings['page_meta']['video']['title_format']       = trim($_POST['video_title_format'] ?? '%s | NeonTV');
    $settings['page_meta']['video']['description_format'] = trim($_POST['video_description_format'] ?? '%s');

    $settings['page_meta']['channel']['title_format']       = trim($_POST['channel_title_format'] ?? '%s Kanalı | NeonTV');
    $settings['page_meta']['channel']['description_format'] = trim($_POST['channel_description_format'] ?? '%s kanalının videolarını izleyin.');

    $settings['page_meta']['search']['title']       = trim($_POST['search_title'] ?? '');
    $settings['page_meta']['search']['description'] = trim($_POST['search_description'] ?? '');

    $settings['page_meta']['auth']['title']       = trim($_POST['auth_title'] ?? '');
    $settings['page_meta']['auth']['description'] = trim($_POST['auth_description'] ?? '');

    $json = json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if (saveSettingsDiff($settingsOld, $settings)) {
        $saved = true;
    } else {
        $saveErr = 'Ayarlar veritabanına kaydedilemedi. site_settings tablosunu kontrol edin.';
    }
}

// Kısa erişim değişkenleri
$pm  = $settings['page_meta'] ?? [];
$idx = $pm['index']   ?? [];
$vid = $pm['video']   ?? [];
$ch  = $pm['channel'] ?? [];
$srch= $pm['search']  ?? [];
$ath = $pm['auth']    ?? [];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meta Etiketler | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }

        .panel {
            background: #0f0f1e;
            border: 1px solid rgba(255,255,255,0.07);
            border-radius: 1rem;
            overflow: hidden;
        }
        .panel-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid rgba(255,255,255,0.06);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        .panel-icon {
            width: 2rem; height: 2rem;
            border-radius: 0.5rem;
            display: flex; align-items: center; justify-content: center;
            font-size: 0.8rem;
        }
        .input-field {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            width: 100%;
            padding: 0.6rem 0.85rem;
            border-radius: 0.625rem;
            transition: all 0.2s;
            color: #fff;
            font-size: 0.875rem;
            font-family: 'Outfit', sans-serif;
        }
        .input-field:focus {
            border-color: rgba(0,245,255,0.5);
            box-shadow: 0 0 0 3px rgba(0,245,255,0.08);
            outline: none;
        }
        .input-field::placeholder { color: rgba(255,255,255,0.2); }
        select.input-field option { background: #0f0f1e; color: #fff; }
        .section-label {
            display: block;
            font-size: 0.7rem;
            font-weight: 600;
            color: #9ca3af;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 0.4rem;
        }
        .hint {
            font-size: 0.7rem;
            color: rgba(255,255,255,0.3);
            margin-top: 0.3rem;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.2rem 0.6rem;
            border-radius: 9999px;
            font-size: 0.65rem;
            font-weight: 600;
        }
        .tab-btn {
            padding: 0.5rem 1rem;
            border-radius: 0.6rem;
            font-size: 0.8rem;
            font-weight: 600;
            transition: all 0.2s;
            cursor: pointer;
            border: 1px solid transparent;
            white-space: nowrap;
        }
        .tab-btn.active {
            background: linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.1));
            border-color: rgba(0,245,255,0.3);
            color: #00f5ff;
        }
        .tab-btn:not(.active) { color: #6b7280; }
        .tab-btn:not(.active):hover { color: #fff; background: rgba(255,255,255,0.06); }
        .tab-panel { display: none; }
        .tab-panel.active { display: block; }

        /* Preview card */
        .preview-card {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 0.75rem;
            padding: 1rem;
        }
        .preview-title {
            font-size: 0.9rem;
            font-weight: 600;
            color: #1a73e8;
            margin-bottom: 0.2rem;
            line-height: 1.3;
        }
        .preview-url {
            font-size: 0.7rem;
            color: #34a853;
            margin-bottom: 0.25rem;
        }
        .preview-desc {
            font-size: 0.75rem;
            color: #bdc1c6;
            line-height: 1.5;
        }
        .char-count {
            font-size: 0.65rem;
            text-align: right;
            margin-top: 0.2rem;
        }
        .char-ok   { color: #22c55e; }
        .char-warn { color: #f59e0b; }
        .char-bad  { color: #ef4444; }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- Top Bar -->
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.95);backdrop-filter:blur(24px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors"
                    style="background:rgba(255,255,255,0.06);">
                <i class="fa-solid fa-bars text-sm"></i>
            </button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white">Meta Etiket Yönetimi</h1>
                <p class="text-xs text-gray-500 hidden sm:block">Sayfa başlıkları, açıklamaları ve SEO ayarları</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <a href="<?= APP_URL ?>/sitemap.php" target="_blank"
               class="flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-gray-400 hover:text-cyan-400 transition-all"
               style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                <i class="fa-solid fa-sitemap text-xs"></i>
                <span class="hidden sm:inline">Sitemap</span>
            </a>
            <a href="<?= APP_URL ?>/admin/index.php"
               class="flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-gray-400 hover:text-white transition-all"
               style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                <i class="fa-solid fa-arrow-left text-xs"></i>
                <span class="hidden sm:inline">Dashboard</span>
            </a>
        </div>
    </header>

    <main class="flex-1 p-4 sm:p-6 overflow-auto">
        <div class="max-w-4xl mx-auto space-y-5">

            <!-- Bildirimler -->
            <?php if ($saved): ?>
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium"
                 style="background:rgba(0,245,255,0.08);border:1px solid rgba(0,245,255,0.25);color:#00f5ff;"
                 id="save-success-msg">
                <i class="fa-solid fa-circle-check"></i>
                Meta etiketler başarıyla kaydedildi!
                <button onclick="this.parentElement.remove()" class="ml-auto text-gray-500 hover:text-white">
                    <i class="fa-solid fa-xmark text-xs"></i>
                </button>
            </div>
            <?php endif; ?>
            <?php if ($saveErr): ?>
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium"
                 style="background:rgba(255,0,122,0.08);border:1px solid rgba(255,0,122,0.25);color:#ff007a;">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <?= e($saveErr) ?>
            </div>
            <?php endif; ?>

            <!-- Üst bilgi kartı -->
            <div class="panel">
                <div class="p-5 flex items-start gap-4">
                    <div class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 text-sm"
                         style="background:linear-gradient(135deg,rgba(0,245,255,0.2),rgba(191,0,255,0.1));color:#00f5ff;border:1px solid rgba(0,245,255,0.2);">
                        <i class="fa-solid fa-circle-info"></i>
                    </div>
                    <div>
                        <p class="text-sm font-semibold text-white mb-1">Meta Etiket Nedir?</p>
                        <p class="text-xs text-gray-400 leading-relaxed">
                            Meta etiketler, arama motorlarının ve sosyal medya platformlarının sayfanızı nasıl gösterdiğini belirler.
                            <strong class="text-gray-300">Başlık</strong> 50-60 karakter, <strong class="text-gray-300">Açıklama</strong> 120-160 karakter olmalıdır.
                            Video/Kanal sayfalarında <code class="text-cyan-400 text-xs bg-white/5 px-1 rounded">%s</code> ifadesi otomatik olarak ilgili içerik adıyla değiştirilir.
                        </p>
                    </div>
                </div>
            </div>

            <form method="POST" action="">
                <?= csrfField() ?>

                <!-- Tabs -->
                <div class="flex items-center gap-2 p-1 rounded-xl overflow-x-auto" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);">
                    <button type="button" class="tab-btn active" onclick="showTab('general', this)" id="tab-general">
                        <i class="fa-solid fa-globe mr-1.5"></i> Genel
                    </button>
                    <button type="button" class="tab-btn" onclick="showTab('index', this)" id="tab-index">
                        <i class="fa-solid fa-house mr-1.5"></i> Ana Sayfa
                    </button>
                    <button type="button" class="tab-btn" onclick="showTab('video', this)" id="tab-video">
                        <i class="fa-solid fa-play mr-1.5"></i> Video
                    </button>
                    <button type="button" class="tab-btn" onclick="showTab('channel', this)" id="tab-channel">
                        <i class="fa-solid fa-users-rectangle mr-1.5"></i> Kanal
                    </button>
                    <button type="button" class="tab-btn" onclick="showTab('search', this)" id="tab-search">
                        <i class="fa-solid fa-magnifying-glass mr-1.5"></i> Arama
                    </button>
                    <button type="button" class="tab-btn" onclick="showTab('auth', this)" id="tab-auth">
                        <i class="fa-solid fa-user mr-1.5"></i> Giriş
                    </button>
                </div>

                <!-- ===== TAB: GENEL ===== -->
                <div class="tab-panel active space-y-4 mt-4" id="panel-general">
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-icon" style="background:rgba(0,245,255,0.1);color:#00f5ff;">
                                <i class="fa-solid fa-robot"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-white">Robots Direktifi</p>
                                <p class="text-xs text-gray-500">Arama motorlarının siteyi nasıl tarayacağını belirler</p>
                            </div>
                        </div>
                        <div class="p-5 space-y-4">
                            <div>
                                <label class="section-label">Meta Robots</label>
                                <select name="site_meta_robots" class="input-field" id="metaRobotsSelect">
                                    <?php $r = $settings['site_meta_robots'] ?? 'index,follow'; ?>
                                    <option value="index,follow"   <?= $r==='index,follow'   ?'selected':'' ?>>index, follow — Tüm botlara açık (Önerilen)</option>
                                    <option value="noindex,nofollow" <?= $r==='noindex,nofollow' ?'selected':'' ?>>noindex, nofollow — Tamamen gizle</option>
                                    <option value="index,nofollow" <?= $r==='index,nofollow' ?'selected':'' ?>>index, nofollow — İndeksle ama linkleri takip etme</option>
                                    <option value="noindex,follow" <?= $r==='noindex,follow' ?'selected':'' ?>>noindex, follow — İndeksleme, linkleri takip et</option>
                                </select>
                                <p class="hint">
                                    <i class="fa-solid fa-triangle-exclamation text-yellow-400"></i>
                                    "noindex" seçerseniz Google sitenizi arama sonuçlarında göstermez.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-icon" style="background:rgba(191,0,255,0.1);color:#bf00ff;">
                                <i class="fa-solid fa-image"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-white">Site OG Görseli</p>
                                <p class="text-xs text-gray-500">Sosyal medyada paylaşılınca gösterilecek varsayılan görsel</p>
                            </div>
                        </div>
                        <div class="p-5 space-y-4">
                            <div>
                                <label class="section-label">OG Image URL (Site Geneli Varsayılan)</label>
                                <input type="url" name="site_og_image" class="input-field"
                                       placeholder="https://neontv.cu.ma/assets/og-image.jpg"
                                       value="<?= e($settings['site_og_image'] ?? '') ?>"
                                       oninput="updateOgPreview(this.value)">
                                <p class="hint">1200×630 piksel önerilen boyut. Video sayfalarında video thumbnail'i kullanılır.</p>
                            </div>
                            <div id="og-preview-wrap" class="<?= empty($settings['site_og_image']) ? 'hidden' : '' ?>">
                                <label class="section-label">Önizleme</label>
                                <div class="rounded-xl overflow-hidden border border-white/10">
                                    <img id="og-preview-img" src="<?= e($settings['site_og_image'] ?? '') ?>"
                                         alt="OG Görsel Önizleme"
                                         class="w-full max-h-48 object-cover" onerror="this.parentElement.parentElement.classList.add('hidden')">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-icon" style="background:rgba(34,197,94,0.1);color:#22c55e;">
                                <i class="fa-solid fa-sitemap"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-white">Sitemap Ayarları</p>
                                <p class="text-xs text-gray-500">XML sitemap güncelleme sıklığı</p>
                            </div>
                        </div>
                        <div class="p-5 space-y-4">
                            <div>
                                <label class="section-label">Güncelleme Sıklığı (changefreq)</label>
                                <select name="sitemap_changefreq" class="input-field">
                                    <?php $cf = $settings['sitemap_changefreq'] ?? 'weekly'; ?>
                                    <option value="always"  <?= $cf==='always'  ?'selected':'' ?>>always — Her zaman</option>
                                    <option value="hourly"  <?= $cf==='hourly'  ?'selected':'' ?>>hourly — Saatlik</option>
                                    <option value="daily"   <?= $cf==='daily'   ?'selected':'' ?>>daily — Günlük</option>
                                    <option value="weekly"  <?= $cf==='weekly'  ?'selected':'' ?>>weekly — Haftalık (Önerilen)</option>
                                    <option value="monthly" <?= $cf==='monthly' ?'selected':'' ?>>monthly — Aylık</option>
                                    <option value="yearly"  <?= $cf==='yearly'  ?'selected':'' ?>>yearly — Yıllık</option>
                                    <option value="never"   <?= $cf==='never'   ?'selected':'' ?>>never — Hiçbir zaman</option>
                                </select>
                                <p class="hint">Arama motorlarına içeriğin ne sıklıkla değiştiğini bildirir.</p>
                            </div>
                            <div class="flex items-center gap-3 p-3 rounded-xl" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);">
                                <i class="fa-solid fa-link text-cyan-400 text-sm"></i>
                                <div class="flex-1 min-w-0">
                                    <p class="text-xs text-gray-400">Sitemap URL'si</p>
                                    <code class="text-xs text-cyan-400"><?= APP_URL ?>/sitemap.php</code>
                                </div>
                                <a href="<?= APP_URL ?>/sitemap.php" target="_blank"
                                   class="px-3 py-1.5 rounded-lg text-xs font-medium text-gray-300 hover:text-white transition-colors"
                                   style="background:rgba(255,255,255,0.08);">
                                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                </a>
                            </div>
                            <div class="flex items-center gap-3 p-3 rounded-xl" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);">
                                <i class="fa-solid fa-robot text-purple-400 text-sm"></i>
                                <div class="flex-1 min-w-0">
                                    <p class="text-xs text-gray-400">Robots.txt</p>
                                    <code class="text-xs text-purple-400"><?= APP_URL ?>/robots.txt</code>
                                </div>
                                <a href="<?= APP_URL ?>/robots.txt" target="_blank"
                                   class="px-3 py-1.5 rounded-lg text-xs font-medium text-gray-300 hover:text-white transition-colors"
                                   style="background:rgba(255,255,255,0.08);">
                                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                </a>
                            </div>
                            <div class="flex items-center gap-3 p-3 rounded-xl" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);">
                                <i class="fa-solid fa-microchip text-green-400 text-sm"></i>
                                <div class="flex-1 min-w-0">
                                    <p class="text-xs text-gray-400">LLMs.txt</p>
                                    <code class="text-xs text-green-400"><?= APP_URL ?>/llms.txt</code>
                                </div>
                                <a href="<?= APP_URL ?>/llms.txt" target="_blank"
                                   class="px-3 py-1.5 rounded-lg text-xs font-medium text-gray-300 hover:text-white transition-colors"
                                   style="background:rgba(255,255,255,0.08);">
                                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ===== TAB: ANA SAYFA ===== -->
                <div class="tab-panel space-y-4 mt-4" id="panel-index">
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-icon" style="background:rgba(0,245,255,0.1);color:#00f5ff;">
                                <i class="fa-solid fa-house"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-white">Ana Sayfa Meta Etiketleri</p>
                                <p class="text-xs text-gray-500"><?= APP_URL ?>/index.php</p>
                            </div>
                        </div>
                        <div class="p-5 space-y-4">
                            <div>
                                <label class="section-label">Sayfa Başlığı</label>
                                <input type="text" name="index_title" class="input-field"
                                       id="index_title"
                                       placeholder="Ana Sayfa | NeonTV"
                                       value="<?= e($idx['title'] ?? 'Ana Sayfa | NeonTV') ?>"
                                       oninput="updatePreview('index'); countChars(this, 'index_title_count', 60)">
                                <div class="flex justify-between items-center mt-1">
                                    <p class="hint">50-60 karakter arası önerilir.</p>
                                    <span class="char-count <?= charClass(strlen($idx['title'] ?? 'Ana Sayfa | NeonTV'), 60) ?>"
                                          id="index_title_count"><?= strlen($idx['title'] ?? 'Ana Sayfa | NeonTV') ?>/60</span>
                                </div>
                            </div>
                            <div>
                                <label class="section-label">Meta Açıklama</label>
                                <textarea name="index_description" class="input-field" rows="3"
                                          id="index_description"
                                          placeholder="NeonTV - Neon ışıklı video deneyimi. En yeni ve popüler videoları izleyin."
                                          oninput="updatePreview('index'); countChars(this, 'index_desc_count', 160)"
                                ><?= e($idx['description'] ?? '') ?></textarea>
                                <div class="flex justify-between items-center mt-1">
                                    <p class="hint">120-160 karakter arası önerilir.</p>
                                    <span class="char-count <?= charClass(strlen($idx['description'] ?? ''), 160) ?>"
                                          id="index_desc_count"><?= strlen($idx['description'] ?? '') ?>/160</span>
                                </div>
                            </div>
                            <div>
                                <label class="section-label">OG Görseli (Sadece bu sayfa için)</label>
                                <input type="url" name="index_og_image" class="input-field"
                                       placeholder="Boş bırakırsanız site geneli OG görseli kullanılır"
                                       value="<?= e($idx['og_image'] ?? '') ?>">
                            </div>

                            <!-- SERP Önizleme -->
                            <div>
                                <label class="section-label">Google Önizlemesi</label>
                                <div class="preview-card">
                                    <div class="preview-url"><?= APP_URL ?>/</div>
                                    <div class="preview-title" id="preview_index_title"><?= e($idx['title'] ?? 'Ana Sayfa | NeonTV') ?></div>
                                    <div class="preview-desc" id="preview_index_desc"><?= e(mb_substr($idx['description'] ?? 'NeonTV - Neon ışıklı video deneyimi.', 0, 160)) ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ===== TAB: VİDEO ===== -->
                <div class="tab-panel space-y-4 mt-4" id="panel-video">
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-icon" style="background:rgba(255,0,122,0.1);color:#ff007a;">
                                <i class="fa-solid fa-play"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-white">Video Sayfası Meta Formatı</p>
                                <p class="text-xs text-gray-500"><?= APP_URL ?>/video.php?id=...</p>
                            </div>
                        </div>
                        <div class="p-5 space-y-4">
                            <div class="p-3 rounded-xl text-xs" style="background:rgba(0,245,255,0.06);border:1px solid rgba(0,245,255,0.15);color:#a5f3fc;">
                                <i class="fa-solid fa-circle-info mr-1.5"></i>
                                <code>%s</code> ifadesi video başlığı/açıklamasıyla otomatik değiştirilir.
                            </div>
                            <div>
                                <label class="section-label">Başlık Formatı</label>
                                <input type="text" name="video_title_format" class="input-field"
                                       placeholder="%s | NeonTV"
                                       value="<?= e($vid['title_format'] ?? '%s | NeonTV') ?>"
                                       oninput="updateFormatPreview('video_title_format', 'video_title_preview', 'Örnek Video Başlığı')">
                                <p class="hint">Örnek: "%s | NeonTV" → "Video Adı | NeonTV"</p>
                                <div class="mt-2 px-3 py-2 rounded-lg text-xs" style="background:rgba(255,255,255,0.04);">
                                    Sonuç: <span class="text-cyan-400 font-medium" id="video_title_preview"><?= e(sprintf($vid['title_format'] ?? '%s | NeonTV', 'Örnek Video Başlığı')) ?></span>
                                </div>
                            </div>
                            <div>
                                <label class="section-label">Açıklama Formatı</label>
                                <input type="text" name="video_description_format" class="input-field"
                                       placeholder="%s"
                                       value="<?= e($vid['description_format'] ?? '%s') ?>"
                                       oninput="updateFormatPreview('video_description_format', 'video_desc_preview', 'Bu videonun açıklaması burada gösterilir...')">
                                <p class="hint">Örnek: "%s" → Video açıklaması aynen kullanılır</p>
                                <div class="mt-2 px-3 py-2 rounded-lg text-xs" style="background:rgba(255,255,255,0.04);">
                                    Sonuç: <span class="text-gray-300" id="video_desc_preview"><?= e(sprintf($vid['description_format'] ?? '%s', 'Bu videonun açıklaması burada gösterilir...')) ?></span>
                                </div>
                            </div>
                            <!-- SERP Preview -->
                            <div>
                                <label class="section-label">Google Önizlemesi</label>
                                <div class="preview-card">
                                    <div class="preview-url"><?= APP_URL ?>/video.php?id=<span class="text-gray-500">uuid...</span></div>
                                    <div class="preview-title" id="preview_video_title"><?= e(sprintf($vid['title_format'] ?? '%s | NeonTV', 'Örnek Video Adı')) ?></div>
                                    <div class="preview-desc"><?= e(sprintf($vid['description_format'] ?? '%s', 'Video açıklaması burada görünür. SEO için önemli bir metin...')) ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ===== TAB: KANAL ===== -->
                <div class="tab-panel space-y-4 mt-4" id="panel-channel">
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-icon" style="background:rgba(191,0,255,0.1);color:#bf00ff;">
                                <i class="fa-solid fa-users-rectangle"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-white">Kanal Sayfası Meta Formatı</p>
                                <p class="text-xs text-gray-500"><?= APP_URL ?>/channel.php?id=...</p>
                            </div>
                        </div>
                        <div class="p-5 space-y-4">
                            <div class="p-3 rounded-xl text-xs" style="background:rgba(0,245,255,0.06);border:1px solid rgba(0,245,255,0.15);color:#a5f3fc;">
                                <i class="fa-solid fa-circle-info mr-1.5"></i>
                                <code>%s</code> ifadesi kanal adıyla otomatik değiştirilir.
                            </div>
                            <div>
                                <label class="section-label">Başlık Formatı</label>
                                <input type="text" name="channel_title_format" class="input-field"
                                       placeholder="%s Kanalı | NeonTV"
                                       value="<?= e($ch['title_format'] ?? '%s Kanalı | NeonTV') ?>"
                                       oninput="updateFormatPreview('channel_title_format', 'channel_title_preview', 'Örnek Kanal')">
                                <p class="hint">Örnek: "%s Kanalı | NeonTV" → "Kanal Adı Kanalı | NeonTV"</p>
                                <div class="mt-2 px-3 py-2 rounded-lg text-xs" style="background:rgba(255,255,255,0.04);">
                                    Sonuç: <span class="text-purple-400 font-medium" id="channel_title_preview"><?= e(sprintf($ch['title_format'] ?? '%s Kanalı | NeonTV', 'Örnek Kanal')) ?></span>
                                </div>
                            </div>
                            <div>
                                <label class="section-label">Açıklama Formatı</label>
                                <input type="text" name="channel_description_format" class="input-field"
                                       placeholder="%s kanalının videolarını izleyin."
                                       value="<?= e($ch['description_format'] ?? '%s kanalının videolarını izleyin.') ?>"
                                       oninput="updateFormatPreview('channel_description_format', 'channel_desc_preview', 'Örnek Kanal')">
                                <p class="hint">Kanal açıklaması varsa önce o kullanılır, yoksa bu format devreye girer.</p>
                                <div class="mt-2 px-3 py-2 rounded-lg text-xs" style="background:rgba(255,255,255,0.04);">
                                    Sonuç: <span class="text-gray-300" id="channel_desc_preview"><?= e(sprintf($ch['description_format'] ?? '%s kanalının videolarını izleyin.', 'Örnek Kanal')) ?></span>
                                </div>
                            </div>
                            <!-- SERP Preview -->
                            <div>
                                <label class="section-label">Google Önizlemesi</label>
                                <div class="preview-card">
                                    <div class="preview-url"><?= APP_URL ?>/channel.php?id=<span class="text-gray-500">uuid...</span></div>
                                    <div class="preview-title" id="preview_channel_title"><?= e(sprintf($ch['title_format'] ?? '%s Kanalı | NeonTV', 'Örnek Kanal')) ?></div>
                                    <div class="preview-desc"><?= e(sprintf($ch['description_format'] ?? '%s kanalının videolarını izleyin.', 'Örnek Kanal')) ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ===== TAB: ARAMA ===== -->
                <div class="tab-panel space-y-4 mt-4" id="panel-search">
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-icon" style="background:rgba(251,191,36,0.1);color:#fbbf24;">
                                <i class="fa-solid fa-magnifying-glass"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-white">Arama Sayfası Meta Etiketleri</p>
                                <p class="text-xs text-gray-500"><?= APP_URL ?>/search.php</p>
                            </div>
                        </div>
                        <div class="p-5 space-y-4">
                            <div>
                                <label class="section-label">Sayfa Başlığı</label>
                                <input type="text" name="search_title" class="input-field"
                                       id="search_title"
                                       placeholder="Arama | NeonTV"
                                       value="<?= e($srch['title'] ?? 'Arama | NeonTV') ?>"
                                       oninput="updatePreview('search'); countChars(this, 'search_title_count', 60)">
                                <div class="flex justify-between items-center mt-1">
                                    <p class="hint">50-60 karakter arası önerilir.</p>
                                    <span class="char-count <?= charClass(strlen($srch['title'] ?? 'Arama | NeonTV'), 60) ?>"
                                          id="search_title_count"><?= strlen($srch['title'] ?? 'Arama | NeonTV') ?>/60</span>
                                </div>
                            </div>
                            <div>
                                <label class="section-label">Meta Açıklama</label>
                                <textarea name="search_description" class="input-field" rows="3"
                                          id="search_description"
                                          placeholder="NeonTV'de video arayın. Binlerce içerik arasından aradığınızı bulun."
                                          oninput="updatePreview('search'); countChars(this, 'search_desc_count', 160)"
                                ><?= e($srch['description'] ?? '') ?></textarea>
                                <div class="flex justify-between items-center mt-1">
                                    <p class="hint">120-160 karakter arası önerilir.</p>
                                    <span class="char-count <?= charClass(strlen($srch['description'] ?? ''), 160) ?>"
                                          id="search_desc_count"><?= strlen($srch['description'] ?? '') ?>/160</span>
                                </div>
                            </div>
                            <div>
                                <label class="section-label">Google Önizlemesi</label>
                                <div class="preview-card">
                                    <div class="preview-url"><?= APP_URL ?>/search.php</div>
                                    <div class="preview-title" id="preview_search_title"><?= e($srch['title'] ?? 'Arama | NeonTV') ?></div>
                                    <div class="preview-desc" id="preview_search_desc"><?= e(mb_substr($srch['description'] ?? 'Video arayın.', 0, 160)) ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ===== TAB: GİRİŞ ===== -->
                <div class="tab-panel space-y-4 mt-4" id="panel-auth">
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-icon" style="background:rgba(34,197,94,0.1);color:#22c55e;">
                                <i class="fa-solid fa-user"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-white">Giriş Sayfası Meta Etiketleri</p>
                                <p class="text-xs text-gray-500"><?= APP_URL ?>/auth.php</p>
                            </div>
                        </div>
                        <div class="p-5 space-y-4">
                            <div>
                                <label class="section-label">Sayfa Başlığı</label>
                                <input type="text" name="auth_title" class="input-field"
                                       id="auth_title"
                                       placeholder="Giriş Yap | NeonTV"
                                       value="<?= e($ath['title'] ?? 'Giriş Yap | NeonTV') ?>"
                                       oninput="updatePreview('auth'); countChars(this, 'auth_title_count', 60)">
                                <div class="flex justify-between items-center mt-1">
                                    <p class="hint">50-60 karakter arası önerilir.</p>
                                    <span class="char-count <?= charClass(strlen($ath['title'] ?? 'Giriş Yap | NeonTV'), 60) ?>"
                                          id="auth_title_count"><?= strlen($ath['title'] ?? 'Giriş Yap | NeonTV') ?>/60</span>
                                </div>
                            </div>
                            <div>
                                <label class="section-label">Meta Açıklama</label>
                                <textarea name="auth_description" class="input-field" rows="3"
                                          id="auth_description"
                                          placeholder="NeonTV hesabınıza giriş yapın veya yeni hesap oluşturun."
                                          oninput="updatePreview('auth'); countChars(this, 'auth_desc_count', 160)"
                                ><?= e($ath['description'] ?? '') ?></textarea>
                                <div class="flex justify-between items-center mt-1">
                                    <p class="hint">120-160 karakter arası önerilir.</p>
                                    <span class="char-count <?= charClass(strlen($ath['description'] ?? ''), 160) ?>"
                                          id="auth_desc_count"><?= strlen($ath['description'] ?? '') ?>/160</span>
                                </div>
                            </div>
                            <div>
                                <label class="section-label">Google Önizlemesi</label>
                                <div class="preview-card">
                                    <div class="preview-url"><?= APP_URL ?>/auth.php</div>
                                    <div class="preview-title" id="preview_auth_title"><?= e($ath['title'] ?? 'Giriş Yap | NeonTV') ?></div>
                                    <div class="preview-desc" id="preview_auth_desc"><?= e(mb_substr($ath['description'] ?? 'Hesabınıza giriş yapın.', 0, 160)) ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Kaydet Butonu -->
                <div class="flex items-center justify-between mt-6 p-4 rounded-xl"
                     style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);">
                    <p class="text-xs text-gray-500">
                        <i class="fa-solid fa-circle-info mr-1"></i>
                        Değişiklikler kaydedildikten hemen sonra aktif olur.
                    </p>
                    <button type="submit"
                            class="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 hover:scale-105"
                            style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#fff;box-shadow:0 0 20px rgba(0,245,255,0.3);">
                        <i class="fa-solid fa-floppy-disk"></i>
                        Kaydet
                    </button>
                </div>
            </form>

        </div>
    </main>
</div>

<script>
// Tab yönetimi
function showTab(name, btn) {
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    const panel = document.getElementById('panel-' + name);
    if (panel) panel.classList.add('active');
    if (btn) btn.classList.add('active');
}

// Karakter sayacı
function countChars(el, counterId, max) {
    const len = el.value.length;
    const el2 = document.getElementById(counterId);
    if (!el2) return;
    el2.textContent = len + '/' + max;
    el2.className = 'char-count ' + (len <= max * 0.85 ? 'char-ok' : len <= max ? 'char-warn' : 'char-bad');
}

// Önizleme güncelle (statik sayfalar)
function updatePreview(page) {
    const titleEl = document.getElementById(page + '_title');
    const descEl  = document.getElementById(page + '_description');
    if (titleEl) {
        const pt = document.getElementById('preview_' + page + '_title');
        if (pt) pt.textContent = titleEl.value || titleEl.placeholder;
    }
    if (descEl) {
        const pd = document.getElementById('preview_' + page + '_desc');
        if (pd) pd.textContent = (descEl.value || descEl.placeholder).substring(0, 160);
    }
}

// Format önizleme (video/kanal)
function updateFormatPreview(inputId, previewId, sample) {
    const val = document.getElementById(inputId)?.value || '';
    const preview = document.getElementById(previewId);
    if (preview) {
        try {
            preview.textContent = val.replace('%s', sample);
        } catch(e) {
            preview.textContent = val;
        }
    }
}

// OG görsel önizleme
function updateOgPreview(url) {
    const wrap = document.getElementById('og-preview-wrap');
    const img  = document.getElementById('og-preview-img');
    if (!wrap || !img) return;
    if (url) {
        img.src = url;
        wrap.classList.remove('hidden');
    } else {
        wrap.classList.add('hidden');
    }
}

// Başarı mesajı otomatik kapat
const msg = document.getElementById('save-success-msg');
if (msg) setTimeout(() => msg.remove(), 4000);
</script>

</body>
</html>
<?php
// Yardımcı fonksiyon: karakter sayısına göre CSS sınıfı
function charClass(int $len, int $max): string {
    if ($len <= $max * 0.85) return 'char-ok';
    if ($len <= $max) return 'char-warn';
    return 'char-bad';
}
?>
