<?php
// ============================================================
// NeonTV - JSON → PostgreSQL Veri Migration Betiği
// G1: Tek seferlik çalıştırın, sonra silin (veya erişimi kapatın)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin('superadmin');

$db      = new Supabase();
$results = [];
$errors  = [];

// ----------------------------------------------------------------
// 1. settings.json → site_settings tablosu
// ----------------------------------------------------------------
$settingsFile = __DIR__ . '/../includes/settings.json';
if (file_exists($settingsFile)) {
    $settings = json_decode(file_get_contents($settingsFile), true) ?? [];
    $migrated = 0;
    foreach ($settings as $key => $value) {
        if ($key === 'admins') continue; // Admin ayrı işlenir
        $ok = Store::setSetting($key, $value);
        if ($ok) $migrated++;
        else $errors[] = "settings.json: '$key' kaydedilemedi";
    }
    $results[] = "✅ settings.json → site_settings: $migrated ayar aktarıldı";
} else {
    $results[] = "⚠️ settings.json bulunamadı, atlandı";
}

// ----------------------------------------------------------------
// 2. settings.json → admin_users tablosu (admins dizisi)
// ----------------------------------------------------------------
if (file_exists($settingsFile)) {
    $settings = json_decode(file_get_contents($settingsFile), true) ?? [];
    $admins   = $settings['admins'] ?? [];
    $migrated = 0;
    foreach ($admins as $admin) {
        if (empty($admin['username']) || empty($admin['password_hash'])) continue;
        // Önce mevcut kontrolü
        $existing = Store::findAdmin($admin['username']);
        if ($existing) {
            $results[] = "ℹ️ Admin '{$admin['username']}' zaten mevcut, atlandı";
            continue;
        }
        $ok = Store::createAdmin(
            $admin['id'] ?? ('adm_' . bin2hex(random_bytes(6))),
            $admin['username'],
            $admin['password_hash'],
            $admin['role'] ?? 'editor'
        );
        if ($ok) $migrated++;
        else $errors[] = "Admin '{$admin['username']}' oluşturulamadı";
    }
    $results[] = "✅ settings.json admins → admin_users: $migrated admin aktarıldı";
}

// ----------------------------------------------------------------
// 3. blocked_ips.json → blocked_ips tablosu
// ----------------------------------------------------------------
$blockedFile = __DIR__ . '/../includes/blocked_ips.json';
if (file_exists($blockedFile)) {
    $blocked  = json_decode(file_get_contents($blockedFile), true) ?? [];
    $migrated = 0;
    foreach ($blocked as $entry) {
        $ip  = is_array($entry) ? ($entry['ip'] ?? '') : $entry;
        if (!$ip) continue;
        // Zaten var mı?
        $existing = $db->first('blocked_ips', 'ip=eq.' . urlencode($ip), true);
        if ($existing) continue;
        $ok = Store::blockIp(
            $ip,
            is_array($entry) ? ($entry['reason'] ?? '') : '',
            is_array($entry) ? ($entry['blocked_by'] ?? 'migration') : 'migration',
            null
        );
        if ($ok) $migrated++;
        else $errors[] = "IP '$ip' eklenemedi";
    }
    $results[] = "✅ blocked_ips.json → blocked_ips: $migrated IP aktarıldı";
} else {
    $results[] = "⚠️ blocked_ips.json bulunamadı, atlandı";
}

// ----------------------------------------------------------------
// 4. activity_log.json → activity_log tablosu
// ----------------------------------------------------------------
$activityFile = __DIR__ . '/../includes/activity_log.json';
if (file_exists($activityFile)) {
    $logs     = json_decode(file_get_contents($activityFile), true) ?? [];
    $migrated = 0;
    // Son 500 kaydı al (eski olanları bırak)
    $logs = array_slice($logs, 0, 500);
    foreach (array_reverse($logs) as $entry) { // Eski→yeni sırasıyla ekle
        $target  = ($entry['target_type'] ?? '') . ':' . ($entry['target_id'] ?? '');
        $details = [
            'old_data' => $entry['old_data'] ?? [],
            'new_data' => $entry['new_data'] ?? [],
            'note'     => $entry['note'] ?? '',
        ];
        $r = $db->insert('activity_log', [
            'created_at'     => $entry['created_at'] ?? date('c'),
            'admin_username' => $entry['admin'] ?? 'migration',
            'action'         => $entry['action'] ?? 'migrated',
            'target'         => $target,
            'details'        => $details,
            'ip_hash'        => Store::hashIp($entry['ip'] ?? '0.0.0.0'),
        ], true);
        if ($r['status'] < 400) $migrated++;
    }
    $results[] = "✅ activity_log.json → activity_log: $migrated kayıt aktarıldı";
} else {
    $results[] = "⚠️ activity_log.json bulunamadı, atlandı";
}

// ----------------------------------------------------------------
// 5. ip_visits.json → ip_visits tablosu
// ----------------------------------------------------------------
$visitsFile = __DIR__ . '/../logs/ip_visits.json';
if (file_exists($visitsFile)) {
    $visits   = json_decode(file_get_contents($visitsFile), true) ?? [];
    // Son 500 kaydı al
    $visits   = array_slice($visits, 0, 500);
    $migrated = 0;
    foreach (array_reverse($visits) as $entry) {
        $ip     = $entry['ip'] ?? '';
        $ipHash = Store::hashIp($ip);
        $r = $db->insert('ip_visits', [
            'created_at'   => $entry['time'] ?? date('c'),
            'ip_hash'      => $ipHash,
            'country_code' => $entry['country_code'] ?? substr($entry['country'] ?? '', 0, 3),
            'city'         => $entry['city'] ?? '',
            'isp'          => $entry['isp'] ?? '',
            'page'         => substr($entry['page'] ?? '/', 0, 500),
            'referrer'     => substr($entry['referrer'] ?? '', 0, 500),
            'ua'           => substr($entry['ua'] ?? '', 0, 300),
        ], true);
        if ($r['status'] < 400) $migrated++;
    }
    $results[] = "✅ ip_visits.json → ip_visits: $migrated ziyaret aktarıldı";
} else {
    $results[] = "⚠️ ip_visits.json bulunamadı, atlandı";
}

// ----------------------------------------------------------------
// 6. ip_geo_cache.json → ip_geo_cache tablosu
// ----------------------------------------------------------------
$geoFile = __DIR__ . '/../logs/ip_geo_cache.json';
if (file_exists($geoFile)) {
    $cache    = json_decode(file_get_contents($geoFile), true) ?? [];
    $migrated = 0;
    foreach ($cache as $ip => $data) {
        $ipHash = Store::hashIp($ip);
        unset($data['_ts']); // Eski cache timestamp'ini çıkar
        Store::setGeoCache($ipHash, $data);
        $migrated++;
    }
    $results[] = "✅ ip_geo_cache.json → ip_geo_cache: $migrated geo kaydı aktarıldı";
} else {
    $results[] = "⚠️ ip_geo_cache.json bulunamadı, atlandı";
}

// ----------------------------------------------------------------
// Çıktı
// ----------------------------------------------------------------
?>
<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veri Migration | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family:'Outfit',sans-serif; background:#070711; }</style>
</head>
<body class="min-h-screen text-white p-8">
    <div class="max-w-2xl mx-auto">
        <h1 class="text-2xl font-bold mb-6" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
            JSON → PostgreSQL Migration
        </h1>

        <?php if (!empty($errors)): ?>
        <div class="rounded-xl p-4 mb-6" style="background:rgba(255,68,68,0.08);border:1px solid rgba(255,68,68,0.2);">
            <h2 class="font-bold text-red-400 mb-2">Hatalar</h2>
            <ul class="space-y-1">
                <?php foreach ($errors as $e): ?>
                <li class="text-sm text-red-300">❌ <?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>

        <div class="rounded-xl p-4 mb-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.06);">
            <h2 class="font-bold text-green-400 mb-3">Migration Sonuçları</h2>
            <ul class="space-y-2">
                <?php foreach ($results as $r): ?>
                <li class="text-sm text-gray-300 font-mono"><?= htmlspecialchars($r) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="rounded-xl p-4" style="background:rgba(255,165,0,0.06);border:1px solid rgba(255,165,0,0.2);">
            <h2 class="font-bold text-yellow-400 mb-2">⚠️ Sonraki Adımlar</h2>
            <ol class="text-sm text-yellow-300 space-y-2 list-decimal pl-5">
                <li>Migration başarılıysa JSON dosyalarını yedekleyip silebilirsiniz:
                    <ul class="mt-1 ml-4 list-disc text-gray-400 text-xs space-y-1">
                        <li><code>includes/settings.json</code></li>
                        <li><code>includes/blocked_ips.json</code></li>
                        <li><code>includes/activity_log.json</code></li>
                        <li><code>logs/ip_visits.json</code></li>
                        <li><code>logs/ip_geo_cache.json</code></li>
                    </ul>
                </li>
                <li><strong>Bu sayfayı silin</strong> veya web erişimini engelleyin:<br>
                    <code class="text-xs text-gray-400">admin/migrate_files_to_db.php</code>
                </li>
                <li>Supabase SQL Editor'da <code>supabase_migration_2026_10.sql</code> dosyasının çalıştırıldığını doğrulayın.</li>
            </ol>
        </div>

        <a href="<?= APP_URL ?>/admin/index.php"
           class="mt-6 inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold text-black transition-all hover:scale-105"
           style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
            <i class="fa-solid fa-arrow-left"></i> Dashboard'a Dön
        </a>
    </div>
</body>
</html>
