<?php
// NeonTV - Admin: Video istekleri
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
requireAdmin(['editor', 'moderator', 'superadmin']);
$db = new Supabase();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/requests.php'); }
    $id = trim(input('id')); requireUuid($id, 'İstek');
    if (input('action') === 'delete') {
        $db->delete('video_requests', 'id=eq.' . $id, true);
        setFlash('success', 'İstek silindi.');
    } elseif (input('action') === 'update') {
        $st   = in_array(input('status'), ['open', 'planned', 'done', 'rejected'], true) ? input('status') : 'open';
        $note = mb_substr(trim(input('admin_note')), 0, 200);
        $old  = $db->first('video_requests', 'id=eq.' . $id . '&select=user_id,title,status', true);
        $db->update('video_requests', ['status' => $st, 'admin_note' => $note], 'id=eq.' . $id, true);
        if ($old && $old['status'] !== $st && $st !== 'open') {
            $txt = ['planned' => 'planlandı', 'done' => 'yapıldı', 'rejected' => 'reddedildi'][$st];
            $db->insert('notifications', ['user_id' => $old['user_id'], 'type' => 'request', 'message' => mb_substr('İsteğin ' . $txt . ': ' . $old['title'] . ($note ? ' — ' . $note : ''), 0, 300), 'link' => '/requests.php'], true);
        }
        setFlash('success', 'İstek güncellendi.');
    }
    redirect(APP_URL . '/admin/requests.php' . (input('f') ? '?f=' . urlencode(input('f')) : ''));
}

$f = in_array($_GET['f'] ?? '', ['open', 'planned', 'done', 'rejected'], true) ? $_GET['f'] : '';
$rows = $db->select('video_requests', 'order=created_at.desc&limit=200' . ($f ? '&status=eq.' . $f : ''), true)['data'] ?? [];
$votes = [];
if ($rows) foreach (($db->select('request_votes', 'request_id=in.(' . implode(',', array_column($rows, 'id')) . ')&select=request_id&limit=20000', true)['data'] ?? []) as $v) $votes[$v['request_id']] = ($votes[$v['request_id']] ?? 0) + 1;
usort($rows, fn($a, $b) => ($votes[$b['id']] ?? 0) <=> ($votes[$a['id']] ?? 0));

$adminTitle = 'Video İstekleri';
$adminSub   = 'Kullanıcı istekleri · oy sayısına göre';
include __DIR__ . '/_top.php';
$inp = 'bg-black/30 border border-gray-800 rounded-lg py-1.5 px-2 text-white text-xs focus:outline-none focus:border-cyan-500';
?>
<div class="flex flex-wrap gap-2 mb-4 text-xs">
    <?php foreach ([''=>'Tümü','open'=>'Açık','planned'=>'Planlandı','done'=>'Yapıldı','rejected'=>'Reddedildi'] as $k=>$l): ?>
    <a href="?f=<?= $k ?>" class="px-3 py-1.5 rounded-full <?= $f === $k ? 'text-black font-bold' : 'text-gray-300' ?>" style="background:<?= $f === $k ? '#00f5ff' : 'rgba(255,255,255,0.06)' ?>"><?= $l ?></a>
    <?php endforeach; ?>
</div>
<?php foreach ($rows as $r): ?>
<div class="rounded-2xl p-4 mb-3" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <div class="flex items-start gap-3">
        <div class="text-center w-12"><div class="text-lg font-bold text-cyan-400"><?= (int)($votes[$r['id']] ?? 0) ?></div><div class="text-[10px] text-gray-500">oy</div></div>
        <div class="flex-1 min-w-0">
            <p class="text-white font-semibold text-sm"><?= e($r['title']) ?></p>
            <?php if ($r['description']): ?><p class="text-xs text-gray-400 mt-1 whitespace-pre-wrap"><?= e($r['description']) ?></p><?php endif; ?>
            <p class="text-[10px] text-gray-600 mt-1"><?= e($r['username']) ?> · <?= e(date('d.m.Y H:i', strtotime($r['created_at']))) ?></p>
            <form method="POST" class="flex flex-wrap items-center gap-2 mt-2">
                <?= csrfField() ?><input type="hidden" name="action" value="update"><input type="hidden" name="id" value="<?= e($r['id']) ?>"><input type="hidden" name="f" value="<?= e($f) ?>">
                <select name="status" class="<?= $inp ?>"><?php foreach (['open'=>'Açık','planned'=>'Planlandı','done'=>'Yapıldı','rejected'=>'Reddedildi'] as $k=>$l): ?><option value="<?= $k ?>" <?= $r['status'] === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select>
                <input name="admin_note" maxlength="200" value="<?= e($r['admin_note']) ?>" placeholder="Kullanıcıya not (isteğe bağlı)" class="<?= $inp ?> flex-1 min-w-[160px]">
                <button class="px-3 py-1.5 rounded-lg text-xs font-bold text-black" style="background:#00f5ff">Kaydet</button>
            </form>
        </div>
        <form method="POST" onsubmit="return confirm('İstek silinsin mi?')"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e($r['id']) ?>"><input type="hidden" name="f" value="<?= e($f) ?>"><button class="text-red-400"><i class="fa-solid fa-trash"></i></button></form>
    </div>
</div>
<?php endforeach; if (!$rows): ?><p class="text-center text-gray-500 py-8">İstek yok.</p><?php endif; ?>
<?php include __DIR__ . '/_bottom.php'; ?>
