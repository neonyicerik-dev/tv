<?php
// NeonTV - Admin: Yavaş istek günlüğü (logs/slow_requests.log)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
requireAdmin('superadmin');
$file = neonSlowLogPath();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/slow.php'); }
    if (input('action') === 'clear') { @unlink($file); @unlink($file . '.1'); setFlash('success', 'Yavaş istek günlüğü temizlendi.'); }
    redirect(APP_URL . '/admin/slow.php');
}
$lines = [];
if (is_file($file) && filesize($file) < 6 * 1048576) {
    foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $ln) { $j = json_decode($ln, true); if (is_array($j) && isset($j['ms'])) $lines[] = $j; }
}
$agg = [];
foreach ($lines as $j) { $k = ($j['m'] ?? 'GET') . ' ' . ($j['p'] ?? ''); $a = &$agg[$k]; $a['n'] = ($a['n'] ?? 0) + 1; $a['sum'] = ($a['sum'] ?? 0) + $j['ms']; $a['max'] = max($a['max'] ?? 0, $j['ms']); $a['db'] = ($a['db'] ?? 0) + ($j['dbms'] ?? 0); unset($a); }
uasort($agg, fn($a, $b) => $b['sum'] <=> $a['sum']);
$recent = array_slice(array_reverse($lines), 0, 40);
$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$adminTitle = 'Yavaş İstekler'; $adminSub = 'Eşik: ' . SLOW_REQUEST_MS . ' ms · ' . count($lines) . ' kayıt';
include __DIR__ . '/_top.php';
$cs = 'background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08)';
?>
<div class="flex items-center gap-3 mb-4">
    <p class="text-xs text-gray-400">Eşiği aşan istekler kaydedilir (yalnızca yol ve parametre adları; değerler yazılmaz). Süreye yanıt sonrası arka plan işleri de dahil olabilir. Eşik için SLOW_REQUEST_MS ortam değişkeni (0 = kapalı).</p>
    <form method="post" class="ml-auto" onsubmit="return confirm('Günlük temizlensin mi?')"><input type="hidden" name="csrf_token" value="<?= $e(generateCsrfToken()) ?>"><input type="hidden" name="action" value="clear"><button class="px-3 py-1.5 rounded-lg text-sm text-white" style="background:rgba(255,0,100,0.25)">Temizle</button></form>
</div>
<div class="p-4 rounded-xl mb-6 overflow-x-auto" style="<?= $cs ?>"><h3 class="font-bold text-white mb-2">Sayfa bazında özet</h3>
<table class="w-full text-sm text-gray-300"><tr class="text-xs text-gray-500 text-left"><th class="py-1">İstek</th><th>Adet</th><th>Ort. ms</th><th>Maks ms</th><th>Ort. DB ms</th></tr>
<?php foreach (array_slice($agg, 0, 20, true) as $k => $a): ?><tr class="border-t border-white/5"><td class="py-1 pr-3 break-all"><?= $e($k) ?></td><td><?= (int)$a['n'] ?></td><td><?= (int)round($a['sum'] / $a['n']) ?></td><td><?= (int)$a['max'] ?></td><td><?= (int)round($a['db'] / $a['n']) ?></td></tr><?php endforeach; if (!$agg) echo '<tr><td class="py-2 text-gray-500" colspan="5">Henüz yavaş istek yok 🎉</td></tr>'; ?></table></div>
<div class="p-4 rounded-xl overflow-x-auto" style="<?= $cs ?>"><h3 class="font-bold text-white mb-2">Son kayıtlar</h3>
<table class="w-full text-xs text-gray-300"><tr class="text-gray-500 text-left"><th class="py-1">Zaman</th><th>ms</th><th>İstek</th><th>Parametreler</th><th>DB (adet/ms)</th><th>Yavaş uç</th><th>Bellek</th></tr>
<?php foreach ($recent as $j): ?><tr class="border-t border-white/5"><td class="py-1 pr-2 whitespace-nowrap"><?= $e(str_replace('T', ' ', substr($j['t'] ?? '', 0, 19))) ?></td><td class="text-pink-400"><?= (int)$j['ms'] ?></td><td class="pr-2 break-all"><?= $e(($j['m'] ?? '') . ' ' . ($j['p'] ?? '')) ?></td><td><?= $e(implode(',', $j['q'] ?? [])) ?></td><td><?= (int)($j['db'] ?? 0) ?>/<?= (int)($j['dbms'] ?? 0) ?></td><td class="break-all"><?= $e($j['slowdb'] ?? '') ?></td><td><?= (int)($j['mem'] ?? 0) ?> MB</td></tr><?php endforeach; ?></table></div>
<?php include __DIR__ . '/_bottom.php'; ?>
