<?php
// Dashboard canlı grafik verisi: son 14 gün izlenme / yeni kullanıcı / yorum + bugünkü sayılar
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
error_reporting(0); ini_set('display_errors', 0);
requireAdmin();

$db = new Supabase();
$N = 14;
$since = gmdate('Y-m-d', time() - ($N - 1) * 86400);
$days = [];
for ($i = 0; $i < $N; $i++) $days[gmdate('Y-m-d', strtotime($since) + $i * 86400)] = ['v' => 0, 'u' => 0, 'c' => 0];

$bucket = function (string $table, string $key) use ($db, $since, &$days) {
    $r = $db->select($table, 'created_at=gte.' . $since . 'T00:00:00Z&select=created_at&limit=50000', true)['data'] ?? [];
    foreach ($r as $row) { $d = substr($row['created_at'], 0, 10); if (isset($days[$d])) $days[$d][$key]++; }
};
$bucket('views_log', 'v');
$bucket('profiles', 'u');
$bucket('comments', 'c');

jsonSuccess([
    'labels' => array_map(fn($d) => substr($d, 5), array_keys($days)),
    'views'  => array_column($days, 'v'),
    'users'  => array_column($days, 'u'),
    'comments' => array_column($days, 'c'),
    'updated' => date('H:i:s'),
]);
