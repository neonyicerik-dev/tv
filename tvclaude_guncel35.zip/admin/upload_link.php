<?php
// ============================================================
// NeonTV - Admin Video Yükleme (Link ile) - Cloudinary'siz
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
requireAdmin();

$db = new Supabase();

// Düzenleme modu
$editId   = trim($_GET['edit'] ?? '');
$editData = null;
if ($editId) {
    $editData = $db->first('videos', 'id=eq.' . $editId, true);
}

$pageTitle = $editData ? 'Video Düzenle (Link)' : 'Video Yükle (Link ile)';

// Kanalları çek
$channelsRes = $db->select('channels', 'order=name.asc', true);
$channelsList = $channelsRes['data'] ?? [];

// Ayarları yükle
require_once __DIR__ . '/../includes/store.php';
$siteSettings = loadSettingsCompat();
$defaultSystemPrompt = $siteSettings['ai_title_system_prompt'] ?? 'Sen bir video platformu için içerik yöneticisisin. Türkçe yaz. SEO uyumlu, dikkat çekici başlıklar ve açıklamalar oluştur.';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        .input-field {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.2s;
            width: 100%;
        }
        .input-field:focus {
            border-color: rgba(0,245,255,0.5);
            box-shadow: 0 0 0 3px rgba(0,245,255,0.08);
            outline: none;
        }
        .neon-btn {
            background: linear-gradient(135deg, #00f5ff, #bf00ff);
            color: #000;
            font-weight: 700;
            transition: all 0.3s;
        }
        .neon-btn:hover { transform: scale(1.02); box-shadow: 0 0 25px rgba(0,245,255,0.3); }
        .neon-btn:disabled { opacity: 0.5; transform: none; cursor: not-allowed; }
        .link-card {
            position: relative;
            overflow: hidden;
        }
        .link-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 2px;
            background: linear-gradient(90deg, #00f5ff, #bf00ff);
            opacity: 0;
            transition: opacity 0.3s;
        }
        .link-card:focus-within::before {
            opacity: 1;
        }
        .url-status {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 11px;
            padding: 2px 8px;
            border-radius: 6px;
            transition: all 0.3s;
        }
        .url-status.valid {
            background: rgba(0,245,255,0.1);
            color: #00f5ff;
        }
        .url-status.invalid {
            background: rgba(255,0,122,0.1);
            color: #ff007a;
        }
        .url-status.empty {
            background: rgba(255,255,255,0.05);
            color: #666;
        }
        .thumb-preview-container {
            position: relative;
            border-radius: 12px;
            overflow: hidden;
            aspect-ratio: 16/9;
            background: #0d0d1a;
        }
        .thumb-preview-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .video-preview-container {
            position: relative;
            border-radius: 12px;
            overflow: hidden;
            aspect-ratio: 16/9;
            background: #0d0d1a;
        }
        .video-preview-container video {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        .loading-shimmer {
            background: linear-gradient(90deg, rgba(255,255,255,0.03) 25%, rgba(255,255,255,0.08) 50%, rgba(255,255,255,0.03) 75%);
            background-size: 200% 100%;
            animation: shimmer 1.5s infinite;
        }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- ===== TOP BAR ===== -->
    <header class="flex items-center gap-3 px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <!-- Hamburger -->
        <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors"
                style="background:rgba(255,255,255,0.06);">
            <i class="fa-solid fa-bars text-sm"></i>
        </button>
        <a href="<?= APP_URL ?>/admin/videos.php" class="text-gray-500 hover:text-white transition-colors">
            <i class="fa-solid fa-arrow-left"></i>
        </a>
        <div class="min-w-0">
            <h1 class="text-lg sm:text-xl font-bold text-white truncate"><?= e($pageTitle) ?></h1>
            <p class="text-xs text-gray-500 hidden sm:block"><i class="fa-solid fa-link mr-1"></i>Link ile Yükleme · Cloudinary Kullanılmaz</p>
        </div>
        <!-- Badge -->
        <span class="ml-auto text-[10px] px-3 py-1 rounded-full font-bold flex-shrink-0"
              style="background:linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.15));color:#00f5ff;border:1px solid rgba(0,245,255,0.2);">
            <i class="fa-solid fa-link mr-1"></i>LINK MODU
        </span>
    </header>

    <!-- ===== ANA İÇERİK ===== -->
    <main class="flex-1 p-4 sm:p-6 overflow-auto">
        <div class="max-w-4xl mx-auto">
            <form id="upload-form" onsubmit="return false;" autocomplete="off">

                <!-- Grid: mobilde tek sütun, büyük ekranda iki sütun -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">

                    <!-- ===== SOL SÜTUN ===== -->
                    <div class="space-y-4 sm:space-y-5">

                        <!-- Başlık -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                <i class="fa-solid fa-heading mr-1"></i>Video Basligi *
                            </label>
                            <input type="text" id="video-title" name="title"
                                   value="<?= e($editData['title'] ?? '') ?>"
                                   placeholder="Dikkat cekici bir baslik girin"
                                   maxlength="200" required
                                   class="input-field px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600">
                        </div>

                        <!-- Açıklama -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                <i class="fa-solid fa-align-left mr-1"></i>Aciklama
                            </label>
                            <textarea id="video-description" name="description"
                                      placeholder="Video aciklamasini girin..."
                                      rows="5" maxlength="5000"
                                      class="input-field px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 resize-none"><?= e($editData['description'] ?? '') ?></textarea>
                        </div>

                        <!-- Etiketler -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                <i class="fa-solid fa-tags mr-1"></i>Etiketler
                            </label>
                            <input type="text" id="video-tags" name="tags"
                                   value="<?= e(implode(', ', $editData['tags'] ?? [])) ?>"
                                   placeholder="Örn: Müzik, Eğlence, Vlog (Virgülle ayırın)"
                                   class="input-field px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600">
                        </div>

                        <!-- Kanal Seçimi -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                <i class="fa-solid fa-user-circle mr-1"></i>Kanal Seçimi
                            </label>
                            <select id="video-channel" name="channel_id" class="input-field px-4 py-3 rounded-xl text-sm text-white">
                                <option value="">(Bağımsız Video)</option>
                                <?php foreach($channelsList as $c): ?>
                                    <option value="<?= e($c['id']) ?>" <?= ($editData && $editData['channel_id'] === $c['id']) ? 'selected' : '' ?>>
                                        <?= e($c['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- AI İçerik Oluşturucu -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(191,0,255,0.2);">
                            <div class="flex items-center gap-2 mb-4">
                                <div class="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style="background:rgba(191,0,255,0.15);">
                                    <i class="fa-solid fa-robot text-xs" style="color:#bf00ff;"></i>
                                </div>
                                <h3 class="text-sm font-bold text-white">AI ile Icerik Olustur</h3>
                                <span class="text-[10px] px-2 py-0.5 rounded-full font-medium flex-shrink-0" style="background:rgba(191,0,255,0.15);color:#bf00ff;">Gemini</span>
                                <span class="ml-auto text-[10px] px-2 py-0.5 rounded-full font-medium flex-shrink-0" style="background:rgba(255,140,0,0.15);color:#ff8c00;border:1px solid rgba(255,140,0,0.3);">
                                    <i class="fa-solid fa-cloud-arrow-down mr-1"></i>CloudConvert
                                </span>
                            </div>

                            <!-- CloudConvert Bilgi Notu -->
                            <div class="mb-3 px-3 py-2 rounded-xl text-xs flex items-start gap-2" style="background:rgba(255,140,0,0.06);border:1px solid rgba(255,140,0,0.2);">
                                <i class="fa-solid fa-circle-info text-orange-400 mt-0.5 flex-shrink-0"></i>
                                <span class="text-gray-400">Video URL girilmişse <strong class="text-orange-300">CloudConvert</strong> ile videonun kısa bir klibi indirilip Gemini'ye gönderilir. URL yoksa konu metnine göre analiz yapılır.</span>
                            </div>

                            <div class="space-y-3">
                                <div>
                                    <label class="block text-xs text-gray-500 mb-1.5">Konu / Video hakkinda kisa bilgi <span class="text-gray-700">(isteğe bağlı, URL varsa boş bırakabilirsiniz)</span></label>
                                    <input type="text" id="ai-topic"
                                           placeholder="Video hakkında kısa bir bilgi girin (veya boş bırakın)"
                                           class="input-field px-3 py-2.5 rounded-lg text-sm text-white placeholder-gray-600">
                                </div>
                                <div>
                                    <label class="block text-xs text-gray-500 mb-1.5">
                                        System Prompt
                                        <span class="text-gray-700">(Ayarlardan otomatik yüklendi)</span>
                                    </label>
                                    <textarea id="ai-system-prompt" rows="3"
                                              placeholder="Orn: Sen egitim platformu icin icerik yazarsin. Turkce yaz."
                                              class="input-field px-3 py-2.5 rounded-lg text-sm text-white placeholder-gray-600 resize-none"><?= htmlspecialchars($defaultSystemPrompt) ?></textarea>
                                </div>
                                <button type="button" id="ai-generate-btn" onclick="generateWithAI()"
                                        class="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold text-white transition-all duration-200"
                                        style="background:linear-gradient(135deg,rgba(191,0,255,0.3),rgba(0,245,255,0.15));border:1px solid rgba(191,0,255,0.4);">
                                    <i class="fa-solid fa-wand-magic-sparkles text-xs"></i>
                                    Baslik + Aciklama Olustur
                                </button>

                                <!-- Adım Göstergesi (işlem sırasında görünür) -->
                                <div id="ai-steps" class="hidden space-y-1.5">
                                    <div id="ai-step-1" class="flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-all" style="background:rgba(255,255,255,0.04);">
                                        <span id="ai-step-1-icon" class="w-4 h-4 flex items-center justify-center flex-shrink-0">
                                            <i class="fa-solid fa-circle text-[6px] text-gray-600"></i>
                                        </span>
                                        <span class="text-gray-500">CloudConvert ile video klibi indiriliyor...</span>
                                    </div>
                                    <div id="ai-step-2" class="flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-all" style="background:rgba(255,255,255,0.04);">
                                        <span id="ai-step-2-icon" class="w-4 h-4 flex items-center justify-center flex-shrink-0">
                                            <i class="fa-solid fa-circle text-[6px] text-gray-600"></i>
                                        </span>
                                        <span class="text-gray-500">Gemini ile video analiz ediliyor...</span>
                                    </div>
                                </div>

                                <!-- AI Sonuç -->
                                <div id="ai-result" class="hidden">
                                    <div class="rounded-xl p-3 text-xs text-gray-400" style="background:rgba(191,0,255,0.05);border:1px solid rgba(191,0,255,0.15);">
                                        <p id="ai-result-text" style="white-space:pre-wrap;"></p>
                                    </div>
                                    <div class="flex gap-2 mt-2">
                                        <button type="button" onclick="applyAiResult()"
                                                class="flex-1 py-2 rounded-lg text-xs font-semibold text-black"
                                                style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                            <i class="fa-solid fa-check mr-1"></i>Formlara Uygula
                                        </button>
                                        <button type="button" onclick="document.getElementById('ai-result').classList.add('hidden')"
                                                class="px-3 py-2 rounded-lg text-xs text-gray-500 hover:text-white transition-colors"
                                                style="background:rgba(255,255,255,0.06);">
                                            <i class="fa-solid fa-xmark"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <!-- Yayın Durumu -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-3 uppercase tracking-wider">
                                <i class="fa-solid fa-circle-dot mr-1"></i>Yayin Durumu
                            </label>
                            <div class="flex flex-col gap-3">
                                <div class="flex gap-3">
                                    <label class="flex-1 flex items-center gap-2 sm:gap-3 p-3 rounded-xl cursor-pointer"
                                           style="background:rgba(0,245,255,0.05);border:1px solid rgba(0,245,255,0.2);">
                                        <input type="radio" name="status" value="published" onchange="toggleScheduledDate()"
                                               <?= (!$editData || $editData['status'] === 'published') ? 'checked' : '' ?>
                                               class="accent-cyan-400 flex-shrink-0">
                                        <div>
                                            <p class="text-sm font-medium text-white">Yayinla</p>
                                            <p class="text-xs text-gray-600">Hemen gorunur</p>
                                        </div>
                                    </label>
                                    <label class="flex-1 flex items-center gap-2 sm:gap-3 p-3 rounded-xl cursor-pointer"
                                           style="background:rgba(251,191,36,0.05);border:1px solid rgba(251,191,36,0.2);">
                                        <input type="radio" name="status" value="scheduled" onchange="toggleScheduledDate()"
                                               <?= ($editData && $editData['status'] === 'scheduled') ? 'checked' : '' ?>
                                               class="accent-yellow-400 flex-shrink-0">
                                        <div>
                                            <p class="text-sm font-medium text-white">Zamanla</p>
                                            <p class="text-xs text-gray-600">İleri tarihte</p>
                                        </div>
                                    </label>
                                    <label class="flex-1 flex items-center gap-2 sm:gap-3 p-3 rounded-xl cursor-pointer"
                                           style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.1);">
                                        <input type="radio" name="status" value="draft" onchange="toggleScheduledDate()"
                                               <?= ($editData && $editData['status'] === 'draft') ? 'checked' : '' ?>
                                               class="accent-gray-400 flex-shrink-0">
                                        <div>
                                            <p class="text-sm font-medium text-gray-300">Taslak</p>
                                            <p class="text-xs text-gray-600">Gizli kalir</p>
                                        </div>
                                    </label>
                                </div>
                                <div id="scheduled-date-wrap" class="<?= ($editData && $editData['status'] === 'scheduled') ? 'block' : 'hidden' ?> mt-2">
                                    <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                        <i class="fa-solid fa-calendar-days mr-1"></i>Yayın Tarihi
                                    </label>
                                    <input type="datetime-local" id="scheduled-at"
                                           value="<?= ($editData && !empty($editData['scheduled_at'])) ? date('Y-m-d\TH:i', strtotime($editData['scheduled_at'])) : '' ?>"
                                           class="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all"
                                           style="background:rgba(255,255,255,0.05);border:1px solid rgba(251,191,36,0.3);color-scheme:dark;">
                                </div>
                                <div class="mt-4">
                                    <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                        <i class="fa-solid fa-hourglass-half mr-1"></i>Kaldırılma Tarihi <span class="normal-case text-gray-600">(geçici CDN videosu için, isteğe bağlı)</span>
                                    </label>
                                    <input type="datetime-local" id="expires-at" data-had="<?= !empty($editData['expires_at']) ? '1' : '0' ?>"
                                           value="<?= ($editData && !empty($editData['expires_at'])) ? date('Y-m-d\TH:i', strtotime($editData['expires_at'])) : '' ?>"
                                           class="w-full px-4 py-3 rounded-xl text-sm text-white outline-none"
                                           style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,107,107,0.3);color-scheme:dark;">
                                    <p class="text-[11px] text-gray-600 mt-1">Doluysa kartlarda ve video sayfasında “yakında kalkacak” uyarısı gösterilir (14 gün kala).</p>
                                </div>
                                <div class="mt-4">
                                    <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider"><i class="fa-solid fa-forward-step mr-1"></i>Giriş bitişi <span class="normal-case text-gray-600">(saniye, "Girişi atla" butonu için, isteğe bağlı)</span></label>
                                    <input type="number" min="0" max="3600" id="intro-end" data-had="<?= !empty($editData['intro_end']) ? '1' : '0' ?>" value="<?= (int)($editData['intro_end'] ?? 0) ?: '' ?>" placeholder="örn. 45"
                                           class="w-full px-4 py-3 rounded-xl text-sm text-white outline-none" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.12);">
                                </div>


                            </div>
                        </div>
                    </div>

                    <!-- ===== SAĞ SÜTUN ===== -->
                    <div class="space-y-4 sm:space-y-5">

                        <!-- Thumbnail Link -->
                        <div class="link-card rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <div class="flex items-center justify-between mb-3">
                                <label class="block text-xs font-semibold text-gray-400 uppercase tracking-wider">
                                    <i class="fa-regular fa-image mr-1"></i>Thumbnail (Kapak Görseli Link)
                                </label>
                                <div class="flex items-center gap-2">
                                    <button type="button" onclick="openAiThumbModal()" class="text-[10px] px-2 py-1 rounded-lg font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                        <i class="fa-solid fa-wand-magic-sparkles mr-1"></i>AI ile Üret
                                    </button>
                                    <span id="thumb-url-status" class="url-status empty">
                                        <i class="fa-solid fa-circle text-[6px]"></i> Bekleniyor
                                    </span>
                                </div>
                            </div>
                            <div class="flex gap-2">
                                <input type="url" id="thumb-url-input"
                                       value="<?= e($editData['thumbnail_url'] ?? '') ?>"
                                       placeholder="https://ornek.com/thumbnail.jpg"
                                       class="input-field px-3 py-2.5 rounded-lg text-sm text-white placeholder-gray-600 flex-1"
                                       oninput="validateThumbUrl()">
                                <button type="button" onclick="previewThumbUrl()"
                                        class="px-4 py-2.5 rounded-lg text-xs font-bold text-black flex-shrink-0"
                                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                    <i class="fa-solid fa-eye mr-1"></i>Önizle
                                </button>
                            </div>
                            <p class="text-xs text-gray-700 mt-1.5">JPG, PNG, WebP formatında direkt görsel linki girin</p>

                            <!-- Thumbnail Önizleme -->
                            <div id="thumb-preview" class="mt-3 <?= ($editData && $editData['thumbnail_url']) ? '' : 'hidden' ?>">
                                <div class="thumb-preview-container">
                                    <img id="thumb-preview-img" src="<?= e($editData['thumbnail_url'] ?? '') ?>"
                                         onerror="thumbLoadError()" onload="thumbLoadSuccess()">
                                    <button type="button" onclick="clearThumbnail()"
                                            class="absolute top-2 right-2 w-7 h-7 rounded-full flex items-center justify-center text-xs"
                                            style="background:rgba(0,0,0,0.7);color:#fff;">
                                        <i class="fa-solid fa-xmark"></i>
                                    </button>
                                </div>
                            </div>
                            <input type="hidden" id="thumb-url" name="thumbnail_url" value="<?= e($editData['thumbnail_url'] ?? '') ?>">
                        </div>

                        <!-- Video Link -->
                        <div class="link-card rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <div class="flex items-center justify-between mb-3">
                                <label class="block text-xs font-semibold text-gray-400 uppercase tracking-wider">
                                    <i class="fa-solid fa-film mr-1"></i>Video Linki
                                    <?php if (!$editData): ?><span class="text-red-400">*</span><?php endif; ?>
                                </label>
                                <span id="video-url-status" class="url-status empty">
                                    <i class="fa-solid fa-circle text-[6px]"></i> Bekleniyor
                                </span>
                            </div>

                            <?php if ($editData && $editData['video_url']): ?>
                            <div class="flex items-center gap-2 p-3 rounded-xl mb-3 text-xs"
                                 style="background:rgba(0,245,255,0.05);border:1px solid rgba(0,245,255,0.15);">
                                <i class="fa-solid fa-circle-check" style="color:#00f5ff;"></i>
                                <span class="text-gray-400 flex-1 truncate">Mevcut video: <?= e(basename($editData['video_url'])) ?></span>
                            </div>
                            <?php endif; ?>

                            <div class="flex gap-2">
                                <input type="url" id="video-url-input"
                                       value="<?= e($editData['video_url'] ?? '') ?>"
                                       placeholder="https://ornek.com/video.mp4"
                                       class="input-field px-3 py-2.5 rounded-lg text-sm text-white placeholder-gray-600 flex-1"
                                       oninput="validateVideoUrl()">
                                <button type="button" onclick="previewVideoUrl()"
                                        class="px-4 py-2.5 rounded-lg text-xs font-bold text-black flex-shrink-0"
                                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                    <i class="fa-solid fa-play mr-1"></i>Önizle
                                </button>
                            </div>
                            <p class="text-xs text-gray-700 mt-1.5">MP4, WebM veya HLS (m3u8) formatında video linki girin</p>

                            <!-- Video Önizleme -->
                            <div id="video-preview" class="mt-3 hidden">
                                <div class="video-preview-container">
                                    <video id="video-preview-player" controls preload="metadata"
                                           onerror="videoLoadError()" onloadedmetadata="videoLoadSuccess()"></video>
                                </div>
                                <div id="video-meta" class="hidden mt-2 flex items-center gap-3 text-xs text-gray-500">
                                    <span id="video-meta-duration"><i class="fa-solid fa-clock mr-1"></i>--:--</span>
                                    <span id="video-meta-resolution"><i class="fa-solid fa-expand mr-1"></i>--</span>
                                </div>
                            </div>
                            <input type="hidden" id="video-url" name="video_url" value="<?= e($editData['video_url'] ?? '') ?>">
                            <input type="hidden" id="video-duration" name="duration" value="<?= e($editData['duration'] ?? '0') ?>">
                        </div>

                        <!-- Otomatik Altyazı -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(0,245,255,0.1);">
                            <label class="flex items-center gap-3 cursor-pointer">
                                <div class="relative">
                                    <input type="checkbox" id="auto-subtitle-check" class="sr-only">
                                    <div id="toggle-track" class="w-11 h-6 rounded-full transition-colors duration-200" style="background:rgba(255,255,255,0.1);"></div>
                                    <div id="toggle-thumb" class="absolute top-1 left-1 w-4 h-4 rounded-full bg-gray-400 transition-transform duration-200"></div>
                                </div>
                                <div>
                                    <p class="text-sm font-semibold text-white">Otomatik Altyazı Oluştur</p>
                                    <p class="text-xs text-gray-500">Video kaydedildikten sonra AI altyazı oluşturur</p>
                                </div>
                                <span class="ml-auto text-[10px] px-2 py-0.5 rounded-full font-medium" style="background:rgba(0,245,255,0.1);color:#00f5ff;">Gemini AI</span>
                            </label>
                        </div>

                        <!-- Bölüm Yönetimi (sadece düzenleme modunda) -->
                        <?php if ($editData): ?>
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(191,0,255,0.2);">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center gap-2">
                                    <div class="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style="background:rgba(191,0,255,0.15);">
                                        <i class="fa-solid fa-list-ul text-xs" style="color:#bf00ff;"></i>
                                    </div>
                                    <h3 class="text-sm font-bold text-white">Bölüm Yönetimi</h3>
                                </div>
                                <button type="button" id="ai-chapters-btn" onclick="generateChaptersWithAI()"
                                        class="text-[10px] px-2 py-1 rounded-lg font-bold text-white flex items-center gap-1"
                                        style="background:linear-gradient(135deg,rgba(191,0,255,0.4),rgba(0,245,255,0.2));border:1px solid rgba(191,0,255,0.3);">
                                    <i class="fa-solid fa-wand-magic-sparkles"></i> AI ile Oluştur
                                </button>
                            </div>

                            <!-- Bölüm listesi -->
                            <div id="chapters-list" class="space-y-2 mb-3 max-h-48 overflow-y-auto"></div>

                            <!-- Yeni Bölüm Formu -->
                            <div class="flex gap-2 mt-2">
                                <input type="text" id="chapter-title-input" placeholder="Bölüm başlığı"
                                       class="input-field flex-1 px-3 py-2 rounded-lg text-xs text-white placeholder-gray-600">
                                <input type="number" id="chapter-time-input" placeholder="Sn" min="0"
                                       class="input-field w-20 px-3 py-2 rounded-lg text-xs text-white placeholder-gray-600">
                                <button type="button" onclick="addChapter()"
                                        class="px-3 py-2 rounded-lg text-xs font-bold text-black flex-shrink-0"
                                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                    <i class="fa-solid fa-plus"></i>
                                </button>
                            </div>
                            <p class="text-xs text-gray-700 mt-1.5">Saniye cinsinden girin (ör: 120 = 2:00)</p>
                        </div>
                        <?php endif; ?>

                        <!-- Kaydet -->
                        <button type="button" id="save-btn" onclick="saveVideo()"
                                class="neon-btn w-full py-3 sm:py-4 rounded-2xl text-sm flex items-center justify-center gap-2">
                            <i class="fa-solid fa-<?= $editData ? 'floppy-disk' : 'cloud-arrow-up' ?>"></i>
                            <?= $editData ? 'Degisiklikleri Kaydet' : 'Videoyu Kaydet' ?>
                        </button>

                        <div id="save-status" class="hidden px-4 py-3 rounded-xl text-sm border"></div>
                    </div>
                </div>
            </form>
        </div>
    </main>
</div>

<!-- ===== AI THUMBNAIL MODAL ===== -->
<div id="ai-thumb-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
    <div class="bg-[#13131f] border border-white/10 rounded-2xl p-6 w-full max-w-3xl shadow-2xl animate-fade-in flex flex-col max-h-[90vh]">
        <h3 class="text-lg font-bold text-white mb-4"><i class="fa-solid fa-wand-magic-sparkles text-cyan-400 mr-2"></i>AI Thumbnail Üretici</h3>
        
        <div class="mb-4">
            <label class="block text-xs text-gray-400 mb-2">Görsel Açıklaması (Prompt)</label>
            <div class="flex gap-2">
                <input type="text" id="ai-thumb-prompt" placeholder="Örn: Siberpunk neon ışıklı bir şehirde uçan araba..." 
                       class="flex-1 input-field px-4 py-2.5 rounded-xl text-sm text-white">
                <button type="button" onclick="generateAiThumbnails()" id="ai-thumb-generate-btn"
                        class="px-5 py-2.5 rounded-xl font-bold text-black whitespace-nowrap"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                    Üret (3 Seçenek)
                </button>
            </div>
        </div>

        <!-- Sonuçlar -->
        <div id="ai-thumb-results" class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4 overflow-y-auto min-h-[150px]">
            <!-- Görseller buraya gelecek -->
        </div>

        <div class="mt-auto flex justify-end gap-2 pt-4 border-t border-white/10">
            <button type="button" onclick="closeAiThumbModal()" 
                    class="px-5 py-2 rounded-xl text-sm text-white bg-white/5 border border-white/10 hover:bg-white/10">
                Kapat
            </button>
        </div>
    </div>
</div>

<script>
const EDIT_ID    = '<?= e($editId) ?>';
const APP_URL_JS = '<?= APP_URL ?>';
let aiGeneratedData = null;

/* ---- Toggle Switch ---- */
const autoSubCheck = document.getElementById('auto-subtitle-check');
const toggleTrack  = document.getElementById('toggle-track');
const toggleThumb  = document.getElementById('toggle-thumb');

if (autoSubCheck) {
    autoSubCheck.addEventListener('change', function() {
        if (this.checked) {
            toggleTrack.style.background = 'linear-gradient(135deg,#00f5ff,#bf00ff)';
            toggleThumb.style.transform = 'translateX(20px)';
            toggleThumb.style.background = '#fff';
        } else {
            toggleTrack.style.background = 'rgba(255,255,255,0.1)';
            toggleThumb.style.transform = 'translateX(0)';
            toggleThumb.style.background = '#9ca3af';
        }
    });
    toggleTrack.parentElement.parentElement.addEventListener('click', function(e) {
        if (e.target.tagName !== 'INPUT') {
            autoSubCheck.checked = !autoSubCheck.checked;
            autoSubCheck.dispatchEvent(new Event('change'));
        }
    });
}

/* ---- Thumbnail URL Doğrulama & Önizleme ---- */
function validateThumbUrl() {
    const url = document.getElementById('thumb-url-input').value.trim();
    const status = document.getElementById('thumb-url-status');
    if (!url) {
        status.className = 'url-status empty';
        status.innerHTML = '<i class="fa-solid fa-circle text-[6px]"></i> Bekleniyor';
        return;
    }
    try {
        new URL(url);
        status.className = 'url-status valid';
        status.innerHTML = '<i class="fa-solid fa-check text-[8px]"></i> Geçerli URL';
    } catch {
        status.className = 'url-status invalid';
        status.innerHTML = '<i class="fa-solid fa-xmark text-[8px]"></i> Geçersiz URL';
    }
}

function previewThumbUrl() {
    const url = document.getElementById('thumb-url-input').value.trim();
    if (!url) { alert('Lütfen bir thumbnail URL\'si girin.'); return; }
    
    document.getElementById('thumb-url').value = url;
    document.getElementById('thumb-preview-img').src = url;
    document.getElementById('thumb-preview').classList.remove('hidden');
}

function thumbLoadSuccess() {
    const status = document.getElementById('thumb-url-status');
    status.className = 'url-status valid';
    status.innerHTML = '<i class="fa-solid fa-circle-check text-[8px]"></i> Görsel yüklendi';
}

function thumbLoadError() {
    const status = document.getElementById('thumb-url-status');
    status.className = 'url-status invalid';
    status.innerHTML = '<i class="fa-solid fa-triangle-exclamation text-[8px]"></i> Görsel yüklenemedi';
}

function clearThumbnail() {
    document.getElementById('thumb-url').value = '';
    document.getElementById('thumb-url-input').value = '';
    document.getElementById('thumb-preview').classList.add('hidden');
    const status = document.getElementById('thumb-url-status');
    status.className = 'url-status empty';
    status.innerHTML = '<i class="fa-solid fa-circle text-[6px]"></i> Bekleniyor';
}

/* ---- Video URL Doğrulama & Önizleme ---- */
function validateVideoUrl() {
    const url = document.getElementById('video-url-input').value.trim();
    const status = document.getElementById('video-url-status');
    if (!url) {
        status.className = 'url-status empty';
        status.innerHTML = '<i class="fa-solid fa-circle text-[6px]"></i> Bekleniyor';
        return;
    }
    try {
        new URL(url);
        status.className = 'url-status valid';
        status.innerHTML = '<i class="fa-solid fa-check text-[8px]"></i> Geçerli URL';
    } catch {
        status.className = 'url-status invalid';
        status.innerHTML = '<i class="fa-solid fa-xmark text-[8px]"></i> Geçersiz URL';
    }
}

function previewVideoUrl() {
    const url = document.getElementById('video-url-input').value.trim();
    if (!url) { alert('Lütfen bir video URL\'si girin.'); return; }
    
    document.getElementById('video-url').value = url;
    const player = document.getElementById('video-preview-player');
    player.src = url;
    player.load();
    document.getElementById('video-preview').classList.remove('hidden');
}

function videoLoadSuccess() {
    const player = document.getElementById('video-preview-player');
    const status = document.getElementById('video-url-status');
    status.className = 'url-status valid';
    status.innerHTML = '<i class="fa-solid fa-circle-check text-[8px]"></i> Video yüklendi';
    
    // Süre ve çözünürlük bilgisi
    const dur = Math.round(player.duration);
    document.getElementById('video-duration').value = dur;
    
    const h = Math.floor(dur / 3600);
    const m = Math.floor((dur % 3600) / 60);
    const s = dur % 60;
    const durText = h > 0 ? `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}` : `${m}:${String(s).padStart(2,'0')}`;
    
    document.getElementById('video-meta-duration').innerHTML = `<i class="fa-solid fa-clock mr-1"></i>${durText}`;
    document.getElementById('video-meta-resolution').innerHTML = `<i class="fa-solid fa-expand mr-1"></i>${player.videoWidth}x${player.videoHeight}`;
    document.getElementById('video-meta').classList.remove('hidden');
}

function videoLoadError() {
    const status = document.getElementById('video-url-status');
    status.className = 'url-status invalid';
    status.innerHTML = '<i class="fa-solid fa-triangle-exclamation text-[8px]"></i> Video yüklenemedi';
}

/* ---- Adım Gösterge Yardımcıları ---- */
function setStep(stepNum, state) {
    // state: 'pending' | 'active' | 'done' | 'error'
    const icon = document.getElementById('ai-step-' + stepNum + '-icon');
    const row  = document.getElementById('ai-step-' + stepNum);
    if (!icon || !row) return;

    const styles = {
        pending: { icon: '<i class="fa-solid fa-circle text-[6px] text-gray-600"></i>', border: 'rgba(255,255,255,0.04)', color: '' },
        active:  { icon: '<i class="fa-solid fa-spinner fa-spin text-[10px]" style="color:#ff8c00;"></i>', border: 'rgba(255,140,0,0.15)', color: 'color:#ff8c00;' },
        done:    { icon: '<i class="fa-solid fa-circle-check text-[10px]" style="color:#00f5ff;"></i>', border: 'rgba(0,245,255,0.1)', color: '' },
        error:   { icon: '<i class="fa-solid fa-circle-xmark text-[10px]" style="color:#ff007a;"></i>', border: 'rgba(255,0,122,0.1)', color: '' },
    };
    const s = styles[state] || styles.pending;
    icon.innerHTML = s.icon;
    row.style.background = s.border ? `rgba(${s.border.match(/\d+,\d+,\d+/)?.[0]||'255,255,255'},0.04)` : 'rgba(255,255,255,0.04)';
    row.style.borderColor = '';

    if (state === 'active') {
        row.style.background = 'rgba(255,140,0,0.07)';
        row.style.border = '1px solid rgba(255,140,0,0.2)';
    } else if (state === 'done') {
        row.style.background = 'rgba(0,245,255,0.05)';
        row.style.border = '1px solid rgba(0,245,255,0.15)';
    } else if (state === 'error') {
        row.style.background = 'rgba(255,0,122,0.05)';
        row.style.border = '1px solid rgba(255,0,122,0.15)';
    } else {
        row.style.background = 'rgba(255,255,255,0.04)';
        row.style.border = '';
    }
}

function showSteps() {
    document.getElementById('ai-steps').classList.remove('hidden');
    setStep(1, 'pending');
    setStep(2, 'pending');
}

function hideSteps() {
    document.getElementById('ai-steps').classList.add('hidden');
}

/* ---- AI İçerik Oluşturucu ---- */
async function generateWithAI() {
    const topic    = document.getElementById('ai-topic').value.trim();
    const btn      = document.getElementById('ai-generate-btn');
    const videoUrl = document.getElementById('video-url-input').value.trim();

    if (!topic && !videoUrl) {
        alert('Lütfen bir konu girin veya video URL\'si ekleyin.');
        return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin text-xs"></i> İşleniyor...';
    document.getElementById('ai-result').classList.add('hidden');

    try {
        // ---- Yol 1: Video URL var → CloudConvert + Gemini ----
        if (videoUrl) {
            showSteps();
            setStep(1, 'active');

            const res = await fetch(APP_URL_JS + '/api/ai.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action:    'analyze_video_url',
                    video_url: videoUrl,
                    video_id:  EDIT_ID || '',
                })
            });

            // Adım 1 bitti (ya başardı ya hata verdi; Gemini adımı sunucu içinde)
            setStep(1, 'done');
            setStep(2, 'active');

            let data;
            try {
                data = await res.json();
            } catch (err) {
                throw new Error('Sunucudan geçersiz yanıt alındı. Sunucu logu kontrol edin.');
            }

            if (data.success) {
                setStep(2, 'done');
                aiGeneratedData = data.data;
                document.getElementById('ai-result-text').textContent =
                    `Başlık: ${data.data.title}\n\nAçıklama: ${data.data.description}`;
                document.getElementById('ai-result').classList.remove('hidden');
            } else {
                setStep(2, 'error');
                alert('AI/CloudConvert hatası: ' + (data.message || 'Bilinmeyen hata'));
            }

        } else {
            // ---- Yol 2: Sadece konu var → klasik generate_title_desc ----
            hideSteps();
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin text-xs"></i> Oluşturuluyor...';

            const fileName = '';
            const res = await fetch(APP_URL_JS + '/api/ai.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    topic,
                    system_prompt: '',
                    image_base64:  '',
                    file_name:     fileName,
                    action:        'generate_title_desc'
                })
            });

            let data;
            try {
                data = await res.json();
            } catch (err) {
                throw new Error('Sunucudan geçersiz yanıt alındı.');
            }

            if (data.success) {
                aiGeneratedData = data.data;
                document.getElementById('ai-result-text').textContent =
                    `Başlık: ${data.data.title}\n\nAçıklama: ${data.data.description}`;
                document.getElementById('ai-result').classList.remove('hidden');
            } else {
                alert('AI hatası: ' + (data.message || 'Bilinmeyen hata'));
            }
        }
    } catch (e) {
        hideSteps();
        alert('Bağlantı hatası: ' + e.message);
    }

    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles text-xs"></i> Başlık + Açıklama Oluştur';
}

function applyAiResult() {
    if (!aiGeneratedData) return;
    document.getElementById('video-title').value       = aiGeneratedData.title;
    document.getElementById('video-description').value = aiGeneratedData.description;
    document.getElementById('ai-result').classList.add('hidden');
}


/* ---- Kaydet ---- */
async function saveVideo() {
    const title  = document.getElementById('video-title').value.trim();
    const desc   = document.getElementById('video-description').value.trim();
    const status = document.querySelector('input[name="status"]:checked')?.value || 'published';
    const btn    = document.getElementById('save-btn');
    const autoSubtitle = document.getElementById('auto-subtitle-check')?.checked;
    const duration = document.getElementById('video-duration')?.value || 0;

    if (!title) { showSaveStatus('Video basligi zorunludur.', 'error'); return; }

    // Thumbnail URL'sini al
    const thumbInput = document.getElementById('thumb-url-input').value.trim();
    if (thumbInput) {
        document.getElementById('thumb-url').value = thumbInput;
    }
    const thumb = document.getElementById('thumb-url').value;

    // Video URL'sini al
    const videoUrlInput = document.getElementById('video-url-input').value.trim();
    if (videoUrlInput) {
        document.getElementById('video-url').value = videoUrlInput;
    }
    let videoUrl = document.getElementById('video-url').value;

    if (!EDIT_ID && !videoUrl) {
        showSaveStatus('Lütfen bir video linki girin.', 'error'); return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Kaydediliyor...';

    try {
        const channelId = document.getElementById('video-channel').value;
        const tagsStr = document.getElementById('video-tags').value.trim();
        const tags = tagsStr ? tagsStr.split(',').map(t => t.trim()).filter(t => t) : [];

        const payload = { 
            title, description: desc, thumbnail_url: thumb, 
            video_url: videoUrl, cloudinary_public_id: '', 
            status, channel_id: channelId, duration: parseInt(duration, 10),
            tags: tags, preview_clip_url: null
        };

        if (status === 'scheduled') {
            const schedAt = document.getElementById('scheduled-at').value;
            if (!schedAt) { showSaveStatus('Zamanlanmış yayın için tarih gereklidir.', 'error'); btn.disabled = false; btn.innerHTML = getDefaultBtnHtml(); return; }
            payload.scheduled_at = new Date(schedAt).toISOString();
        }

                        { const ie = document.getElementById('intro-end'); if (ie) { const n = parseInt(ie.value, 10); if (n > 0) payload.intro_end = n; else if (ie.dataset.had === '1') payload.intro_end = null; } }
        { const ex = document.getElementById('expires-at'); if (ex) { if (ex.value) payload.expires_at = new Date(ex.value).toISOString(); else if (ex.dataset.had === '1') payload.expires_at = null; } }

        const res = await fetch(APP_URL_JS + '/api/videos.php' + (EDIT_ID ? '?id=' + EDIT_ID : ''), {
            method: EDIT_ID ? 'PATCH' : 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (data.success) {
            const videoId = data.data?.id || data.data?.[0]?.id || EDIT_ID;
            
            // Otomatik altyazı oluştur
            if (autoSubtitle && videoId && videoUrl) {
                btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Altyazi olusturuluyor...';
                try {
                    const subRes = await fetch(APP_URL_JS + '/api/subtitles.php', {
                        method: 'POST',
                        headers: {'Content-Type':'application/json'},
                        body: JSON.stringify({ video_id: videoId, cloudinary_public_id: '', video_url: videoUrl })
                    });
                    const subData = await subRes.json();
                    if (subData.success) {
                        showSaveStatus((EDIT_ID ? 'Degisiklikler kaydedildi' : 'Video kaydedildi') + ' ve altyazi olusturuldu!', 'success');
                    } else {
                        showSaveStatus('Video kaydedildi fakat altyazi hatasi: ' + (subData.message || 'Bilinmeyen'), 'error');
                    }
                } catch(e) {
                    showSaveStatus('Video kaydedildi, altyazi olusturulamadi.', 'error');
                }
            } else {
                showSaveStatus(EDIT_ID ? 'Degisiklikler kaydedildi!' : 'Video basariyla kaydedildi!', 'success');
            }
            
            if (!EDIT_ID) setTimeout(() => window.location.href = APP_URL_JS + '/admin/videos.php', 2500);
        } else {
            showSaveStatus('Hata: ' + (data.message || 'Bilinmeyen hata'), 'error');
        }
    } catch(err) { showSaveStatus('Hata: ' + err.message, 'error'); }
    btn.disabled = false;
    btn.innerHTML = getDefaultBtnHtml();
}

function getDefaultBtnHtml() {
    return '<i class="fa-solid fa-' + (EDIT_ID ? 'floppy-disk' : 'cloud-arrow-up') + '"></i> ' + (EDIT_ID ? 'Degisiklikleri Kaydet' : 'Videoyu Kaydet');
}
</script>

<script>
/* ---- showSaveStatus ---- */
function showSaveStatus(msg, type) {
    const el = document.getElementById('save-status');
    const s  = { success: 'background:rgba(0,245,255,0.08);border-color:rgba(0,245,255,0.25);color:#00f5ff;',
                 error:   'background:rgba(255,0,122,0.08);border-color:rgba(255,0,122,0.25);color:#ff007a;' };
    el.style.cssText = s[type] || s.error;
    el.innerHTML = `<i class="fa-solid fa-${type==='success'?'circle-check':'circle-xmark'} mr-2"></i>${msg}`;
    el.classList.remove('hidden');
    el.scrollIntoView({ behavior:'smooth', block:'nearest' });
}

function toggleScheduledDate() {
    const status = document.querySelector('input[name="status"]:checked')?.value;
    const wrap = document.getElementById('scheduled-date-wrap');
    if (status === 'scheduled') wrap.classList.remove('hidden');
    else wrap.classList.add('hidden');
}

/* ---- Chapters Yönetimi ---- */
const EDIT_VIDEO_ID = '<?= e($editId) ?>';

function formatSeconds(s) {
    s = parseInt(s) || 0;
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
    return `${m}:${String(sec).padStart(2,'0')}`;
}

async function loadChapters() {
    if (!EDIT_VIDEO_ID) return;
    const res = await fetch(APP_URL_JS + '/api/chapters.php?video_id=' + EDIT_VIDEO_ID);
    const data = await res.json();
    if (data.success) renderChapters(data.data || []);
}

function renderChapters(chapters) {
    const list = document.getElementById('chapters-list');
    if (!list) return;
    if (!chapters.length) {
        list.innerHTML = '<p class="text-xs text-gray-600 text-center py-2">Henüz bölüm yok</p>';
        return;
    }
    list.innerHTML = chapters.map(ch => `
        <div class="flex items-center gap-2 p-2 rounded-lg" style="background:rgba(255,255,255,0.04);">
            <span class="text-xs font-mono text-cyan-400 flex-shrink-0">${formatSeconds(ch.start_time)}</span>
            <span class="text-xs text-gray-300 flex-1 truncate">${ch.title}</span>
            <button onclick="deleteChapter('${ch.id}')" class="text-gray-600 hover:text-red-400 transition-colors flex-shrink-0">
                <i class="fa-solid fa-xmark text-xs"></i>
            </button>
        </div>
    `).join('');
}

async function addChapter() {
    const title = document.getElementById('chapter-title-input').value.trim();
    const time  = parseInt(document.getElementById('chapter-time-input').value) || 0;
    if (!title) { alert('Bölüm başlığı gerekli'); return; }
    if (!EDIT_VIDEO_ID) { alert('Önce videoyu kaydedin'); return; }

    const res  = await fetch(APP_URL_JS + '/api/chapters.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ video_id: EDIT_VIDEO_ID, title, start_time: time })
    });
    const data = await res.json();
    if (data.success) {
        document.getElementById('chapter-title-input').value = '';
        document.getElementById('chapter-time-input').value  = '';
        loadChapters();
    } else {
        alert('Hata: ' + (data.message || 'Bilinmeyen'));
    }
}

async function deleteChapter(id) {
    if (!confirm('Bu bölümü silmek istiyor musunuz?')) return;
    const res  = await fetch(APP_URL_JS + '/api/chapters.php?id=' + id, { method: 'DELETE' });
    const data = await res.json();
    if (data.success) loadChapters();
}

/* ---- AI ile Bölüm Oluştur ---- */
async function generateChaptersWithAI() {
    if (!EDIT_VIDEO_ID) { alert('Önce videoyu kaydedin'); return; }

    const btn = document.getElementById('ai-chapters-btn');
    const oldHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Oluşturuluyor...';

    try {
        const subRes  = await fetch(APP_URL_JS + '/api/subtitles.php?video_id=' + EDIT_VIDEO_ID);
        const subData = await subRes.json();
        const subtitleContent = subData.data?.content || '';

        if (!subtitleContent) {
            alert('Bu video için altyazı bulunamadı. Önce altyazı oluşturun.');
            btn.disabled = false; btn.innerHTML = oldHtml;
            return;
        }

        const res  = await fetch(APP_URL_JS + '/api/chapters.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ video_id: EDIT_VIDEO_ID, ai: true, subtitle_content: subtitleContent })
        });
        const data = await res.json();

        if (data.success) {
            loadChapters();
            showSaveStatus(data.message || 'Bölümler oluşturuldu!', 'success');
        } else {
            alert('Hata: ' + (data.message || 'Bilinmeyen'));
        }
    } catch(e) {
        alert('Bağlantı hatası: ' + e.message);
    }

    btn.disabled = false;
    btn.innerHTML = oldHtml;
}

// Sayfa yüklenince
if (EDIT_VIDEO_ID) loadChapters();

// Sayfa yüklenince mevcut URL'leri doğrula
window.addEventListener('DOMContentLoaded', () => {
    validateThumbUrl();
    validateVideoUrl();
    // Edit modunda mevcut thumbnail'i göster
    const thumbUrl = document.getElementById('thumb-url-input').value.trim();
    if (thumbUrl) {
        previewThumbUrl();
    }
});

// ===== AI THUMBNAIL İŞLEMLERİ =====
function openAiThumbModal() {
    document.getElementById('ai-thumb-modal').classList.remove('hidden');
    const title = document.getElementById('video-title').value.trim();
    if (title && !document.getElementById('ai-thumb-prompt').value) {
        document.getElementById('ai-thumb-prompt').value = "YouTube thumbnail for a video titled: " + title;
    }
}

function closeAiThumbModal() {
    document.getElementById('ai-thumb-modal').classList.add('hidden');
}

function generateAiThumbnails() {
    const prompt = document.getElementById('ai-thumb-prompt').value.trim();
    if (!prompt) return alert('Lütfen bir prompt girin.');

    const btn = document.getElementById('ai-thumb-generate-btn');
    const resultsContainer = document.getElementById('ai-thumb-results');
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i>Üretiliyor...';
    resultsContainer.innerHTML = '';

    const variations = 3;
    let html = '';
    
    for (let i = 0; i < variations; i++) {
        const seed = Math.floor(Math.random() * 1000000);
        const imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1280&height=720&nologo=true&seed=${seed}`;
        
        html += `
        <div class="relative group rounded-xl overflow-hidden cursor-pointer border-2 border-transparent hover:border-cyan-400 transition-colors"
             onclick="selectAiThumb('${imageUrl}')">
            <img src="${imageUrl}" class="w-full aspect-video object-cover" onload="this.nextElementSibling.style.display='none'" onerror="this.nextElementSibling.innerHTML='Yüklenemedi'">
            <div class="absolute inset-0 flex items-center justify-center bg-black/50 text-xs text-white">Yükleniyor...</div>
            <div class="absolute inset-0 bg-cyan-400/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span class="bg-black/80 px-3 py-1 rounded-lg text-xs font-bold text-cyan-400">Seç</span>
            </div>
        </div>`;
    }
    
    resultsContainer.innerHTML = html;
    
    btn.disabled = false;
    btn.innerHTML = 'Üret (3 Seçenek)';
}

function selectAiThumb(url) {
    const input = document.getElementById('thumb-url-input');
    input.value = url;
    document.getElementById('thumb-url').value = url;
    
    // Yükleme kontrolünü tetikle
    validateThumbUrl();
    
    closeAiThumbModal();
}
</script>
</body>
</html>
