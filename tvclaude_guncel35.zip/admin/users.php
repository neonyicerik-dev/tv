<?php
// ============================================================
// NeonTV - Admin: Kullanıcı & Premium Yönetimi
// F4: Kayıtlı kullanıcılar, Premium üyelik verme/iptal etme
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin('superadmin');

$db    = new Supabase();
$flash = '';

// ---- Aksiyon ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) {
        setFlash('error', 'Güvenlik hatası.');
        redirect(APP_URL . '/admin/users.php');
    }

    $action = input('action');

    if ($action === 'grant_premium') {
        $userId   = trim(input('user_id'));
        $until    = trim(input('premium_until'));  // ISO8601 veya boş (süresiz)
        $note     = trim(input('note'));

        if (!$userId) {
            setFlash('error', 'Lütfen bir kullanıcı seçin veya UUID girin.');
        } else {
            $premiumUntil = $until ? date('c', strtotime($until)) : null; // null = süresiz
            $ok = Store::grantPremium($userId, $premiumUntil, '', $note);
            if ($ok) {
                logActivity('user_premium_grant', 'user', $userId, [], ['until' => $premiumUntil, 'note' => $note]);
                setFlash('success', 'Premium üyelik başarıyla tanımlandı.');
            } else {
                setFlash('error', 'İşlem başarısız oldu.');
            }
        }
        redirect(APP_URL . '/admin/users.php');
    }

    if ($action === 'ban_user') {
        $userId = trim(input('user_id'));
        $days   = input('days');
        $reason = mb_substr(trim(input('reason')), 0, 200);
        if (!isUuid($userId)) {
            setFlash('error', 'Geçerli bir kullanıcı seçin.');
        } else {
            $until = ($days === 'perm' || (int)$days <= 0) ? null : gmdate('Y-m-d\TH:i:s\Z', time() + (int)$days * 86400);
            $ex = $db->first('user_bans', 'user_id=eq.' . $userId . '&select=user_id', true);
            $row = ['reason' => $reason, 'banned_until' => $until, 'banned_by' => $_SESSION['admin_username'] ?? '', 'created_at' => gmdate('Y-m-d\TH:i:s\Z')];
            $r = $ex ? $db->update('user_bans', $row, 'user_id=eq.' . $userId, true) : $db->insert('user_bans', ['user_id' => $userId] + $row, true);
            if (($r['status'] ?? 500) < 400) { logActivity('user_ban', 'user', $userId, [], ['days' => $days, 'reason' => $reason]); setFlash('success', 'Kullanıcı yasaklandı.'); }
            else setFlash('error', 'Yasaklanamadı (SQL çalıştırıldı mı?).');
        }
        redirect(APP_URL . '/admin/users.php');
    }

    if ($action === 'unban_user') {
        $userId = trim(input('user_id'));
        if (isUuid($userId)) { $db->delete('user_bans', 'user_id=eq.' . $userId, true); logActivity('user_unban', 'user', $userId); setFlash('success', 'Yasak kaldırıldı.'); }
        redirect(APP_URL . '/admin/users.php');
    }

    if ($action === 'revoke_premium') {
        $userId = trim(input('user_id'));
        if (!$userId) {
            setFlash('error', 'Kullanıcı ID zorunlu.');
        } else {
            $ok = Store::revokePremium($userId);
            if ($ok) {
                logActivity('user_premium_revoke', 'user', $userId);
                setFlash('success', 'Premium üyelik iptal edildi.');
            } else {
                setFlash('error', 'İşlem başarısız.');
            }
        }
        redirect(APP_URL . '/admin/users.php');
    }
}

// ---- Yasaklar ----
$banList = $db->select('user_bans', 'order=created_at.desc&limit=200', true)['data'] ?? [];
$banMap = [];
foreach ($banList as $b) { if (empty($b['banned_until']) || strtotime($b['banned_until']) > time()) $banMap[$b['user_id']] = $b; }

// ---- Premium kullanıcı listesi ----
$premiumList = $db->select('user_premium', 'order=created_at.desc&limit=100', true)['data'] ?? [];
$premiumMap  = [];
foreach ($premiumList as $p) {
    $isActive = empty($p['premium_until']) || strtotime($p['premium_until']) > time();
    $premiumMap[$p['user_id']] = [
        'is_active' => $isActive,
        'until'     => $p['premium_until'],
        'note'      => $p['note'] ?? '',
        'granted_by'=> $p['granted_by'] ?? '',
    ];
}

// ---- Kayıtlı Kullanıcıları Çek (Auth Admin API + Profiles Tablosu) ----
$profilesRes   = $db->select('profiles', 'order=created_at.desc', true);
$profilesList  = $profilesRes['data'] ?? [];
$authUsersList = $db->adminListUsers(1, 100);

$registeredUsers = [];

// 1. Auth Admin API kullanıcıları
foreach ($authUsersList as $au) {
    $uid = $au['id'] ?? '';
    if (!$uid) continue;
    $rawMeta  = $au['user_metadata'] ?? ($au['raw_user_meta_data'] ?? []);
    $email    = $au['email'] ?? '';
    $username = $rawMeta['username'] ?? ($email ? explode('@', $email)[0] : 'Kullanıcı');
    $avatar   = $rawMeta['avatar_url'] ?? '';

    $registeredUsers[$uid] = [
        'id'         => $uid,
        'email'      => $email,
        'username'   => $username,
        'avatar_url' => $avatar,
        'created_at' => $au['created_at'] ?? '',
    ];
}

// 2. Profiles tablosundan zenginleştir veya ekle
foreach ($profilesList as $p) {
    $uid = $p['id'] ?? '';
    if (!$uid) continue;
    if (isset($registeredUsers[$uid])) {
        if (!empty($p['username'])) $registeredUsers[$uid]['username'] = $p['username'];
        if (!empty($p['avatar_url'])) $registeredUsers[$uid]['avatar_url'] = $p['avatar_url'];
    } else {
        $registeredUsers[$uid] = [
            'id'         => $uid,
            'email'      => '',
            'username'   => $p['username'] ?? 'Kullanıcı',
            'avatar_url' => $p['avatar_url'] ?? '',
            'created_at' => $p['created_at'] ?? '',
        ];
    }
}

// ---- YZ Kullanım İstatistikleri ----
$period   = date('Y-m');
$aiUsage  = $db->select('ai_usage', 'period=eq.' . urlencode($period) . '&order=used.desc&limit=50', true)['data'] ?? [];
?>
<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcılar | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family:'Outfit',sans-serif; background:#070711; color:#fff; }
        ::-webkit-scrollbar{width:6px;} ::-webkit-scrollbar-track{background:#0d0d1a;} ::-webkit-scrollbar-thumb{background:#1e1e3a;border-radius:3px;}
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- TOP BAR (Mobil Menü Butonu Dahil) -->
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <!-- Hamburger Menü -->
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors"
                    style="background:rgba(255,255,255,0.06);">
                <i class="fa-solid fa-bars text-sm"></i>
            </button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white">Kullanıcı & Premium Yönetimi</h1>
                <p class="text-xs text-gray-500">Kayıtlı kullanıcılar, VIP abonelikler ve YZ kotası (<?= count($registeredUsers) ?> kayıtlı kullanıcı)</p>
            </div>
        </div>
        <a href="#premium-form-section"
           class="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-black transition-all hover:scale-105"
           style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
            <i class="fa-solid fa-crown text-xs"></i>
            <span class="hidden sm:inline">Premium Tanımla</span>
            <span class="sm:hidden">Premium</span>
        </a>
    </header>

    <main class="flex-1 p-4 sm:p-6 overflow-auto">
        <div class="max-w-5xl mx-auto space-y-8">

            <?= renderFlash() ?>

            <!-- ===== PREMIUM EKLEME FORMU ===== -->
            <section id="premium-form-section" class="rounded-2xl p-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.06);">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-base font-bold text-cyan-400 flex items-center gap-2">
                        <i class="fa-solid fa-crown"></i> Premium Üyelik Ver
                    </h2>
                    <span class="text-xs text-gray-500">Aşağıdaki kayıtlı kullanıcılardan seçebilir veya UUID yazabilirsiniz</span>
                </div>

                <form method="POST" class="space-y-4">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="grant_premium">

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <!-- Kayıtlı Kullanıcı Seçimi -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-400 mb-1.5">
                                <i class="fa-solid fa-users text-cyan-400 mr-1"></i>Kayıtlı Kullanıcı Seç
                            </label>
                            <select id="user-select-dropdown" onchange="pickUser(this.value)"
                                    class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                                <option value="">-- Kayıtlı Kullanıcı Listesinden Seçin (<?= count($registeredUsers) ?> Kişi) --</option>
                                <?php foreach ($registeredUsers as $u): 
                                    $hasPrem = isset($premiumMap[$u['id']]) && $premiumMap[$u['id']]['is_active'];
                                ?>
                                <option value="<?= e($u['id']) ?>">
                                    <?= e($u['username']) ?><?= $u['email'] ? ' (' . e($u['email']) . ')' : '' ?><?= $hasPrem ? ' [★ VIP]' : '' ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Kullanıcı UUID (Elle girilebilir veya otomatik dolar) -->
                        <div>
                            <label class="block text-xs font-semibold text-gray-400 mb-1.5">Kullanıcı ID (UUID) *</label>
                            <input type="text" name="user_id" id="input-user-id" required placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                                   class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50 font-mono">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-gray-400 mb-1.5">Premium Bitiş Tarihi (boş bırakılırsa = süresiz)</label>
                            <input type="datetime-local" name="premium_until" id="input-premium-until"
                                   class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-gray-400 mb-1.5">Açıklama / Not</label>
                            <input type="text" name="note" id="input-note" placeholder="Örn: 1 Aylık VIP Paketi"
                                   class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                        </div>
                    </div>

                    <div class="flex items-center justify-between pt-2">
                        <div class="flex items-center gap-2">
                            <button type="button" onclick="setQuickDate(30)" class="px-2.5 py-1 rounded-lg text-xs bg-white/5 hover:bg-white/10 text-gray-300 transition-colors">+1 Ay</button>
                            <button type="button" onclick="setQuickDate(90)" class="px-2.5 py-1 rounded-lg text-xs bg-white/5 hover:bg-white/10 text-gray-300 transition-colors">+3 Ay</button>
                            <button type="button" onclick="setQuickDate(365)" class="px-2.5 py-1 rounded-lg text-xs bg-white/5 hover:bg-white/10 text-gray-300 transition-colors">+1 Yıl</button>
                            <button type="button" onclick="document.getElementById('input-premium-until').value=''" class="px-2.5 py-1 rounded-lg text-xs bg-white/5 hover:bg-white/10 text-cyan-400 transition-colors">Süresiz</button>
                        </div>
                        <button type="submit"
                                class="px-6 py-2.5 rounded-xl text-sm font-bold text-black transition-all hover:scale-105"
                                style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                            <i class="fa-solid fa-crown mr-2"></i>Premium Ver
                        </button>
                    </div>
                </form>
            </section>

            <!-- ===== YASAKLAMA ===== -->
            <section id="ban-section" class="rounded-2xl p-6" style="background:#13131f;border:1px solid rgba(255,68,68,0.2);">
                <h2 class="text-base font-bold text-white flex items-center gap-2 mb-3"><i class="fa-solid fa-user-slash" style="color:#ff4d6d"></i> Kullanıcı Yasakla</h2>
                <form method="POST" class="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
                    <?= csrfField() ?><input type="hidden" name="action" value="ban_user">
                    <div class="md:col-span-2"><label class="block text-xs font-semibold text-gray-400 mb-1.5">Kullanıcı</label>
                        <select name="user_id" id="ban-user" required class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none">
                            <option value="">-- Seçin --</option>
                            <?php foreach ($registeredUsers as $u): ?><option value="<?= e($u['id']) ?>"><?= e($u['username']) ?><?= $u['email'] ? ' (' . e($u['email']) . ')' : '' ?><?= isset($banMap[$u['id']]) ? ' [YASAKLI]' : '' ?></option><?php endforeach; ?>
                        </select></div>
                    <div><label class="block text-xs font-semibold text-gray-400 mb-1.5">Süre</label>
                        <select name="days" class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none">
                            <option value="1">1 gün</option><option value="3">3 gün</option><option value="7" selected>7 gün</option><option value="30">30 gün</option><option value="perm">Kalıcı</option>
                        </select></div>
                    <div><label class="block text-xs font-semibold text-gray-400 mb-1.5">Sebep</label>
                        <input type="text" name="reason" maxlength="200" placeholder="Örn: Spam yorum" class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none"></div>
                    <div class="md:col-span-4"><button type="submit" class="px-6 py-2.5 rounded-xl text-sm font-bold text-white" style="background:linear-gradient(135deg,#ff4d6d,#ff7a00);"><i class="fa-solid fa-ban mr-2"></i>Yasakla</button></div>
                </form>
                <?php if ($banMap): ?>
                <div class="mt-5 space-y-2">
                    <h3 class="text-xs font-semibold text-gray-400">Aktif yasaklar (<?= count($banMap) ?>)</h3>
                    <?php foreach ($banMap as $uid2 => $b): $bu = $registeredUsers[$uid2] ?? null; ?>
                    <div class="flex flex-wrap items-center gap-3 p-3 rounded-xl text-sm" style="background:rgba(255,255,255,0.03)">
                        <span class="font-semibold text-white"><?= e($bu['username'] ?? $uid2) ?></span>
                        <span class="text-gray-400 text-xs"><?= empty($b['banned_until']) ? 'Kalıcı' : 'Bitiş: ' . e(date('d.m.Y H:i', strtotime($b['banned_until']))) ?></span>
                        <span class="text-gray-500 text-xs flex-1"><?= e($b['reason'] ?? '') ?></span>
                        <form method="POST" onsubmit="return confirm('Yasak kaldırılsın mı?')"><?= csrfField() ?><input type="hidden" name="action" value="unban_user"><input type="hidden" name="user_id" value="<?= e($uid2) ?>"><button class="px-3 py-1 rounded-lg text-xs" style="background:rgba(0,255,127,0.12);color:#00ff7f;border:1px solid rgba(0,255,127,0.3)">Yasağı Kaldır</button></form>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </section>

            <!-- ===== KAYITLI KULLANICILAR LİSTESİ ===== -->
            <section>
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-base font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-users text-cyan-400"></i>
                        Kayıtlı Kullanıcılar (<?= count($registeredUsers) ?>)
                    </h2>
                    <span class="text-xs text-gray-500">Platformda hesabı olan üyeler</span>
                </div>
                <div class="rounded-2xl overflow-hidden" style="background:#13131f;border:1px solid rgba(255,255,255,0.06);">
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead>
                                <tr style="background:rgba(0,245,255,0.04);border-bottom:1px solid rgba(255,255,255,0.06);">
                                    <th class="px-4 py-3.5 text-left text-gray-400 font-semibold">Kullanıcı</th>
                                    <th class="px-4 py-3.5 text-left text-gray-400 font-semibold">E-posta</th>
                                    <th class="px-4 py-3.5 text-left text-gray-400 font-semibold">Kayıt Tarihi</th>
                                    <th class="px-4 py-3.5 text-center text-gray-400 font-semibold">Premium Durumu</th>
                                    <th class="px-4 py-3.5 text-center text-gray-400 font-semibold">Hızlı İşlem</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y" style="border-color:rgba(255,255,255,0.04);">
                                <?php if (empty($registeredUsers)): ?>
                                <tr><td colspan="5" class="px-4 py-8 text-center text-gray-500">Kayıtlı kullanıcı bulunamadı</td></tr>
                                <?php else: ?>
                                <?php foreach ($registeredUsers as $u): 
                                    $prem = $premiumMap[$u['id']] ?? null;
                                    $isPrem = $prem && $prem['is_active'];
                                ?>
                                <tr class="hover:bg-white/[0.02] transition-colors">
                                    <td class="px-4 py-3.5">
                                        <div class="flex items-center gap-2.5">
                                            <?php if (!empty($u['avatar_url'])): ?>
                                                <img src="<?= e($u['avatar_url']) ?>" alt="Avatar" class="w-8 h-8 rounded-full object-cover border border-white/10 flex-shrink-0">
                                            <?php else: ?>
                                                <div class="w-8 h-8 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs font-bold flex-shrink-0">
                                                    <?= strtoupper(substr($u['username'] ?: 'U', 0, 1)) ?>
                                                </div>
                                            <?php endif; ?>
                                            <div class="min-w-0">
                                                <p class="font-semibold text-white text-xs sm:text-sm truncate"><?= e($u['username']) ?></p>
                                                <p class="font-mono text-[10px] text-gray-500 truncate" title="<?= e($u['id']) ?>"><?= substr($u['id'], 0, 16) ?>…</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-4 py-3.5 text-xs text-gray-300">
                                        <?= e($u['email'] ?: '—') ?>
                                    </td>
                                    <td class="px-4 py-3.5 text-xs text-gray-400">
                                        <?= !empty($u['created_at']) ? date('d.m.Y H:i', strtotime($u['created_at'])) : '—' ?>
                                    </td>
                                    <td class="px-4 py-3.5 text-center">
                                        <?php if ($isPrem): ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold"
                                                  style="background:rgba(191,0,255,0.12);color:#bf00ff;border:1px solid rgba(191,0,255,0.25);">
                                                <i class="fa-solid fa-crown text-[10px]"></i>
                                                <?= empty($prem['until']) ? 'Süresiz VIP' : date('d.m.Y', strtotime($prem['until'])) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2.5 py-0.5 rounded-full text-xs text-gray-500 bg-white/5 border border-white/5">Standart</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-3.5 text-center">
                                        <div class="flex items-center justify-center gap-2">
                                            <button onclick="selectAndScroll('<?= e($u['id']) ?>')"
                                                    class="px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all hover:scale-105"
                                                    style="background:rgba(0,245,255,0.1);color:#00f5ff;border:1px solid rgba(0,245,255,0.25);">
                                                <i class="fa-solid fa-crown mr-1"></i><?= $isPrem ? 'Süre Uzat' : 'Premium Ver' ?>
                                            </button>
                                            <button type="button" onclick="document.getElementById('ban-user').value='<?= e($u['id']) ?>';document.getElementById('ban-section').scrollIntoView({behavior:'smooth'})" class="px-2 py-1.5 rounded-lg text-xs font-medium" style="background:rgba(255,77,109,0.1);color:#ff4d6d;border:1px solid rgba(255,77,109,0.25);" title="Yasakla"><i class="fa-solid fa-user-slash"></i></button>
                                            <?php if ($isPrem): ?>
                                            <form method="POST" class="inline" onsubmit="return confirm('<?= e($u['username']) ?> kullanıcısının premium üyeliğini iptal etmek istediğinizden emin misiniz?')">
                                                <?= csrfField() ?>
                                                <input type="hidden" name="action" value="revoke_premium">
                                                <input type="hidden" name="user_id" value="<?= e($u['id']) ?>">
                                                <button type="submit" class="px-2 py-1.5 rounded-lg text-xs font-medium transition-all hover:scale-105"
                                                        style="background:rgba(255,68,68,0.1);color:#ff4444;border:1px solid rgba(255,68,68,0.2);">
                                                    <i class="fa-solid fa-ban"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <!-- ===== MEVCUT PREMIUM ÜYELER ===== -->
            <section>
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-base font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-award text-neon-pink"></i>
                        Mevcut Premium Üyeler (<?= count($premiumList) ?>)
                    </h2>
                    <span class="text-xs text-gray-500">Premium yetkisi tanımlanmış kullanıcılar</span>
                </div>
                <div class="rounded-2xl overflow-hidden" style="background:#13131f;border:1px solid rgba(255,255,255,0.06);">
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead>
                                <tr style="background:rgba(0,245,255,0.04);border-bottom:1px solid rgba(255,255,255,0.06);">
                                    <th class="px-4 py-3 text-left text-gray-400 font-semibold">Kullanıcı</th>
                                    <th class="px-4 py-3 text-left text-gray-400 font-semibold">Premium Bitiş</th>
                                    <th class="px-4 py-3 text-left text-gray-400 font-semibold">Veren</th>
                                    <th class="px-4 py-3 text-left text-gray-400 font-semibold">Not</th>
                                    <th class="px-4 py-3 text-center text-gray-400 font-semibold">İşlem</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y" style="border-color:rgba(255,255,255,0.04);">
                                <?php if (empty($premiumList)): ?>
                                <tr><td colspan="5" class="px-4 py-8 text-center text-gray-500">Henüz premium üye yok</td></tr>
                                <?php else: ?>
                                <?php foreach ($premiumList as $p): 
                                    $uData = $registeredUsers[$p['user_id']] ?? null;
                                    $isActive = empty($p['premium_until']) || strtotime($p['premium_until']) > time();
                                ?>
                                <tr class="hover:bg-white/[0.02] transition-colors">
                                    <td class="px-4 py-3">
                                        <div class="flex items-center gap-2">
                                            <span class="font-semibold text-white text-xs sm:text-sm">
                                                <?= e($uData['username'] ?? 'Kullanıcı') ?>
                                            </span>
                                            <?php if (!empty($uData['email'])): ?>
                                                <span class="text-xs text-gray-500">(<?= e($uData['email']) ?>)</span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="font-mono text-[10px] text-gray-500 truncate" title="<?= e($p['user_id']) ?>">
                                            <?= substr($p['user_id'], 0, 18) ?>…
                                        </p>
                                    </td>
                                    <td class="px-4 py-3 text-sm <?= $isActive ? 'text-cyan-400 font-medium' : 'text-red-400' ?>">
                                        <?= empty($p['premium_until']) ? 'Süresiz' : date('d.m.Y H:i', strtotime($p['premium_until'])) ?>
                                        <?= !$isActive ? '<span class="text-xs text-red-400 ml-1">(Dolmuş)</span>' : '' ?>
                                    </td>
                                    <td class="px-4 py-3 text-gray-400 text-xs"><?= e($p['granted_by'] ?? '—') ?></td>
                                    <td class="px-4 py-3 text-gray-400 text-xs"><?= e($p['note'] ?? '—') ?></td>
                                    <td class="px-4 py-3 text-center">
                                        <form method="POST" class="inline" onsubmit="return confirm('Premium üyeliği iptal etmek istediğinizden emin misiniz?')">
                                            <?= csrfField() ?>
                                            <input type="hidden" name="action" value="revoke_premium">
                                            <input type="hidden" name="user_id" value="<?= e($p['user_id']) ?>">
                                            <button type="submit" class="px-3 py-1.5 rounded-lg text-xs font-medium transition-all hover:scale-105"
                                                    style="background:rgba(255,68,68,0.1);color:#ff4444;border:1px solid rgba(255,68,68,0.2);">
                                                <i class="fa-solid fa-ban mr-1"></i>İptal Et
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <!-- ===== YZ KOTA KULLANIMI ===== -->
            <section>
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-base font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-robot text-purple-400"></i>
                        YZ Kota Kullanımı (<?= date('F Y') ?>)
                    </h2>
                    <span class="text-xs text-gray-500">NeTvYZ asistanını kullanan kullanıcılar</span>
                </div>
                <div class="rounded-2xl overflow-hidden" style="background:#13131f;border:1px solid rgba(255,255,255,0.06);">
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead>
                                <tr style="background:rgba(191,0,255,0.04);border-bottom:1px solid rgba(255,255,255,0.06);">
                                    <th class="px-4 py-3 text-left text-gray-400 font-semibold">Kullanıcı</th>
                                    <th class="px-4 py-3 text-center text-gray-400 font-semibold">Kullanılan</th>
                                    <th class="px-4 py-3 text-center text-gray-400 font-semibold">Aylık Limit</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y" style="border-color:rgba(255,255,255,0.04);">
                                <?php if (empty($aiUsage)): ?>
                                <tr><td colspan="3" class="px-4 py-8 text-center text-gray-500">Bu ay henüz YZ kullanımı yok</td></tr>
                                <?php else: ?>
                                <?php foreach ($aiUsage as $u): 
                                    $uData = $registeredUsers[$u['user_id']] ?? null;
                                    $isPremUser = Store::isPremium($u['user_id']);
                                ?>
                                <tr class="hover:bg-white/[0.02] transition-colors">
                                    <td class="px-4 py-3">
                                        <div class="flex items-center gap-2">
                                            <span class="font-semibold text-white text-xs sm:text-sm">
                                                <?= e($uData['username'] ?? 'Kullanıcı') ?>
                                            </span>
                                            <?php if ($isPremUser): ?>
                                                <span class="px-1.5 py-0.5 rounded-full text-[10px]" style="background:rgba(191,0,255,0.1);color:#bf00ff;border:1px solid rgba(191,0,255,0.2);">VIP</span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="font-mono text-[10px] text-gray-500 truncate"><?= substr($u['user_id'], 0, 18) ?>…</p>
                                    </td>
                                    <td class="px-4 py-3 text-center text-white font-bold"><?= (int)$u['used'] ?></td>
                                    <td class="px-4 py-3 text-center text-gray-400"><?= $isPremUser ? AI_PREMIUM_MONTHLY_LIMIT : AI_FREE_MONTHLY_LIMIT ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </main>
</div>

<script>
function pickUser(uid) {
    if (uid) {
        document.getElementById('input-user-id').value = uid;
    }
}

function selectAndScroll(uid) {
    document.getElementById('input-user-id').value = uid;
    const dd = document.getElementById('user-select-dropdown');
    if (dd) dd.value = uid;
    const formSection = document.getElementById('premium-form-section');
    if (formSection) {
        formSection.scrollIntoView({ behavior: 'smooth' });
        formSection.classList.add('ring-2', 'ring-cyan-400');
        setTimeout(() => formSection.classList.remove('ring-2', 'ring-cyan-400'), 1500);
    }
}

function setQuickDate(days) {
    const d = new Date();
    d.setDate(d.getDate() + days);
    // YYYY-MM-DDTHH:mm
    const iso = d.toISOString().slice(0, 16);
    document.getElementById('input-premium-until').value = iso;
}
</script>
</body>
</html>
