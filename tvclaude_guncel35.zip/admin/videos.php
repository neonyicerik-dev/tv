<?php
// ============================================================
// NeonTV - Admin Video Yönetimi (Responsive)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/activity_log.php';
requireAdmin();

$db     = new Supabase();
$page   = max(1, (int)($_GET['page'] ?? 1));
$search = trim($_GET['q'] ?? '');
$filterStatus  = trim($_GET['status'] ?? '');
$filterChannel = trim($_GET['channel_id'] ?? '');
$perPg  = 15;
$offset = ($page - 1) * $perPg;

$channelsRes  = $db->select('channels', 'order=name.asc', true);
$channelsList = $channelsRes['data'] ?? [];
$catsList     = $db->select('categories', 'order=name.asc&select=id,name', true)['data'] ?? [];
// Süresi belirlenmemiş videolar (otomatik süre butonu için)
$noDur = $db->select('videos', 'or=(duration.is.null,duration.eq.0)&select=id,title,video_url&limit=500', true)['data'] ?? [];

$where = [];
if ($search) $where[] = 'title=ilike.*' . urlencode($search) . '*';
if ($filterStatus) $where[] = 'status=eq.' . urlencode($filterStatus);
if ($filterChannel) $where[] = 'channel_id=eq.' . urlencode($filterChannel);

$whereStr = $where ? implode('&', $where) . '&' : '';
$q = $whereStr . 'order=created_at.desc&limit=' . $perPg . '&offset=' . $offset;

$videosRes  = $db->select('videos', $q, true);
$videos     = $videosRes['data'] ?? [];
$cntRes     = $db->select('videos', $whereStr . 'select=id', true);
$total      = count($cntRes['data'] ?? []);
$totalPages = max(1, (int)ceil($total / $perPg));
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Videolar | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        .table-row { transition: background 0.15s; }
        .table-row:hover { background: rgba(255,255,255,0.03); }
        .table-row.selected { background: rgba(0,245,255,0.04); }
        .bulk-toolbar { transition: all 0.3s; }
        .video-cb:checked + label, .video-cb:checked ~ * { /* handled via JS */ }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- TOP BAR -->
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <!-- Hamburger -->
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors"
                    style="background:rgba(255,255,255,0.06);">
                <i class="fa-solid fa-bars text-sm"></i>
            </button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white">Video Yonetimi</h1>
                <p class="text-xs text-gray-500"><?= $total ?> video</p>
            </div>
        </div>
        <a href="<?= APP_URL ?>/admin/upload.php"
           class="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-5 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-black"
           style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
            <i class="fa-solid fa-plus text-xs"></i>
            <span class="hidden sm:inline">Yeni Video</span>
            <span class="sm:hidden">Yeni</span>
        </a>
    </header>

    <main class="flex-1 p-4 sm:p-6 overflow-auto">

        <?php if ($noDur): ?>
        <div class="mb-4 px-4 py-3 rounded-2xl flex items-center gap-3 flex-wrap" style="background:rgba(255,215,106,0.07);border:1px solid rgba(255,215,106,0.25);">
            <i class="fa-solid fa-hourglass-half" style="color:#ffd76a"></i>
            <span class="text-sm text-gray-200"><b id="nodur-count"><?= count($noDur) ?></b> videonun süresi belirlenmemiş.</span>
            <button id="nodur-btn" onclick="autoDurations()" class="px-4 py-2 rounded-xl text-sm font-semibold text-black" style="background:#ffd76a;">
                <i class="fa-solid fa-wand-magic-sparkles mr-1"></i>Süreleri Otomatik Ayarla
            </button>
            <span id="nodur-status" class="text-xs text-gray-400"></span>
        </div>
        <?php endif; ?>

        <!-- Arama ve Filtreler -->
        <form method="GET" class="mb-4 sm:mb-5 flex flex-wrap gap-2">
            <div class="relative flex-1 min-w-[200px] max-w-sm">
                <input type="text" name="q" value="<?= e($search) ?>"
                       placeholder="Video basligi ara..."
                       class="w-full pl-9 pr-4 py-2.5 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all"
                       style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                       onfocus="this.style.borderColor='rgba(0,245,255,0.4)'"
                       onblur="this.style.borderColor='rgba(255,255,255,0.1)'">
                <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-600 text-xs"></i>
            </div>
            
            <select name="status" class="px-3 py-2.5 rounded-xl text-sm text-white outline-none appearance-none" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                <option value="" style="background:#13131f;">Tüm Durumlar</option>
                <option value="published" <?= $filterStatus === 'published' ? 'selected' : '' ?> style="background:#13131f;">Yayında</option>
                <option value="draft" <?= $filterStatus === 'draft' ? 'selected' : '' ?> style="background:#13131f;">Taslak</option>
                <option value="scheduled" <?= $filterStatus === 'scheduled' ? 'selected' : '' ?> style="background:#13131f;">Zamanlandı</option>
            </select>

            <select name="channel_id" class="px-3 py-2.5 rounded-xl text-sm text-white outline-none appearance-none max-w-[150px] truncate" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                <option value="" style="background:#13131f;">Tüm Kanallar</option>
                <?php foreach($channelsList as $ch): ?>
                <option value="<?= e($ch['id']) ?>" <?= $filterChannel === $ch['id'] ? 'selected' : '' ?> style="background:#13131f;">
                    <?= e($ch['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="px-3 sm:px-4 py-2.5 rounded-xl text-sm font-medium text-gray-300 hover:text-white transition-colors"
                    style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                <i class="fa-solid fa-search sm:hidden"></i>
                <span class="hidden sm:inline">Ara</span>
            </button>
            <?php if ($search || $filterStatus || $filterChannel): ?>
            <a href="<?= APP_URL ?>/admin/videos.php"
               class="px-3 py-2.5 rounded-xl text-sm text-gray-500 hover:text-white transition-colors"
               style="background:rgba(255,255,255,0.04);">
                <i class="fa-solid fa-xmark"></i> Temizle
            </a>
            <?php endif; ?>
        </form>

        <!-- ===== TOPLU İŞLEM TOOLBAR ===== -->
        <div id="bulk-toolbar" class="hidden bulk-toolbar mb-4 px-4 py-3 rounded-2xl flex items-center gap-3 flex-wrap"
             style="background:rgba(0,245,255,0.05);border:1px solid rgba(0,245,255,0.2);">
            <span id="bulk-count" class="text-sm font-bold text-cyan-400">0 seçili</span>
            <div class="flex gap-2 flex-wrap">
                <button onclick="openBulkEditModal()"
                        class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-black"
                        style="background:linear-gradient(135deg,#00f5ff,#00c8d4);">
                    <i class="fa-solid fa-pen-to-square"></i> Toplu Düzenle
                </button>
                <button onclick="bulkAction('published')"
                        class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-black"
                        style="background:rgba(255,255,255,0.8);">
                    <i class="fa-solid fa-circle-check"></i> Yayınla
                </button>
                <button onclick="bulkAction('draft')"
                        class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold"
                        style="background:rgba(255,255,255,0.1);color:#d1d5db;">
                    <i class="fa-solid fa-eye-slash"></i> Taslak Yap
                </button>
                <button onclick="bulkAIGenerate()"
                        class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-purple-400"
                        style="background:rgba(191,0,255,0.1);border:1px solid rgba(191,0,255,0.2);">
                    <i class="fa-solid fa-wand-magic-sparkles"></i> Toplu AI Başlık Üret
                </button>
                <button onclick="bulkDelete()"
                        class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-red-400"
                        style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);">
                    <i class="fa-solid fa-trash-can"></i> Seçilenleri Sil
                </button>
            </div>
            <button onclick="clearSelection()" class="ml-auto text-gray-600 hover:text-white transition-colors">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <!-- Video Listesi -->
        <?php if (empty($videos)): ?>
        <div class="rounded-2xl py-16 text-center text-gray-600"
             style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
            <i class="fa-solid fa-film text-3xl mb-3 block opacity-30"></i>
            <?= $search ? '"' . e($search) . '" icin video bulunamadi' : 'Henuz video yok' ?>
        </div>

        <?php else: ?>

        <!-- MOBİL KART GÖRÜNÜMÜ (sm altı) -->
        <div class="space-y-3 sm:hidden">
            <?php foreach ($videos as $v): ?>
            <?php
                $statusStyle = match($v['status'] ?? 'draft') {
                    'published' => 'background:rgba(0,245,255,0.1);color:#00f5ff;border:1px solid rgba(0,245,255,0.2);',
                    'scheduled' => 'background:rgba(251,191,36,0.1);color:#fbbf24;border:1px solid rgba(251,191,36,0.2);',
                    default     => 'background:rgba(255,255,255,0.06);color:#6b7280;border:1px solid rgba(255,255,255,0.1);'
                };
                $statusLabel = match($v['status'] ?? 'draft') {
                    'published' => 'Yayında',
                    'scheduled' => '⏰ Zamanlandı',
                    default     => 'Taslak'
                };
            ?>
            <div id="video-row-<?= e($v['id']) ?>" class="rounded-2xl p-4 transition-all"
                 style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                <div class="flex gap-3">
                    <!-- Checkbox -->
                    <div class="flex-shrink-0 flex items-start pt-1">
                        <input type="checkbox" class="video-cb w-4 h-4 rounded accent-cyan-400 cursor-pointer"
                               data-id="<?= e($v['id']) ?>" onchange="onCheckboxChange()">
                    </div>
                    <!-- Thumbnail -->
                    <div class="w-24 rounded-xl overflow-hidden flex-shrink-0" style="aspect-ratio:16/9;background:#0d0d1a;">
                        <img src="<?= e($v['thumbnail_url'] ?? 'https://placehold.co/160x90/070711/00f5ff?text=N') ?>"
                             class="w-full h-full object-cover" loading="lazy">
                    </div>
                    <!-- Bilgiler -->
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-semibold text-white truncate"><?= e($v['title']) ?></p>
                        <div class="flex items-center gap-3 text-xs text-gray-600 mt-1">
                            <span><i class="fa-solid fa-eye mr-1"></i><?= formatNumber((int)($v['views'] ?? 0)) ?></span>
                            <span><i class="fa-solid fa-heart mr-1"></i><?= formatNumber((int)($v['likes_count'] ?? 0)) ?></span>
                        </div>
                        <div class="flex items-center gap-2 mt-2">
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium"
                                  style="<?= $statusStyle ?>">
                                <i class="fa-solid fa-circle text-[6px]"></i>
                                <?= $statusLabel ?>
                            </span>
                            <?php if ($v['status'] === 'scheduled' && !empty($v['scheduled_at'])): ?>
                            <span class="text-[10px] text-yellow-600"><?= date('d.m.Y H:i', strtotime($v['scheduled_at'])) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="flex flex-wrap gap-2 mt-3 pt-3" style="border-top:1px solid rgba(255,255,255,0.06);">
                    <button onclick="openThumbnailPicker('<?= e($v['id']) ?>', '<?= e($v['cloudinary_public_id'] ?? '') ?>', '<?= e($v['video_url'] ?? '') ?>')"
                            class="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs text-gray-400 hover:text-cyan-400 transition-colors"
                            style="background:rgba(255,255,255,0.04);" title="Thumbnail Seç">
                        <i class="fa-solid fa-image"></i>
                    </button>
                    <button onclick="generateAiContent('<?= e($v['id']) ?>', '<?= e($v['cloudinary_public_id'] ?? '') ?>', '<?= e(addslashes($v['video_url'] ?? '')) ?>', this)"
                            class="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs text-gray-400 hover:text-purple-400 transition-colors"
                            style="background:rgba(255,255,255,0.04);" title="AI İçerik Oluştur">
                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                        <span>AI</span>
                    </button>
                    <button onclick="generateSubtitle('<?= e($v['id']) ?>', '<?= e(addslashes($v['video_url'] ?? '')) ?>', this)"
                            class="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs text-gray-400 hover:text-yellow-400 transition-colors"
                            style="background:rgba(255,255,255,0.04);">
                        <i class="fa-solid fa-closed-captioning"></i>
                        <span>Alt</span>
                    </button>
                    <button onclick="openChangeVideoModal('<?= e($v['id']) ?>', '<?= e(addslashes($v['video_url'] ?? '')) ?>')"
                            class="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs text-gray-400 hover:text-orange-400 transition-colors"
                            style="background:rgba(255,255,255,0.04);">
                        <i class="fa-solid fa-link"></i>
                    </button>
                    <button onclick="duplicateVideo('<?= e($v['id']) ?>', '<?= e(addslashes($v['title'])) ?>')"
                            class="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs text-gray-400 hover:text-green-400 transition-colors"
                            style="background:rgba(255,255,255,0.04);" title="Kopyala">
                        <i class="fa-solid fa-copy"></i>
                    </button>
                    <a href="<?= APP_URL ?>/admin/upload.php?edit=<?= e($v['id']) ?>"
                       class="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs text-gray-400 hover:text-cyan-400 transition-colors"
                       style="background:rgba(255,255,255,0.04);">
                        <i class="fa-solid fa-pen"></i>
                    </a>
                    <button onclick="deleteVideo('<?= e($v['id']) ?>', '<?= e(addslashes($v['title'])) ?>')"
                            class="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs text-gray-400 hover:text-red-400 transition-colors"
                            style="background:rgba(255,255,255,0.04);">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- MASAÜSTÜ TABLO GÖRÜNÜMÜ (sm ve üzeri) -->
        <div class="hidden sm:block rounded-2xl overflow-hidden" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
            <div class="overflow-x-auto">
                <table class="w-full min-w-[700px]">
                    <thead>
                        <tr style="border-bottom:1px solid rgba(255,255,255,0.06);">
                            <th class="px-4 py-3">
                                <input type="checkbox" id="select-all" class="w-4 h-4 rounded accent-cyan-400 cursor-pointer"
                                       onchange="toggleSelectAll(this)">
                            </th>
                            <th class="text-left px-4 sm:px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Video</th>
                            <th class="text-center px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider hidden md:table-cell">Izlenme</th>
                            <th class="text-center px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider hidden lg:table-cell">Begeni</th>
                            <th class="text-center px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Durum</th>
                            <th class="text-center px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider hidden lg:table-cell">Tarih</th>
                            <th class="text-right px-4 sm:px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Islemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($videos as $v): ?>
                        <?php
                            $statusStyle = match($v['status'] ?? 'draft') {
                                'published' => 'background:rgba(0,245,255,0.1);color:#00f5ff;border:1px solid rgba(0,245,255,0.2);',
                                'scheduled' => 'background:rgba(251,191,36,0.1);color:#fbbf24;border:1px solid rgba(251,191,36,0.2);',
                                default     => 'background:rgba(255,255,255,0.06);color:#6b7280;border:1px solid rgba(255,255,255,0.1);'
                            };
                            $statusLabel = match($v['status'] ?? 'draft') {
                                'published' => 'Yayında',
                                'scheduled' => '⏰ Zamanlandı',
                                default     => 'Taslak'
                            };
                        ?>
                        <tr class="table-row" id="video-row-<?= e($v['id']) ?>">
                            <td class="px-4 py-4 text-center">
                                <input type="checkbox" class="video-cb w-4 h-4 rounded accent-cyan-400 cursor-pointer"
                                       data-id="<?= e($v['id']) ?>" onchange="onCheckboxChange()">
                            </td>
                            <td class="px-4 sm:px-5 py-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-16 sm:w-20 rounded-lg overflow-hidden flex-shrink-0"
                                         style="aspect-ratio:16/9;background:#0d0d1a;">
                                        <img src="<?= e($v['thumbnail_url'] ?? 'https://placehold.co/160x90/070711/00f5ff?text=N') ?>"
                                             class="w-full h-full object-cover" loading="lazy">
                                    </div>
                                    <div class="min-w-0">
                                        <p class="text-sm font-medium text-white truncate max-w-[160px] sm:max-w-xs"><?= e($v['title']) ?></p>
                                        <?php if ($v['status'] === 'scheduled' && !empty($v['scheduled_at'])): ?>
                                        <p class="text-[10px] text-yellow-600 mt-0.5"><?= date('d.m.Y H:i', strtotime($v['scheduled_at'])) ?>'de yayınlanacak</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="px-4 py-4 text-center text-sm text-gray-400 hidden md:table-cell">
                                <span class="flex items-center justify-center gap-1">
                                    <i class="fa-solid fa-eye text-[10px] text-gray-600"></i>
                                    <?= formatNumber((int)($v['views'] ?? 0)) ?>
                                </span>
                            </td>
                            <td class="px-4 py-4 text-center text-sm text-gray-400 hidden lg:table-cell">
                                <span class="flex items-center justify-center gap-1">
                                    <i class="fa-solid fa-heart text-[10px] text-pink-600"></i>
                                    <?= formatNumber((int)($v['likes_count'] ?? 0)) ?>
                                </span>
                            </td>
                            <td class="px-4 py-4 text-center">
                                <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium"
                                      style="<?= $statusStyle ?>">
                                    <i class="fa-solid fa-circle text-[6px]"></i>
                                    <?= $statusLabel ?>
                                </span>
                            </td>
                            <td class="px-4 py-4 text-center text-xs text-gray-600 hidden lg:table-cell">
                                <?= date('d.m.Y', strtotime($v['created_at'])) ?>
                            </td>
                            <td class="px-4 sm:px-5 py-4">
                                <div class="flex items-center justify-end gap-1">
                                    <button onclick="openThumbnailPicker('<?= e($v['id']) ?>', '<?= e($v['cloudinary_public_id'] ?? '') ?>', '<?= e(addslashes($v['video_url'] ?? '')) ?>')"
                                            class="p-2 rounded-lg transition-colors text-gray-500 hover:text-cyan-400"
                                            style="background:rgba(255,255,255,0.04);" title="Thumbnail Seç">
                                        <i class="fa-solid fa-image text-xs"></i>
                                    </button>
                                    <button onclick="generateAiContent('<?= e($v['id']) ?>', '<?= e($v['cloudinary_public_id'] ?? '') ?>', '<?= e(addslashes($v['video_url'] ?? '')) ?>', this)"
                                            class="p-2 rounded-lg transition-colors text-gray-500 hover:text-purple-400"
                                            style="background:rgba(255,255,255,0.04);" title="AI İçerik Oluştur">
                                        <i class="fa-solid fa-wand-magic-sparkles text-xs"></i>
                                    </button>
                                    <button onclick="generateSubtitle('<?= e($v['id']) ?>', '<?= e(addslashes($v['video_url'] ?? '')) ?>', this)"
                                            class="p-2 rounded-lg transition-colors text-gray-500 hover:text-yellow-400"
                                            style="background:rgba(255,255,255,0.04);" title="Altyazi">
                                        <i class="fa-solid fa-closed-captioning text-xs"></i>
                                    </button>
                                    <button onclick="openChangeVideoModal('<?= e($v['id']) ?>', '<?= e(addslashes($v['video_url'] ?? '')) ?>')"
                                            class="p-2 rounded-lg transition-colors text-gray-500 hover:text-orange-400"
                                            style="background:rgba(255,255,255,0.04);" title="Video URL Degistir">
                                        <i class="fa-solid fa-link text-xs"></i>
                                    </button>
                                    <button onclick="duplicateVideo('<?= e($v['id']) ?>', '<?= e(addslashes($v['title'])) ?>')"
                                            class="p-2 rounded-lg transition-colors text-gray-500 hover:text-green-400"
                                            style="background:rgba(255,255,255,0.04);" title="Videoyu Kopyala">
                                        <i class="fa-solid fa-copy text-xs"></i>
                                    </button>
                                    <a href="<?= APP_URL ?>/video.php?id=<?= e($v['id']) ?>" target="_blank"
                                       class="p-2 rounded-lg transition-colors text-gray-500 hover:text-white"
                                       style="background:rgba(255,255,255,0.04);">
                                        <i class="fa-solid fa-eye text-xs"></i>
                                    </a>
                                    <a href="<?= APP_URL ?>/admin/upload.php?edit=<?= e($v['id']) ?>"
                                       class="p-2 rounded-lg transition-colors text-gray-500 hover:text-cyan-400"
                                       style="background:rgba(255,255,255,0.04);">
                                        <i class="fa-solid fa-pen text-xs"></i>
                                    </a>
                                    <button onclick="deleteVideo('<?= e($v['id']) ?>', '<?= e(addslashes($v['title'])) ?>')"
                                            class="p-2 rounded-lg transition-colors text-gray-500 hover:text-red-400"
                                            style="background:rgba(255,255,255,0.04);">
                                        <i class="fa-solid fa-trash-can text-xs"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="flex items-center justify-center gap-2 mt-5 sm:mt-6">
            <?php if ($page > 1): ?>
            <a href="?q=<?= urlencode($search) ?>&page=<?= $page - 1 ?>"
               class="px-3 sm:px-4 py-2 rounded-xl text-sm text-gray-400 hover:text-white transition-colors"
               style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                <i class="fa-solid fa-chevron-left text-xs mr-1"></i><span class="hidden sm:inline">Onceki</span>
            </a>
            <?php endif; ?>
            <span class="text-sm text-gray-500"><?= $page ?> / <?= $totalPages ?></span>
            <?php if ($page < $totalPages): ?>
            <a href="?q=<?= urlencode($search) ?>&page=<?= $page + 1 ?>"
               class="px-3 sm:px-4 py-2 rounded-xl text-sm text-gray-400 hover:text-white transition-colors"
               style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                <span class="hidden sm:inline">Sonraki</span><i class="fa-solid fa-chevron-right text-xs ml-1"></i>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </main>
</div>

<!-- ===== Video URL Değiştir Modal ===== -->
<div id="change-video-modal" class="fixed inset-0 z-50 hidden items-center justify-center px-4"
     style="background:rgba(0,0,0,0.85);backdrop-filter:blur(6px);">
    <div class="w-full max-w-lg rounded-2xl p-5 sm:p-6" style="background:#13131f;border:1px solid rgba(255,165,0,0.25);box-shadow:0 0 40px rgba(255,165,0,0.08);">
        <!-- Başlık -->
        <div class="flex items-center gap-3 mb-5">
            <div class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style="background:rgba(255,165,0,0.12);">
                <i class="fa-solid fa-link" style="color:#f97316;"></i>
            </div>
            <div>
                <h3 class="text-base font-bold text-white">Video URL Değiştir</h3>
                <p class="text-xs text-gray-500">Cloudinary MP4 veya harici link</p>
            </div>
            <button onclick="closeChangeVideoModal()" class="ml-auto p-1.5 rounded-lg text-gray-600 hover:text-white transition-colors" style="background:rgba(255,255,255,0.04);">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <!-- Mevcut URL bilgisi -->
        <div id="cvm-current-wrap" class="mb-4 p-3 rounded-xl text-xs" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);">
            <p class="text-gray-500 mb-1">Mevcut URL:</p>
            <p id="cvm-current-url" class="text-gray-400 break-all font-mono"></p>
        </div>

        <!-- Yeni URL input -->
        <div class="mb-3">
            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                <i class="fa-solid fa-film mr-1"></i>Yeni MP4 / Video URL
            </label>
            <input type="url" id="cvm-new-url"
                   placeholder="https://res.cloudinary.com/.../video.mp4"
                   class="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all"
                   style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,165,0,0.3);"
                   onfocus="this.style.borderColor='rgba(249,115,22,0.6)';this.style.boxShadow='0 0 0 3px rgba(249,115,22,0.1)'"
                   onblur="this.style.borderColor='rgba(255,165,0,0.3)';this.style.boxShadow='none'">
        </div>

        <!-- Cloudinary Public ID (opsiyonel) -->
        <div class="mb-5">
            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                <i class="fa-solid fa-cloud mr-1"></i>Cloudinary Public ID <span class="text-gray-600 normal-case font-normal">(opsiyonel)</span>
            </label>
            <input type="text" id="cvm-public-id"
                   placeholder="neontv/videos/ornek_id"
                   class="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all"
                   style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                   onfocus="this.style.borderColor='rgba(0,245,255,0.4)'"
                   onblur="this.style.borderColor='rgba(255,255,255,0.1)'">
            <p class="text-xs text-gray-700 mt-1.5">Yalnızca Cloudinary videoları için gereklidir. Altyazı, AI gibi araçlar bu ID'ye ihtiyaç duyar.</p>
        </div>

        <!-- Durum mesajı -->
        <div id="cvm-status" class="hidden mb-3 px-3 py-2 rounded-lg text-xs"></div>

        <!-- Butonlar -->
        <div class="flex gap-2">
            <button type="button" onclick="saveChangeVideo()"
                    id="cvm-save-btn"
                    class="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold text-black transition-all hover:scale-[1.02]"
                    style="background:linear-gradient(135deg,#f97316,#fbbf24);">
                <i class="fa-solid fa-floppy-disk"></i>
                Kaydet
            </button>
            <button type="button" onclick="closeChangeVideoModal()"
                    class="px-5 py-3 rounded-xl text-sm text-gray-400 hover:text-white transition-colors"
                    style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.08);">
                İptal
            </button>
        </div>
    </div>
</div>

<!-- ===== Thumbnail Seçici Modal ===== -->
<div id="thumb-picker-modal" class="fixed inset-0 z-50 hidden items-center justify-center px-4"
     style="background:rgba(0,0,0,0.88);backdrop-filter:blur(8px);">
    <div class="w-full max-w-2xl rounded-2xl p-5 sm:p-6" style="background:#13131f;border:1px solid rgba(0,245,255,0.2);box-shadow:0 0 60px rgba(0,245,255,0.06);">
        <!-- Başlık -->
        <div class="flex items-center gap-3 mb-5">
            <div class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style="background:rgba(0,245,255,0.1);">
                <i class="fa-solid fa-image" style="color:#00f5ff;"></i>
            </div>
            <div>
                <h3 class="text-base font-bold text-white">Thumbnail Seç</h3>
                <p class="text-xs text-gray-500">Videodan istediğiniz kareyi thumbnail olarak ayarlayın</p>
            </div>
            <button onclick="closeThumbPicker()" class="ml-auto p-1.5 rounded-lg text-gray-600 hover:text-white transition-colors" style="background:rgba(255,255,255,0.04);">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <!-- Video Önizleme -->
        <div class="relative rounded-xl overflow-hidden mb-4" style="aspect-ratio:16/9;background:#0d0d1a;">
            <video id="thumb-video" class="w-full h-full object-contain" preload="metadata" crossorigin="anonymous" muted></video>
            <!-- Mevcut thumbnail overlay -->
            <div id="thumb-no-video" class="absolute inset-0 flex flex-col items-center justify-center text-gray-600">
                <i class="fa-solid fa-film text-3xl mb-2 opacity-30"></i>
                <p class="text-xs">Video yükleniyor...</p>
            </div>
            <!-- Anlık kare önizleme canvas -->
            <canvas id="thumb-canvas" class="hidden"></canvas>
        </div>

        <!-- Süre Slider -->
        <div class="mb-4">
            <div class="flex items-center justify-between mb-2">
                <label class="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    <i class="fa-solid fa-clock mr-1"></i>Kare Konumu
                </label>
                <span id="thumb-time-label" class="text-xs font-mono text-cyan-400">0:00</span>
            </div>
            <input type="range" id="thumb-seek" min="0" max="100" step="0.1" value="0"
                   class="w-full h-2 rounded-full cursor-pointer"
                   style="-webkit-appearance:none;appearance:none;background:rgba(255,255,255,0.1);outline:none;"
                   oninput="seekThumbVideo(this.value)">
            <style>
                #thumb-seek::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;background:linear-gradient(135deg,#00f5ff,#bf00ff);cursor:pointer;box-shadow:0 0 8px rgba(0,245,255,0.5);}
            </style>
        </div>

        <!-- Önizleme Thumbnail -->
        <div id="thumb-preview-wrap" class="hidden mb-4">
            <p class="text-xs text-gray-500 mb-2"><i class="fa-solid fa-eye mr-1"></i>Seçilen Kare Önizlemesi:</p>
            <img id="thumb-preview-img" src="" alt="Önizleme" class="w-full rounded-xl object-cover" style="max-height:200px;">
        </div>

        <!-- Durum mesajı -->
        <div id="thumb-status" class="hidden mb-3 px-3 py-2 rounded-lg text-xs"></div>

        <!-- Butonlar -->
        <div class="flex gap-2">
            <button type="button" onclick="captureThumbFrame()"
                    id="thumb-capture-btn"
                    class="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white transition-all hover:scale-[1.02]"
                    style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.1);">
                <i class="fa-solid fa-camera"></i> Kareyi Önizle
            </button>
            <button type="button" onclick="saveThumbFrame()"
                    id="thumb-save-btn"
                    class="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold text-black transition-all hover:scale-[1.02]"
                    style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                <i class="fa-solid fa-floppy-disk"></i> Thumbnail Olarak Kaydet
            </button>
            <button type="button" onclick="closeThumbPicker()"
                    class="px-4 py-2.5 rounded-xl text-sm text-gray-400 hover:text-white transition-colors"
                    style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.08);">
                İptal
            </button>
        </div>
    </div>
</div>

<!-- ===== Toplu Düzenleme Modal ===== -->
<div id="bulk-edit-modal" class="fixed inset-0 z-50 hidden items-center justify-center px-4"
     style="background:rgba(0,0,0,0.8);backdrop-filter:blur(4px);">
    <div class="w-full max-w-md rounded-2xl p-6" style="background:#13131f;border:1px solid rgba(0,245,255,0.2);">
        <h3 class="text-lg font-bold text-white mb-2 flex items-center gap-2">
            <i class="fa-solid fa-pen-to-square text-cyan-400"></i>
            Toplu Video Düzenle
        </h3>
        <p id="bulk-edit-info" class="text-xs text-gray-400 mb-4">0 video seçildi.</p>

        <div class="mb-4">
            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase">Durum</label>
            <select id="bulk-status" class="w-full px-3 py-2.5 rounded-xl text-sm text-white outline-none appearance-none" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                <option value="" style="background:#13131f;">(Değiştirme)</option>
                <option value="published" style="background:#13131f;">Yayında</option>
                <option value="draft" style="background:#13131f;">Taslak</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase">Kanal</label>
            <select id="bulk-channel" class="w-full px-3 py-2.5 rounded-xl text-sm text-white outline-none appearance-none" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                <option value="" style="background:#13131f;">(Değiştirme)</option>
                <?php foreach($channelsList as $ch): ?>
                <option value="<?= e($ch['id']) ?>" style="background:#13131f;"><?= e($ch['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-4">
            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase">Kategori Ekle</label>
            <select id="bulk-category" class="w-full px-3 py-2.5 rounded-xl text-sm text-white outline-none appearance-none" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                <option value="" style="background:#13131f;">(Değiştirme)</option>
                <?php foreach($catsList as $ct): ?><option value="<?= e($ct['id']) ?>" style="background:#13131f;"><?= e($ct['name']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="mb-4">
            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase">Premium Erken Erişim (bu tarihe kadar)</label>
            <input type="datetime-local" id="bulk-early" class="w-full px-3 py-2.5 rounded-xl text-sm text-white outline-none" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
            <label class="flex items-center gap-2 text-xs text-gray-400 mt-1.5"><input type="checkbox" id="bulk-early-clear" class="accent-cyan-400"> Erken erişimi kaldır</label>
        </div>

        <div class="mb-5">
            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase">Etiketler Ekle (Virgülle ayırın)</label>
            <input type="text" id="bulk-tags" placeholder="aksiyon, komedi, yeni..." class="w-full px-3 py-2.5 rounded-xl text-sm text-white placeholder-gray-600 outline-none" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
            <p class="text-[10px] text-gray-500 mt-1">Sadece yazdığınız etiketler eklenecek, diğerleri silinecektir. Boş bırakırsanız değişmez.</p>
        </div>

        <div class="flex gap-2">
            <button onclick="closeBulkEditModal()" class="flex-1 py-2.5 rounded-xl text-sm text-gray-500 hover:text-white transition-colors" style="background:rgba(255,255,255,0.06);">İptal</button>
            <button onclick="saveBulkEdit()" id="bulk-save-btn" class="flex-1 py-2.5 rounded-xl text-sm font-semibold text-black transition-all hover:opacity-90" style="background:linear-gradient(135deg,#00f5ff,#00c8d4);">Kaydet</button>
        </div>
    </div>
</div>

<!-- ===== Altyazı Yöneticisi Modal ===== -->
<div id="subtitle-modal" class="fixed inset-0 z-50 hidden items-center justify-center px-4"
     style="background:rgba(0,0,0,0.8);backdrop-filter:blur(4px);">
    <div class="w-full max-w-2xl rounded-2xl p-6 flex flex-col max-h-[90vh]" style="background:#13131f;border:1px solid rgba(255,255,255,0.1);">
        
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-bold text-white flex items-center gap-2">
                <i class="fa-solid fa-closed-captioning text-yellow-400"></i>
                Altyazı Yöneticisi
            </h3>
            <button onclick="closeSubtitleModal()" class="p-1.5 rounded-lg text-gray-600 hover:text-white transition-colors" style="background:rgba(255,255,255,0.04);">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <!-- Yükleniyor Durumu -->
        <div id="subtitle-loading" class="py-8 flex flex-col items-center justify-center">
            <i class="fa-solid fa-spinner fa-spin text-3xl text-cyan-400 mb-3"></i>
            <p class="text-sm text-gray-400">Altyazı bilgileri alınıyor...</p>
        </div>

        <!-- Mevcut Altyazı Editörü -->
        <div id="subtitle-editor-section" class="hidden flex-1 flex flex-col min-h-0">
            <p class="text-xs text-gray-400 mb-2">Videoya ait VTT altyazı içeriğini aşağıdan düzenleyebilirsiniz.</p>
            <textarea id="subtitle-editor-content" class="flex-1 w-full p-3 rounded-xl text-xs font-mono text-gray-300 outline-none resize-none mb-3" style="background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.1);min-height:200px;" spellcheck="false"></textarea>
            <div class="flex gap-2">
                <button onclick="saveSubtitleContent()" id="subtitle-save-btn" class="flex-1 py-2.5 rounded-xl text-sm font-semibold text-black transition-all hover:opacity-90" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                    <i class="fa-solid fa-floppy-disk mr-1"></i>Değişiklikleri Kaydet
                </button>
                <button onclick="showSubtitleGenerateSection()" class="px-4 py-2.5 rounded-xl text-sm text-yellow-400 hover:bg-yellow-400 hover:text-black transition-colors" style="border:1px solid rgba(255,215,0,0.3);" title="Yeniden AI ile Oluştur">
                    <i class="fa-solid fa-wand-magic-sparkles"></i>
                </button>
            </div>
        </div>

        <!-- Faz 1: MP3 URL Giriş Formu (Yeniden Oluşturma) -->
        <div id="subtitle-phase-input" class="hidden">
            <div class="p-4 rounded-xl mb-4" style="background:rgba(255,215,0,0.05);border:1px dashed rgba(255,215,0,0.2);">
                <p class="text-yellow-400 text-sm font-semibold mb-2"><i class="fa-solid fa-wand-magic-sparkles mr-1"></i>AI Altyazı Üret</p>
                <p class="text-gray-400 text-xs mb-3">Bu işlem varsa mevcut altyazının üzerine yazar. Sadece gerekliyse kullanın.</p>
                
                <label class="block text-xs font-semibold text-gray-400 mb-1 uppercase tracking-wide">
                    <i class="fa-solid fa-music mr-1 text-yellow-400"></i>MP3 / Ses URL'si
                </label>
                <input id="subtitle-mp3-url" type="url" placeholder="https://... .mp3 veya boş bırakın" class="w-full rounded-xl px-3 py-2 text-sm text-white placeholder-gray-600 outline-none mb-2" style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);"/>
                <p class="text-[10px] text-gray-500 mb-3">MP3 girilirse çok daha hızlı çalışır.</p>

                <div class="flex gap-2">
                    <button onclick="cancelSubtitleGenerate()" class="flex-1 py-2 rounded-xl text-sm text-gray-500 hover:text-white transition-colors" style="background:rgba(255,255,255,0.06);">Geri Dön</button>
                    <button id="subtitle-start-btn" onclick="startSubtitleGeneration()" class="flex-1 py-2 rounded-xl text-sm font-semibold text-black transition-all hover:opacity-90" style="background:linear-gradient(135deg,#ffd700,#bf00ff);">
                        <i class="fa-solid fa-play mr-1"></i>Üretimi Başlat
                    </button>
                </div>
            </div>
        </div>

        <!-- Faz 2: Progress -->
        <div id="subtitle-phase-progress" class="hidden py-4">
            <p class="text-gray-400 text-sm mb-4 text-center">Bu işlem birkaç dakika sürebilir, lütfen bekleyin.</p>
            <div id="subtitle-status" class="text-sm text-gray-300 mb-3 flex items-center justify-center gap-2">
                <i class="fa-solid fa-spinner fa-spin text-cyan-400"></i>
                <span id="subtitle-status-text">Hazırlanıyor...</span>
            </div>
            <div class="h-1.5 rounded-full overflow-hidden mb-4" style="background:rgba(255,255,255,0.08);">
                <div id="subtitle-progress" class="h-full rounded-full transition-all duration-500" style="background:linear-gradient(90deg,#ffd700,#bf00ff);width:0%;"></div>
            </div>
        </div>

    </div>
</div>

<!-- AI Modal -->
<div id="ai-video-modal" class="fixed inset-0 z-50 hidden items-center justify-center px-4"
     style="background:rgba(0,0,0,0.8);backdrop-filter:blur(4px);">
    <div class="w-full max-w-md rounded-2xl p-5 sm:p-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.1);">
        <h3 class="text-lg font-bold text-white mb-2 flex items-center gap-2">
            <i class="fa-solid fa-wand-magic-sparkles text-purple-400"></i>
            AI Video Analizi
        </h3>
        <p class="text-gray-500 text-sm mb-4">Videonun ilk saniyeleri hem görsel hem de işitsel olarak analiz ediliyor. Lütfen bekleyin.</p>
        <div id="ai-video-status" class="text-sm text-gray-400 mb-4 flex items-center gap-2">
            <i class="fa-solid fa-spinner fa-spin" style="color:#bf00ff;"></i>
            <span id="ai-video-status-text">Video klibi indiriliyor...</span>
        </div>
        <div class="h-1.5 rounded-full overflow-hidden" style="background:rgba(255,255,255,0.08);">
            <div id="ai-video-progress" class="h-full rounded-full transition-all duration-500"
                 style="background:linear-gradient(90deg,#00f5ff,#bf00ff);width:0%;"></div>
        </div>
        <button onclick="closeAiVideoModal()"
                class="mt-4 w-full py-2 rounded-xl text-sm text-gray-500 hover:text-white transition-colors"
                style="background:rgba(255,255,255,0.06);">
            Kapat
        </button>
    </div>
</div>

<script>
const APP_URL_JS = '<?= APP_URL ?>';
let _cvmVideoId = null;

/* ====== BULK SELECT ====== */
function getSelectedIds() {
    return [...document.querySelectorAll('.video-cb:checked')].map(cb => cb.dataset.id);
}
function onCheckboxChange() {
    const ids = getSelectedIds();
    const toolbar = document.getElementById('bulk-toolbar');
    const countEl = document.getElementById('bulk-count');
    if (ids.length > 0) {
        toolbar.classList.remove('hidden');
        countEl.textContent = ids.length + ' seçili';
    } else {
        toolbar.classList.add('hidden');
    }
    // Satır highlight
    document.querySelectorAll('.video-cb').forEach(cb => {
        const row = document.getElementById('video-row-' + cb.dataset.id);
        if (row) row.classList.toggle('selected', cb.checked);
    });
    // Select-all state
    const all = document.getElementById('select-all');
    if (all) {
        const total = document.querySelectorAll('.video-cb').length;
        all.indeterminate = ids.length > 0 && ids.length < total;
        all.checked = ids.length === total;
    }
}
function toggleSelectAll(el) {
    document.querySelectorAll('.video-cb').forEach(cb => { cb.checked = el.checked; });
    onCheckboxChange();
}
function clearSelection() {
    document.querySelectorAll('.video-cb').forEach(cb => { cb.checked = false; });
    const all = document.getElementById('select-all');
    if (all) { all.checked = false; all.indeterminate = false; }
    document.getElementById('bulk-toolbar').classList.add('hidden');
    document.querySelectorAll('.table-row, [id^=video-row-]').forEach(r => r.classList.remove('selected'));
}

async function bulkAction(status) {
    const ids = getSelectedIds();
    if (!ids.length) return;
    const label = status === 'published' ? 'yayınlamak' : 'taslak yapmak';
    if (!confirm(`${ids.length} videoyu ${label} istiyor musunuz?`)) return;
    const res  = await fetch(APP_URL_JS + '/api/videos.php', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bulk_ids: ids, status })
    });
    const data = await res.json();
    if (data.success) { window.location.reload(); }
    else { alert('Hata: ' + (data.message || 'Bilinmeyen')); }
}

async function bulkDelete() {
    const ids = getSelectedIds();
    if (!ids.length) return;
    if (!confirm(`${ids.length} videoyu kalıcı olarak silmek istediğinizden emin misiniz?`)) return;
    const res  = await fetch(APP_URL_JS + '/api/videos.php', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bulk_ids: ids })
    });
    const data = await res.json();
    if (data.success) {
        ids.forEach(id => {
            const row = document.getElementById('video-row-' + id);
            if (row) { row.style.opacity='0'; row.style.transform='translateX(-10px)'; row.style.transition='all 0.3s'; setTimeout(()=>row.remove(),300); }
        });
        clearSelection();
    } else { alert('Hata: ' + (data.message || 'Bilinmeyen')); }
}

/* ====== DUPLICATE ====== */
async function duplicateVideo(id, title) {
    if (!confirm(`"${title}" videosunu kopyalamak istiyor musunuz? Taslak olarak oluşturulur.`)) return;
    try {
        const res = await fetch(APP_URL_JS + '/api/videos.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'duplicate', id })
        }).then(r => r.json());
        if (res.success) {
            alert('✓ Video kopyalandı! Düzenlemek için videos listesini yenileyin.');
            location.reload();
        } else {
            alert('Hata: ' + (res.message || 'Bilinmeyen hata'));
        }
    } catch (e) {
        console.error(e);
        alert('İşlem başarısız.');
    }
}

async function bulkAIGenerate() {
    const ids = getSelectedIds();
    if (!ids.length) return;
    if (!confirm(ids.length + ' video için sırayla AI ile başlık/açıklama üretilecek. Bu işlem zaman alabilir. Emin misiniz?')) return;

    try {
        const res = await fetch(APP_URL_JS + '/api/videos.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ action: 'bulk_ai_title', ids: ids })
        }).then(r => r.json());

        if (res.success) {
            alert('Toplu AI işlemi tamamlandı!');
            location.reload();
        } else {
            alert('Hata: ' + (res.message || 'Bilinmeyen hata'));
        }
    } catch (e) {
        console.error(e);
        alert('İşlem başarısız.');
    }
}

// Tümünü seç
document.getElementById('select-all')?.addEventListener('change', function() {
    toggleSelectAll(this);
});

function openChangeVideoModal(videoId, currentUrl) {
    _cvmVideoId = videoId;
    document.getElementById('cvm-current-url').textContent = currentUrl || '(boş)';
    document.getElementById('cvm-new-url').value = '';
    document.getElementById('cvm-public-id').value = '';
    const s = document.getElementById('cvm-status');
    s.classList.add('hidden'); s.textContent = '';
    const m = document.getElementById('change-video-modal');
    m.classList.remove('hidden'); m.classList.add('flex');
    setTimeout(() => document.getElementById('cvm-new-url').focus(), 100);
}

function closeChangeVideoModal() {
    const m = document.getElementById('change-video-modal');
    m.classList.add('hidden'); m.classList.remove('flex');
    _cvmVideoId = null;
}

async function saveChangeVideo() {
    const newUrl  = document.getElementById('cvm-new-url').value.trim();
    const pubId   = document.getElementById('cvm-public-id').value.trim();
    const saveBtn = document.getElementById('cvm-save-btn');
    const status  = document.getElementById('cvm-status');

    if (!newUrl) {
        status.className = 'mb-3 px-3 py-2 rounded-lg text-xs';
        status.style.cssText = 'background:rgba(239,68,68,0.1);color:#f87171;border:1px solid rgba(239,68,68,0.2);';
        status.textContent = '⚠ Lütfen geçerli bir URL girin.';
        status.classList.remove('hidden');
        return;
    }

    saveBtn.disabled = true;
    saveBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Kaydediliyor...';
    status.classList.add('hidden');

    try {
        const payload = { video_url: newUrl };
        if (pubId) payload.cloudinary_public_id = pubId;

        const res  = await fetch(APP_URL_JS + '/api/videos.php?id=' + _cvmVideoId, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();

        if (data.success) {
            status.style.cssText = 'background:rgba(0,245,255,0.08);color:#00f5ff;border:1px solid rgba(0,245,255,0.2);';
            status.textContent = '✓ Video URL başarıyla güncellendi!';
            status.classList.remove('hidden');
            document.getElementById('cvm-current-url').textContent = newUrl;
            // Mevcut URL göstergesini güncelle
            saveBtn.innerHTML = '<i class="fa-solid fa-check"></i> Kaydedildi';
            setTimeout(() => closeChangeVideoModal(), 1800);
        } else {
            status.style.cssText = 'background:rgba(239,68,68,0.1);color:#f87171;border:1px solid rgba(239,68,68,0.2);';
            status.textContent = 'Hata: ' + (data.message || 'Güncelleme başarısız');
            status.classList.remove('hidden');
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Kaydet';
        }
    } catch(e) {
        status.style.cssText = 'background:rgba(239,68,68,0.1);color:#f87171;border:1px solid rgba(239,68,68,0.2);';
        status.textContent = 'Bağlantı hatası: ' + e.message;
        status.classList.remove('hidden');
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Kaydet';
    }
}

// Modal dışına tıklayınca kapat
document.getElementById('change-video-modal').addEventListener('click', function(e) {
    if (e.target === this) closeChangeVideoModal();
});

function closeSubtitleModal() {
    const m = document.getElementById('subtitle-modal');
    m.classList.add('hidden'); m.classList.remove('flex');
}

function closeAiVideoModal() {
    const m = document.getElementById('ai-video-modal');
    m.classList.add('hidden'); m.classList.remove('flex');
}

async function deleteVideo(id, title) {
    if (!confirm(`"${title}" videosunu silmek istediginizden emin misiniz?`)) return;
    const res  = await fetch(APP_URL_JS + '/api/videos.php?id=' + id, { method: 'DELETE' });
    const data = await res.json();
    if (data.success) {
        const row = document.getElementById('video-row-' + id);
        if (row) {
            row.style.transition = 'all 0.3s';
            row.style.opacity    = '0';
            row.style.transform  = 'translateX(-10px)';
            setTimeout(() => row.remove(), 300);
        }
    } else {
        alert('Silme basarisiz: ' + (data.message || 'Hata'));
    }
}

/* ====== BULK EDIT ====== */
function openBulkEditModal() {
    const ids = getSelectedIds();
    if (!ids.length) return;
    document.getElementById('bulk-edit-info').textContent = ids.length + ' video seçildi. Sadece değiştirmek istediğiniz alanları doldurun.';
    document.getElementById('bulk-status').value = '';
    document.getElementById('bulk-channel').value = '';
    document.getElementById('bulk-tags').value = '';
    const m = document.getElementById('bulk-edit-modal');
    m.classList.remove('hidden'); m.classList.add('flex');
}

function closeBulkEditModal() {
    const m = document.getElementById('bulk-edit-modal');
    m.classList.add('hidden'); m.classList.remove('flex');
}

async function saveBulkEdit() {
    const ids = getSelectedIds();
    if (!ids.length) return;
    
    const statusVal = document.getElementById('bulk-status').value;
    const channelVal = document.getElementById('bulk-channel').value;
    const tagsVal = document.getElementById('bulk-tags').value;

    const payload = { bulk_ids: ids };
    if (statusVal) payload.status = statusVal;
    if (channelVal) payload.channel_id = channelVal;
    const catVal = document.getElementById('bulk-category').value;
    if (catVal) payload.category_id = catVal;
    const earlyVal = document.getElementById('bulk-early').value;
    if (document.getElementById('bulk-early-clear').checked) payload.premium_only_until = null;
    else if (earlyVal) payload.premium_only_until = new Date(earlyVal).toISOString();
    if (tagsVal.trim() !== '') {
        payload.tags = tagsVal.split(',').map(t => t.trim()).filter(t => t.length > 0);
    }

    if (Object.keys(payload).length === 1) {
        alert('Hiçbir değişiklik seçilmedi.');
        return;
    }

    const btn = document.getElementById('bulk-save-btn');
    btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

    try {
        const res = await fetch(APP_URL_JS + '/api/videos.php', {
            method: 'PATCH',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        }).then(r => r.json());
        
        if (res.success) { location.reload(); }
        else { alert('Hata: ' + (res.message || 'Bilinmeyen')); btn.disabled = false; btn.textContent = 'Kaydet'; }
    } catch(e) {
        alert('İşlem başarısız.');
        btn.disabled = false; btn.textContent = 'Kaydet';
    }
}

// Modal dışına tıklayınca kapat (Bulk Edit)
document.getElementById('bulk-edit-modal').addEventListener('click', function(e) {
    if (e.target === this) closeBulkEditModal();
});


/* ====== ALTYAZI YÖNETİCİSİ ====== */
let _subtitleVideoId  = null;
let _subtitleVideoUrl = null;

async function generateSubtitle(videoId, videoUrl, btn) {
    _subtitleVideoId  = videoId;
    _subtitleVideoUrl = videoUrl;
    
    // UI Sıfırla
    document.getElementById('subtitle-loading').classList.remove('hidden');
    document.getElementById('subtitle-editor-section').classList.add('hidden');
    document.getElementById('subtitle-phase-input').classList.add('hidden');
    document.getElementById('subtitle-phase-progress').classList.add('hidden');
    
    // Modalı aç
    const modal = document.getElementById('subtitle-modal');
    modal.classList.remove('hidden'); modal.classList.add('flex');

    // Mevcut altyazıyı kontrol et
    try {
        const res = await fetch(APP_URL_JS + '/api/subtitles.php?video_id=' + videoId);
        const data = await res.json();
        document.getElementById('subtitle-loading').classList.add('hidden');
        
        if (data.success && data.data && data.data.content) {
            // Var, editörü göster
            document.getElementById('subtitle-editor-content').value = data.data.content;
            document.getElementById('subtitle-editor-section').classList.remove('hidden');
            document.getElementById('subtitle-editor-section').classList.add('flex');
        } else {
            // Yok, üretim kısmını göster
            showSubtitleGenerateSection();
        }
    } catch (e) {
        alert('Bağlantı hatası.');
        closeSubtitleModal();
    }
}

function showSubtitleGenerateSection() {
    document.getElementById('subtitle-mp3-url').value = '';
    document.getElementById('subtitle-phase-input').classList.remove('hidden');
}

function cancelSubtitleGenerate() {
    document.getElementById('subtitle-phase-input').classList.add('hidden');
}

async function saveSubtitleContent() {
    const content = document.getElementById('subtitle-editor-content').value.trim();
    if (!content) { alert('İçerik boş olamaz.'); return; }

    const btn = document.getElementById('subtitle-save-btn');
    btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Kaydediliyor...';

    try {
        const res = await fetch(APP_URL_JS + '/api/subtitles.php', {
            method: 'PATCH',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ video_id: _subtitleVideoId, content: content })
        }).then(r => r.json());

        if (res.success) {
            btn.innerHTML = '<i class="fa-solid fa-check"></i> Kaydedildi!';
            setTimeout(() => { 
                btn.disabled = false; 
                btn.innerHTML = '<i class="fa-solid fa-floppy-disk mr-1"></i>Değişiklikleri Kaydet'; 
            }, 2000);
        } else {
            alert('Hata: ' + (res.message || 'Bilinmeyen hata'));
            btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-floppy-disk mr-1"></i>Değişiklikleri Kaydet';
        }
    } catch(e) {
        alert('Kaydetme başarısız: ' + e.message);
        btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-floppy-disk mr-1"></i>Değişiklikleri Kaydet';
    }
}

async function startSubtitleGeneration() {
    const mp3Url   = document.getElementById('subtitle-mp3-url').value.trim();
    const videoUrl = mp3Url || _subtitleVideoUrl;

    if (!videoUrl) { alert('Video URL bulunamadı.'); return; }

    // Faz 2'ye geç (progress)
    document.getElementById('subtitle-editor-section').classList.add('hidden');
    document.getElementById('subtitle-editor-section').classList.remove('flex');
    document.getElementById('subtitle-phase-input').classList.add('hidden');
    document.getElementById('subtitle-phase-progress').classList.remove('hidden');

    const statusText = document.getElementById('subtitle-status-text');
    const statusDiv  = document.getElementById('subtitle-status');
    const progressBar = document.getElementById('subtitle-progress');

    statusText.textContent = mp3Url
        ? 'MP3 ses dosyası Gemini\'ye gönderiliyor...'
        : 'Video analiz ediliyor ve Gemini\'ye yükleniyor...';
    progressBar.style.width = '10%';
    
    statusDiv.style.color = '';
    const icon = statusDiv.querySelector('i');
    if (icon) icon.className = 'fa-solid fa-spinner fa-spin text-cyan-400';

    let prog = 10;
    const progTimer = setInterval(() => {
        prog = Math.min(prog + 2, 80);
        progressBar.style.width = prog + '%';
        if (prog >= 40) statusText.textContent = 'Gemini altyazı üretiyor, lütfen bekleyin...';
    }, 3000);

    try {
        const res = await fetch(APP_URL_JS + '/api/subtitles.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ video_id: _subtitleVideoId, video_url: videoUrl })
        });
        clearInterval(progTimer);
        progressBar.style.width = '100%';
        const data = await res.json();
        
        if (data.success) {
            statusText.textContent = 'Altyazı başarıyla oluşturuldu! Düzenleyiciye geçiliyor...';
            statusDiv.style.color  = '#00f5ff';
            if (icon) icon.className = 'fa-solid fa-circle-check';
            
            setTimeout(() => {
                document.getElementById('subtitle-phase-progress').classList.add('hidden');
                document.getElementById('subtitle-editor-content').value = data.data.vtt || '';
                document.getElementById('subtitle-editor-section').classList.remove('hidden');
                document.getElementById('subtitle-editor-section').classList.add('flex');
            }, 1500);
        } else {
            statusText.textContent = 'Hata: ' + (data.message || 'Altyazı oluşturulamadı');
            statusDiv.style.color  = '#ff007a';
            if (icon) icon.className = 'fa-solid fa-circle-xmark';
        }
    } catch(e) {
        clearInterval(progTimer);
        statusText.textContent = 'Bağlantı hatası: ' + e.message;
        statusDiv.style.color  = '#ff007a';
        if (icon) icon.className = 'fa-solid fa-circle-xmark';
    }
}

async function generateAiContent(videoId, publicId, videoUrl, btn) {
    if (!publicId && !videoUrl) { 
        alert('Bu video için Cloudinary ID veya geçerli bir Video URL bulunamadı.'); 
        return; 
    }
    const modal = document.getElementById('ai-video-modal');
    modal.classList.remove('hidden'); modal.classList.add('flex');
    
    document.getElementById('ai-video-status-text').textContent = 'Videonun kısa bir klibi indiriliyor...';
    document.getElementById('ai-video-progress').style.width = '20%';
    
    try {
        let payload;
        if (publicId) {
            payload = {
                action: 'analyze_video',
                video_id: videoId,
                cloudinary_public_id: publicId
            };
        } else {
            document.getElementById('ai-video-status-text').textContent = 'Video analiz klibi (CloudConvert) hazırlanıyor, bu işlem zaman alabilir...';
            payload = {
                action: 'analyze_video_url',
                video_id: videoId,
                video_url: videoUrl
            };
        }

        const res = await fetch(APP_URL_JS + '/api/ai.php', {
            method: 'POST', 
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify(payload)
        });
        
        document.getElementById('ai-video-progress').style.width = '60%';
        document.getElementById('ai-video-status-text').textContent = 'Yapay Zeka (Gemini 1.5) videoyu izliyor ve dinliyor...';
        
        const data = await res.json();
        document.getElementById('ai-video-progress').style.width = '100%';
        
        if (data.success) {
            document.getElementById('ai-video-status-text').textContent = 'Başlık ve Açıklama güncellendi!';
            document.getElementById('ai-video-status').style.color = '#00f5ff';
            const icon = document.getElementById('ai-video-status').querySelector('i');
            if (icon) icon.className = 'fa-solid fa-circle-check';
            
            // UI'ı 1 saniye sonra yenile
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            document.getElementById('ai-video-status-text').textContent = 'Hata: ' + (data.message || 'İçerik oluşturulamadı');
            document.getElementById('ai-video-status').style.color = '#ff007a';
        }
    } catch(e) {
        document.getElementById('ai-video-status-text').textContent = 'Bağlantı hatası: ' + e.message;
        document.getElementById('ai-video-status').style.color = '#ff007a';
    }
}

/* ====== THUMBNAIL SEÇİCİ ====== */
let _thumbVideoId   = null;
let _thumbPublicId  = null;
let _thumbVideoUrl  = null;
let _thumbCurrentSec = 0;

function openThumbnailPicker(videoId, publicId, videoUrl) {
    _thumbVideoId  = videoId;
    _thumbPublicId = publicId;
    _thumbVideoUrl = videoUrl;
    _thumbCurrentSec = 0;

    const modal = document.getElementById('thumb-picker-modal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');

    // Durumu sıfırla
    const statusEl = document.getElementById('thumb-status');
    statusEl.classList.add('hidden');
    statusEl.textContent = '';
    document.getElementById('thumb-preview-wrap').classList.add('hidden');
    document.getElementById('thumb-seek').value = 0;
    document.getElementById('thumb-time-label').textContent = '0:00';
    document.getElementById('thumb-save-btn').disabled = false;
    document.getElementById('thumb-save-btn').innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Thumbnail Olarak Kaydet';

    // Videoyu yükle
    const vid = document.getElementById('thumb-video');
    if (videoUrl) {
        document.getElementById('thumb-no-video').classList.add('hidden');
        vid.src = videoUrl;
        vid.load();
        vid.addEventListener('loadedmetadata', function onMeta() {
            vid.removeEventListener('loadedmetadata', onMeta);
            // Slider ayarla
            const seek = document.getElementById('thumb-seek');
            seek.max = Math.floor(vid.duration);
            seek.step = 1;
        });
    } else {
        document.getElementById('thumb-no-video').classList.remove('hidden');
        vid.src = '';
    }
}

function closeThumbPicker() {
    const modal = document.getElementById('thumb-picker-modal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    const vid = document.getElementById('thumb-video');
    vid.pause();
    vid.src = '';
    _thumbVideoId = _thumbPublicId = _thumbVideoUrl = null;
}

function seekThumbVideo(val) {
    const vid = document.getElementById('thumb-video');
    const sec = parseFloat(val);
    if (vid && isFinite(sec)) {
        vid.currentTime = sec;
        _thumbCurrentSec = sec;
        // Zaman etiketini güncelle
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60).toString().padStart(2, '0');
        document.getElementById('thumb-time-label').textContent = m + ':' + s;
        // Önizlemeyi güncelle
        captureThumbFrame(false);
    }
}

function captureThumbFrame(showFeedback = true) {
    const vid = document.getElementById('thumb-video');
    if (!vid || !vid.src || vid.readyState < 2) {
        if (showFeedback) showThumbStatus('Video henüz yüklenmedi.', 'error');
        return;
    }

    // Canvas'a çiz
    const canvas = document.getElementById('thumb-canvas');
    canvas.width  = vid.videoWidth  || 1280;
    canvas.height = vid.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(vid, 0, 0, canvas.width, canvas.height);

    // Önizleme olarak göster
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    const preview = document.getElementById('thumb-preview-img');
    preview.src = dataUrl;
    document.getElementById('thumb-preview-wrap').classList.remove('hidden');
}

async function saveThumbFrame() {
    if (!_thumbPublicId) {
        showThumbStatus('Bu video için Cloudinary ID bulunamadı. Sadece Cloudinary videoları desteklenmektedir.', 'error');
        return;
    }

    const sec     = Math.floor(_thumbCurrentSec);
    const saveBtn = document.getElementById('thumb-save-btn');
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Kaydediliyor...';
    showThumbStatus('', 'hidden');

    try {
        const res  = await fetch(APP_URL_JS + '/api/ai.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action:                 'extract_thumbnail',
                video_id:               _thumbVideoId,
                cloudinary_public_id:   _thumbPublicId,
                offset:                 sec
            })
        });
        const data = await res.json();

        if (data.success) {
            showThumbStatus('✓ Thumbnail başarıyla güncellendi!', 'success');
            saveBtn.innerHTML = '<i class="fa-solid fa-check"></i> Kaydedildi!';
            // Sayfadaki thumbnail'ı güncelle
            const imgs = document.querySelectorAll('[id^="video-row-' + _thumbVideoId + '"] img, #video-row-' + _thumbVideoId + ' img');
            imgs.forEach(img => { if (img.src && !img.src.includes('placehold')) img.src = data.data.thumbnail_url + '?t=' + Date.now(); });
            setTimeout(() => closeThumbPicker(), 2000);
        } else {
            showThumbStatus('Hata: ' + (data.message || 'Thumbnail güncellenemedi'), 'error');
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Thumbnail Olarak Kaydet';
        }
    } catch(e) {
        showThumbStatus('Bağlantı hatası: ' + e.message, 'error');
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Thumbnail Olarak Kaydet';
    }
}

function showThumbStatus(msg, type) {
    const el = document.getElementById('thumb-status');
    if (type === 'hidden' || !msg) { el.classList.add('hidden'); return; }
    el.classList.remove('hidden');
    if (type === 'success') {
        el.style.cssText = 'background:rgba(0,245,255,0.08);color:#00f5ff;border:1px solid rgba(0,245,255,0.2);';
    } else {
        el.style.cssText = 'background:rgba(239,68,68,0.1);color:#f87171;border:1px solid rgba(239,68,68,0.2);';
    }
    el.textContent = msg;
}

// Modal dışına tıklayınca kapat
document.getElementById('thumb-picker-modal').addEventListener('click', function(e) {
    if (e.target === this) closeThumbPicker();
});
</script>
<script>
// Süresi olmayan videoların süresini tarayıcıda okuyup kaydeder (sunucuda ffprobe gerekmez)
const NO_DUR = <?= json_encode(array_map(fn($v) => ['id' => $v['id'], 'url' => $v['video_url'] ?? '', 'title' => $v['title']], $noDur), JSON_UNESCAPED_UNICODE) ?>;
function readDuration(url) {
    return new Promise(resolve => {
        const v = document.createElement('video');
        let done = false;
        const fin = d => { if (done) return; done = true; v.removeAttribute('src'); v.load(); resolve(d); };
        v.preload = 'metadata'; v.muted = true;
        v.onloadedmetadata = () => fin(isFinite(v.duration) && v.duration > 0 ? Math.round(v.duration) : 0);
        v.onerror = () => fin(0);
        setTimeout(() => fin(0), 20000);
        v.src = url;
    });
}
async function autoDurations() {
    const btn = document.getElementById('nodur-btn'), st = document.getElementById('nodur-status'), cnt = document.getElementById('nodur-count');
    btn.disabled = true; let ok = 0, fail = 0;
    for (let i = 0; i < NO_DUR.length; i++) {
        const it = NO_DUR[i];
        st.textContent = (i + 1) + '/' + NO_DUR.length + ' işleniyor: ' + it.title.slice(0, 40);
        const d = it.url ? await readDuration(it.url) : 0;
        if (!d) { fail++; continue; }
        try {
            const r = await fetch(APP_URL_JS + '/api/videos.php?id=' + it.id, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ duration: d }) }).then(r => r.json());
            if (r.success) { ok++; cnt.textContent = NO_DUR.length - ok; } else fail++;
        } catch (e) { fail++; }
    }
    st.textContent = 'Bitti: ' + ok + ' video güncellendi' + (fail ? ', ' + fail + ' video okunamadı (bağlantı/erişim sorunu)' : '') + '.';
    btn.disabled = false;
    if (ok) setTimeout(() => location.reload(), 2500);
}
</script>
</body>
</html>
