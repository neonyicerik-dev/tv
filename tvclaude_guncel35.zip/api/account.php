<?php
// ============================================================
// NeonTV - Hesap verileri (KVKK)
// GET  ?action=export          -> kullanıcının tüm verilerini JSON dosyası olarak indirir
// POST {action:"delete", password, confirm:"HESABIMI SİL"} -> hesabı kalıcı olarak siler
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/store.php';
error_reporting(0); ini_set('display_errors', 0);

$db   = new Supabase();
$user = requireUserApi($db);
$uid  = $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'export') {
    // aşırı kullanım koruması: 60 sn'de bir
    $rl = sys_get_temp_dir() . '/nv_export_' . md5($uid) . '.t';
    if (is_file($rl) && time() - (int)@file_get_contents($rl) < 60) jsonError('Çok sık istek. Bir dakika sonra tekrar dene.', 429);
    @file_put_contents($rl, (string)time());

    $tables = [
        'comments', 'comment_likes', 'comment_reactions', 'video_ratings', 'likes', 'watch_history', 'watch_later',
        'subscriptions', 'user_playlists', 'notifications', 'user_blocks', 'ai_chat_messages', 'ai_usage',
        'video_requests', 'request_votes', 'post_poll_votes', 'user_premium', 'user_themes',
    ];
    $data = [];
    $p = $db->select('profiles', 'id=eq.' . $uid . '&select=*&limit=1', true);
    $data['profile'] = $p['data'][0] ?? null;
    foreach ($tables as $t) {
        $r = $db->select($t, 'user_id=eq.' . $uid . '&limit=5000', true);
        $data[$t] = ($r['status'] === 200 && is_array($r['data'])) ? $r['data'] : ['not_available' => true];
    }
    // çalma listelerinin içeriği
    $pl = is_array($data['user_playlists']) ? array_column($data['user_playlists'], 'id') : [];
    $pl = array_values(array_filter($pl, 'isUuid'));
    if ($pl) {
        $r = $db->select('user_playlist_items', 'playlist_id=in.(' . implode(',', $pl) . ')&limit=10000', true);
        $data['user_playlist_items'] = is_array($r['data']) ? $r['data'] : [];
    }
    // giriş geçmişi: yalnızca tarihler (IP/cihaz özetleri dışa verilmez)
    $r = $db->select('login_events', 'user_id=eq.' . $uid . '&select=created_at&order=created_at.desc&limit=200', true);
    $data['login_times'] = is_array($r['data']) ? array_column($r['data'], 'created_at') : [];

    $out = [
        'exported_at' => gmdate('c'),
        'notice'      => 'Bu dosya NeonTV hesabına ait kişisel verilerinin bir kopyasıdır.',
        'account'     => [
            'id' => $uid, 'email' => $user['email'] ?? '', 'created_at' => $user['created_at'] ?? '',
            'username' => $user['user_metadata']['username'] ?? '',
        ],
        'data' => $data,
    ];
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="neontv-verilerim-' . date('Ymd') . '.json"');
    header('Cache-Control: no-store');
    echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $in = inputJson() ?? [];
    if (($in['action'] ?? '') !== 'delete') jsonError('Geçersiz işlem');
    $confirm = trim((string)($in['confirm'] ?? ''));
    $pass    = (string)($in['password'] ?? '');
    if (mb_strtoupper($confirm, 'UTF-8') !== 'HESABIMI SİL') jsonError('Onay metni hatalı. "HESABIMI SİL" yazmalısın.');
    $email = (string)($user['email'] ?? '');
    if ($email === '' || $pass === '') jsonError('Şifreni girmelisin.');

    // şifre denemelerini sınırla
    $key = 'del:' . Store::hashIp($uid);
    if (Store::countLoginAttempts($key) >= 5) jsonError('Çok fazla hatalı deneme. 15 dakika sonra tekrar dene.', 429);
    $chk = $db->signIn($email, $pass);
    if (($chk['status'] ?? 0) !== 200 || empty($chk['data']['access_token'])) {
        Store::recordLoginAttempt($key);
        jsonError('Şifre hatalı.', 403);
    }
    Store::clearLoginAttempts($key);

    // sunucudaki profil/kapak resimlerini sil
    foreach (glob(__DIR__ . '/../assets/profiles/*' . $uid . '*') ?: [] as $f) { if (is_file($f)) @unlink($f); }

    // hesabı sil: bağlı tüm tablolar ON DELETE CASCADE ile temizlenir
    if (!$db->adminDeleteUser($uid)) jsonError('Hesap silinemedi. Lütfen daha sonra tekrar dene veya bize ulaş.', 500);
    // CASCADE olmayan olası artıklar için en iyi çaba
    try { $db->delete('profiles', 'id=eq.' . $uid, true); } catch (\Throwable $e) {}
    jsonSuccess([], 'Hesabın silindi.');
}
jsonError('Geçersiz metod', 405);
