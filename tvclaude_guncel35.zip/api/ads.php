<?php
// ============================================================
// NeonTV - Ads API (Reklam İstatistikleri)
// POST /api/ads.php  { "ad_id": "uuid", "stat": "impressions"|"clicks" }
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';

error_reporting(0);
ini_set('display_errors', 0);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('Geçersiz metod', 405);
}

$input  = inputJson() ?? [];
$adId   = trim($input['ad_id'] ?? '');
$stat   = trim($input['stat'] ?? '');

// Doğrulama
requireUuid($adId, 'Reklam ID');
$allowedStats = ['impressions', 'clicks'];
if (!in_array($stat, $allowedStats, true)) {
    jsonError('Geçersiz stat değeri');
}

$db  = new Supabase();
$res = $db->rpc('increment_ad_stat', ['p_ad_id' => $adId, 'p_stat' => $stat], true);

if ($res['status'] >= 400) {
    jsonError('İstatistik güncellenemedi', 500);
}

jsonSuccess([], 'Güncellendi');
