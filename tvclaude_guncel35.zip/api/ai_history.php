<?php
// NeTvYZ sohbet geçmişi
// GET            -> son 40 mesaj (eskiden yeniye)
// DELETE         -> tüm geçmişi sil
// POST {id, rating: 1|-1|0} -> bot mesajına puan ver
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db);
$uid = $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $rows = $db->select('ai_chat_messages', 'user_id=eq.' . $uid . '&order=created_at.desc&limit=40&select=id,role,content,refs,rating,created_at', true)['data'] ?? [];
    jsonSuccess(['items' => array_reverse($rows)]);
}
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $db->delete('ai_chat_messages', 'user_id=eq.' . $uid, true);
    jsonSuccess([], 'Geçmiş silindi');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $in = inputJson() ?? [];
    $id = trim($in['id'] ?? ''); requireUuid($id, 'Mesaj ID');
    $rt = (int)($in['rating'] ?? 0);
    if (!in_array($rt, [-1, 0, 1], true)) jsonError('Geçersiz puan');
    $db->update('ai_chat_messages', ['rating' => $rt === 0 ? null : $rt], 'id=eq.' . $id . '&user_id=eq.' . $uid . '&role=eq.bot', true);
    jsonSuccess(['rating' => $rt]);
}
jsonError('Geçersiz metod', 405);
