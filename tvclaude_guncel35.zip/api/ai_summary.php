<?php
// Videonun ALTYAZISINDAN kısa özet (YZ). Üretilen özet kaydedilir; aynı video için tekrar istek ücretsizdir.
// GET ?video_id=<uuid>  (giriş gerekli; yeni özet üretimi 1 YZ hakkı kullanır)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/gemini.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db);
$uid = $user['id'];
$vid = trim($_GET['video_id'] ?? ''); requireUuid($vid, 'Video ID');

$v = $db->first('videos', 'id=eq.' . $vid . '&status=eq.published&select=id,title,premium_only_until', true);
if (!$v) jsonError('Video bulunamadı', 404);

// Premium erken erişimdeki videonun özeti de yalnızca premiuma açık
if (!empty($v['premium_only_until']) && strtotime($v['premium_only_until']) > time() && !Store::isPremium($uid)) {
    jsonResponse(['success' => false, 'message' => 'Bu video şu an yalnızca Premium üyelere açık.', 'need_premium' => true], 403);
}

$cached = $db->first('video_summaries', 'video_id=eq.' . $vid, true);
if ($cached) jsonSuccess(['summary' => $cached['summary'], 'cached' => true]);

$sub = $db->first('subtitles', 'video_id=eq.' . $vid . '&language=eq.tr&select=content', true)
    ?: $db->first('subtitles', 'video_id=eq.' . $vid . '&select=content', true);
if (!$sub || trim((string)$sub['content']) === '') jsonError('Bu videoda altyazı olmadığı için özet çıkarılamıyor.', 404);

// VTT -> düz metin
$txt = preg_replace('/^WEBVTT.*?\n/s', '', (string)$sub['content'], 1);
$txt = preg_replace('/^\d+\s*$/m', '', $txt);
$txt = preg_replace('/\d{1,2}:\d{2}(?::\d{2})?[.,]\d{3}\s*-->.*$/m', '', $txt);
$txt = trim(preg_replace('/\s+/u', ' ', strip_tags($txt)));
if (mb_strlen($txt) < 40) jsonError('Altyazı özet için çok kısa.', 422);
$txt = mb_substr($txt, 0, 12000);

$isPremium = Store::isPremium($uid);
$maxQuota  = $isPremium ? AI_PREMIUM_MONTHLY_LIMIT : AI_FREE_MONTHLY_LIMIT;
$period    = date('Y-m');
if (!Store::consumeAiQuota($uid, $period, $maxQuota)) {
    jsonResponse(['success' => false, 'message' => "Aylık YZ limitinize ({$maxQuota}) ulaştınız. Özet üretmek 1 hak kullanır.", 'remaining' => 0], 429);
}

$payload = [
    'systemInstruction' => ['parts' => [['text' => 'Sen bir video altyazısını özetleyen asistansın. Türkçe yaz. Yalnızca verilen altyazı metnine dayan, uydurma. 3-5 kısa madde halinde (her satır "• " ile başlasın), toplam en fazla 600 karakter. Ayrıntılı müstehcen anlatımdan kaçın; konuyu ve akışı genel hatlarıyla özetle.']]],
    'contents' => [['role' => 'user', 'parts' => [['text' => "Video başlığı: {$v['title']}\n\nAltyazı:\n{$txt}"]]]],
    'generationConfig' => ['temperature' => 0.3, 'maxOutputTokens' => 1024],
    'safetySettings' => geminiSafety(),
];
$res = geminiCall($payload);
$summary = trim($res['text']);
if ($res['http'] !== 200 || $summary === '') {
    Store::refundAiQuota($uid, $period);
    jsonError('Özet şu anda üretilemedi, lütfen tekrar deneyin.', 503);
}
$summary = mb_substr($summary, 0, 1500);
$db->insert('video_summaries', ['video_id' => $vid, 'summary' => $summary], true);
jsonSuccess(['summary' => $summary, 'cached' => false]);
