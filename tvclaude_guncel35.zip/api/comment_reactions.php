<?php
// GET ?video_id=..  -> {counts:{comment_id:{emoji:n}}, mine:{comment_id:[emoji]}}  (giriş isteğe bağlı)
// POST {comment_id, emoji} -> tepkiyi ekle/kaldır
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

const REACTION_EMOJIS = ['👍', '🔥', '😂', '😮', '❤️'];
$db = new Supabase();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $vid = trim($_GET['video_id'] ?? ''); requireUuid($vid, 'Video ID');
    $uid = null; $tok = getBearerToken();
    if ($tok) { $u = $db->verifyToken($tok); if ($u && !empty($u['id'])) $uid = $u['id']; }
    $cs  = $db->select('comments', 'video_id=eq.' . $vid . '&select=id&limit=2000', true)['data'] ?? [];
    $ids = array_values(array_filter(array_column($cs, 'id'), 'isUuid'));
    $counts = []; $mine = [];
    if ($ids) {
        $rows = $db->select('comment_reactions', 'comment_id=in.(' . implode(',', $ids) . ')&select=comment_id,emoji,user_id&limit=50000', true)['data'] ?? [];
        foreach ($rows as $r) {
            $counts[$r['comment_id']][$r['emoji']] = ($counts[$r['comment_id']][$r['emoji']] ?? 0) + 1;
            if ($uid && $r['user_id'] === $uid) $mine[$r['comment_id']][] = $r['emoji'];
        }
    }
    jsonSuccess(['counts' => (object)$counts, 'mine' => (object)$mine]);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = requireUserApi($db);
    denyIfBanned($db, $user['id']);
    $in = inputJson() ?? [];
    $cid = trim($in['comment_id'] ?? ''); requireUuid($cid, 'Yorum ID');
    $em  = (string)($in['emoji'] ?? '');
    if (!in_array($em, REACTION_EMOJIS, true)) jsonError('Geçersiz tepki');
    $q = 'user_id=eq.' . $user['id'] . '&comment_id=eq.' . $cid . '&emoji=eq.' . urlencode($em);
    $ex = $db->first('comment_reactions', $q . '&select=comment_id', true);
    if ($ex) { $db->delete('comment_reactions', $q, true); $on = false; }
    else {
        if (!$db->first('comments', 'id=eq.' . $cid . '&select=id', true)) jsonError('Yorum bulunamadı', 404);
        $db->insert('comment_reactions', ['user_id' => $user['id'], 'comment_id' => $cid, 'emoji' => $em], true); $on = true;
    }
    $n = $db->count('comment_reactions', 'comment_id=eq.' . $cid . '&emoji=eq.' . urlencode($em), true);
    jsonSuccess(['on' => $on, 'count' => $n]);
}
jsonError('Geçersiz metod', 405);
