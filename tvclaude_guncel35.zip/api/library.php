<?php
// GET ?tab=history|later  -> kullanıcının listesi (video bilgisiyle)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db   = new Supabase();
$user = requireUserApi($db);
$uid  = $user['id'];
$tab  = ($_GET['tab'] ?? 'history') === 'later' ? 'later' : 'history';

if ($tab === 'later') {
    $r = $db->select('watch_later', 'user_id=eq.' . $uid . '&order=created_at.desc&limit=100&select=created_at,videos(id,title,thumbnail_url,duration,views,created_at,status)', true);
} else {
    $r = $db->select('watch_history', 'user_id=eq.' . $uid . '&order=watched_at.desc&limit=100&select=position_seconds,duration_seconds,watched_at,videos(id,title,thumbnail_url,duration,views,created_at,status)', true);
}
$items = [];
foreach (($r['data'] ?? []) as $row) {
    $v = $row['videos'] ?? null;
    if (!$v || ($v['status'] ?? '') !== 'published') continue;
    $v['position'] = (int)($row['position_seconds'] ?? 0);
    $v['saved_at'] = $row['watched_at'] ?? $row['created_at'] ?? '';
    $items[] = $v;
}
jsonSuccess(['items' => $items]);
