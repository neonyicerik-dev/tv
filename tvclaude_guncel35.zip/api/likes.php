<?php
// ============================================================
// NeonTV - Likes API
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';

error_reporting(0);
ini_set('display_errors', 0);

$method = $_SERVER['REQUEST_METHOD'];
$db     = new Supabase();
$input  = inputJson();

$token = getBearerToken();
if (!$token) jsonError('Giris yapmaniz gerekli', 401);

$user = $db->verifyToken($token);
if (!$user) jsonError('Gecersiz token', 401);

$videoId = $_GET['video_id'] ?? $input['video_id'] ?? '';
if (!$videoId) jsonError('Video ID gerekli');

if ($method === 'GET') {
    $res = $db->first('likes', 'video_id=eq.' . $videoId . '&user_id=eq.' . $user['id'], true);
    jsonSuccess(['liked' => !empty($res)]);
}

if ($method === 'POST') {
    $res = $db->insert('likes', [
        'video_id' => $videoId,
        'user_id'  => $user['id']
    ], true);

    if ($res['status'] === 409) jsonSuccess(['liked' => true, 'success' => true]);
    if ($res['status'] >= 400) jsonError($res['error'] ?? 'Begeni kaydedilemedi');
    jsonSuccess(['liked' => true, 'success' => true]);
}

if ($method === 'DELETE') {
    $res = $db->delete('likes', 'video_id=eq.' . $videoId . '&user_id=eq.' . $user['id'], true);
    if ($res['status'] >= 400) jsonError($res['error'] ?? 'Begeni kaldirilmadi');
    jsonSuccess(['liked' => false, 'success' => true]);
}

jsonError('Gecersiz metod', 405);
