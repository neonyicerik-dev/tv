<?php
// ============================================================
// NeonTV - Sunucu taraflı giriş (hız sınırı + yeni cihaz uyarısı)
// POST {email, password} -> {access_token, refresh_token, expires_in, new_device}
// Parola Supabase'e (GoTrue) iletilir; sunucuda saklanmaz/günlüğe yazılmaz.
// Not: Bu, arayüz üzerinden yapılan deneme saldırılarını sınırlar. Supabase'in kendi hız sınırı ayrıca geçerlidir.
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/ip_log.php';
require_once __DIR__ . '/../includes/store.php';
error_reporting(0); ini_set('display_errors', 0);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);

$in    = inputJson() ?? [];
$email = strtolower(trim((string)($in['email'] ?? '')));
$pass  = (string)($in['password'] ?? '');
if ($email === '' || $pass === '' || strlen($email) > 254 || strlen($pass) > 200 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonError('E-posta veya şifre hatalı.', 401);
}

const LOGIN_MAX_FAILS = 8;      // 15 dakikada en fazla hatalı deneme (IP başına)
const LOGIN_MAX_FAILS_EMAIL = 6; // aynı e-posta için (dağıtık saldırıya karşı)

$ip      = getClientIp();
$ipKey   = 'site_ip:' . Store::hashIp($ip);
$mailKey = 'site_mail:' . Store::hashIp($email);

if (Store::countLoginAttempts($ipKey) >= LOGIN_MAX_FAILS || Store::countLoginAttempts($mailKey) >= LOGIN_MAX_FAILS_EMAIL) {
    header('Retry-After: 900');
    jsonResponse(['success' => false, 'message' => 'Çok fazla hatalı deneme. Lütfen 15 dakika sonra tekrar deneyin.', 'locked' => true], 429);
}

$db = new Supabase();
$r  = $db->signIn($email, $pass);

if (($r['status'] ?? 0) !== 200 || empty($r['data']['access_token'])) {
    // ağ/sunucu hatası ile yanlış parolayı ayır: yalnızca 400/401/422 yanıtları "hatalı deneme" sayılır
    $st = (int)($r['status'] ?? 0);
    if (in_array($st, [400, 401, 422], true)) {
        Store::recordLoginAttempt($ipKey);
        Store::recordLoginAttempt($mailKey);
        usleep(300000);
        $left = max(0, LOGIN_MAX_FAILS_EMAIL - Store::countLoginAttempts($mailKey));
        jsonResponse(['success' => false, 'message' => 'E-posta veya şifre hatalı.' . ($left > 0 && $left <= 3 ? " ($left deneme hakkın kaldı)" : '')], 401);
    }
    jsonResponse(['success' => false, 'message' => 'Giriş şu an yapılamıyor, biraz sonra tekrar deneyin.'], 502);
}

Store::clearLoginAttempts($ipKey);
Store::clearLoginAttempts($mailKey);

$uid       = $r['data']['user']['id'] ?? '';
$newDevice = false;
try {
    if ($uid && isUuid($uid)) {
        $ipHash = Store::hashIp($ip);
        $uaHash = Store::hashIp((string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
        $prev = $db->select('login_events', 'user_id=eq.' . $uid . '&select=ip_hash,ua_hash&order=created_at.desc&limit=30', true);
        $rows = is_array($prev['data'] ?? null) ? $prev['data'] : [];
        $known = false;
        foreach ($rows as $row) { if ($row['ip_hash'] === $ipHash || $row['ua_hash'] === $uaHash) { $known = true; break; } }
        // Daha önce hiç kayıt yoksa (ilk giriş) uyarı verme; yalnızca hem IP hem cihaz tamamen yeniyse uyar
        if ($rows && !$known) {
            $newDevice = true;
            $db->insert('notifications', [
                'user_id' => $uid, 'type' => 'security',
                'message' => 'Hesabına yeni bir cihazdan/konumdan giriş yapıldı (' . date('d.m.Y H:i') . '). Sen değilsen şifreni hemen değiştir.',
                'link'    => '/myprofile.php',
            ], true);
        }
        $db->insert('login_events', ['user_id' => $uid, 'ip_hash' => $ipHash, 'ua_hash' => $uaHash], true);
    }
} catch (\Throwable $e) { error_log('[login] olay kaydı: ' . get_class($e)); }

jsonSuccess([
    'access_token'  => $r['data']['access_token'],
    'refresh_token' => $r['data']['refresh_token'] ?? '',
    'expires_in'    => (int)($r['data']['expires_in'] ?? 3600),
    'new_device'    => $newDevice,
]);
