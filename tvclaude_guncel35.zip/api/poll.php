<?php
// ============================================================
// NeonTV - Topluluk gönderisi anketi
// GET  ?post_id=..                -> {counts:[..], mine:int|null, ended:bool}
// POST {post_id, option}          -> oy ver (değiştirilemez)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$m  = $_SERVER['REQUEST_METHOD'];

function pollState(Supabase $db, string $pid, ?string $uid): array {
    $post = $db->first('channel_posts', 'id=eq.' . $pid . '&select=id,poll,poll_ends_at', true);
    if (!$post || empty($post['poll'])) jsonError('Anket bulunamadı', 404);
    $opts = is_array($post['poll']) ? $post['poll'] : (json_decode($post['poll'], true) ?: []);
    $counts = array_fill(0, count($opts), 0); $mine = null;
    foreach (($db->select('post_poll_votes', 'post_id=eq.' . $pid . '&select=user_id,option_idx&limit=50000', true)['data'] ?? []) as $v) {
        $i = (int)$v['option_idx']; if (isset($counts[$i])) $counts[$i]++;
        if ($uid && $v['user_id'] === $uid) $mine = $i;
    }
    $ended = !empty($post['poll_ends_at']) && strtotime($post['poll_ends_at']) <= time();
    return ['counts' => $counts, 'mine' => $mine, 'ended' => $ended, 'n' => count($opts)];
}

if ($m === 'GET') {
    $pid = trim($_GET['post_id'] ?? ''); requireUuid($pid, 'Gönderi');
    $uid = null; $tok = getBearerToken();
    if ($tok) { $u = $db->verifyToken($tok); if ($u && !empty($u['id'])) $uid = $u['id']; }
    jsonSuccess(pollState($db, $pid, $uid));
}
if ($m === 'POST') {
    $user = requireUserApi($db); $uid = $user['id'];
    denyIfBanned($db, $uid);
    $in  = inputJson() ?? [];
    $pid = trim($in['post_id'] ?? ''); requireUuid($pid, 'Gönderi');
    $opt = (int)($in['option'] ?? -1);
    $st  = pollState($db, $pid, $uid);
    if ($st['ended']) jsonError('Bu anket sona erdi');
    if ($opt < 0 || $opt >= $st['n']) jsonError('Geçersiz seçenek');
    if ($st['mine'] !== null) jsonError('Zaten oy verdin');
    $db->insert('post_poll_votes', ['post_id' => $pid, 'user_id' => $uid, 'option_idx' => $opt], true);
    jsonSuccess(pollState($db, $pid, $uid));
}
jsonError('Geçersiz metod', 405);
