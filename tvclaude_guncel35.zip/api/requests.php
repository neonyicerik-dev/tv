<?php
// ============================================================
// NeonTV - Video istek panosu
// GET    ?sort=votes|new&status=open|planned|done  -> liste
// POST   {title, description}                        -> yeni istek
// POST   {vote: <id>}                                -> oy ver / geri al
// DELETE ?id=<id>                                    -> kendi (açık) isteğini sil
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$m  = $_SERVER['REQUEST_METHOD'];

if ($m === 'GET') {
    $uid = null;
    $tok = getBearerToken();
    if ($tok) { $u = $db->verifyToken($tok); if ($u && !empty($u['id'])) $uid = $u['id']; }
    $status = in_array($_GET['status'] ?? '', ['open', 'planned', 'done'], true) ? $_GET['status'] : '';
    $q = 'select=id,user_id,username,title,description,status,admin_note,created_at&order=created_at.desc&limit=200';
    if ($status) $q .= '&status=eq.' . $status; else $q .= '&status=neq.rejected';
    $rows = $db->select('video_requests', $q, true)['data'] ?? [];
    $ids = array_column($rows, 'id');
    $votes = []; $mine = [];
    if ($ids) {
        $vr = $db->select('request_votes', 'request_id=in.(' . implode(',', $ids) . ')&select=request_id,user_id&limit=20000', true)['data'] ?? [];
        foreach ($vr as $v) { $votes[$v['request_id']] = ($votes[$v['request_id']] ?? 0) + 1; if ($uid && $v['user_id'] === $uid) $mine[$v['request_id']] = true; }
    }
    $items = [];
    foreach ($rows as $r) {
        $items[] = ['id' => $r['id'], 'username' => $r['username'], 'title' => $r['title'], 'description' => $r['description'], 'status' => $r['status'],
            'admin_note' => $r['admin_note'], 'created_at' => $r['created_at'], 'votes' => $votes[$r['id']] ?? 0, 'voted' => !empty($mine[$r['id']]), 'mine' => $uid && $r['user_id'] === $uid];
    }
    if (($_GET['sort'] ?? 'votes') === 'votes') usort($items, fn($a, $b) => $b['votes'] <=> $a['votes'] ?: strcmp($b['created_at'], $a['created_at']));
    jsonSuccess(['items' => $items, 'logged_in' => (bool)$uid]);
}

$user = requireUserApi($db);
$uid  = $user['id'];

if ($m === 'POST') {
    denyIfBanned($db, $uid);
    $in = inputJson() ?? [];

    if (!empty($in['vote'])) {
        $rid = trim($in['vote']); requireUuid($rid, 'İstek');
        $req = $db->first('video_requests', 'id=eq.' . $rid . '&select=id,status', true);
        if (!$req) jsonError('İstek bulunamadı', 404);
        if (!in_array($req['status'], ['open', 'planned'], true)) jsonError('Bu istek için oylama kapalı');
        $ex = $db->first('request_votes', 'request_id=eq.' . $rid . '&user_id=eq.' . $uid . '&select=request_id', true);
        if ($ex) { $db->delete('request_votes', 'request_id=eq.' . $rid . '&user_id=eq.' . $uid, true); $voted = false; }
        else { $db->insert('request_votes', ['request_id' => $rid, 'user_id' => $uid], true); $voted = true; }
        $cnt = $db->count('request_votes', 'request_id=eq.' . $rid, true);
        jsonSuccess(['voted' => $voted, 'votes' => $cnt]);
    }

    $title = trim(preg_replace('/\s+/u', ' ', (string)($in['title'] ?? '')));
    $desc  = mb_substr(trim((string)($in['description'] ?? '')), 0, 600);
    if (mb_strlen($title) < 3 || mb_strlen($title) > 120) jsonError('Başlık 3–120 karakter olmalı');
    // günde en fazla 3 istek
    $recent = $db->count('video_requests', 'user_id=eq.' . $uid . '&created_at=gte.' . urlencode(gmdate('Y-m-d\TH:i:s\Z', time() - 86400)), true);
    if ($recent >= 3) jsonError('Günde en fazla 3 istek gönderebilirsin', 429);
    // aynı başlık zaten açıksa tekrar ekleme
    $dup = $db->first('video_requests', 'title=ilike.' . urlencode(str_replace(['*', '%'], '', $title)) . '&status=in.(open,planned)&select=id', true);
    if ($dup) jsonError('Benzer bir istek zaten var; listeden oy verebilirsin');

    $prof = $db->first('profiles', 'id=eq.' . $uid . '&select=username', true);
    $name = $prof['username'] ?? ($user['user_metadata']['username'] ?? explode('@', $user['email'] ?? 'kullanici')[0]);
    $r = $db->insert('video_requests', ['user_id' => $uid, 'username' => mb_substr($name, 0, 40), 'title' => $title, 'description' => $desc], true);
    if (($r['status'] ?? 500) >= 400) jsonError('İstek kaydedilemedi', 500);
    $new = $r['data'][0] ?? null;
    if ($new) $db->insert('request_votes', ['request_id' => $new['id'], 'user_id' => $uid], true);   // kendi isteğine otomatik oy
    jsonSuccess(['id' => $new['id'] ?? ''], 'İsteğin alındı');
}

if ($m === 'DELETE') {
    $rid = trim($_GET['id'] ?? ''); requireUuid($rid, 'İstek');
    $req = $db->first('video_requests', 'id=eq.' . $rid . '&select=id,user_id,status', true);
    if (!$req || $req['user_id'] !== $uid) jsonError('Bu isteği silemezsin', 403);
    if ($req['status'] !== 'open') jsonError('Yalnızca açık istekler silinebilir');
    $db->delete('video_requests', 'id=eq.' . $rid, true);
    jsonSuccess([], 'Silindi');
}
jsonError('Geçersiz metod', 405);
