<?php
// ============================================================
// NeonTV - Search Suggest API
// G3: Girdi sanitize, injection güvenliği
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$q = trim($_GET['q'] ?? '');

if (mb_strlen($q) < 2 || mb_strlen($q) > 100) {
    echo json_encode(['data' => []]);
    exit;
}

// G3: Özel karakterleri temizle (LIKE injection'a karşı pgLike kullanılıyor)
$db     = new Supabase();
// G3: pgLike helper kullan – % _ * özel karakterlerini kaçırır
$likeFilter = pgLike('title', $q);
$descFilter = pgLike('description', $q);

$result = $db->select('videos',
    'status=eq.published' .
    '&or=(' . $likeFilter . ',' . $descFilter . ')' .
    '&order=views.desc' .
    '&limit=6' .
    '&select=id,title,thumbnail_url,views,duration'
);

$items = [];
foreach (($result['data'] ?? []) as $v) {
    $items[] = [
        'id'            => $v['id'],
        'title'         => $v['title'],
        'thumbnail_url' => $v['thumbnail_url'] ?? '',
        'views'         => (int)($v['views'] ?? 0),
        'duration'      => isset($v['duration']) ? formatDuration((int)$v['duration']) : '',
    ];
}

// Etiket ve kanal önerileri
$tags = []; $chans = [];
$lq = mb_strtolower($q);
$tr = $db->select('videos', 'status=eq.published&select=tags&order=views.desc&limit=300');
foreach (($tr['data'] ?? []) as $row) {
    $rt = $row['tags'] ?? []; if (is_string($rt)) $rt = json_decode($rt, true) ?: [];
    foreach ($rt as $t) { $t = trim((string)$t); if ($t !== '' && mb_strpos(mb_strtolower($t), $lq) !== false) $tags[$t] = ($tags[$t] ?? 0) + 1; }
}
arsort($tags); $tags = array_slice(array_keys($tags), 0, 3);
$cr = $db->select('channels', 'or=(' . pgLike('name', $q) . ')&select=id,name,avatar_url&limit=3');
foreach (($cr['data'] ?? []) as $c) $chans[] = ['id' => $c['id'], 'name' => $c['name'], 'avatar_url' => $c['avatar_url'] ?? ''];

echo json_encode(['data' => $items, 'tags' => $tags, 'channels' => $chans], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
