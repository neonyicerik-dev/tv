<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $db = new Supabase();

    // 1. Let's see what verifyToken does with an invalid token
    // Actually, we don't have a valid token. Let's just mock $user.
    $user = [
        'id' => '11111111-1111-1111-1111-111111111111',
        'email' => 'test@test.com',
        'user_metadata' => ['username' => 'test']
    ];

    $profile = $db->first('profiles', 'id=eq.' . $user['id'], true);
    var_dump("Profile check:", $profile);

    // Let's do a basic select
    $res = $db->select('videos', 'limit=1');
    var_dump("Videos select:", $res);

} catch (Exception $e) {
    echo "Exception: " . $e->getMessage();
} catch (Error $e) {
    echo "Error: " . $e->getMessage();
}
