<?php
// GET  -> {is_premium, theme, frame, themes:[{key,name,desc,icon,colors}]}
// POST {theme, frame} -> premium kullanıcının tema/çerçevesini kaydeder ('' = kaldır)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/themes.php';
error_reporting(0); ini_set('display_errors', 0);

$db   = new Supabase();
$user = requireUserApi($db);
$uid  = $user['id'];
$isPremium = Store::isPremium($uid);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $row = $db->first('user_themes', 'user_id=eq.' . $uid . '&select=theme,frame', true) ?: [];
    $list = [];
    foreach (nvThemes() as $k => $t) $list[] = ['key' => $k] + $t;
    jsonSuccess([
        'is_premium' => $isPremium,
        'theme'      => $row['theme'] ?? '',
        'frame'      => $row['frame'] ?? '',
        'themes'     => $list,
        'frames'     => nvFrameList(),
    ]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$isPremium) jsonError('Profil temaları yalnızca Premium üyelere özeldir.', 403);
    denyIfBanned($db, $uid);
    $in    = inputJson() ?? [];
    $theme = trim((string)($in['theme'] ?? ''));
    $frame = trim((string)($in['frame'] ?? ''));
    if (!nvValidKey($theme) || !nvValidFrame($frame)) jsonError('Geçersiz tema veya çerçeve.');
    $data = ['user_id' => $uid, 'theme' => $theme !== '' ? $theme : null, 'frame' => $frame !== '' ? $frame : null, 'updated_at' => gmdate('Y-m-d\TH:i:s\Z')];
    $exists = $db->first('user_themes', 'user_id=eq.' . $uid . '&select=user_id', true);
    $r = $exists
        ? $db->update('user_themes', $data, 'user_id=eq.' . $uid, true)
        : $db->insert('user_themes', $data, true);
    if (($r['status'] ?? 500) >= 400) jsonError('Kaydedilemedi (SQL güncellemesi çalıştırıldı mı?)', 500);
    jsonSuccess(['theme' => $theme, 'frame' => $frame], 'Kaydedildi');
}
jsonError('Geçersiz metod', 405);
