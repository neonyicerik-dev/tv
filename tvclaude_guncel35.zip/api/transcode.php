<?php
// ============================================================
// NeonTV - Transcode API
// POST /api/transcode.php
// Body: { video_id, cloudinary_public_id }
// Cloudinary Eager Transformations ile 720p / 480p / 360p oluştur
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/cloudinary.php';

header('Content-Type: application/json; charset=utf-8');

// Sadece POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input    = json_decode(file_get_contents('php://input'), true) ?? [];
$videoId  = trim($input['video_id'] ?? '');
$publicId = trim($input['cloudinary_public_id'] ?? '');

if (!$videoId || !$publicId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'video_id ve cloudinary_public_id gerekli']);
    exit;
}

// --------------------------------------------------------
// Cloudinary Explicit API ile eager transcode tetikle
// (asenkron — sonuçları notification_url ile almak yerine
//  URL'leri doğrudan hesaplıyoruz; Cloudinary lazy olarak üretir)
// --------------------------------------------------------
$cloudName = CLOUDINARY_CLOUD_NAME;
$apiKey    = CLOUDINARY_API_KEY;
$apiSecret = CLOUDINARY_API_SECRET;
$timestamp = time();

// Eager transformasyonlar
$eager = [
    ['width' => 1280, 'height' => 720,  'crop' => 'scale', 'quality' => 'auto', 'format' => 'mp4'],
    ['width' => 854,  'height' => 480,  'crop' => 'scale', 'quality' => 'auto', 'format' => 'mp4'],
    ['width' => 640,  'height' => 360,  'crop' => 'scale', 'quality' => 'auto', 'format' => 'mp4'],
];

// Eager string'ini oluştur
$eagerStr = implode('|', array_map(function($t) {
    return "w_{$t['width']},h_{$t['height']},c_{$t['crop']},q_{$t['quality']},f_{$t['format']}";
}, $eager));

// İmza
$signParams = [
    'eager'       => $eagerStr,
    'eager_async' => 'true',
    'public_id'   => $publicId,
    'timestamp'   => $timestamp,
    'type'        => 'upload',
];
ksort($signParams);
$signStr = '';
foreach ($signParams as $k => $v) {
    if ($signStr !== '') $signStr .= '&';
    $signStr .= $k . '=' . $v;
}
$signStr  .= $apiSecret;
$signature = sha1($signStr);

// Cloudinary explicit API çağrısı
$url = "https://api.cloudinary.com/v1_1/{$cloudName}/video/explicit";

$postData = [
    'public_id'   => $publicId,
    'type'        => 'upload',
    'eager'       => $eagerStr,
    'eager_async' => 'true',
    'timestamp'   => $timestamp,
    'api_key'     => $apiKey,
    'signature'   => $signature,
];

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL            => $url,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => http_build_query($postData),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_TIMEOUT        => 30,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$cloudRes = json_decode($response, true) ?? [];

// URL'leri hesapla (eager_async=true → URL'ler önceden bilinir)
$baseUrl   = "https://res.cloudinary.com/{$cloudName}/video/upload";
$qualities = [
    '1080p' => "{$baseUrl}/q_auto,f_mp4/{$publicId}.mp4",
    '720p'  => "{$baseUrl}/w_1280,h_720,c_scale,q_auto,f_mp4/{$publicId}.mp4",
    '480p'  => "{$baseUrl}/w_854,h_480,c_scale,q_auto,f_mp4/{$publicId}.mp4",
    '360p'  => "{$baseUrl}/w_640,h_360,c_scale,q_auto,f_mp4/{$publicId}.mp4",
];

// Supabase'e kaydet
$db = new Supabase();
$db->update('videos', $videoId, [
    'video_qualities' => json_encode($qualities),
]);

echo json_encode([
    'success'   => $httpCode === 200,
    'qualities' => $qualities,
    'cloudinary'=> $cloudRes,
]);
