<?php
// ============================================================
// NeonTV - Profil Resmi Yükleme (sunucuya, assets/profiles/)
// POST multipart/form-data: avatar=<dosya>   Header: Authorization: Bearer <token>
// Resim yeniden kodlanır (GD): 400x400 JPEG, metadata ve gömülü kod temizlenir.
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';

error_reporting(0);
ini_set('display_errors', 0);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);

$token = getBearerToken();
if (!$token) jsonError('Giriş yapmanız gerekli', 401);
$db   = new Supabase();
$user = $db->verifyToken($token);
if (!$user || empty($user['id']) || !isUuid($user['id'])) jsonError('Geçersiz oturum', 401);
$uid = $user['id'];

$isCover = (($_GET['type'] ?? '') === 'cover');
$field   = $isCover ? 'cover' : 'avatar';
if (empty($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
    $code = $_FILES[$field]['error'] ?? -1;
    if ($code === UPLOAD_ERR_INI_SIZE || $code === UPLOAD_ERR_FORM_SIZE) jsonError('Dosya sunucu sınırını aşıyor. Daha küçük bir resim seçin.', 413);
    jsonError('Dosya alınamadı', 400);
}
$file = $_FILES[$field];
if ($file['size'] > 5 * 1024 * 1024) jsonError('Dosya 5 MB\'dan küçük olmalı', 413);
if (!is_uploaded_file($file['tmp_name'])) jsonError('Geçersiz yükleme', 400);

// İçerik gerçekten resim mi?
$info = @getimagesize($file['tmp_name']);
$allowed = [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, IMAGETYPE_WEBP];
if (!$info || !in_array($info[2], $allowed, true)) jsonError('Yalnızca JPG, PNG, GIF veya WEBP resim yükleyebilirsiniz', 415);
if ($info[0] > 6000 || $info[1] > 6000) jsonError('Resim boyutları çok büyük', 413);
if (!function_exists('imagecreatefromstring') || !function_exists('imagejpeg')) {
    jsonError('Sunucuda resim işleme (GD) kapalı', 500);
}

$src = @imagecreatefromstring(file_get_contents($file['tmp_name']));
if (!$src) jsonError('Resim okunamadı', 400);

// EXIF yönü (telefon fotoğrafları)
if ($info[2] === IMAGETYPE_JPEG && function_exists('exif_read_data')) {
    $exif = @exif_read_data($file['tmp_name']);
    $o = $exif['Orientation'] ?? 1;
    $rot = [3 => 180, 6 => -90, 8 => 90][$o] ?? 0;
    if ($rot) { $r = imagerotate($src, $rot, 0); if ($r) { imagedestroy($src); $src = $r; } }
}

// Ortadan kırp: profil 400x400, kapak 1200x300 (4:1)
$w = imagesx($src); $h = imagesy($src);
if ($isCover) {
    $tw = 1200; $th = 300;
    $ratio = $tw / $th;
    if ($w / $h > $ratio) { $ch = $h; $cw = (int)($h * $ratio); } else { $cw = $w; $ch = (int)($w / $ratio); }
} else {
    $tw = 400; $th = 400; $cw = $ch = min($w, $h);
}
$sx = (int)(($w - $cw) / 2); $sy = (int)(($h - $ch) / 2);
$dst = imagecreatetruecolor($tw, $th);
imagefill($dst, 0, 0, imagecolorallocate($dst, 19, 19, 31)); // şeffaf PNG arka planı
imagecopyresampled($dst, $src, 0, 0, $sx, $sy, $tw, $th, $cw, $ch);
imagedestroy($src);

$dir = __DIR__ . '/../assets/profiles';
if (!is_dir($dir) && !@mkdir($dir, 0755, true)) { imagedestroy($dst); jsonError('Klasör oluşturulamadı', 500); }

$name = ($isCover ? 'cover_' : '') . $uid . '_' . bin2hex(random_bytes(4)) . '.jpg';
$path = $dir . '/' . $name;
$ok   = imagejpeg($dst, $path, 82);
imagedestroy($dst);
if (!$ok) jsonError('Resim kaydedilemedi (klasör yazma izni?)', 500);
@chmod($path, 0644);

// Bu kullanıcının eski profil resimlerini sil (disk dolmasın)
foreach (glob($dir . '/' . ($isCover ? 'cover_' : '') . $uid . '_*.jpg') ?: [] as $old) {
    if (basename($old) !== $name) @unlink($old);
}

// Kapak resmi: adresi sunucu tarafında profile kaydet
if ($isCover) {
    $db->update('profiles', ['cover_url' => APP_URL . '/assets/profiles/' . $name], 'id=eq.' . $uid, true);
}

jsonSuccess(['url' => APP_URL . '/assets/profiles/' . $name], 'Yüklendi');
