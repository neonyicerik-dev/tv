<?php
// ============================================================
// NeonTV - Cloudinary Upload Signature API
// G7: Yalnızca admin imza üretebilir
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/cloudinary.php';

error_reporting(0);
ini_set('display_errors', 0);

// G7: Yalnızca oturum açmış admin imza üretebilir
if (!isAdminLoggedIn()) {
    jsonError('Yetkisiz erişim', 401);
}

$type   = $_GET['type'] ?? 'video';
$folder = $_GET['folder'] ?? '';

$allowedFolders = ['neontv/videos', 'neontv/thumbnails', 'neontv/channels'];
if (!in_array($folder, $allowedFolders, true)) {
    $folder = ($type === 'video') ? 'neontv/videos' : 'neontv/thumbnails';
}

$cld = new Cloudinary();
$sig = $cld->generateUploadSignature(['folder' => $folder]);

header('Content-Type: application/json; charset=utf-8');
echo json_encode($sig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
