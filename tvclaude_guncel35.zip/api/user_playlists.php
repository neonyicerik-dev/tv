<?php
// Kullanıcı oynatma listeleri
// GET                       -> listelerim (+ ?video_id ile "içinde mi")
// GET ?id=<liste>           -> liste videoları (sahibi veya herkese açıksa)
// POST {action: create|toggle|delete|visibility, ...}
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$m  = $_SERVER['REQUEST_METHOD'];

if ($m === 'GET' && !empty($_GET['id'])) {
    $id = trim($_GET['id']); requireUuid($id, 'Liste ID');
    $pl = $db->first('user_playlists', 'id=eq.' . $id, true);
    if (!$pl) jsonError('Liste bulunamadı', 404);
    $uid = null; $tok = getBearerToken();
    if ($tok) { $u = $db->verifyToken($tok); if ($u && !empty($u['id'])) $uid = $u['id']; }
    $owner = $uid && $uid === $pl['user_id'];
    if (!$owner && !$pl['is_public']) jsonError('Bu liste gizli', 403);
    $r = $db->select('user_playlist_items', 'playlist_id=eq.' . $id . '&order=added_at.desc&select=videos(id,title,thumbnail_url,duration,views,status,created_at)', true);
    $items = [];
    foreach (($r['data'] ?? []) as $x) { $v = $x['videos'] ?? null; if ($v && ($v['status'] ?? '') === 'published') $items[] = $v; }
    jsonSuccess(['playlist' => ['id' => $pl['id'], 'title' => $pl['title'], 'is_public' => (bool)$pl['is_public'], 'owner' => $owner], 'items' => $items]);
}

$user = requireUserApi($db);
$uid  = $user['id'];

if ($m === 'GET') {
    $lists = $db->select('user_playlists', 'user_id=eq.' . $uid . '&order=created_at.desc&limit=100', true)['data'] ?? [];
    $ids = array_column($lists, 'id');
    $cnt = []; $has = [];
    $vid = trim($_GET['video_id'] ?? '');
    if ($ids) {
        $rows = $db->select('user_playlist_items', 'playlist_id=in.(' . implode(',', array_filter($ids, 'isUuid')) . ')&select=playlist_id,video_id&limit=20000', true)['data'] ?? [];
        foreach ($rows as $r) { $cnt[$r['playlist_id']] = ($cnt[$r['playlist_id']] ?? 0) + 1; if ($vid && $r['video_id'] === $vid) $has[$r['playlist_id']] = true; }
    }
    foreach ($lists as &$l) { $l['count'] = $cnt[$l['id']] ?? 0; $l['has_video'] = !empty($has[$l['id']]); }
    jsonSuccess(['lists' => $lists]);
}

if ($m === 'POST') {
    $in = inputJson() ?? [];
    $a  = $in['action'] ?? '';
    if ($a === 'create') {
        $title = mb_substr(trim($in['title'] ?? ''), 0, 80);
        if ($title === '') jsonError('Liste adı gerekli');
        if ($db->count('user_playlists', 'user_id=eq.' . $uid, true) >= 50) jsonError('En fazla 50 liste oluşturabilirsin');
        $r = $db->insert('user_playlists', ['user_id' => $uid, 'title' => $title], true);
        $row = $r['data'][0] ?? null;
        if (!$row) jsonError('Oluşturulamadı', 500);
        jsonSuccess(['list' => $row]);
    }
    $pid = trim($in['playlist_id'] ?? ''); requireUuid($pid, 'Liste ID');
    $pl = $db->first('user_playlists', 'id=eq.' . $pid . '&user_id=eq.' . $uid, true);
    if (!$pl) jsonError('Liste bulunamadı', 404);
    if ($a === 'delete') { $db->delete('user_playlists', 'id=eq.' . $pid, true); jsonSuccess([]); }
    if ($a === 'visibility') {
        $db->update('user_playlists', ['is_public' => !empty($in['is_public'])], 'id=eq.' . $pid, true);
        jsonSuccess([]);
    }
    if ($a === 'toggle') {
        $vid = trim($in['video_id'] ?? ''); requireUuid($vid, 'Video ID');
        $ex = $db->first('user_playlist_items', 'playlist_id=eq.' . $pid . '&video_id=eq.' . $vid . '&select=video_id', true);
        if ($ex) { $db->delete('user_playlist_items', 'playlist_id=eq.' . $pid . '&video_id=eq.' . $vid, true); jsonSuccess(['added' => false]); }
        $db->insert('user_playlist_items', ['playlist_id' => $pid, 'video_id' => $vid], true);
        jsonSuccess(['added' => true]);
    }
    jsonError('Geçersiz işlem');
}
jsonError('Geçersiz metod', 405);
