<?php
// ============================================================
// NeonTV - Premium ayrıcalıkları
// GET ?id=<video>            -> erken erişimli videonun URL'si (yalnızca premium)
// GET ?id=<video>&download=1 -> indirme bağlantısı (yalnızca premium)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db   = new Supabase();
$user = requireUserApi($db);
$id   = trim($_GET['id'] ?? '');
requireUuid($id, 'Video ID');

if (!Store::isPremium($user['id'])) {
    jsonResponse(['success' => false, 'message' => 'Bu özellik yalnızca Premium üyelere açık.', 'need_premium' => true], 403);
}
$v = $db->first('videos', 'id=eq.' . $id . '&status=eq.published&select=video_url,title', true);
if (!$v) jsonError('Video bulunamadı', 404);
jsonSuccess(['video_url' => $v['video_url'], 'title' => $v['title']]);
