<?php
// ============================================================
// NeonTV - Videos API
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/cloudinary.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/store.php';

$method = $_SERVER['REQUEST_METHOD'];
$db     = new Supabase();
$input  = inputJson();

if ($method === 'GET') {
    $id = trim($_GET['id'] ?? '');
    if ($id) {
        requireUuid($id, 'Video ID');
        $res = $db->first('videos', 'id=eq.' . urlencode($id));
        jsonSuccess($res ?? []);
    }
    jsonError('Eksik ID', 400);
}

if ($method === 'POST') {
    requireAdmin();

    // ---- Toplu AI Başlık Üret ----
    if (($input['action'] ?? '') === 'bulk_ai_title') {
        $ids = $input['ids'] ?? [];
        if (empty($ids) || !is_array($ids)) jsonError('ID listesi geçersiz');
        // G3: her ID'yi doğrula
        $ids = array_filter($ids, 'isUuid');
        if (empty($ids)) jsonError('Geçerli UUID bulunamadı');

        // Store üzerinden ayarları oku
        $settings         = Store::getSettings();
        $systemPrompt     = is_string($settings['ai_title_system_prompt'] ?? null)
            ? $settings['ai_title_system_prompt']
            : 'Sen bir video platformu için içerik yöneticisisin. Türkçe yaz. SEO uyumlu, dikkat çekici başlıklar ve açıklamalar oluştur.';
        $titleTemperature = (float)($settings['title_temperature'] ?? 0.7);

        $successCount = 0;
        foreach ($ids as $vid) {
            $vid   = (string)$vid;
            if (!isUuid($vid)) continue;
            $video = $db->first('videos', 'id=eq.' . urlencode($vid), true);
            if (!$video) continue;

            $topic = $video['title'];
            $prompt = "Aşağıdaki konu hakkında bir video için ilgi çekici, tıklama oranını artıracak bir başlık ve detaylı bir SEO uyumlu açıklama oluştur. 
            Mevcut başlık/konu: " . $topic . "
            Lütfen yanıtını SADECE aşağıdaki JSON formatında ver:
            { \"title\": \"Yeni Başlık\", \"description\": \"Yeni Açıklama\" }";

            $payload = [
                'systemInstruction' => ['parts' => [['text' => $systemPrompt]]],
                'contents' => [['parts' => [['text' => $prompt]]]],
                'generationConfig' => ['responseMimeType' => 'application/json', 'temperature' => $titleTemperature]
            ];

            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL            => GEMINI_API_BASE . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY,
                CURLOPT_POST           => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
                CURLOPT_POSTFIELDS     => json_encode($payload),
                CURLOPT_TIMEOUT        => 30,
                CURLOPT_SSL_VERIFYPEER => true
            ]);
            $response = curl_exec($ch);
            curl_close($ch);

            if ($response) {
                $data = json_decode($response, true);
                $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
                $jsonStart = strpos($text, '{');
                $jsonEnd   = strrpos($text, '}');

                if ($jsonStart !== false && $jsonEnd !== false) {
                    $cleanJson = substr($text, $jsonStart, $jsonEnd - $jsonStart + 1);
                    $result    = json_decode($cleanJson, true);
            if ($vid) {
                $db->update('videos', [
                    'title'       => $result['title'],
                    'description' => $result['description']
                ], 'id=eq.' . urlencode($vid), true);

                        $successCount++;
                    }
                }
            }
        }
        logActivity('video_bulk_ai_title', 'video', count($ids) . ' video', [], [], "Toplu AI Başlık Üretimi");
        jsonSuccess([], $successCount . ' video guncellendi');
    }

    // ---- Duplicate (klonlama — Gelişmiş: etiket + altyazı + bölüm dahil) ----
    if (($input['action'] ?? '') === 'duplicate') {
        $srcId = $input['id'] ?? '';
        if (!$srcId) jsonError('ID gerekli');
        $src = $db->first('videos', 'id=eq.' . $srcId, true);
        if (!$src) jsonError('Video bulunamadi', 404);

        // Temel alanları kopyala
        $clone = [
            'title'                => 'Kopya — ' . ($src['title'] ?? 'Video'),
            'description'          => $src['description'] ?? '',
            'thumbnail_url'        => $src['thumbnail_url'] ?? '',
            'video_url'            => $src['video_url'] ?? '',
            'cloudinary_public_id' => $src['cloudinary_public_id'] ?? '',
            'channel_id'           => $src['channel_id'] ?? null,
            'status'               => 'draft',
            'duration'             => (int)($src['duration'] ?? 0),
            'preview_clip_url'     => $src['preview_clip_url'] ?? null,
        ];

        // Etiketleri (tags) kopyala — Supabase'de text[] array
        if (!empty($src['tags'])) {
            $clone['tags'] = $src['tags'];
        }

        // Bölümleri (chapters) kopyala — varsa
        if (!empty($src['chapters'])) {
            $clone['chapters'] = $src['chapters'];
        }

        // Videoyu oluştur
        $res = $db->insert('videos', $clone, true);
        if ($res['status'] >= 400) jsonError($res['error'] ?? 'Kopyalama basarisiz');

        $newVideoId = $res['data'][0]['id'] ?? null;

        // Altyazıları (subtitles) kopyala
        if ($newVideoId) {
            $subsRes = $db->select('subtitles', 'video_id=eq.' . $srcId, true);
            $subs    = $subsRes['data'] ?? [];
            foreach ($subs as $sub) {
                $newSub = [
                    'video_id'  => $newVideoId,
                    'language'  => $sub['language'] ?? 'tr',
                    'label'     => $sub['label'] ?? 'Türkçe',
                    'content'   => $sub['content'] ?? '',
                    'is_auto'   => $sub['is_auto'] ?? false,
                ];
                if (!empty($sub['vtt_url'])) $newSub['vtt_url'] = $sub['vtt_url'];
                $db->insert('subtitles', $newSub, true);
            }
            $clonedSubs = count($subs);
        } else {
            $clonedSubs = 0;
        }

        logActivity('video_duplicate', 'video', $srcId, [], ['new_id' => $newVideoId], $src['title'] ?? '');
        jsonSuccess(
            array_merge($res['data'][0] ?? [], ['cloned_subtitles' => $clonedSubs]),
            'Video kopyalandi (' . $clonedSubs . ' altyazi dahil)'
        );
    }


    // ---- Yeni Video Ekle ----
    if (empty($input['title']) || empty($input['video_url'])) {
        jsonError('Baslik ve video gerekli');
    }

    $insertData = [
        'title'                => $input['title'],
        'description'          => $input['description'] ?? '',
        'thumbnail_url'        => $input['thumbnail_url'] ?? '',
        'video_url'            => $input['video_url'],
        'cloudinary_public_id' => $input['cloudinary_public_id'] ?? '',
        'channel_id'           => !empty($input['channel_id']) ? $input['channel_id'] : null,
        'status'               => $input['status'] ?? 'published',
        'duration'             => (int)($input['duration'] ?? 0),
        'preview_clip_url'     => $input['preview_clip_url'] ?? null,
        'tags'                 => isset($input['tags']) && is_array($input['tags']) ? '{' . implode(',', array_map(function($t){ return '"' . str_replace('"', '\"', $t) . '"'; }, $input['tags'])) . '}' : '{}',
    ];

    if (!empty($input['expires_at'])) $insertData['expires_at'] = $input['expires_at'];
    if (!empty($input['intro_end']))  $insertData['intro_end']  = max(0, min(3600, (int)$input['intro_end']));

    // Zamanlanmış yayın
    if (!empty($input['scheduled_at'])) {
        $insertData['scheduled_at'] = $input['scheduled_at'];
        $insertData['status']       = 'scheduled';
    }

    $res = $db->insert('videos', $insertData, true);
    if ($res['status'] >= 400) jsonError($res['error']);
    jsonSuccess($res['data'] ?? []);
}

if ($method === 'PATCH') {
    $id = trim($_GET['id'] ?? '');

    // ---- Toplu Durum Değiştirme ve Düzenleme ----
    if (!$id && !empty($input['bulk_ids'])) {
        requireAdmin();
        // G3: UUID doğrulama
        $rawIds = (array)$input['bulk_ids'];
        $ids    = array_values(array_filter($rawIds, 'isUuid'));
        if (empty($ids)) jsonError('Geçerli UUID bulunamadı');

        $updatePayload = [];
        if (isset($input['status'])) {
            $st = pgEnum($input['status'], ['published', 'draft', 'scheduled']);
            if ($st) {
                $updatePayload['status'] = $st;
                if ($st === 'scheduled' && !empty($input['scheduled_at'])) {
                    $updatePayload['scheduled_at'] = $input['scheduled_at'];
                }
            }
        }
        if (array_key_exists('channel_id', $input)) {
            $updatePayload['channel_id'] = $input['channel_id'] ?: null;
        }
        if (isset($input['tags']) && is_array($input['tags'])) {
            if (empty($input['tags'])) {
                $updatePayload['tags'] = '{}';
            } else {
                $updatePayload['tags'] = '{' . implode(',', array_map(function($t){ return '"' . str_replace('"', '\"', $t) . '"'; }, $input['tags'])) . '}';
            }
        }

        // Toplu kategori ekleme
        $catId = trim((string)($input['category_id'] ?? ''));
        if ($catId !== '' && !isUuid($catId)) jsonError('Geçersiz kategori');
        // Toplu premium erken erişim (tarih) / kaldırma
        if (array_key_exists('premium_only_until', $input)) {
            $pu = $input['premium_only_until'];
            if ($pu === null || $pu === '') $updatePayload['premium_only_until'] = null;
            else { $ts = strtotime((string)$pu); if (!$ts) jsonError('Geçersiz tarih'); $updatePayload['premium_only_until'] = gmdate('c', $ts); }
        }

        if (empty($updatePayload) && $catId === '') jsonError('Guncellenecek alan yok');

        if ($catId !== '') {
            foreach ($ids as $vid) {
                $ex = $db->first('video_categories', 'video_id=eq.' . urlencode($vid) . '&category_id=eq.' . urlencode($catId), true);
                if (!$ex) $db->insert('video_categories', ['video_id' => $vid, 'category_id' => $catId], true);
            }
            if (empty($updatePayload)) {
                logActivity('video_bulk_edit', 'video', count($ids) . ' video', [], ['category_id' => $catId], 'Toplu kategori');
                jsonSuccess([], count($ids) . ' videoya kategori eklendi');
            }
        }

        $errors = [];
        foreach ($ids as $vid) {
            if (!isUuid($vid)) { $errors[] = $vid; continue; }
            $r = $db->update('videos', $updatePayload, 'id=eq.' . urlencode($vid), true);
            if ($r['status'] >= 400) $errors[] = $vid;
        }
        if ($errors) jsonError('Bazi videolar guncellenemedi: ' . implode(',', $errors));
        logActivity('video_bulk_edit', 'video', count($ids) . ' video', [], $updatePayload, "Toplu Video Düzenleme");
        jsonSuccess([], count($ids) . ' video guncellendi');
    }

    if (!$id) jsonError('ID gerekli');
    requireUuid($id, 'Video ID');

    // Sadece duration güncellemesi için admin şartı yok
    $onlyDuration = isset($input['duration']) && count($input) === 1;
    if (!$onlyDuration) requireAdmin();

    $updateData = [];
    if (isset($input['title']))                $updateData['title']                = $input['title'];
    if (isset($input['description']))          $updateData['description']          = $input['description'];
    if (isset($input['thumbnail_url']))        $updateData['thumbnail_url']        = $input['thumbnail_url'];
    if (isset($input['video_url']))            $updateData['video_url']            = $input['video_url'];
    if (isset($input['cloudinary_public_id'])) $updateData['cloudinary_public_id'] = $input['cloudinary_public_id'];
    if (array_key_exists('channel_id', $input)) $updateData['channel_id']         = $input['channel_id'] ?: null;
    if (isset($input['status'])) {
        $st = pgEnum($input['status'], ['published', 'draft', 'scheduled']);
        if ($st) $updateData['status'] = $st;
    }
    if (isset($input['duration']))             $updateData['duration']             = (int)$input['duration'];
    if (array_key_exists('preview_clip_url', $input)) $updateData['preview_clip_url'] = $input['preview_clip_url'] ?: null;
    if (isset($input['scheduled_at']))         $updateData['scheduled_at']         = $input['scheduled_at'] ?: null;
    if (array_key_exists('intro_end', $input))  $updateData['intro_end']           = $input['intro_end'] ? max(0, min(3600, (int)$input['intro_end'])) : null;
    if (array_key_exists('expires_at', $input)) $updateData['expires_at']          = $input['expires_at'] ?: null;
    if (isset($input['tags']) && is_array($input['tags'])) {
        $updateData['tags'] = '{' . implode(',', array_map(function($t){ return '"' . str_replace('"', '\"', $t) . '"'; }, $input['tags'])) . '}';
    }

    if (empty($updateData)) jsonError('Güncellenecek alan yok');

    // Aktivite log: durum değişikliği
    if (!$onlyDuration && isset($input['status'])) {
        $oldVideo = $db->first('videos', 'id=eq.' . $id, true);
        if ($oldVideo) {
            logActivity('video_status_change', 'video', $id,
                ['status' => $oldVideo['status']],
                ['status' => $input['status']]
            );
        }
    } elseif (!$onlyDuration && (isset($input['title']) || isset($input['description']))) {
        $oldVideo = $db->first('videos', 'id=eq.' . $id, true);
        if ($oldVideo) {
            logActivity('video_edit', 'video', $id, $oldVideo, $updateData);
        }
    }

    $res = $db->update('videos', $updateData, 'id=eq.' . urlencode($id), true);
    if ($res['status'] >= 400) jsonError($res['error']);
    jsonSuccess($res['data'] ?? []);
}

if ($method === 'DELETE') {
    requireAdmin();

    // ---- Toplu Silme ----
    $bulkIds = $input['bulk_ids'] ?? ($_GET['bulk_ids'] ?? null);
    if (!empty($bulkIds)) {
        $rawIds = (array)$bulkIds;
        $ids    = array_values(array_filter($rawIds, 'isUuid'));
        if (empty($ids)) jsonError('Geçerli UUID bulunamadı');
        $cld = new Cloudinary();
        $deleted = 0;
        foreach ($ids as $vid) {
            $video = $db->first('videos', 'id=eq.' . urlencode($vid), true);
            if ($video) {
                if (!empty($video['cloudinary_public_id'])) {
                    $cld->deleteResource($video['cloudinary_public_id'], 'video');
                }
                $db->delete('videos', 'id=eq.' . urlencode($vid), true);
                $deleted++;
            }
        }
        logActivity('video_bulk_delete', 'video', count($ids) . ' video', [], [], "Toplu Video Silme");
        jsonSuccess([], $deleted . ' video silindi');
    }

    // ---- Tekil Silme ----
    $id = trim($_GET['id'] ?? '');
    if (!$id) jsonError('ID gerekli');
    requireUuid($id, 'Video ID');

    $video = $db->first('videos', 'id=eq.' . urlencode($id), true);
    if ($video) {
        // Aktivite log: silme öncesi eski veriyi kaydet (geri alma için)
        logActivity('video_delete', 'video', $id, $video, [], $video['title'] ?? '');
        $cld = new Cloudinary();
        if (!empty($video['cloudinary_public_id'])) {
            $cld->deleteResource($video['cloudinary_public_id'], 'video');
        }
        $db->delete('videos', 'id=eq.' . urlencode($id), true);
    }
    jsonSuccess([], 'Silindi');
}

jsonError('Gecersiz metod', 405);
