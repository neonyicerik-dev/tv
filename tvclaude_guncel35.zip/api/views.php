<?php
// ============================================================
// NeonTV - Views API (İzlenme Sayacı)
// G5: IP hashleme, G3: UUID doğrulama
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/ip_log.php';
require_once __DIR__ . '/../includes/store.php';

error_reporting(0);
ini_set('display_errors', 0);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('Geçersiz metod', 405);
}

$input   = inputJson();
$videoId = trim($input['video_id'] ?? '');

// G3: UUID doğrulama
requireUuid($videoId, 'Video ID');

$db     = new Supabase();
$ip     = getClientIp();
$ipHash = hashIp($ip);
$since  = gmdate('Y-m-d\TH:i:s\Z', time() - 1800); // son 30 dk

// Spam koruması: son 30 dakikada aynı ip_hash bu videoyu izlediyse sayma
$recent = $db->first(
    'views_log',
    'video_id=eq.' . urlencode($videoId) .
    '&ip_hash=eq.' . urlencode($ipHash) .
    '&created_at=gte.' . urlencode($since),
    true
);

if (!$recent) {
    // ip_hash ile kaydet (ham IP yok)
    $insertRes = $db->insert('views_log', [
        'video_id' => $videoId,
        'ip_hash'  => $ipHash,
    ], true);

    if ($insertRes['status'] < 400) {
        // Atomik artış – PostgreSQL RPC
        $db->rpc('increment_view_count', ['video_uuid' => $videoId], true);
    }
}

jsonSuccess([], 'İzlenme kaydedildi');
