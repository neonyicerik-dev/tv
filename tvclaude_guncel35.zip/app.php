<?php
// ============================================================
// NeonTV - Uygulama İndirme Sayfası
// APK dosyası sunucuda tutulmaz; ayarlardaki harici bağlantıya yönlendirilir.
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/store.php';

// Varsayılan indirme bağlantısı (admin/app.php'den değiştirilebilir)
$defaultUrl = 'https://www.dropbox.com/scl/fi/pn56tqe6fove4g34cgxk0/NeonTv.apk?rlkey=izlscu65v3sehivg353azmbd1&st=ce438dsx&dl=1';
$url     = trim((string)Store::getSetting('app_download_url', '')) ?: $defaultUrl;
$version = trim((string)Store::getSetting('app_version', '1.0'));
$size    = trim((string)Store::getSetting('app_size', '')) ?: '~70 MB';
$notes   = trim((string)Store::getSetting('app_changelog', ''));
$enabled = (bool)Store::getSetting('app_enabled', true);
$ready   = $enabled && preg_match('#^https://#i', $url);

// /app.php?indir=1 -> sayacı artır ve indirme bağlantısına yönlendir
if ($ready && isset($_GET['indir'])) {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (!preg_match('/bot|crawl|spider|preview/i', $ua)) {
        Store::setSetting('app_download_count', (int)Store::getSetting('app_download_count', 0) + 1);
    }
    header('Location: ' . $url, true, 302);
    exit;
}

$pageTitle = 'Uygulamayı İndir';
?>
<?php include __DIR__ . '/components/header.php'; ?>

<div class="max-w-xl mx-auto py-10 px-4 text-center">
    <div class="mx-auto mb-6 w-24 h-24 rounded-3xl flex items-center justify-center"
         style="background:linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.15));border:1px solid rgba(0,245,255,0.35);box-shadow:0 0 40px rgba(0,245,255,0.25), 0 0 60px rgba(191,0,255,0.2);">
        <i class="fa-solid fa-play text-4xl" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);-webkit-background-clip:text;background-clip:text;color:transparent;"></i>
    </div>

    <h1 class="text-3xl sm:text-4xl font-bold mb-2" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);-webkit-background-clip:text;background-clip:text;color:transparent;">
        NeonTV Uygulaması
    </h1>
    <p class="text-gray-400 mb-6">Daha hızlı, daha akıcı NeonTV deneyimi. Android telefonunuza indirin.</p>

    <div class="flex flex-wrap items-center justify-center gap-2 mb-8 text-xs">
        <span class="px-3 py-1.5 rounded-full" style="background:rgba(0,245,255,0.08);border:1px solid rgba(0,245,255,0.25);color:#00f5ff;"><i class="fa-brands fa-android mr-1"></i>Android</span>
        <?php if ($version !== ''): ?><span class="px-3 py-1.5 rounded-full text-gray-300" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">Sürüm <?= e($version) ?></span><?php endif; ?>
        <?php if ($size !== ''): ?><span class="px-3 py-1.5 rounded-full text-gray-300" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"><?= e($size) ?></span><?php endif; ?>
    </div>

    <?php if ($ready): ?>
    <a href="<?= APP_URL ?>/app.php?indir=1" rel="nofollow"
       class="inline-flex items-center justify-center gap-3 w-full sm:w-auto sm:px-14 py-4 rounded-full text-lg font-bold text-black transition-transform hover:scale-105"
       style="background:linear-gradient(135deg,#00f5ff,#bf00ff);box-shadow:0 0 30px rgba(0,245,255,0.4);">
        <i class="fa-solid fa-download"></i> Hemen İndir
    </a>
    <?php else: ?>
    <div class="inline-flex items-center gap-2 px-6 py-3 rounded-full text-gray-400" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
        <i class="fa-regular fa-clock"></i> Uygulama çok yakında burada
    </div>
    <?php endif; ?>

    <?php if ($notes !== ''): ?>
    <div class="mt-8 text-left rounded-2xl p-4 text-sm text-gray-400 whitespace-pre-wrap" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <div class="font-semibold text-white mb-1">Yenilikler</div><?= e($notes) ?>
    </div>
    <?php endif; ?>

    <div class="mt-8 text-left rounded-2xl p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h2 class="font-bold text-white mb-3"><i class="fa-solid fa-circle-info mr-2" style="color:#00f5ff;"></i>Kurulum</h2>
        <ol class="space-y-2 text-sm text-gray-400 list-decimal list-inside">
            <li>"Hemen İndir" butonuna dokunup APK dosyasını indirin.</li>
            <li>İndirilen dosyaya dokunun. Telefon "bilinmeyen kaynaklardan yükleme" izni isterse <b class="text-gray-300">Ayarlar</b>'dan tarayıcınız için izni açın.</li>
            <li>"Yükle"ye dokunun ve kurulum bittikten sonra uygulamayı açın.</li>
        </ol>
        <p class="text-xs text-gray-600 mt-3">Uygulama yalnızca 18 yaş ve üzeri kullanıcılar içindir. Sorun yaşarsanız <a href="<?= APP_URL ?>/iletisim.php" class="text-cyan-400 hover:underline">bize yazın</a>.</p>
    </div>
</div>

<?php include __DIR__ . '/components/footer.php'; ?>
