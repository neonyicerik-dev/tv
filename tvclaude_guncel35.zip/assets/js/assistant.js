// ============================================================
// NeonTV - NeTvYZ Yapay Zeka Asistan UI
// Sohbet, akışlı yanıt, video kartları, hızlı öneriler, geçmiş, puanlama, "sonra izle" eylemi
// ============================================================
(function () {
    'use strict';

    const btn      = document.getElementById('netvy-btn');
    const panel    = document.getElementById('netvy-panel');
    const closeBtn = document.getElementById('netvy-close');
    const form     = document.getElementById('netvy-form');
    const input    = document.getElementById('netvy-input');
    const messages = document.getElementById('netvy-messages');
    const quotaEl  = document.getElementById('netvy-quota');
    if (!btn || !panel) return;

    const APP = (typeof _appUrl !== 'undefined' && _appUrl) ? _appUrl : '';
    let historyLoaded = false, busy = false;

    async function getToken() {
        try {
            if (typeof sbClient !== 'undefined') {
                const { data } = await sbClient.auth.getSession();
                if (data && data.session && data.session.access_token) return data.session.access_token;
            }
        } catch (e) {}
        try {
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && key.startsWith('sb-') && key.endsWith('-auth-token')) {
                    const d = JSON.parse(localStorage.getItem(key) || '{}');
                    if (d && d.access_token) return d.access_token;
                }
            }
            return localStorage.getItem('sb_access_token') || null;
        } catch (e) {}
        return null;
    }
    const authHeaders = (tok, extra) => Object.assign({ 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok }, extra || {});

    // ---- Ek arayüz: geçmiş temizle butonu + hızlı öneri düğmeleri ----
    const header = panel.querySelector('.netvy-header');
    const clearBtn = document.createElement('button');
    clearBtn.type = 'button'; clearBtn.id = 'netvy-clear'; clearBtn.title = 'Sohbet geçmişini sil'; clearBtn.setAttribute('aria-label', 'Sohbet geçmişini sil');
    clearBtn.innerHTML = '<i class="fa-solid fa-trash-can"></i>';
    if (header && closeBtn) header.insertBefore(clearBtn, closeBtn);

    const chips = document.createElement('div');
    chips.className = 'netvy-chips';
    ['Bugün ne izleyeyim?', 'En çok izlenenler', 'Yeni eklenenler', 'Rastgele bir şey öner'].forEach(t => {
        const c = document.createElement('button');
        c.type = 'button'; c.className = 'netvy-chip'; c.textContent = t;
        c.addEventListener('click', () => send(t));
        chips.appendChild(c);
    });
    if (form) form.parentNode.insertBefore(chips, form);

    // ---- Misafir: giriş / kayıt yönlendirmesi ----
    function showLoginPrompt() {
        if (document.getElementById('netvy-login-prompt')) return;
        const wrap = document.createElement('div');
        wrap.className = 'netvy-msg netvy-msg-bot'; wrap.id = 'netvy-login-prompt';
        const bubble = document.createElement('div');
        bubble.className = 'netvy-bubble';
        bubble.textContent = 'NeTvYZ\'yi kullanmak için üye olman gerekiyor. Ücretsiz üyelere ayda 5 mesaj hakkı verilir, Premium üyelere 50.';
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;gap:8px;margin-top:10px;';
        const mk = (txt, href, primary) => {
            const a = document.createElement('a');
            a.href = APP + href; a.textContent = txt;
            a.style.cssText = 'flex:1;text-align:center;padding:9px 10px;border-radius:999px;font-size:13px;font-weight:700;text-decoration:none;' +
                (primary ? 'background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;' : 'border:1px solid rgba(255,255,255,0.25);color:#fff;');
            return a;
        };
        row.appendChild(mk('Kayıt Ol', '/auth.php?tab=register', true));
        row.appendChild(mk('Giriş Yap', '/auth.php', false));
        bubble.appendChild(row); wrap.appendChild(bubble);
        messages.appendChild(wrap); messages.scrollTop = messages.scrollHeight;
    }

    async function refreshAccessState() {
        const tok = await getToken();
        if (!tok) {
            input.disabled = true; input.placeholder = 'Kullanmak için giriş yap';
            if (quotaEl) quotaEl.textContent = '';
            chips.style.display = 'none'; clearBtn.style.display = 'none';
            showLoginPrompt();
        } else {
            input.disabled = false; input.placeholder = 'Video önerisi isteyin...';
            chips.style.display = ''; clearBtn.style.display = '';
            const p = document.getElementById('netvy-login-prompt'); if (p) p.remove();
        }
        return tok;
    }

    // ---- Geçmişi yükle ----
    function greet() {
        addMessage('bot', 'Merhaba! Ben NeTvYZ 🤖 NeonTV\'nin yapay zeka video asistanıyım. Hangi tür video arıyorsun? Aşağıdaki önerilerden birini de seçebilirsin.');
    }
    async function loadHistory(tok) {
        if (historyLoaded) return;
        historyLoaded = true;
        try {
            const r = await fetch(APP + '/api/ai_history.php?token=' + encodeURIComponent(tok), { headers: authHeaders(tok) });
            const j = await r.json();
            const items = (j.data && j.data.items) || [];
            if (!items.length) { greet(); return; }
            items.forEach(m => addMessage(m.role, m.content, m.refs || [], { id: m.id, rating: m.rating, noScroll: true }));
            messages.scrollTop = messages.scrollHeight;
        } catch (e) { greet(); }
    }

    // ---- Panel aç/kapat ----
    btn.addEventListener('click', async () => {
        panel.classList.toggle('netvy-open');
        if (panel.classList.contains('netvy-open')) {
            const tok = await refreshAccessState();
            if (tok) await loadHistory(tok); else if (!messages.children.length) greet();
        }
    });
    if (closeBtn) closeBtn.addEventListener('click', () => panel.classList.remove('netvy-open'));
    document.addEventListener('click', (e) => {
        if (!panel.contains(e.target) && !btn.contains(e.target)) panel.classList.remove('netvy-open');
    });

    clearBtn.addEventListener('click', async () => {
        if (!confirm('NeTvYZ sohbet geçmişin silinsin mi?')) return;
        const tok = await getToken(); if (!tok) return;
        try { await fetch(APP + '/api/ai_history.php?token=' + encodeURIComponent(tok), { method: 'DELETE', headers: authHeaders(tok) }); } catch (e) {}
        messages.innerHTML = ''; greet();
    });

    // ---- Gönder ----
    if (form) form.addEventListener('submit', (e) => { e.preventDefault(); const m = input.value.trim(); if (m) { input.value = ''; send(m); } });

    // Akış sırasında henüz tamamlanmamış [video: ...] / [sonra: ...] işaretlerini gizle
    function cleanLive(t) {
        return t.replace(/\[(?:video|sonra):\s*[0-9a-f-]{36}\]/gi, '').replace(/\[(?:video|sonra)?:?[^\]]{0,45}$/i, '').replace('[RED]', '').trimStart();
    }

    async function send(msg) {
        if (busy) return;
        const tok = await getToken();
        if (!tok) { await refreshAccessState(); return; }
        busy = true; input.disabled = true;
        addMessage('user', msg);
        const bot = addMessage('bot', '');
        const bubble = bot.querySelector('.netvy-bubble');
        bubble.classList.add('netvy-typing'); bubble.innerHTML = '<span></span><span></span><span></span>';

        let full = '', started = false, final = null, errMsg = '';
        const onEvent = (ev) => {
            if (ev.t === 'delta') {
                full += ev.text;
                if (!started) { started = true; bubble.classList.remove('netvy-typing'); bubble.innerHTML = ''; }
                bubble.textContent = cleanLive(full);
                messages.scrollTop = messages.scrollHeight;
            } else if (ev.t === 'done') final = ev;
            else if (ev.t === 'error') errMsg = ev.message || 'Bir hata oluştu.';
        };

        try {
            const resp = await fetch(APP + '/api/assistant.php', {
                method: 'POST',
                headers: authHeaders(tok, { 'Content-Type': 'application/json' }),
                body: JSON.stringify({ message: msg, stream: true, token: tok }),
            });
            const ctype = resp.headers.get('content-type') || '';
            if (ctype.includes('text/event-stream')) {
                const reader = resp.body && resp.body.getReader ? resp.body.getReader() : null;
                const dec = new TextDecoder(); let buf = '';
                const feed = (chunk) => {
                    buf += chunk;
                    let i;
                    while ((i = buf.indexOf('\n\n')) !== -1) {
                        const block = buf.slice(0, i); buf = buf.slice(i + 2);
                        block.split('\n').forEach(line => {
                            if (line.startsWith('data:')) { try { onEvent(JSON.parse(line.slice(5).trim())); } catch (e) {} }
                        });
                    }
                };
                if (reader) { for (;;) { const { done, value } = await reader.read(); if (done) break; feed(dec.decode(value, { stream: true })); } }
                else feed(await resp.text());
            } else {
                const data = await resp.json().catch(() => ({}));
                if (resp.status === 401) { errMsg = 'Oturumun sona ermiş olabilir. Lütfen tekrar giriş yap.'; showLoginPrompt(); }
                else if (!resp.ok || !data.success) errMsg = data.message || 'Bir hata oluştu. Lütfen tekrar dene.';
                else final = Object.assign({ t: 'done' }, data.data || {});
            }
        } catch (err) { errMsg = 'Bağlantı hatası. İnternet bağlantını kontrol et.'; }

        if (final) {
            bubble.classList.remove('netvy-typing');
            bubble.textContent = final.reply || cleanLive(full);
            decorate(bot, final.references || [], final.actions || [], final.message_id, 0);
            if (final.remaining !== undefined && final.remaining !== null && quotaEl) quotaEl.textContent = 'Kalan: ' + final.remaining + ' istek';
        } else {
            bubble.classList.remove('netvy-typing');
            bubble.textContent = '⚠️ ' + (errMsg || 'Yanıt alınamadı.');
            if (full) bubble.textContent = cleanLive(full) + '\n\n⚠️ ' + errMsg;
        }
        messages.scrollTop = messages.scrollHeight;
        busy = false;
        const still = await getToken();
        input.disabled = !still; if (still) input.focus();
    }

    // ---- Mesaj baloncuğu ----
    function addMessage(role, text, refs, meta) {
        meta = meta || {};
        const wrap = document.createElement('div');
        wrap.className = 'netvy-msg netvy-msg-' + role;
        const bubble = document.createElement('div');
        bubble.className = 'netvy-bubble';
        bubble.textContent = text; // XSS yok
        wrap.appendChild(bubble);
        messages.appendChild(wrap);
        if (role === 'bot' && (text || (refs && refs.length))) decorate(wrap, refs || [], [], meta.id, meta.rating || 0);
        if (!meta.noScroll) messages.scrollTop = messages.scrollHeight;
        return wrap;
    }

    // Video kartları, eylem bildirimleri, puan butonları
    function decorate(wrap, refs, actions, msgId, rating) {
        wrap.querySelectorAll('.netvy-cards,.netvy-actions').forEach(n => n.remove());
        if (refs.length) {
            const box = document.createElement('div'); box.className = 'netvy-cards';
            refs.forEach(r => {
                const a = document.createElement('a');
                a.href = APP + '/video.php?id=' + encodeURIComponent(r.id); a.className = 'netvy-card';
                const th = document.createElement('div'); th.className = 'netvy-card-thumb';
                if (r.thumbnail_url && /^https?:\/\//i.test(r.thumbnail_url)) { const im = document.createElement('img'); im.src = r.thumbnail_url; im.alt = ''; im.loading = 'lazy'; th.appendChild(im); }
                if (r.duration) { const d = document.createElement('span'); d.className = 'netvy-card-dur'; const s = Math.floor(r.duration); d.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); th.appendChild(d); }
                const t = document.createElement('div'); t.className = 'netvy-card-title'; t.textContent = r.title;
                a.appendChild(th); a.appendChild(t); box.appendChild(a);
            });
            wrap.appendChild(box);
        }
        actions.forEach(ac => {
            if (ac.type !== 'later') return;
            const n = document.createElement('div'); n.className = 'netvy-actions';
            n.textContent = '✔ "Daha sonra izle" listene eklendi: ' + ac.title;
            wrap.appendChild(n);
        });
        renderFeedback(wrap, msgId, rating);
    }

    function renderFeedback(wrap, msgId, rating) {
        wrap.querySelectorAll('.netvy-fb').forEach(n => n.remove());
        if (msgId) {
            const fb = document.createElement('div'); fb.className = 'netvy-fb';
            const mk = (val, icon, label) => {
                const b = document.createElement('button'); b.type = 'button'; b.title = label; b.innerHTML = '<i class="fa-' + (rating === val ? 'solid' : 'regular') + ' ' + icon + '"></i>';
                if (rating === val) b.classList.add('on');
                b.addEventListener('click', async () => {
                    const tok = await getToken(); if (!tok) return;
                    const next = (rating === val) ? 0 : val;
                    try { await fetch(APP + '/api/ai_history.php?token=' + encodeURIComponent(tok), { method: 'POST', headers: authHeaders(tok, { 'Content-Type': 'application/json' }), body: JSON.stringify({ id: msgId, rating: next }) }); rating = next; renderFeedback(wrap, msgId, rating); } catch (e) {}
                });
                return b;
            };
            fb.appendChild(mk(1, 'fa-thumbs-up', 'İşe yaradı')); fb.appendChild(mk(-1, 'fa-thumbs-down', 'İşe yaramadı'));
            wrap.appendChild(fb);
        }
    }
})();
