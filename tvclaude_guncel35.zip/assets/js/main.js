/* ============================================================
   NeonTV - Ana JS (main.js)
   - Flash mesajı otomatik kapanma
   - Navbar scroll efekti
   - Lazy loading fallback
   - Video kart hover/touch önizleme (rastgele ham video klipleri)
============================================================ */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Flash Mesajlarının Otomatik Kapanması
    const flashMessages = document.querySelectorAll('.flash-message');
    if (flashMessages.length > 0) {
        setTimeout(() => {
            flashMessages.forEach(msg => {
                msg.style.opacity = '0';
                msg.style.transform = 'translateY(-10px)';
                msg.style.transition = 'all 0.4s ease-out';
                setTimeout(() => msg.remove(), 400);
            });
        }, 4000);
    }

    // 2. Navbar Scroll Efekti
    const navbar = document.getElementById('navbar');
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 10) {
                navbar.style.background = 'rgba(7,7,17,0.95)';
                navbar.style.boxShadow = '0 4px 30px rgba(0,0,0,0.5)';
                navbar.style.borderBottom = '1px solid rgba(0,245,255,0.1)';
            } else {
                navbar.style.background = 'rgba(7,7,17,0.85)';
                navbar.style.boxShadow = 'none';
                navbar.style.borderBottom = '1px solid rgba(255,255,255,0.06)';
            }
        });
    }

    // 3. Lazy Loading Fallback
    const lazyImages = [].slice.call(document.querySelectorAll("img[loading='lazy']"));
    if ("IntersectionObserver" in window) {
        let lazyImageObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    let lazyImage = entry.target;
                    lazyImage.style.opacity = 1;
                    lazyImageObserver.unobserve(lazyImage);
                }
            });
        });
        lazyImages.forEach(function(lazyImage) {
            lazyImageObserver.observe(lazyImage);
        });
    }

    // 4. Video Kart Önizlemeleri
    initCardPreviews();
});

/* ============================================================
   Video Kart Önizleme Sistemi
   - data-raw-video varsa: ham videodan rastgele 4 klip (4–12 sn)
   - data-preview varsa: hazır klip (eski davranış, loop)
   - Masaüstü: mouseenter/mouseleave
   - Mobil: touchstart (ilk → preview, ikinci → link)
============================================================ */
function initCardPreviews() {
    const cards = document.querySelectorAll('.card-thumb-wrap');
    if (!cards.length) return;

    /* Ayarlar */
    const CLIP_COUNT   = 4;
    const CLIP_MIN_SEC = 4;
    const CLIP_MAX_SEC = 12;
    const HOVER_DELAY  = 350;   // ms — yanlışlıkla hover'ı önle
    const MARGIN_SEC   = 5;     // baştan/sondan güvenli mesafe

    /* Aktif durumlar */
    let activeCard  = null;
    let hoverTimer  = null;

    /* ---------- Rastgele klip noktaları üret ---------- */
    function generateClips(totalDuration) {
        const safe = totalDuration - MARGIN_SEC * 2;
        if (safe <= CLIP_MIN_SEC) return null;

        const durations = Array.from({ length: CLIP_COUNT }, () =>
            CLIP_MIN_SEC + Math.random() * (CLIP_MAX_SEC - CLIP_MIN_SEC)
        );

        const starts = [];
        let attempts = 0;
        while (starts.length < CLIP_COUNT && attempts < 2000) {
            attempts++;
            const s = MARGIN_SEC + Math.random() * safe;
            const d = durations[starts.length];
            if (s + d > totalDuration - MARGIN_SEC) continue;
            // Diğer başlangıç noktalarıyla en az (d+3) sn arayla
            const ok = starts.every((ps, i) => Math.abs(ps - s) > durations[i] + 3);
            if (ok) starts.push(s);
        }

        // Yeterli nokta bulunamazsa eşit aralıklarla doldur
        while (starts.length < CLIP_COUNT) {
            const i = starts.length;
            starts.push(MARGIN_SEC + (safe / CLIP_COUNT) * i);
        }

        return starts.map((s, i) => ({ start: s, duration: durations[i] ?? CLIP_MAX_SEC }));
    }

    /* ---------- Kart state nesnesi ---------- */
    function createState() {
        return {
            clips:        null,   // [{start, duration}] — ham video için
            currentClip:  0,
            clipTimer:    null,
            durationReady: false,
            playing:      false,
            useRaw:       false,  // true → ham video modu
        };
    }

    const stateMap = new WeakMap(); // wrap → state

    /* ---------- Tek bir klip oynat, bitince sonrakine ---------- */
    function playClip(wrap, state) {
        if (!state.playing) return;
        const video = wrap.querySelector('.card-preview');
        if (!video || !state.clips) return;

        const clip = state.clips[state.currentClip % CLIP_COUNT];
        video.currentTime = clip.start;
        video.play().catch(() => {});

        state.clipTimer = setTimeout(() => {
            if (!state.playing) return;
            video.pause();
            state.currentClip = (state.currentClip + 1) % CLIP_COUNT;
            playClip(wrap, state);
        }, clip.duration * 1000);
    }

    /* ---------- Görseller: thumbnail soldur, video göster ---------- */
    function showVideo(wrap) {
        const video = wrap.querySelector('.card-preview');
        const thumb = wrap.querySelector('.card-thumb');
        const badge = wrap.querySelector('.card-duration-badge');
        if (video) video.style.opacity = '1';
        if (thumb) thumb.style.opacity = '0';
        if (badge) badge.style.opacity = '0';
    }

    function hideVideo(wrap) {
        const video = wrap.querySelector('.card-preview');
        const thumb = wrap.querySelector('.card-thumb');
        const badge = wrap.querySelector('.card-duration-badge');
        if (video) { video.pause(); video.style.opacity = '0'; }
        if (thumb) thumb.style.opacity = '1';
        if (badge) badge.style.opacity = '1';
    }

    /* ---------- Önizlemeyi başlat ---------- */
    function startPreview(wrap) {
        if (activeCard === wrap) return;
        stopPreview(); // öncekini kapat

        const video    = wrap.querySelector('.card-preview');
        if (!video) return;

        activeCard = wrap;

        let state = stateMap.get(wrap);
        if (!state) { state = createState(); stateMap.set(wrap, state); }

        state.playing     = true;
        state.currentClip = 0;
        state.useRaw      = !!wrap.dataset.rawVideo && !wrap.dataset.preview;

        /* Ham video modu */
        if (state.useRaw) {
            // src henüz set edilmediyse yükle
            if (!video.src || video.src === window.location.href) {
                video.src = wrap.dataset.rawVideo;
            }

            if (state.durationReady && state.clips) {
                showVideo(wrap);
                playClip(wrap, state);
            } else {
                const onMeta = () => {
                    video.removeEventListener('loadedmetadata', onMeta);
                    state.durationReady = true;
                    state.clips = generateClips(video.duration);
                    if (state.playing) {
                        showVideo(wrap);
                        playClip(wrap, state);
                    }
                };
                video.addEventListener('loadedmetadata', onMeta);
                video.load();
            }

        /* Hazır klip modu (preview_clip_url) */
        } else if (wrap.dataset.preview) {
            video.currentTime = 0;
            video.play().catch(() => {});
            showVideo(wrap);
        }
    }

    /* ---------- Önizlemeyi durdur ---------- */
    function stopPreview(wrap) {
        clearTimeout(hoverTimer);
        const target = wrap || activeCard;
        if (!target) return;

        const state = stateMap.get(target);
        if (state) {
            clearTimeout(state.clipTimer);
            state.playing = false;
        }

        hideVideo(target);
        if (target === activeCard) activeCard = null;
    }

    /* ---------- Olay dinleyicileri ---------- */
    cards.forEach(wrap => {
        // data-raw-video yoksa ama data-preview de yoksa: atla
        // GÜNCELLEME (#38): data-raw-video yoksa fallback olarak veri setinden almaya çalış
        if (!wrap.dataset.rawVideo && !wrap.dataset.preview) {
            // Kartın çevresindeki article/a'dan video URL'sini çekmeye çalış
            // video_card.php'de data-raw-video dolduruluyorsa bu branch hiç çalışmaz
            // Ek güvenlik: tamamen thumbnail-only kartlar için skip
            return;
        }

        /* Masaüstü: hover */
        wrap.addEventListener('mouseenter', () => {
            hoverTimer = setTimeout(() => startPreview(wrap), HOVER_DELAY);
        });
        wrap.addEventListener('mouseleave', () => {
            clearTimeout(hoverTimer);
            stopPreview(wrap);
        });

        /* Mobil: touch
           - İlk dokunuş → önizlemeyi başlat (linke gitme)
           - İkinci dokunuş (zaten oynuyor) → linke git (varsayılan davranış)
        */
        wrap.addEventListener('touchstart', (e) => {
            if (activeCard === wrap) {
                // Zaten oynuyor → linke gidebilir
                return;
            }
            // İlk dokunuş → önizleme başlat
            e.preventDefault();
            // Diğer açık kartları kapat
            cards.forEach(other => { if (other !== wrap) stopPreview(other); });
            clearTimeout(hoverTimer);
            startPreview(wrap);
        }, { passive: false });
    });


    /* Kart dışına dokunulunca tüm önizlemeleri kapat */
    document.addEventListener('touchstart', (e) => {
        if (activeCard && !activeCard.contains(e.target)) {
            stopPreview(activeCard);
        }
    }, { passive: true });
}
