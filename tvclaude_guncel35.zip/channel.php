<?php
// ============================================================
// NeonTV - Kanal Profili
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';

$id = $_GET['id'] ?? '';
if (!$id) {
    header("Location: " . APP_URL . "/index.php");
    exit;
}

$db = new Supabase();
$channel = $db->first('channels', 'id=eq.' . $id);
if (!$channel) {
    die("Kanal bulunamadı.");
}

// Kanalın videolarını çek
$videosRes = $db->select('videos', 'channel_id=eq.' . $id . '&status=eq.published&order=created_at.desc');
$videos = $videosRes['data'] ?? [];

$tab = pgEnum($_GET['tab'] ?? '', ['videos', 'about', 'popular', 'playlists', 'community'], 'videos');
$totalViews = 0; foreach ($videos as $v) $totalViews += (int)($v['views'] ?? 0);
$popular = $videos; usort($popular, fn($a, $b) => (int)($b['views'] ?? 0) <=> (int)($a['views'] ?? 0));
$playlists = []; $plVideos = []; $posts = [];
{
    $posts = $db->select('channel_posts', 'channel_id=eq.' . $channel['id'] . '&order=created_at.desc&limit=50', true)['data'] ?? [];
}
{
    $pr = $db->select('playlists', 'channel_id=eq.' . $channel['id'] . '&order=created_at.desc', true);
    $playlists = $pr['data'] ?? [];
    // Tek sorguda tüm listelerin videoları (liste başına ayrı istek yok)
    foreach ($playlists as $pl) $plVideos[$pl['id']] = [];
    if ($playlists) {
        $r = $db->select('playlist_videos', 'playlist_id=in.(' . implode(',', array_column($playlists, 'id')) . ')&order=position.asc&select=playlist_id,videos(id,title,thumbnail_url,duration,views,status,created_at)', true);
        foreach (($r['data'] ?? []) as $x) {
            $v = $x['videos'] ?? null;
            if ($v && ($v['status'] ?? '') === 'published') $plVideos[$x['playlist_id']][] = $v;
        }
    }
}
$pageTitle = e($channel['name']) . ' Kanalı';
$metaDesc  = truncate($channel['description'] ?? ($channel['name'] . ' kanalının videolarını izleyin.'), 160);
?>
<?php
function renderChannelGrid(array $list) { ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <?php foreach ($list as $video): ?>
                        <a href="<?= APP_URL ?>/video?id=<?= $video['id'] ?>" class="group video-card rounded-2xl overflow-hidden block">
                            <div class="relative overflow-hidden bg-gray-800" style="aspect-ratio:16/9;">
                                <img src="<?= e($video['thumbnail_url'] ?: 'https://placehold.co/1280x720/070711/00f5ff?text=NeonTV') ?>"
                                     alt="<?= e($video['title']) ?>"
                                     class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                                <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                <?php if (!empty($video['duration'])): ?>
                                <div class="absolute bottom-2 right-2 text-[10px] font-bold px-1.5 py-0.5 rounded"
                                     style="background:rgba(0,0,0,0.8);color:#fff;">
                                    <?= formatDuration((int)$video['duration']) ?>
                                </div>
                                <?php endif; ?>
                                <div class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all scale-75 group-hover:scale-100 duration-300">
                                    <div class="w-12 h-12 rounded-full flex items-center justify-center"
                                         style="background:rgba(0,245,255,0.9);color:#000;box-shadow:0 0 30px rgba(0,245,255,0.6);">
                                        <i class="fa-solid fa-play ml-1"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="p-4">
                                <h3 class="font-bold text-white mb-2 leading-snug group-hover:text-cyan-400 transition-colors"
                                    style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">
                                    <?= e($video['title']) ?>
                                </h3>
                                <div class="flex items-center text-xs text-gray-500 gap-3">
                                    <span><i class="fa-solid fa-eye mr-1"></i><?= formatNumber((int)($video['views'] ?? 0)) ?></span>
                                    <span><i class="fa-regular fa-clock mr-1"></i><?= timeAgo($video['created_at']) ?></span>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
<?php } ?>
<?php include __DIR__ . '/components/header.php'; ?>

<style>
.channel-cover {
    width: 100%;
    height: 220px;
    object-fit: cover;
    background: linear-gradient(135deg, rgba(0,245,255,0.2), rgba(191,0,255,0.2));
}
.cover-gradient {
    background: linear-gradient(to top, #070711 0%, transparent 100%);
}
.video-card {
    background: rgba(255, 255, 255, 0.02);
    border: 1px solid rgba(255, 255, 255, 0.05);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}
.video-card:hover {
    transform: translateY(-5px);
    border-color: rgba(191, 0, 255, 0.3);
    box-shadow: 0 10px 30px -10px rgba(191, 0, 255, 0.2);
}
</style>

<div class="max-w-screen-2xl mx-auto">
    <!-- Cover -->
    <div class="relative w-full overflow-hidden" style="height:220px;background:#0d0d1a;">
        <?php if (!empty($channel['cover_url'])): ?>
            <img src="<?= e($channel['cover_url']) ?>" class="w-full h-full object-cover">
        <?php else: ?>
            <div class="w-full h-full" style="background:linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.15));"></div>
        <?php endif; ?>
        <div class="absolute inset-0 cover-gradient"></div>
    </div>

    <!-- Channel Info -->
    <div class="max-w-screen-xl mx-auto px-4 sm:px-6 relative -mt-16 md:-mt-20 pb-8">
        <div class="flex flex-col md:flex-row items-center md:items-end gap-6 pb-8" style="border-bottom:1px solid rgba(255,255,255,0.08);">
            <!-- Avatar -->
            <div class="w-28 h-28 md:w-36 md:h-36 rounded-full border-4 overflow-hidden flex items-center justify-center text-5xl font-bold shrink-0 bg-gray-800 text-white"
                 style="border-color:#070711;box-shadow:0 0 30px rgba(0,245,255,0.2);">
                <?php if (!empty($channel['avatar_url'])): ?>
                    <img src="<?= e($channel['avatar_url']) ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <?= strtoupper(substr($channel['name'], 0, 1)) ?>
                <?php endif; ?>
            </div>

            <!-- Text -->
            <div class="flex-grow text-center md:text-left">
                <h1 class="text-3xl md:text-4xl font-bold text-white mb-2"><?= e($channel['name']) ?></h1>
                <p class="text-gray-400 max-w-2xl text-sm md:text-base leading-relaxed">
                    <?= e($channel['description'] ?: 'Bu kanal için henüz bir açıklama girilmedi.') ?>
                </p>
                <div class="flex items-center gap-4 mt-3 justify-center md:justify-start">
                    <span class="text-sm text-gray-500">
                        <i class="fa-solid fa-film mr-1" style="color:#00f5ff;"></i>
                        <?= count($videos) ?> Video
                    </span>
                </div>
            </div>

            <!-- Action -->
            <div class="shrink-0">
                <button id="channel-subscribe-btn" data-channel-id="<?= e($channel['id']) ?>"
                        class="px-6 py-3 rounded-full font-bold text-sm transition-all hover:scale-105"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;box-shadow:0 0 20px rgba(0,245,255,0.3);">
                    <i class="fa-solid fa-bell mr-1.5"></i>Abone Ol
                </button>
                <button id="channel-block-btn" type="button" class="block mx-auto mt-2 text-xs text-gray-600 hover:text-pink-400"><i class="fa-solid fa-ban mr-1"></i><span>Kanalı engelle</span></button>
            </div>
        </div>

        <!-- Sekmeler -->
        <div class="flex gap-1 overflow-x-auto pt-6" style="border-bottom:1px solid rgba(255,255,255,0.06);">
            <?php foreach (['videos' => 'Videolar', 'popular' => 'Popüler', 'playlists' => 'Oynatma Listeleri', 'community' => 'Topluluk', 'about' => 'Hakkında'] as $k => $lbl): ?>
            <a href="?id=<?= e($channel['id']) ?>&tab=<?= $k ?>" data-tab="<?= $k ?>"
               class="ch-tab px-4 py-2.5 text-sm font-semibold whitespace-nowrap <?= $tab === $k ? 'text-cyan-400' : 'text-gray-400 hover:text-white' ?>"
               style="<?= $tab === $k ? 'border-bottom:2px solid #00f5ff;' : '' ?>"><?= $lbl ?></a>
            <?php endforeach; ?>
        </div>

        <div class="py-8">
        <div class="ch-panel" data-tab="about" <?= $tab !== 'about' ? 'hidden' : '' ?>>
            <div class="max-w-2xl space-y-4">
                <p class="text-gray-300 leading-relaxed"><?= nl2br(e($channel['description'] ?: 'Bu kanal için henüz bir açıklama girilmedi.')) ?></p>
                <div class="grid grid-cols-3 gap-3 text-center">
                    <div class="p-4 rounded-xl" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);"><div class="text-xl font-bold text-white"><?= count($videos) ?></div><div class="text-xs text-gray-500">Video</div></div>
                    <div class="p-4 rounded-xl" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);"><div class="text-xl font-bold text-white"><?= formatNumber($totalViews) ?></div><div class="text-xs text-gray-500">Toplam izlenme</div></div>
                    <div class="p-4 rounded-xl" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);"><div class="text-sm font-bold text-white"><?= !empty($channel['created_at']) ? e(date('d.m.Y', strtotime($channel['created_at']))) : '-' ?></div><div class="text-xs text-gray-500">Katılma tarihi</div></div>
                </div>
            </div>
        </div><div class="ch-panel" data-tab="community" <?= $tab !== 'community' ? 'hidden' : '' ?>>
            <div class="max-w-2xl space-y-3">
            <?php if (empty($posts)): ?>
                <p class="text-gray-500 text-center py-10">Bu kanal henüz bir duyuru paylaşmadı.</p>
            <?php else: foreach ($posts as $po): ?>
                <div class="p-4 rounded-2xl" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);">
                    <div class="flex items-center gap-2 mb-2 text-xs text-gray-500"><i class="fa-solid fa-bullhorn text-cyan-400"></i><span class="font-semibold text-gray-300"><?= e($channel['name']) ?></span> · <?= timeAgo($po['created_at']) ?></div>
                    <p class="text-gray-200 text-sm leading-relaxed whitespace-pre-wrap"><?= e($po['content']) ?></p>
                    <?php if (!empty($po['image_url'])): $pimg = preg_match('#^https://#i', $po['image_url']) ? $po['image_url'] : APP_URL . '/' . ltrim($po['image_url'], '/'); ?>
                    <img src="<?= e($pimg) ?>" alt="" loading="lazy" class="mt-3 rounded-xl max-h-96 w-auto max-w-full" style="border:1px solid rgba(255,255,255,0.08)">
                    <?php endif; ?>
                    <?php if (!empty($po['poll'])): $popts = is_array($po['poll']) ? $po['poll'] : (json_decode($po['poll'], true) ?: []); ?>
                    <div class="poll-box mt-3 space-y-2" data-post="<?= e($po['id']) ?>" data-opts="<?= e(json_encode(array_values($popts), JSON_UNESCAPED_UNICODE)) ?>" data-ends="<?= e($po['poll_ends_at'] ?? '') ?>"></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; endif; ?>
            </div>
        </div><div class="ch-panel" data-tab="playlists" <?= $tab !== 'playlists' ? 'hidden' : '' ?>>
            <?php if (empty($playlists)): ?>
                <p class="text-center text-gray-500 py-16">Bu kanalda henüz oynatma listesi yok.</p>
            <?php else: foreach ($playlists as $pl): ?>
                <h3 class="text-lg font-bold text-white mb-1"><i class="fa-solid fa-list-ul mr-2" style="color:#bf00ff;"></i><?= e($pl['title']) ?></h3>
                <?php if (!empty($pl['description'])): ?><p class="text-sm text-gray-500 mb-3"><?= e($pl['description']) ?></p><?php endif; ?>
                <?php if (empty($plVideos[$pl['id']])): ?><p class="text-sm text-gray-600 mb-8">Bu listede video yok.</p>
                <?php else: renderChannelGrid($plVideos[$pl['id']]); echo '<div class="mb-10"></div>'; endif; ?>
            <?php endforeach; endif; ?>
        </div><?php foreach (['videos' => $videos, 'popular' => $popular] as $pk => $list): ?><div class="ch-panel" data-tab="<?= $pk ?>" <?= $tab !== $pk ? 'hidden' : '' ?>>
            <?php if (empty($list)): ?>
                <div class="text-center py-20 rounded-3xl" style="background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);">
                    <i class="fa-solid fa-video-slash text-5xl mb-4 block opacity-30"></i>
                    <p class="text-lg text-gray-500">Bu kanalda henüz video bulunmuyor.</p>
                </div>
            <?php else: renderChannelGrid($list); endif; ?>
            </div><?php endforeach; ?>
        </div>
    </div>
</div>

<script>
// Topluluk anketleri
window.addEventListener('load', async function () {
    const boxes = document.querySelectorAll('.poll-box'); if (!boxes.length) return;
    const BASE = '<?= APP_URL ?>';
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    let t = null; try { const { data } = await sbClient.auth.getSession(); t = data.session ? data.session.access_token : null; } catch (e) {}
    if (!t) { try { t = localStorage.getItem('sb_access_token'); } catch (e) {} }
    const H = t ? { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };
    const Q = t ? '&token=' + encodeURIComponent(t) : '';
    function draw(box, st) {
        const opts = JSON.parse(box.dataset.opts), total = st.counts.reduce((a, b) => a + b, 0), show = st.mine !== null || st.ended;
        box.innerHTML = opts.map((o, i) => {
            const n = st.counts[i] || 0, pct = total ? Math.round(n * 100 / total) : 0;
            return show
                ? '<div class="relative rounded-xl overflow-hidden text-sm" style="background:rgba(255,255,255,0.05)"><div style="position:absolute;inset:0;width:' + pct + '%;background:' + (st.mine === i ? 'rgba(0,245,255,0.28)' : 'rgba(255,255,255,0.10)') + '"></div><div class="relative flex justify-between px-3 py-2 text-gray-100"><span>' + esc(o) + (st.mine === i ? ' ✓' : '') + '</span><b>' + pct + '%</b></div></div>'
                : '<button type="button" data-i="' + i + '" class="poll-opt w-full text-left px-3 py-2 rounded-xl text-sm text-gray-100 hover:bg-white/10" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1)">' + esc(o) + '</button>';
        }).join('') + '<p class="text-[11px] text-gray-500">' + total + ' oy' + (st.ended ? ' · anket sona erdi' : (box.dataset.ends ? ' · bitiş ' + new Date(box.dataset.ends).toLocaleString('tr-TR') : '')) + '</p>';
    }
    boxes.forEach(async box => {
        try { const j = await (await fetch(BASE + '/api/poll.php?post_id=' + encodeURIComponent(box.dataset.post) + Q, { headers: H })).json(); if (j.success) draw(box, j.data); } catch (e) {}
        box.addEventListener('click', async e => {
            const b = e.target.closest('.poll-opt'); if (!b) return;
            if (!t) { location.href = BASE + '/auth.php'; return; }
            const j = await (await fetch(BASE + '/api/poll.php?token=' + encodeURIComponent(t), { method: 'POST', headers: H, body: JSON.stringify({ post_id: box.dataset.post, option: parseInt(b.dataset.i, 10) }) })).json();
            if (j.success) draw(box, j.data); else alert(j.message || 'Oy verilemedi');
        });
    });
});
</script>
<script>
// Sekmeler: tüm içerik ilk yüklemede geldi, geçiş anında (sayfa yenilemeden)
(function () {
    const tabs = document.querySelectorAll('.ch-tab'), panels = document.querySelectorAll('.ch-panel');
    function show(k) {
        panels.forEach(p => { p.hidden = p.dataset.tab !== k; });
        tabs.forEach(t => { const on = t.dataset.tab === k; t.classList.toggle('text-cyan-400', on); t.classList.toggle('text-gray-400', !on); t.style.borderBottom = on ? '2px solid #00f5ff' : ''; });
    }
    tabs.forEach(t => t.addEventListener('click', e => {
        e.preventDefault(); show(t.dataset.tab);
        try { history.replaceState(null, '', t.getAttribute('href')); } catch (x) {}
    }));
})();
</script>
<script>
// Abone ol butonu
document.getElementById('channel-subscribe-btn')?.addEventListener('click', async function() {
    let token = getAuthToken();
    try { const { data: { session } } = await sbClient.auth.getSession(); if (session) token = session.access_token; } catch (e) {}
    if (!token) {
        window.location.href = '<?= APP_URL ?>/auth.php';
        return;
    }
    const btn = this;
    const channelId = btn.dataset.channelId;
    const wasSubscribed = btn.dataset.subscribed === 'true';
    
    // Anında göster (sunucu yanıtı gelince doğrulanır, hata olursa geri alınır)
    setSubscribed(btn, !wasSubscribed);
    btn.disabled = true;
    
    try {
        const res = await fetch('<?= APP_URL ?>/api/channels.php?subscribe=' + channelId + '&token=' + token, {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' }
        });
        const resp = await res.json();
        if (!resp.success) throw new Error(resp.message || 'İşlem başarısız');
        setSubscribed(btn, !!((resp.data && resp.data.subscribed) || resp.subscribed));
    } catch(e) {
        alert(e.message || 'Abone olunamadı. Lütfen tekrar deneyin.');
        setSubscribed(btn, wasSubscribed);
    }
    btn.disabled = false;
});

function setSubscribed(btn, on) {
    btn.dataset.subscribed = on ? 'true' : 'false';
    try { localStorage.setItem('sub_' + btn.dataset.channelId, on ? '1' : '0'); } catch (e) {}
    if (on) {
        btn.innerHTML = '<i class="fa-solid fa-check mr-1.5"></i>Abone Olundu';
        btn.style.background = 'rgba(0,245,255,0.15)';
        btn.style.color = '#00f5ff';
        btn.style.border = '1px solid rgba(0,245,255,0.4)';
    } else {
        btn.innerHTML = '<i class="fa-solid fa-bell mr-1.5"></i>Abone Ol';
        btn.style.background = '';
        btn.style.color = '';
        btn.style.border = '';
    }
}

// Sayfa açılışında mevcut abonelik durumunu göster (sbClient footer'da tanımlanır)
document.addEventListener('DOMContentLoaded', async function () {
    const btn = document.getElementById('channel-subscribe-btn');
    if (!btn) return;
    // Önbellekten hemen göster
    try { if (localStorage.getItem('sub_' + btn.dataset.channelId) === '1') setSubscribed(btn, true); } catch (e) {}
    try {
        const { data: { session } } = await sbClient.auth.getSession();
        if (!session) return;
        const res = await fetch('<?= APP_URL ?>/api/channels.php?check_subscribe=' + encodeURIComponent(btn.dataset.channelId) + '&token=' + session.access_token, {
            headers: { 'Authorization': 'Bearer ' + session.access_token }
        });
        const resp = await res.json();
        setSubscribed(btn, !!((resp.data && resp.data.subscribed) || resp.subscribed));
    } catch (e) {}
});

// Kanalı engelle / engeli kaldır
window.addEventListener('load', async function () {
    const b = document.getElementById('channel-block-btn'); if (!b) return;
    const CID = <?= json_encode($channel['id']) ?>, BASE = <?= json_encode(APP_URL) ?>;
    let t = null; try { const { data } = await sbClient.auth.getSession(); t = data.session ? data.session.access_token : null; } catch (e) {}
    const h = () => ({ 'Authorization': 'Bearer ' + t, 'X-Access-Token': t, 'Content-Type': 'application/json' });
    const paint = on => { b.querySelector('span').textContent = on ? 'Engeli kaldır' : 'Kanalı engelle'; b.dataset.on = on ? '1' : ''; };
    if (t) { try { const j = await (await fetch(BASE + '/api/blocks.php?token=' + encodeURIComponent(t), { headers: h() })).json(); paint(!!(j.data && j.data.channels.some(c => c.id === CID))); } catch (e) {} }
    b.addEventListener('click', async () => {
        if (!t) { location.href = BASE + '/auth.php'; return; }
        const want = !b.dataset.on;
        try { const j = await (await fetch(BASE + '/api/blocks.php?token=' + encodeURIComponent(t), { method: 'POST', headers: h(), body: JSON.stringify({ kind: 'channel', target_id: CID, block: want }) })).json(); if (j.success) { paint(j.data.blocked); try { sessionStorage.removeItem('neon_blocks'); } catch (e) {} } } catch (e) {}
    });
});
</script>

<?php include __DIR__ . '/components/footer.php'; ?>
