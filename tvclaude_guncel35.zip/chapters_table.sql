-- Supabase SQL Editor'da çalıştırın
CREATE TABLE IF NOT EXISTS public.chapters (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id   UUID NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    title      TEXT NOT NULL,
    start_time INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.chapters ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "chapters_public_read" ON public.chapters;
CREATE POLICY "chapters_public_read" ON public.chapters FOR SELECT USING (true);
