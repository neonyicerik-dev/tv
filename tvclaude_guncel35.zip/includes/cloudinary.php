<?php
// ============================================================
// NeonTV - Cloudinary Helper Sınıfı
// ============================================================
require_once __DIR__ . '/config.php';

class Cloudinary {
    private string $cloudName;
    private string $apiKey;
    private string $apiSecret;

    public function __construct() {
        $this->cloudName = CLOUDINARY_CLOUD_NAME;
        $this->apiKey    = CLOUDINARY_API_KEY;
        $this->apiSecret = CLOUDINARY_API_SECRET;
    }

    // --------------------------------------------------------
    // Chunked Upload için İmza Oluşturma
    // Tarayıcı doğrudan Cloudinary'e yükler, PHP sadece imzalar
    // --------------------------------------------------------
    public function generateUploadSignature(array $params = []): array {
        $timestamp = time();

        // İmzalanacak parametreler
        $signParams = array_merge($params, ['timestamp' => $timestamp]);

        // api_key, file, resource_type imzalanmaz
        $exclude = ['api_key', 'file', 'resource_type', 'cloud_name'];
        foreach ($exclude as $key) {
            unset($signParams[$key]);
        }

        // Alfabetik sıralama
        ksort($signParams);

        // İmza string'i oluştur
        $signStr = '';
        foreach ($signParams as $key => $value) {
            if ($signStr !== '') $signStr .= '&';
            $signStr .= $key . '=' . $value;
        }
        $signStr .= $this->apiSecret;

        return [
            'timestamp'  => $timestamp,
            'signature'  => sha1($signStr),
            'api_key'    => $this->apiKey,
            'cloud_name' => $this->cloudName,
        ];
    }

    // --------------------------------------------------------
    // Thumbnail (Resim) için İmza
    // --------------------------------------------------------
    public function generateImageSignature(array $params = []): array {
        return $this->generateUploadSignature($params);
    }

    // --------------------------------------------------------
    // Cloudinary'den Kaynak Silme
    // --------------------------------------------------------
    public function deleteResource(string $publicId, string $resourceType = 'video'): array {
        $timestamp = time();
        $signStr   = "public_id={$publicId}&timestamp={$timestamp}" . $this->apiSecret;
        $signature = sha1($signStr);

        $url = "https://api.cloudinary.com/v1_1/{$this->cloudName}/{$resourceType}/destroy";

        $ch = curl_init();
        $dOpts = [
            CURLOPT_URL            => $url,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query([
                'public_id'  => $publicId,
                'timestamp'  => $timestamp,
                'api_key'    => $this->apiKey,
                'signature'  => $signature,
            ]),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT        => 15,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') $dOpts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        curl_setopt_array($ch, $dOpts);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true) ?? [];
    }

    // --------------------------------------------------------
    // URL Helpers
    // --------------------------------------------------------
    public function getVideoUrl(string $publicId, array $transformations = []): string {
        $transform = '';
        if (!empty($transformations)) {
            $parts = [];
            foreach ($transformations as $key => $val) {
                $parts[] = $key . '_' . $val;
            }
            $transform = implode(',', $parts) . '/';
        }
        return "https://res.cloudinary.com/{$this->cloudName}/video/upload/{$transform}{$publicId}";
    }

    public function getImageUrl(string $publicId, array $transformations = []): string {
        $transform = '';
        if (!empty($transformations)) {
            $parts = [];
            foreach ($transformations as $key => $val) {
                $parts[] = $key . '_' . $val;
            }
            $transform = implode(',', $parts) . '/';
        }
        return "https://res.cloudinary.com/{$this->cloudName}/image/upload/{$transform}{$publicId}";
    }

    // Video'dan sadece ses (MP3) URL'i - altyazı çıkarma için (16kbps ile yüksek sıkıştırma, 40dk video = ~4.8MB)
    public function getAudioUrl(string $publicId): string {
        return "https://res.cloudinary.com/{$this->cloudName}/video/upload/br_16k,f_mp3/{$publicId}.mp3";
    }

    // Thumbnail boyutlandırma
    public function getThumbnailUrl(string $thumbnailUrl, int $width = 640, int $height = 360): string {
        // Zaten tam URL ise Cloudinary transformasyonu ekle
        if (strpos($thumbnailUrl, 'res.cloudinary.com') !== false) {
            return preg_replace(
                '#/upload/#',
                "/upload/w_{$width},h_{$height},c_fill,q_auto,f_auto/",
                $thumbnailUrl
            );
        }
        return $thumbnailUrl;
    }

    // --------------------------------------------------------
    // Ses Dosyasını Sunucudan İndir (altyazı çıkarma için)
    // --------------------------------------------------------
    public function downloadAudio(string $publicId): ?string {
        $audioUrl = $this->getAudioUrl($publicId);

        $ch = curl_init();
        $aOpts = [
            CURLOPT_URL            => $audioUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_MAXREDIRS      => 3,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') $aOpts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        curl_setopt_array($ch, $aOpts);

        $data     = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $size     = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
        curl_close($ch);

        if ($httpCode !== 200 || empty($data)) return null;

        // Boyut limiti: 25MB (Gemini Files API limiti)
        if (strlen($data) > 25 * 1024 * 1024) return null;

        return $data;
    }

    // --------------------------------------------------------
    // Video'nun Kısa Bir Kısmını İndir (AI Görüntü Analizi İçin)
    // $startOffset: başlangıç saniyesi (varsayılan 0 = baştan)
    // --------------------------------------------------------
    public function downloadVideoClip(string $publicId, int $startOffset = 0): ?string {
        $so = $startOffset > 0 ? $startOffset : 0;
        $eo = $so + 8;
        $videoUrl = "https://res.cloudinary.com/{$this->cloudName}/video/upload/c_limit,w_480/q_auto:low/so_{$so},eo_{$eo}/{$publicId}.mp4";

        $ch = curl_init();
        $vOpts = [
            CURLOPT_URL            => $videoUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 90,
            CURLOPT_MAXREDIRS      => 3,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') $vOpts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        curl_setopt_array($ch, $vOpts);

        $data     = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200 || empty($data)) return null;

        // Boyut limiti: 19MB (Gemini inline_data limiti)
        if (strlen($data) > 19 * 1024 * 1024) return null;

        return $data;
    }

    // --------------------------------------------------------
    // Videonun Süresini Cloudinary API ile Öğren
    // --------------------------------------------------------
    public function getVideoDuration(string $publicId): ?float {
        $url = "https://res.cloudinary.com/{$this->cloudName}/video/upload/fl_attachment/{$publicId}.mp4";
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_NOBODY         => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 15,
        ]);
        curl_exec($ch);
        curl_close($ch);
        
        // Cloudinary Admin API ile süre bilgisini al
        $apiUrl = "https://api.cloudinary.com/v1_1/{$this->cloudName}/resources/video/upload/{$publicId}";
        
        $ch = curl_init();
        $durationOpts = [
            CURLOPT_URL            => $apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_USERPWD        => "{$this->apiKey}:{$this->apiSecret}",
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') $durationOpts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        curl_setopt_array($ch, $durationOpts);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) return null;
        
        $data = json_decode($response, true);
        return $data['duration'] ?? null;
    }

    // --------------------------------------------------------
    // Upload URL'i
    // --------------------------------------------------------
    public function getUploadUrl(string $resourceType = 'video'): string {
        return "https://api.cloudinary.com/v1_1/{$this->cloudName}/{$resourceType}/upload";
    }
}
