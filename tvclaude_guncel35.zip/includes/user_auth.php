<?php
// Giriş yapmış site kullanıcısını (Supabase token) doğrular. API dosyaları için.
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/supabase.php';

function requireUserApi(Supabase $db): array {
    $token = getBearerToken();
    if (!$token) jsonResponse(['success' => false, 'message' => 'Giriş yapmalısın.', 'need_login' => true], 401);
    $user = $db->verifyToken($token);
    if (!$user || empty($user['id']) || !isUuid($user['id'])) {
        jsonResponse(['success' => false, 'message' => 'Oturum geçersiz.', 'need_login' => true], 401);
    }
    return $user;
}


// ---- Kullanıcı yasakları (admin > Kullanıcılar) ----
function activeBan(Supabase $db, string $uid): ?array {
    try {
        $r = $db->first('user_bans', 'user_id=eq.' . urlencode($uid), true);
    } catch (\Throwable $e) { return null; }
    if (!$r || !is_array($r)) return null;
    if (!empty($r['banned_until']) && strtotime($r['banned_until']) <= time()) return null;
    return $r;
}
function banMessage(array $b): string {
    $m = 'Hesabın askıya alındı';
    $m .= empty($b['banned_until']) ? ' (kalıcı)' : ' (' . date('d.m.Y H:i', strtotime($b['banned_until'])) . ' tarihine kadar)';
    if (!empty($b['reason'])) $m .= ': ' . $b['reason'];
    return $m . '. Yorum, puan ve etkileşim yapamazsın.';
}
function denyIfBanned(Supabase $db, string $uid): void {
    $b = activeBan($db, $uid);
    if ($b) jsonResponse(['success' => false, 'message' => banMessage($b), 'banned' => true], 403);
}
