<?php
// ============================================================
// NeonTV - Basit Video Oynatma Sayfası (Playerjs)
// Kullanım: izle.php?id=<video-uuid>
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';

if (isMaintenanceMode() && !isAdminLoggedIn()) {
    die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>Bakım Modu</title><style>body{background:#070711;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;padding:20px;}h1{color:#00f5ff;}</style></head><body><div><h1>Bakım Modu</h1><p>' . htmlspecialchars(getMaintenanceMessage()) . '</p></div></body></html>');
}

// IP Engel Kontrolü
if (isIpBlocked()) {
    http_response_code(403);
    die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>Erisim Engellendi</title><style>body{background:#070711;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;}h1{color:#ff007a;}</style></head><body><div><h1>🚫 Erisim Engellendi</h1><p>IP adresiniz bu platforma erişim engellenmiştir.</p></div></body></html>');
}

// Ziyareti kaydet
logVisit();

// video.php ile aynı url/parametre yapısı: ?id=<uuid>
$videoId = trim($_GET['id'] ?? '');
if (!$videoId || !preg_match('/^[0-9a-f\-]{36}$/', $videoId)) {
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$db       = new Supabase();
$videoRes = $db->select('videos', 'id=eq.' . $videoId . '&status=eq.published&select=*');
$video    = $videoRes['data'][0] ?? null;

if (!$video) {
    require_once __DIR__ . '/404.php';
    exit;
}

// video.php ile aynı altyazı sorgusu (TR altyazı)
$subtitle = $db->first('subtitles', 'video_id=eq.' . $videoId . '&language=eq.tr');

// Playerjs "subtitle" parametresi: [Dil Adı]url formatında bekler.
// VTT içeriğini data URI olarak gömüyoruz (video.php'deki <track> mantığının aynısı).
$subtitleParam = '';
if ($subtitle) {
    $subtitleParam = '[Türkçe]data:text/vtt;charset=utf-8;base64,' . base64_encode($subtitle['content']);
}

$pageTitle = $video['title'];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($video['title']) ?></title>
<style>
    * { box-sizing: border-box; }
    body {
        margin: 0;
        background: #070711;
        color: #fff;
        font-family: 'Outfit', Arial, sans-serif;
    }
    .wrap {
        max-width: 1100px;
        margin: 0 auto;
        padding: 24px 16px;
    }
    #player-container {
        width: 100%;
        aspect-ratio: 16 / 9;
        background: #000;
        border-radius: 1rem;
        overflow: hidden;
        box-shadow: 0 0 60px rgba(0, 245, 255, 0.08), 0 0 0 1px rgba(255,255,255,0.06);
    }
    h1#video-title {
        font-size: 1.4rem;
        font-weight: 700;
        margin: 18px 0 0;
        line-height: 1.3;
    }
    .subtitle-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin-top: 10px;
        padding: 4px 12px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 600;
        color: #00f5ff;
        background: rgba(0,245,255,0.08);
        border: 1px solid rgba(0,245,255,0.2);
    }
</style>
</head>
<body>

<div class="wrap">
    <div id="player-container">
        <div id="player"></div>
    </div>
    <h1 id="video-title"><?= e($video['title']) ?></h1>
    <?php if ($subtitle): ?>
    <div class="subtitle-badge">CC &nbsp;Altyazı (TR)</div>
    <?php endif; ?>
</div>

<!-- Aynı klasördeki playerjs.js oynatıcısı -->
<script src="playerjs.js"></script>
<script>
    new Playerjs({
        id:       "player",
        file:     "<?= e($video['video_url']) ?>",
        poster:   "<?= e($video['thumbnail_url'] ?? '') ?>",
        title:    "<?= e(addslashes($video['title'])) ?>"<?php if ($subtitleParam): ?>,
        subtitle: "<?= $subtitleParam ?>"<?php endif; ?>

    });
</script>

</body>
</html>
