<?php
// llms.txt: adresleri APP_URL'e göre günceller
require_once __DIR__ . '/includes/config.php';
header('Content-Type: text/plain; charset=utf-8');
$t = (string)@file_get_contents(__DIR__ . '/llms.txt');
echo preg_replace('#https?://neontv\.[a-z.]+#i', rtrim(APP_URL, '/'), $t);
