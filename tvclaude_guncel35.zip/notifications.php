<?php
// NeonTV - Bildirimler
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Bildirimler'; $metaDesc = 'NeonTV bildirimlerin.';
?>
<?php include __DIR__ . '/components/header.php'; ?>
<div class="max-w-screen-md mx-auto px-4 sm:px-6 py-8">
    <div class="flex items-center mb-5"><h1 class="text-xl font-bold text-white"><i class="fa-solid fa-bell text-cyan-400 mr-2"></i>Bildirimler</h1>
        <button id="read-all" class="ml-auto text-xs text-gray-500 hover:text-cyan-400">Tümünü okundu say</button></div>
    <div id="push-box" class="hidden mb-4 p-3 rounded-xl flex items-center gap-3 text-sm" style="background:rgba(0,245,255,0.06);border:1px solid rgba(0,245,255,0.25)">
        <i class="fa-solid fa-mobile-screen-button text-cyan-400"></i><span id="push-text" class="text-gray-300 flex-1">Yeni yanıt, anma ve takipçi bildirimlerini tarayıcı bildirimi olarak al.</span>
        <button type="button" id="push-btn" class="px-3 py-1.5 rounded-lg text-xs font-bold text-black" style="background:#00f5ff">Aç</button>
    </div>
    <div id="n-msg" class="text-gray-500 text-sm py-10 text-center">Yükleniyor...</div>
    <div id="n-list" class="space-y-2"></div>
</div>
<script>
window.addEventListener('load', async function () {
    const BASE = '<?= APP_URL ?>', msg = document.getElementById('n-msg'), box = document.getElementById('n-list');
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    let t = null; try { const { data } = await sbClient.auth.getSession(); t = data.session ? data.session.access_token : null; } catch (e) {} if (!t) { try { t = localStorage.getItem('sb_access_token'); } catch (e) {} }
    if (!t) { msg.innerHTML = 'Bildirimleri görmek için <a class="text-cyan-400 underline" href="' + BASE + '/auth.php">giriş yap</a>.'; return; }
    const h = { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t };
    const q = '?token=' + encodeURIComponent(t);
    document.getElementById('read-all').onclick = async () => { await fetch(BASE + '/api/notifications.php' + q, { method: 'POST', headers: h }); location.reload(); };
    try {
        const j = await (await fetch(BASE + '/api/notifications.php' + q, { headers: h })).json();
        const it = (j.data && j.data.items) || [];
        if (!it.length) { msg.textContent = 'Bildirimin yok.'; return; }
        msg.remove();
        box.innerHTML = it.map(n => {
            const href = n.link && n.link.startsWith('/') ? BASE + n.link : '#';
            return '<a href="' + esc(href) + '" class="block px-4 py-3 rounded-xl text-sm text-gray-200 hover:text-white" style="background:' + (n.is_read ? 'rgba(255,255,255,0.03)' : 'rgba(0,245,255,0.08)') + ';border:1px solid rgba(255,255,255,0.08)">' +
                (n.is_read ? '' : '<span class="inline-block w-2 h-2 rounded-full mr-2" style="background:#00f5ff"></span>') + esc(n.message) +
                '<span class="block text-[11px] text-gray-500 mt-1">' + esc(new Date(n.created_at).toLocaleString('tr-TR')) + '</span></a>';
        }).join('');
    } catch (e) { msg.textContent = 'Yüklenemedi.'; }
});

// ===== Web push aç/kapat =====
(async function () {
    const BASE = <?= json_encode(APP_URL) ?>, box = document.getElementById('push-box'), btn = document.getElementById('push-btn'), txt = document.getElementById('push-text');
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) return;
    let t = null; try { const { data } = await sbClient.auth.getSession(); t = data.session ? data.session.access_token : null; } catch (e) {} if (!t) return;
    const H = { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t, 'Content-Type': 'application/json' }, q = '?token=' + encodeURIComponent(t);
    const reg = await navigator.serviceWorker.register(BASE + '/sw.js').catch(() => null); if (!reg) return;
    box.classList.remove('hidden');
    const b64 = s => { const p = '='.repeat((4 - s.length % 4) % 4), r = atob((s + p).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from([...r].map(c => c.charCodeAt(0))); };
    async function paint() { const sub = await reg.pushManager.getSubscription(); btn.dataset.on = sub ? '1' : ''; btn.textContent = sub ? 'Kapat' : 'Aç'; txt.textContent = sub ? 'Bu cihazda tarayıcı bildirimleri açık.' : 'Yeni yanıt, anma ve takipçi bildirimlerini tarayıcı bildirimi olarak al.'; if (Notification.permission === 'denied') { txt.textContent = 'Tarayıcı bildirimleri engellenmiş; site ayarlarından izin ver.'; btn.disabled = true; } }
    btn.onclick = async () => {
        btn.disabled = true;
        try {
            const cur = await reg.pushManager.getSubscription();
            if (cur) { await fetch(BASE + '/api/push.php' + q, { method: 'POST', headers: H, body: JSON.stringify({ action: 'unsubscribe', endpoint: cur.endpoint }) }); await cur.unsubscribe(); }
            else {
                if (await Notification.requestPermission() !== 'granted') { await paint(); return; }
                const k = (await (await fetch(BASE + '/api/push.php?action=key')).json()).data.key;
                const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64(k) });
                const r = await (await fetch(BASE + '/api/push.php' + q, { method: 'POST', headers: H, body: JSON.stringify({ action: 'subscribe', endpoint: sub.endpoint }) })).json();
                if (!r.success) { await sub.unsubscribe(); txt.textContent = r.message || 'Açılamadı.'; }
            }
        } catch (e) { txt.textContent = 'Açılamadı: tarayıcı desteklemiyor olabilir.'; }
        btn.disabled = false; await paint();
    };
    await paint();
})();
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
