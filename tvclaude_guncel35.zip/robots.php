<?php
// Dinamik robots.txt (adres APP_URL'den gelir; domain değişse bile doğru kalır)
require_once __DIR__ . '/includes/config.php';
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: public, max-age=3600');
$base = rtrim(APP_URL, '/');
?>
User-agent: *
Allow: /
Disallow: /admin/
Disallow: /includes/
Disallow: /api/
Disallow: /logs/
Disallow: /cc_test.php
Disallow: /sync.php
Disallow: /hash.txt
Disallow: /player2.php
Disallow: /izle.php
Disallow: /library.php
Disallow: /notifications.php
Disallow: /subscriptions.php
Disallow: /random.php
Disallow: /myprofile
Disallow: /auth.php
Disallow: /search.php?*

Sitemap: <?= $base ?>/sitemap.xml
<?php
