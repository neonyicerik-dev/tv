<?php
// ============================================================
// NeonTV - Dinamik XML Sitemap
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/supabase.php';

// Bakım modunda bile sitemap erişilebilir olsun
// Sadece published içerik gösterilir

$db = new Supabase();

// Tüm yayınlanmış videoları çek
$videosRes = $db->select('videos',
    'status=eq.published&order=updated_at.desc&limit=5000&select=id,title,description,thumbnail_url,video_url,duration,created_at,updated_at',
    true
);
$videos = $videosRes['data'] ?? [];

// Tüm kanalları çek
$channelsRes = $db->select('channels',
    'select=id,name,created_at,updated_at&order=updated_at.desc',
    true
);
$channels = $channelsRes['data'] ?? [];

// Settings.json'dan ayarları oku
require_once __DIR__ . '/includes/store.php';
$settings = loadSettingsCompat();
$changefreq = $settings['sitemap_changefreq'] ?? 'weekly';

// XML başlığı
header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');

// Çıktı tamponlaması
ob_start();

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
        xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">

    <!-- ===== STATİK SAYFALAR ===== -->

    <!-- Ana Sayfa -->
    <url>
        <loc><?= htmlspecialchars(APP_URL . '/index.php', ENT_XML1) ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>

    <!-- Arama -->
    <url>
        <loc><?= htmlspecialchars(APP_URL . '/search.php', ENT_XML1) ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq>daily</changefreq>
        <priority>0.6</priority>
    </url>

    <!-- Uygulama / İletişim -->
    <url>
        <loc><?= htmlspecialchars(APP_URL . '/app.php', ENT_XML1) ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.5</priority>
    </url>
    <url>
        <loc><?= htmlspecialchars(APP_URL . '/iletisim.php', ENT_XML1) ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq>yearly</changefreq>
        <priority>0.3</priority>
    </url>

    <!-- Giriş / Kayıt -->
    <url>
        <loc><?= htmlspecialchars(APP_URL . '/auth.php', ENT_XML1) ?></loc>
        <lastmod><?= date('Y-m-d') ?></lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.4</priority>
    </url>

    <!-- ===== KANAL SAYFALARI ===== -->
<?php foreach ($channels as $channel):
    $channelUrl  = APP_URL . '/channel.php?id=' . urlencode($channel['id']);
    $lastmod     = isset($channel['updated_at'])
        ? date('Y-m-d', strtotime($channel['updated_at']))
        : date('Y-m-d');
?>
    <url>
        <loc><?= htmlspecialchars($channelUrl, ENT_XML1) ?></loc>
        <lastmod><?= $lastmod ?></lastmod>
        <changefreq><?= htmlspecialchars($changefreq, ENT_XML1) ?></changefreq>
        <priority>0.7</priority>
    </url>
<?php endforeach; ?>

    <!-- ===== VİDEO SAYFALARI ===== -->
<?php foreach ($videos as $video):
    $videoUrl   = APP_URL . '/video.php?id=' . urlencode($video['id']);
    $lastmod    = isset($video['updated_at'])
        ? date('Y-m-d', strtotime($video['updated_at']))
        : (isset($video['created_at'])
            ? date('Y-m-d', strtotime($video['created_at']))
            : date('Y-m-d'));

    // Başlık ve açıklama temizle (XML için güvenli)
    $title      = htmlspecialchars(trim($video['title'] ?? ''), ENT_XML1, 'UTF-8');
    $desc       = htmlspecialchars(mb_substr(trim($video['description'] ?? ''), 0, 300), ENT_XML1, 'UTF-8');
    $thumbnail  = $video['thumbnail_url'] ?? '';
?>
    <url>
        <loc><?= htmlspecialchars($videoUrl, ENT_XML1) ?></loc>
        <lastmod><?= $lastmod ?></lastmod>
        <changefreq><?= htmlspecialchars($changefreq, ENT_XML1) ?></changefreq>
        <priority>0.8</priority>
<?php if ($thumbnail): ?>
        <image:image>
            <image:loc><?= htmlspecialchars($thumbnail, ENT_XML1) ?></image:loc>
<?php if ($title): ?>
            <image:title><?= $title ?></image:title>
<?php endif; ?>
<?php if ($desc): ?>
            <image:caption><?= $desc ?></image:caption>
<?php endif; ?>
        </image:image>
<?php endif; ?>
<?php if ($thumbnail && !empty($video['video_url'])): ?>
        <video:video>
            <video:thumbnail_loc><?= htmlspecialchars($thumbnail, ENT_XML1) ?></video:thumbnail_loc>
            <video:title><?= $title !== '' ? $title : 'Video' ?></video:title>
            <video:description><?= $desc !== '' ? $desc : ($title !== '' ? $title : 'Video') ?></video:description>
            <video:content_loc><?= htmlspecialchars($video['video_url'], ENT_XML1) ?></video:content_loc>
            <video:player_loc><?= htmlspecialchars($videoUrl, ENT_XML1) ?></video:player_loc>
<?php if (!empty($video['duration'])): ?>
            <video:duration><?= (int)$video['duration'] ?></video:duration>
<?php endif; ?>
            <video:publication_date><?= gmdate('c', strtotime($video['created_at'] ?? 'now')) ?></video:publication_date>
            <video:family_friendly>no</video:family_friendly>
        </video:video>
<?php endif; ?>
    </url>
<?php endforeach; ?>

</urlset>
<?php
$content = ob_get_clean();
echo $content;
?>
