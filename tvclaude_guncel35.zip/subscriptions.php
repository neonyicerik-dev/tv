<?php
// NeonTV - Abonelikler akışı
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Abonelikler'; $metaDesc = 'Abone olduğun kanalların yeni videoları.';
?>
<?php include __DIR__ . '/components/header.php'; ?>
<div class="max-w-screen-2xl mx-auto px-4 sm:px-6 py-8">
    <h1 class="text-xl font-bold text-white mb-6"><i class="fa-solid fa-bell text-cyan-400 mr-2"></i>Abonelikler</h1>
    <div id="s-msg" class="text-gray-500 text-sm py-10 text-center">Yükleniyor...</div>
    <div id="s-grid" class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"></div>
    <div class="text-center mt-8"><button id="s-more" class="hidden px-6 py-2.5 rounded-full text-sm font-semibold text-black" style="background:#00f5ff">Daha fazla</button></div>
</div>
<script>
window.addEventListener('load', async function () {
    const BASE = '<?= APP_URL ?>', msg = document.getElementById('s-msg'), grid = document.getElementById('s-grid'), more = document.getElementById('s-more');
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const fmt = s => { s = Math.floor(s || 0); const h = Math.floor(s/3600), m = Math.floor(s%3600/60), x = s%60; return (h ? h + ':' + String(m).padStart(2,'0') : m) + ':' + String(x).padStart(2,'0'); };
    let t = null; try { const { data } = await sbClient.auth.getSession(); t = data.session ? data.session.access_token : null; } catch (e) {}
    if (!t) { try { t = localStorage.getItem('sb_access_token'); } catch (e) {} }
    if (!t) { msg.innerHTML = 'Abonelik akışı için <a class="text-cyan-400 underline" href="' + BASE + '/auth.php">giriş yap</a>.'; return; }
    let page = 1;
    async function load() {
        const j = await (await fetch(BASE + '/api/feed.php?page=' + page + '&token=' + encodeURIComponent(t), { headers: { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t } })).json();
        const d = j.data || {};
        if (page === 1) {
            if (!d.channels) { msg.innerHTML = 'Henüz hiçbir kanala abone değilsin. <a class="text-cyan-400 underline" href="' + BASE + '/index.php">Kanallara göz at</a>.'; return; }
            if (!(d.items || []).length) { msg.textContent = 'Abone olduğun kanallarda henüz video yok.'; return; }
            msg.remove();
        }
        grid.insertAdjacentHTML('beforeend', (d.items || []).map(v =>
            '<a href="' + BASE + '/video.php?id=' + esc(v.id) + '" class="block"><div class="relative rounded-xl overflow-hidden" style="aspect-ratio:16/9;background:#13131f"><img src="' + esc(v.thumbnail_url) + '" class="w-full h-full object-cover" loading="lazy" alt="">' +
            (v.duration ? '<span class="absolute bottom-2 right-2 text-[10px] font-bold px-1.5 py-0.5 rounded" style="background:rgba(0,0,0,.8)">' + fmt(v.duration) + '</span>' : '') + '</div>' +
            '<h3 class="text-sm font-semibold text-white mt-2" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' + esc(v.title) + '</h3>' +
            '<p class="text-xs text-gray-500 mt-0.5">' + esc(v.channels ? v.channels.name : '') + ' · ' + esc(v.views) + ' izlenme</p></a>').join(''));
        more.classList.toggle('hidden', !d.has_more);
    }
    more.onclick = () => { page++; load(); };
    try { await load(); } catch (e) { msg.textContent = 'Yüklenemedi.'; }
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
