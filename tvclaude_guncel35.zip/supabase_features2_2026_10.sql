-- ============================================================
-- NeonTV - 2. özellik paketi (kullanıcı listeleri, puanlama, bildirimler)
-- Supabase > SQL Editor'da bir kez çalıştırın. Tekrar çalıştırılabilir.
-- Tablolara yalnızca service_role (PHP sunucusu) erişir.
-- ============================================================

-- Kullanıcı oynatma listeleri
CREATE TABLE IF NOT EXISTS public.user_playlists (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    title      text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 80),
    is_public  boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS user_playlists_user_idx ON public.user_playlists (user_id);
ALTER TABLE public.user_playlists ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.user_playlists FROM anon, authenticated;
GRANT ALL ON public.user_playlists TO service_role;

CREATE TABLE IF NOT EXISTS public.user_playlist_items (
    playlist_id uuid NOT NULL REFERENCES public.user_playlists(id) ON DELETE CASCADE,
    video_id    uuid NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    added_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (playlist_id, video_id)
);
ALTER TABLE public.user_playlist_items ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.user_playlist_items FROM anon, authenticated;
GRANT ALL ON public.user_playlist_items TO service_role;

-- Video puanları (1-5)
CREATE TABLE IF NOT EXISTS public.video_ratings (
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    video_id   uuid NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    rating     int  NOT NULL CHECK (rating BETWEEN 1 AND 5),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, video_id)
);
CREATE INDEX IF NOT EXISTS video_ratings_video_idx ON public.video_ratings (video_id);
ALTER TABLE public.video_ratings ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.video_ratings FROM anon, authenticated;
GRANT ALL ON public.video_ratings TO service_role;

-- Bildirimler (@etiketleme vb.)
CREATE TABLE IF NOT EXISTS public.notifications (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    type       text NOT NULL DEFAULT 'mention',
    message    text NOT NULL CHECK (char_length(message) <= 300),
    link       text,
    is_read    boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS notifications_user_idx ON public.notifications (user_id, is_read, created_at DESC);
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.notifications FROM anon, authenticated;
GRANT ALL ON public.notifications TO service_role;
