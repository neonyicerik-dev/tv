-- ============================================================
-- NeonTV - 4. özellik paketi: profil kapak/bio, yorum tepkileri ve düzenleme,
-- engelleme, kanal topluluk gönderileri
-- (NEONTV_TUM_SQL.sql içinde de vardır; tekrar çalıştırılabilir)
-- ============================================================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS bio       text DEFAULT '';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS cover_url text DEFAULT '';
ALTER TABLE public.comments ADD COLUMN IF NOT EXISTS edited_at timestamptz;

CREATE TABLE IF NOT EXISTS public.comment_reactions (
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    comment_id uuid NOT NULL REFERENCES public.comments(id) ON DELETE CASCADE,
    emoji      text NOT NULL CHECK (emoji IN ('👍','🔥','😂','😮','❤️')),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, comment_id, emoji)
);
CREATE INDEX IF NOT EXISTS comment_reactions_comment_idx ON public.comment_reactions (comment_id);
ALTER TABLE public.comment_reactions ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.comment_reactions FROM anon, authenticated;
GRANT ALL ON public.comment_reactions TO service_role;

CREATE TABLE IF NOT EXISTS public.user_blocks (
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    kind       text NOT NULL CHECK (kind IN ('channel','user')),
    target_id  uuid NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, kind, target_id)
);
ALTER TABLE public.user_blocks ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.user_blocks FROM anon, authenticated;
GRANT ALL ON public.user_blocks TO service_role;

CREATE TABLE IF NOT EXISTS public.channel_posts (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id uuid NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    content    text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 2000),
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS channel_posts_channel_idx ON public.channel_posts (channel_id, created_at DESC);
ALTER TABLE public.channel_posts ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.channel_posts FROM anon, authenticated;
GRANT ALL ON public.channel_posts TO service_role;
