-- ============================================================
-- NeonTV - 5. özellik paketi: NeTvYZ sohbet geçmişi/puanlama/kullanım paneli ve
-- video altyazı özetleri (NEONTV_TUM_SQL.sql içinde de vardır; tekrar çalıştırılabilir)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.ai_chat_messages (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    role       text NOT NULL CHECK (role IN ('user','bot')),
    content    text NOT NULL,
    refs       jsonb NOT NULL DEFAULT '[]'::jsonb,
    refused    boolean NOT NULL DEFAULT false,
    rating     smallint CHECK (rating IN (-1, 1)),
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ai_chat_user_idx ON public.ai_chat_messages (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ai_chat_time_idx ON public.ai_chat_messages (created_at DESC);
ALTER TABLE public.ai_chat_messages ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.ai_chat_messages FROM anon, authenticated;
GRANT ALL ON public.ai_chat_messages TO service_role;

CREATE TABLE IF NOT EXISTS public.video_summaries (
    video_id   uuid PRIMARY KEY REFERENCES public.videos(id) ON DELETE CASCADE,
    summary    text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.video_summaries ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.video_summaries FROM anon, authenticated;
GRANT ALL ON public.video_summaries TO service_role;
