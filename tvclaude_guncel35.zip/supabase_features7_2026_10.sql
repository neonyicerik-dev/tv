-- NeonTV features7: kullanıcı yasakları, video istek panosu, topluluk anketi/resim. Tekrar çalıştırılabilir, RLS güvenli.

CREATE TABLE IF NOT EXISTS public.user_bans (
    user_id      uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    reason       text NOT NULL DEFAULT '',
    banned_until timestamptz,                 -- NULL = kalıcı
    banned_by    text NOT NULL DEFAULT '',
    created_at   timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.user_bans ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.user_bans FROM anon, authenticated;
GRANT ALL ON public.user_bans TO service_role;

CREATE TABLE IF NOT EXISTS public.video_requests (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    username    text NOT NULL DEFAULT '',
    title       text NOT NULL CHECK (char_length(title) BETWEEN 3 AND 120),
    description text NOT NULL DEFAULT '' CHECK (char_length(description) <= 600),
    status      text NOT NULL DEFAULT 'open' CHECK (status IN ('open','planned','done','rejected')),
    admin_note  text NOT NULL DEFAULT '',
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS video_requests_time_idx ON public.video_requests (created_at DESC);
ALTER TABLE public.video_requests ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.video_requests FROM anon, authenticated;
GRANT ALL ON public.video_requests TO service_role;

CREATE TABLE IF NOT EXISTS public.request_votes (
    request_id uuid NOT NULL REFERENCES public.video_requests(id) ON DELETE CASCADE,
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (request_id, user_id)
);
ALTER TABLE public.request_votes ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.request_votes FROM anon, authenticated;
GRANT ALL ON public.request_votes TO service_role;

ALTER TABLE public.channel_posts ADD COLUMN IF NOT EXISTS image_url    text;
ALTER TABLE public.channel_posts ADD COLUMN IF NOT EXISTS poll         jsonb;
ALTER TABLE public.channel_posts ADD COLUMN IF NOT EXISTS poll_ends_at timestamptz;

CREATE TABLE IF NOT EXISTS public.post_poll_votes (
    post_id    uuid NOT NULL REFERENCES public.channel_posts(id) ON DELETE CASCADE,
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    option_idx smallint NOT NULL CHECK (option_idx BETWEEN 0 AND 9),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (post_id, user_id)
);
ALTER TABLE public.post_poll_votes ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.post_poll_votes FROM anon, authenticated;
GRANT ALL ON public.post_poll_votes TO service_role;
