-- ============================================================
-- NeTvYZ kota düzeltmesi (Supabase SQL Editor'da bir kez çalıştırın)
-- Sorun: consume_ai_quota / refund_ai_quota fonksiyonları hem uuid hem text
-- imzasıyla iki kez tanımlıydı. PostgREST hangisini çağıracağını seçemediği
-- için RPC hata veriyor ve kota düşmüyordu.
-- ============================================================
DROP FUNCTION IF EXISTS public.consume_ai_quota(text, text, int);
DROP FUNCTION IF EXISTS public.refund_ai_quota(text, text);

CREATE OR REPLACE FUNCTION public.consume_ai_quota(p_uid uuid, p_period text, p_max int)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_used int;
BEGIN
    INSERT INTO public.ai_usage (user_id, period, used)
    VALUES (p_uid, p_period, 1)
    ON CONFLICT (user_id, period) DO UPDATE
        SET used = public.ai_usage.used + 1
        WHERE public.ai_usage.used < p_max
    RETURNING used INTO v_used;
    RETURN FOUND AND v_used IS NOT NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.refund_ai_quota(p_uid uuid, p_period text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
    UPDATE public.ai_usage SET used = GREATEST(0, used - 1)
    WHERE user_id = p_uid AND period = p_period;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.consume_ai_quota(uuid, text, int) FROM PUBLIC, anon, authenticated;
GRANT  EXECUTE ON FUNCTION public.consume_ai_quota(uuid, text, int) TO service_role;
REVOKE EXECUTE ON FUNCTION public.refund_ai_quota(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT  EXECUTE ON FUNCTION public.refund_ai_quota(uuid, text) TO service_role;
