/* NeonTV service worker – yalnızca web push için */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('push', e => {
    e.waitUntil((async () => {
        let d = { title: 'NeonTV', body: 'Yeni bildirimin var.', url: self.registration.scope };
        try {
            const sub = await self.registration.pushManager.getSubscription();
            if (sub) {
                const r = await fetch(new URL('api/push.php?action=latest', self.registration.scope), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ endpoint: sub.endpoint }) });
                const j = await r.json();
                if (j && j.success && j.data) d = j.data;
            }
        } catch (err) {}
        await self.registration.showNotification(d.title || 'NeonTV', { body: d.body, tag: 'neontv', renotify: true, data: { url: d.url } });
    })());
});
self.addEventListener('notificationclick', e => {
    e.notification.close();
    const url = (e.notification.data && e.notification.data.url) || self.registration.scope;
    e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
        for (const c of list) { if (c.url === url && 'focus' in c) return c.focus(); }
        return self.clients.openWindow(url);
    }));
});
