<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/supabase.php';

$db = new Supabase();
// 1. Get all profiles
$profilesRes = $db->select('profiles', 'select=*', true);
$profiles = $profilesRes['data'] ?? [];

// 2. We don't have direct access to auth.users from REST easily without service key.
// But we can just execute raw SQL to sync all profiles from auth.users.
$sql = "
UPDATE public.profiles p
SET 
  avatar_url = COALESCE(u.raw_user_meta_data->>'avatar_url', p.avatar_url),
  username = COALESCE(u.raw_user_meta_data->>'username', p.username)
FROM auth.users u
WHERE p.id = u.id AND (p.avatar_url = '' OR p.avatar_url IS NULL);
";

// Supabase REST doesn't support raw SQL natively, so we'll just fix it for the user when they comment as a fallback, but wait...
