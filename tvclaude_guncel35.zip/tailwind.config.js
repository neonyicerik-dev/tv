// Tailwind yapılandırması (site CSS'i assets/css/tw.css olarak önceden derlenir)
module.exports = {
  darkMode: 'class',
  content: ['./*.php', './components/*.php', './assets/js/*.js', './includes/*.php', './api/*.php'],
  theme: { extend: {
    colors: { neon: { cyan: 'rgb(var(--ac1) / <alpha-value>)', purple: 'rgb(var(--ac2) / <alpha-value>)', pink: '#ff007a' },
      dark: { 900: '#070711', 800: '#0d0d1a', 700: '#13131f', 600: '#1a1a2e', 500: '#22223b' } },
    fontFamily: { sans: ['Outfit', 'sans-serif'] },
    animation: { 'glow-pulse': 'glowPulse 2s ease-in-out infinite', 'fade-in': 'fadeIn 0.3s ease-out', 'slide-up': 'slideUp 0.3s ease-out' },
    keyframes: { glowPulse: { '0%, 100%': { opacity: '1' }, '50%': { opacity: '0.6' } }, fadeIn: { from: { opacity: '0' }, to: { opacity: '1' } }, slideUp: { from: { opacity: '0', transform: 'translateY(10px)' }, to: { opacity: '1', transform: 'translateY(0)' } } }
  } }
}
