<?php
// ============================================================
// NeonTV - Admin Dashboard (Yeniden Tasarım)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
requireAdmin();

$db = new Supabase();

// İstatistikler
$videosRes   = $db->select('videos', 'select=id,views,likes_count,status,created_at,title,thumbnail_url', true);
$allVideos   = $videosRes['data'] ?? [];
$totalVideos = count($allVideos);
$published   = count(array_filter($allVideos, function($v) { return $v['status'] === 'published'; }));
$drafts      = count(array_filter($allVideos, function($v) { return $v['status'] === 'draft'; }));
$totalViews  = array_sum(array_column($allVideos, 'views'));
$totalLikes  = array_sum(array_column($allVideos, 'likes_count'));

$commentsRes   = $db->select('comments', 'select=id,created_at', true);
$allComments   = $commentsRes['data'] ?? [];
$totalComments = count($allComments);

// Son 5 video
$recentRes    = $db->select('videos', 'order=created_at.desc&limit=5', true);
$recentVideos = $recentRes['data'] ?? [];

// En çok izlenen 5 video
$popularRes    = $db->select('videos', 'status=eq.published&order=views.desc&limit=5', true);
$popularVideos = $popularRes['data'] ?? [];

// Altyazısı olan video sayısı
$subtitleRes   = $db->select('subtitles', 'select=video_id', true);
$totalSubtitles = count($subtitleRes['data'] ?? []);

// Ayarlar
require_once __DIR__ . '/../includes/store.php';
$settings = loadSettingsCompat();

// Son 5 Aktivite
require_once __DIR__ . '/../includes/activity_log.php';
$recentActivities = array_slice(readActivityLog(), 0, 5);
?>
<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; }

        .stat-card {
            background: #0f0f1e;
            border: 1px solid rgba(255,255,255,0.07);
            transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            inset: 0;
            opacity: 0;
            transition: opacity 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            border-color: rgba(0,245,255,0.25);
            box-shadow: 0 8px 32px rgba(0,245,255,0.08);
        }
        .stat-card:hover::before { opacity: 1; }

        .glow-cyan { box-shadow: 0 0 20px rgba(0,245,255,0.15); }
        .glow-purple { box-shadow: 0 0 20px rgba(191,0,255,0.15); }
        .glow-pink { box-shadow: 0 0 20px rgba(255,0,122,0.15); }
        .glow-gold { box-shadow: 0 0 20px rgba(255,215,0,0.15); }

        .panel {
            background: #0f0f1e;
            border: 1px solid rgba(255,255,255,0.07);
            border-radius: 1rem;
            overflow: hidden;
        }
        .panel-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid rgba(255,255,255,0.06);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .progress-ring {
            transform: rotate(-90deg);
            transform-origin: center;
        }
        .quick-action {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.08);
            transition: all 0.25s;
        }
        .quick-action:hover {
            background: rgba(0,245,255,0.06);
            border-color: rgba(0,245,255,0.25);
            transform: scale(1.02);
        }
        .sparkline-bar {
            width: 4px;
            border-radius: 2px;
            background: linear-gradient(to top, #00f5ff, #bf00ff);
            opacity: 0.7;
            transition: opacity 0.2s;
        }
        .sparkline-bar:hover { opacity: 1; }

        @keyframes pulse-glow {
            0%, 100% { box-shadow: 0 0 8px rgba(0,245,255,0.3); }
            50% { box-shadow: 0 0 18px rgba(0,245,255,0.6); }
        }
        .live-dot {
            width: 8px; height: 8px; border-radius: 50%;
            background: #00f5ff;
            animation: pulse-glow 2s infinite;
        }

        .table-row {
            border-bottom: 1px solid rgba(255,255,255,0.04);
            transition: background 0.15s;
        }
        .table-row:hover { background: rgba(255,255,255,0.025); }
        .table-row:last-child { border-bottom: none; }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- Top Bar -->
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.95);backdrop-filter:blur(24px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors"
                    style="background:rgba(255,255,255,0.06);">
                <i class="fa-solid fa-bars text-sm"></i>
            </button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                    Dashboard
                    <span class="live-dot"></span>
                </h1>
                <p class="text-xs text-gray-500 hidden sm:block">
                    Hoşgeldiniz, <?= e(ADMIN_USERNAME) ?> &mdash;
                    <span style="color:#00f5ff;"><?= date('d M Y, H:i') ?></span>
                </p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <!-- Widget Özelleştir Butonu -->
            <button id="widget-edit-btn" onclick="toggleWidgetEdit()"
                    class="flex items-center gap-2 px-3 py-2 rounded-xl text-xs transition-all"
                    style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:#9ca3af;"
                    title="Widget Sıralamasını Düzenle">
                <i class="fa-solid fa-sliders text-xs"></i>
                <span class="hidden sm:inline">Widget Düzenle</span>
            </button>
            <a href="<?= APP_URL ?>/admin/settings.php"
               class="flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-gray-400 hover:text-white transition-all"
               style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                <i class="fa-solid fa-sliders text-xs"></i>
                <span class="hidden sm:inline">Ayarlar</span>
            </a>
            <a href="<?= APP_URL ?>/index.php" target="_blank"
               class="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all hover:scale-105"
               style="background:linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.15));border:1px solid rgba(0,245,255,0.3);color:#00f5ff;">
                <i class="fa-solid fa-arrow-up-right-from-square text-xs"></i>
                <span class="hidden sm:inline">Siteyi Görüntüle</span>
            </a>
        </div>
    </header>

    <main class="flex-1 p-4 sm:p-6 overflow-auto space-y-6">

        <!-- ===== CANLI GRAFİK (14 gün, 30 sn'de bir yenilenir) ===== -->
        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
            <div class="flex items-center mb-3">
                <h2 class="text-sm font-bold text-white"><i class="fa-solid fa-chart-line text-cyan-400 mr-2"></i>Son 14 Gün</h2>
                <span id="live-updated" class="ml-auto text-[11px] text-gray-500"></span>
            </div>
            <canvas id="live-chart" height="90"></canvas>
        </div>

        <!-- ===== İSTATİSTİK KARTLARI ===== -->
        <div class="grid grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4">

            <!-- Çevrimiçi -->
            <div class="stat-card rounded-2xl p-5">
                <p class="text-3xl font-black" style="color:#39ff14;"><?= (int)nvOnlineCount(300) ?></p>
                <p class="text-xs text-gray-500"><i class="fa-solid fa-circle text-[8px] mr-1" style="color:#39ff14"></i>Şu an çevrimiçi (son 5 dk)</p>
            </div>

            <!-- Toplam Video -->
            <div class="stat-card rounded-2xl p-5">
                <div class="flex items-start justify-between mb-4">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center"
                         style="background:linear-gradient(135deg,rgba(0,245,255,0.15),rgba(0,245,255,0.05));border:1px solid rgba(0,245,255,0.2);">
                        <i class="fa-solid fa-video text-base" style="color:#00f5ff;"></i>
                    </div>
                    <span class="text-xs px-2.5 py-1 rounded-full font-semibold"
                          style="background:rgba(0,245,255,0.1);color:#00f5ff;">
                        <?= $published ?> aktif
                    </span>
                </div>
                <p class="text-3xl font-bold text-white mb-1"><?= $totalVideos ?></p>
                <p class="text-xs text-gray-500">Toplam Video</p>
                <div class="mt-3 h-1 rounded-full overflow-hidden" style="background:rgba(255,255,255,0.06);">
                    <div class="h-full rounded-full" style="background:linear-gradient(90deg,#00f5ff,#00a8b5);width:<?= $totalVideos > 0 ? round($published/$totalVideos*100) : 0 ?>%;"></div>
                </div>
                <p class="text-[10px] text-gray-600 mt-1"><?= $drafts ?> taslak</p>
            </div>

            <!-- Toplam İzlenme -->
            <div class="stat-card rounded-2xl p-5">
                <div class="flex items-start justify-between mb-4">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center"
                         style="background:linear-gradient(135deg,rgba(191,0,255,0.15),rgba(191,0,255,0.05));border:1px solid rgba(191,0,255,0.2);">
                        <i class="fa-solid fa-eye text-base" style="color:#bf00ff;"></i>
                    </div>
                </div>
                <p class="text-3xl font-bold text-white mb-1"><?= formatNumber($totalViews) ?></p>
                <p class="text-xs text-gray-500">Toplam İzlenme</p>
                <div class="mt-3 flex items-end gap-0.5 h-8">
                    <?php
                    $bars = [30,55,40,80,60,90,70,45,85,65,100,75];
                    foreach($bars as $h): ?>
                    <div class="sparkline-bar flex-1" style="height:<?= $h ?>%;"></div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Toplam Beğeni -->
            <div class="stat-card rounded-2xl p-5">
                <div class="flex items-start justify-between mb-4">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center"
                         style="background:linear-gradient(135deg,rgba(255,0,122,0.15),rgba(255,0,122,0.05));border:1px solid rgba(255,0,122,0.2);">
                        <i class="fa-solid fa-heart text-base" style="color:#ff007a;"></i>
                    </div>
                </div>
                <p class="text-3xl font-bold text-white mb-1"><?= formatNumber($totalLikes) ?></p>
                <p class="text-xs text-gray-500">Toplam Beğeni</p>
                <div class="mt-3 flex items-center gap-1.5">
                    <div class="flex-1 h-1 rounded-full overflow-hidden" style="background:rgba(255,255,255,0.06);">
                        <div class="h-full rounded-full" style="background:linear-gradient(90deg,#ff007a,#bf00ff);width:<?= $totalVideos > 0 ? min(100, round($totalLikes/max(1,$totalVideos)*10)) : 0 ?>%;"></div>
                    </div>
                    <span class="text-[10px] text-gray-600">ortalama <?= $totalVideos > 0 ? formatNumber(intval($totalLikes/max(1,$totalVideos))) : 0 ?>/video</span>
                </div>
            </div>

            <!-- Toplam Yorum -->
            <div class="stat-card rounded-2xl p-5">
                <div class="flex items-start justify-between mb-4">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center"
                         style="background:linear-gradient(135deg,rgba(255,215,0,0.15),rgba(255,215,0,0.05));border:1px solid rgba(255,215,0,0.2);">
                        <i class="fa-solid fa-comments text-base" style="color:#ffd700;"></i>
                    </div>
                </div>
                <p class="text-3xl font-bold text-white mb-1"><?= $totalComments ?></p>
                <p class="text-xs text-gray-500">Toplam Yorum</p>
                <div class="mt-3 flex items-center gap-2">
                    <div class="w-6 h-6 rounded-lg flex items-center justify-center" style="background:rgba(255,215,0,0.1);">
                        <i class="fa-solid fa-closed-captioning text-[10px]" style="color:#ffd700;"></i>
                    </div>
                    <span class="text-[10px] text-gray-600"><?= $totalSubtitles ?> video altyazılı</span>
                </div>
            </div>
        </div>

        <!-- ===== HIZLI İŞLEMLER & ÖZET ===== -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">

            <!-- Hızlı İşlemler -->
            <div class="lg:col-span-2 grid grid-cols-2 gap-3">
                <a href="<?= APP_URL ?>/admin/upload.php"
                   class="quick-action rounded-2xl p-5 flex items-center gap-4 group">
                    <div class="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
                         style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                        <i class="fa-solid fa-upload text-black text-xl"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-white text-base group-hover:text-cyan-300 transition-colors">Video Yükle</h3>
                        <p class="text-gray-500 text-xs mt-0.5">Yeni içerik ekle</p>
                    </div>
                    <i class="fa-solid fa-arrow-right ml-auto text-gray-600 group-hover:text-cyan-400 group-hover:translate-x-1 transition-all"></i>
                </a>

                <a href="<?= APP_URL ?>/admin/videos.php"
                   class="quick-action rounded-2xl p-5 flex items-center gap-4 group">
                    <div class="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
                         style="background:rgba(255,255,255,0.08);">
                        <i class="fa-solid fa-film text-white text-xl"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-white text-base">Videoları Yönet</h3>
                        <p class="text-gray-500 text-xs mt-0.5">Düzenle &amp; sil</p>
                    </div>
                    <i class="fa-solid fa-arrow-right ml-auto text-gray-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
                </a>

                <a href="<?= APP_URL ?>/admin/settings.php"
                   class="quick-action rounded-2xl p-5 flex items-center gap-4 group">
                    <div class="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
                         style="background:rgba(191,0,255,0.1);border:1px solid rgba(191,0,255,0.2);">
                        <i class="fa-solid fa-robot text-xl" style="color:#bf00ff;"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-white text-base group-hover:text-purple-300 transition-colors">AI Ayarları</h3>
                        <p class="text-gray-500 text-xs mt-0.5">Sistem promptunu düzenle</p>
                    </div>
                    <i class="fa-solid fa-arrow-right ml-auto text-gray-600 group-hover:text-purple-400 group-hover:translate-x-1 transition-all"></i>
                </a>

                <a href="<?= APP_URL ?>/admin/tools.php"
                   class="quick-action rounded-2xl p-5 flex items-center gap-4 group">
                    <div class="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
                         style="background:rgba(255,0,122,0.1);border:1px solid rgba(255,0,122,0.2);">
                        <i class="fa-solid fa-toolbox text-xl" style="color:#ff007a;"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-white text-base group-hover:text-pink-300 transition-colors">Araçlar</h3>
                        <p class="text-gray-500 text-xs mt-0.5">Video & Metin Yardımcıları</p>
                    </div>
                    <i class="fa-solid fa-arrow-right ml-auto text-gray-600 group-hover:text-pink-400 group-hover:translate-x-1 transition-all"></i>
                </a>
            </div>

            <!-- Platform Özeti -->
            <div class="panel">
                <div class="panel-header">
                    <h2 class="font-bold text-white text-sm flex items-center gap-2">
                        <i class="fa-solid fa-chart-pie text-xs" style="color:#00f5ff;"></i>
                        Platform Özeti
                    </h2>
                </div>
                <div class="p-4 space-y-3">
                    <div class="flex items-center justify-between p-3 rounded-xl" style="background:rgba(0,245,255,0.04);border:1px solid rgba(0,245,255,0.1);">
                        <div class="flex items-center gap-2">
                            <i class="fa-solid fa-circle-check text-xs" style="color:#00f5ff;"></i>
                            <span class="text-sm text-gray-300">Yayında</span>
                        </div>
                        <span class="font-bold text-white"><?= $published ?></span>
                    </div>
                    <div class="flex items-center justify-between p-3 rounded-xl" style="background:rgba(255,255,255,0.03);">
                        <div class="flex items-center gap-2">
                            <i class="fa-solid fa-pen text-xs text-gray-500"></i>
                            <span class="text-sm text-gray-400">Taslak</span>
                        </div>
                        <span class="font-bold text-gray-300"><?= $drafts ?></span>
                    </div>
                    <div class="flex items-center justify-between p-3 rounded-xl" style="background:rgba(191,0,255,0.04);border:1px solid rgba(191,0,255,0.1);">
                        <div class="flex items-center gap-2">
                            <i class="fa-solid fa-closed-captioning text-xs" style="color:#bf00ff;"></i>
                            <span class="text-sm text-gray-300">Altyazılı</span>
                        </div>
                        <span class="font-bold text-white"><?= $totalSubtitles ?></span>
                    </div>
                    <div class="flex items-center justify-between p-3 rounded-xl" style="background:rgba(255,215,0,0.04);border:1px solid rgba(255,215,0,0.1);">
                        <div class="flex items-center gap-2">
                            <i class="fa-solid fa-comments text-xs" style="color:#ffd700;"></i>
                            <span class="text-sm text-gray-300">Yorum</span>
                        </div>
                        <span class="font-bold text-white"><?= $totalComments ?></span>
                    </div>
                    <div class="pt-2" style="border-top:1px solid rgba(255,255,255,0.06);">
                        <div class="flex items-center gap-2 text-xs text-gray-600">
                            <i class="fa-solid fa-robot" style="color:#bf00ff;"></i>
                            <span>AI Prompt: <?= !empty($settings['subtitle_system_prompt']) ? '<span style="color:#00f5ff;">Özelleştirilmiş</span>' : '<span class="text-gray-600">Varsayılan</span>' ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== ALT PANELLER ===== -->
        <!-- Widget Düzenleme Bilgi Bantı -->
        <div id="widget-edit-bar" class="hidden mb-3 px-4 py-2 rounded-xl flex items-center gap-3 text-xs"
             style="background:rgba(0,245,255,0.05);border:1px solid rgba(0,245,255,0.2);">
            <i class="fa-solid fa-grip text-cyan-400"></i>
            <span class="text-cyan-300 font-medium">Düzenleme modu aktif — widget'ları sürükleyerek sıralayabilirsiniz</span>
            <button onclick="resetWidgets()" class="ml-auto text-gray-500 hover:text-red-400 transition-colors">
                <i class="fa-solid fa-rotate-left mr-1"></i>Sıfırla
            </button>
        </div>

        <div id="widgets-container" class="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-4">

            <!-- Son Eklenen Videolar -->
            <div class="panel" data-widget-id="recent-videos">
                <div class="panel-header">
                    <h2 class="font-bold text-white text-sm flex items-center gap-2">
                        <i class="fa-solid fa-clock-rotate-left text-xs" style="color:#00f5ff;"></i>
                        Son Eklenen Videolar
                    </h2>
                    <a href="<?= APP_URL ?>/admin/videos.php" class="text-xs text-gray-500 hover:text-cyan-400 transition-colors flex items-center gap-1">
                        Tümünü gör <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>

                <?php if (empty($recentVideos)): ?>
                <div class="text-center py-12 text-gray-600">
                    <i class="fa-solid fa-film text-3xl mb-3 block opacity-30"></i>
                    Henüz video yok
                </div>
                <?php else: ?>
                <div>
                    <?php foreach ($recentVideos as $v): ?>
                    <div class="table-row flex items-center gap-3 px-4 py-3">
                        <div class="w-16 rounded-lg overflow-hidden flex-shrink-0" style="aspect-ratio:16/9;background:#0d0d1a;">
                            <img src="<?= e($v['thumbnail_url'] ?? 'https://placehold.co/160x90/070711/00f5ff?text=N') ?>"
                                 alt="<?= e($v['title']) ?>" class="w-full h-full object-cover" loading="lazy">
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="font-medium text-white text-xs truncate"><?= e($v['title']) ?></p>
                            <div class="flex items-center gap-2 text-xs text-gray-600 mt-0.5">
                                <span><i class="fa-solid fa-eye mr-1"></i><?= formatNumber((int)($v['views'] ?? 0)) ?></span>
                                <span><i class="fa-solid fa-heart mr-1"></i><?= formatNumber((int)($v['likes_count'] ?? 0)) ?></span>
                                <span class="hidden sm:inline text-gray-700"><?= timeAgo($v['created_at']) ?></span>
                            </div>
                        </div>
                        <div class="flex items-center gap-1.5 flex-shrink-0">
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-medium"
                                  style="<?= $v['status'] === 'published'
                                    ? 'background:rgba(0,245,255,0.1);color:#00f5ff;'
                                    : 'background:rgba(255,255,255,0.06);color:#888;' ?>">
                                <?= $v['status'] === 'published' ? 'Yayında' : 'Taslak' ?>
                            </span>
                            <a href="<?= APP_URL ?>/video.php?id=<?= e($v['id']) ?>" target="_blank"
                               class="p-1.5 rounded-lg text-gray-600 hover:text-white transition-colors"
                               style="background:rgba(255,255,255,0.04);" title="İzle">
                                <i class="fa-solid fa-eye text-xs"></i>
                            </a>
                            <a href="<?= APP_URL ?>/admin/upload.php?edit=<?= e($v['id']) ?>"
                               class="p-1.5 rounded-lg text-gray-600 hover:text-cyan-400 transition-colors"
                               style="background:rgba(255,255,255,0.04);" title="Düzenle">
                                <i class="fa-solid fa-pen text-xs"></i>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- En Çok İzlenen Videolar -->
            <div class="panel" data-widget-id="popular-videos">
                <div class="panel-header">
                    <h2 class="font-bold text-white text-sm flex items-center gap-2">
                        <i class="fa-solid fa-fire text-xs" style="color:#ff007a;"></i>
                        En Çok İzlenenler
                    </h2>
                    <span class="text-xs text-gray-600">Tüm zamanlar</span>
                </div>

                <?php if (empty($popularVideos)): ?>
                <div class="text-center py-12 text-gray-600">
                    <i class="fa-solid fa-chart-bar text-3xl mb-3 block opacity-30"></i>
                    Henüz veri yok
                </div>
                <?php else: ?>
                <div>
                    <?php $maxViews = max(array_column($popularVideos, 'views') ?: [1]); ?>
                    <?php foreach ($popularVideos as $idx => $pv): ?>
                    <div class="table-row px-4 py-3">
                        <div class="flex items-center gap-3 mb-2">
                            <span class="text-xs font-bold w-5 text-center flex-shrink-0"
                                  style="color:<?= $idx === 0 ? '#ffd700' : ($idx === 1 ? '#c0c0c0' : ($idx === 2 ? '#cd7f32' : '#555')) ?>;">
                                #<?= $idx+1 ?>
                            </span>
                            <div class="w-12 rounded-md overflow-hidden flex-shrink-0" style="aspect-ratio:16/9;background:#0d0d1a;">
                                <img src="<?= e($pv['thumbnail_url'] ?? 'https://placehold.co/120x67/070711/00f5ff?text=N') ?>"
                                     alt="<?= e($pv['title']) ?>" class="w-full h-full object-cover" loading="lazy">
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="font-medium text-white text-xs truncate"><?= e($pv['title']) ?></p>
                                <span class="text-xs font-semibold" style="color:#bf00ff;"><?= formatNumber((int)($pv['views'] ?? 0)) ?> izlenme</span>
                            </div>
                        </div>
                        <div class="ml-8 h-1 rounded-full overflow-hidden" style="background:rgba(255,255,255,0.06);">
                            <div class="h-full rounded-full" style="background:linear-gradient(90deg,#bf00ff,#ff007a);width:<?= $maxViews > 0 ? round(($pv['views']/$maxViews)*100) : 0 ?>%;"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Son Aktiviteler -->
            <div class="panel" data-widget-id="recent-activity">
                <div class="panel-header">
                    <h2 class="font-bold text-white text-sm flex items-center gap-2">
                        <i class="fa-solid fa-clock-rotate-left text-xs" style="color:#00f5ff;"></i>
                        Son Aktiviteler
                    </h2>
                    <a href="<?= APP_URL ?>/admin/activity.php" class="text-xs text-gray-500 hover:text-cyan-400 transition-colors flex items-center gap-1">
                        Tümünü gör <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </a>
                </div>

                <?php if (empty($recentActivities)): ?>
                <div class="text-center py-12 text-gray-600">
                    <i class="fa-solid fa-clipboard-list text-3xl mb-3 block opacity-30"></i>
                    Henüz aktivite yok
                </div>
                <?php else: ?>
                <div>
                    <?php foreach ($recentActivities as $act): ?>
                    <?php
                        $actColor = actionColor($act['action'] ?? '');
                        $actLabel = actionLabel($act['action'] ?? '');
                        $targetLabel = targetTypeLabel($act['target_type'] ?? '');
                    ?>
                    <div class="table-row px-4 py-3">
                        <div class="flex items-start gap-3">
                            <div class="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                                 style="background:<?= $actColor ?>20; color:<?= $actColor ?>;">
                                <i class="fa-solid <?= str_contains($act['action'] ?? '', 'delete') ? 'fa-trash' : (str_contains($act['action'] ?? '', 'create') ? 'fa-plus' : 'fa-pen') ?> text-xs"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-xs text-white">
                                    <span class="font-bold text-cyan-400"><?= e($act['admin'] ?? '-') ?></span>
                                    <span class="text-gray-400"> (<?= e($act['role'] ?? '') ?>)</span>
                                    <?= e($actLabel) ?>
                                </p>
                                <p class="text-[10px] text-gray-500 mt-0.5"><?= e($targetLabel) ?> <?= e(!empty($act['target_id']) ? '#'.$act['target_id'] : '') ?></p>
                                <p class="text-[10px] text-gray-600 mt-1"><?= timeAgo($act['created_at']) ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ===== SİSTEM BİLGİSİ ===== -->
        <div class="panel" data-widget-id="system-info">
            <div class="panel-header">
                <h2 class="font-bold text-white text-sm flex items-center gap-2">
                    <i class="fa-solid fa-circle-info text-xs" style="color:#00f5ff;"></i>
                    Sistem Bilgisi
                </h2>
            </div>
            <div class="p-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div class="p-3 rounded-xl text-center" style="background:rgba(255,255,255,0.03);">
                    <p class="text-xs text-gray-600 mb-1">PHP Versiyon</p>
                    <p class="font-bold text-white text-sm"><?= phpversion() ?></p>
                </div>
                <div class="p-3 rounded-xl text-center" style="background:rgba(0,245,255,0.04);">
                    <p class="text-xs text-gray-600 mb-1">AI Modeli</p>
                    <p class="font-bold text-sm" style="color:#00f5ff;"><?= e(GEMINI_MODEL) ?></p>
                </div>
                <div class="p-3 rounded-xl text-center" style="background:rgba(191,0,255,0.04);">
                    <p class="text-xs text-gray-600 mb-1">Cloudinary CDN</p>
                    <p class="font-bold text-sm" style="color:#bf00ff;"><?= e(CLOUDINARY_CLOUD_NAME) ?></p>
                </div>
                <div class="p-3 rounded-xl text-center" style="background:rgba(255,215,0,0.04);">
                    <p class="text-xs text-gray-600 mb-1">Zaman Dilimi</p>
                    <p class="font-bold text-white text-sm">Europe/Istanbul</p>
                </div>
            </div>
        </div>

    </main>
</div>

<!-- ===== Widget Sıralama + Gizle/Göster JS ===== -->
<script>
/* ------ Sabitler ------ */
const WIDGET_STORAGE_KEY = 'neontv_widget_prefs';
const WIDGET_IDS = ['recent-videos', 'popular-videos', 'recent-activity', 'system-info'];

let widgetEditMode = false;
let sortableInstance = null;

/* ------ Kaydedilmiş tercihleri yükle ------ */
function loadWidgetPrefs() {
    try {
        const raw = localStorage.getItem(WIDGET_STORAGE_KEY);
        return raw ? JSON.parse(raw) : null;
    } catch { return null; }
}

/* ------ Tercihleri kaydet ------ */
function saveWidgetPrefs() {
    const container = document.getElementById('widgets-container');
    const systemPanel = document.querySelector('[data-widget-id="system-info"]');
    const prefs = { order: [], hidden: [] };

    // Container içindeki sırayı al
    container.querySelectorAll('[data-widget-id]').forEach(el => {
        prefs.order.push(el.dataset.widgetId);
        if (el.classList.contains('widget-hidden')) {
            prefs.hidden.push(el.dataset.widgetId);
        }
    });

    // Sistem bilgisi ayrı bir panel
    if (systemPanel && systemPanel.classList.contains('widget-hidden')) {
        prefs.hidden.push('system-info');
    }

    localStorage.setItem(WIDGET_STORAGE_KEY, JSON.stringify(prefs));
}

/* ------ Kaydedilmiş tercihleri uygula ------ */
function applyWidgetPrefs() {
    const prefs = loadWidgetPrefs();
    if (!prefs) return;

    const container = document.getElementById('widgets-container');

    // Sıralama uygula
    if (prefs.order && prefs.order.length) {
        prefs.order.forEach(id => {
            const el = container.querySelector(`[data-widget-id="${id}"]`);
            if (el) container.appendChild(el);
        });
    }

    // Gizlilik uygula
    if (prefs.hidden && prefs.hidden.length) {
        prefs.hidden.forEach(id => {
            const el = document.querySelector(`[data-widget-id="${id}"]`);
            if (el) {
                el.classList.add('widget-hidden');
                el.style.display = 'none';
            }
        });
    }
}

/* ------ Düzenleme modu toggle ------ */
function toggleWidgetEdit() {
    widgetEditMode = !widgetEditMode;
    const bar     = document.getElementById('widget-edit-bar');
    const btn     = document.getElementById('widget-edit-btn');
    const container = document.getElementById('widgets-container');

    if (widgetEditMode) {
        bar.classList.remove('hidden');
        btn.style.cssText = 'background:rgba(0,245,255,0.12);border:1px solid rgba(0,245,255,0.4);color:#00f5ff;';

        // Drag handle + Gizle butonu göster
        container.querySelectorAll('[data-widget-id]').forEach(panel => {
            addWidgetControls(panel);
        });

        // SortableJS
        if (!sortableInstance) {
            sortableInstance = Sortable.create(container, {
                animation: 200,
                handle: '.widget-drag-handle',
                ghostClass: 'widget-ghost',
                dragClass: 'widget-dragging',
                onEnd: saveWidgetPrefs,
            });
        }
    } else {
        bar.classList.add('hidden');
        btn.style.cssText = 'background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:#9ca3af;';
        // Kontrolleri kaldır
        document.querySelectorAll('.widget-controls-bar').forEach(el => el.remove());
        if (sortableInstance) { sortableInstance.destroy(); sortableInstance = null; }
    }
}

/* ------ Widget kontrol çubuğu ekle (düzenleme modunda) ------ */
function addWidgetControls(panel) {
    if (panel.querySelector('.widget-controls-bar')) return; // zaten var
    const widgetId = panel.dataset.widgetId;
    const isHidden = panel.classList.contains('widget-hidden');

    const bar = document.createElement('div');
    bar.className = 'widget-controls-bar';
    bar.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:6px 12px;margin:-1px -1px 0;background:rgba(0,245,255,0.06);border-bottom:1px solid rgba(0,245,255,0.15);border-radius:1rem 1rem 0 0;';
    bar.innerHTML = `
        <div class="widget-drag-handle" style="cursor:grab;display:flex;align-items:center;gap:6px;color:#6b7280;font-size:11px;">
            <i class="fa-solid fa-grip-lines"></i>
            <span>Sürükle</span>
        </div>
        <button onclick="toggleWidgetVisibility('${widgetId}', this)"
                style="font-size:11px;padding:3px 10px;border-radius:6px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.06);color:#9ca3af;cursor:pointer;transition:all 0.2s;">
            <i class="fa-solid fa-eye${isHidden ? '-slash' : ''}"></i>
            ${isHidden ? 'Göster' : 'Gizle'}
        </button>
    `;
    panel.insertBefore(bar, panel.firstChild);
}

/* ------ Widget görünürlüğünü toggle et ------ */
function toggleWidgetVisibility(widgetId, btn) {
    const panel = document.querySelector(`[data-widget-id="${widgetId}"]`);
    if (!panel) return;
    const isHidden = panel.classList.contains('widget-hidden');

    if (isHidden) {
        panel.classList.remove('widget-hidden');
        panel.style.opacity = '1';
        panel.style.filter  = '';
        btn.innerHTML = '<i class="fa-solid fa-eye"></i> Gizle';
    } else {
        panel.classList.add('widget-hidden');
        panel.style.opacity = '0.3';
        panel.style.filter  = 'grayscale(1)';
        btn.innerHTML = '<i class="fa-solid fa-eye-slash"></i> Göster';
    }
    saveWidgetPrefs();
}

/* ------ Sıfırla ------ */
function resetWidgets() {
    localStorage.removeItem(WIDGET_STORAGE_KEY);
    location.reload();
}

/* ------ Sayfa yüklenince tercihleri uygula ------ */
document.addEventListener('DOMContentLoaded', function() {
    applyWidgetPrefs();
});

/* Gizleme animasyonu için CSS */
const widgetStyle = document.createElement('style');
widgetStyle.textContent = `
    .widget-ghost { opacity:0.3; background:rgba(0,245,255,0.05) !important; }
    .widget-dragging { transform:rotate(1deg); box-shadow:0 20px 60px rgba(0,0,0,0.5),0 0 0 2px rgba(0,245,255,0.3); }
    [data-widget-id] { transition:opacity 0.3s,filter 0.3s; }
`;
document.head.appendChild(widgetStyle);
</script>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
(function () {
    let chart = null;
    const mk = (label, color, data, y) => ({ label, data, borderColor: color, backgroundColor: color + '22', tension: .3, fill: y === 'y', yAxisID: y });
    async function load() {
        try {
            const j = await (await fetch('<?= APP_URL ?>/admin/stats_api.php', { headers: { 'Accept': 'application/json' } })).json();
            if (!j.success) return; const d = j.data;
            if (!chart) {
                chart = new Chart(document.getElementById('live-chart'), { type: 'line',
                    data: { labels: d.labels, datasets: [mk('İzlenme', '#00f5ff', d.views, 'y'), mk('Yeni kullanıcı', '#bf00ff', d.users, 'y1'), mk('Yorum', '#ffd76a', d.comments, 'y1')] },
                    options: { interaction: { mode: 'index', intersect: false }, plugins: { legend: { labels: { color: '#9ca3af' } } },
                        scales: { x: { ticks: { color: '#6b7280' }, grid: { color: 'rgba(255,255,255,.05)' } },
                            y: { beginAtZero: true, ticks: { color: '#00f5ff' }, grid: { color: 'rgba(255,255,255,.05)' } },
                            y1: { beginAtZero: true, position: 'right', ticks: { color: '#bf00ff', precision: 0 }, grid: { display: false } } } } });
            } else {
                chart.data.labels = d.labels; chart.data.datasets[0].data = d.views; chart.data.datasets[1].data = d.users; chart.data.datasets[2].data = d.comments; chart.update('none');
            }
            document.getElementById('live-updated').textContent = 'Güncelleme: ' + d.updated;
        } catch (e) {}
    }
    load(); setInterval(() => { if (!document.hidden) load(); }, 30000);
})();
</script>
</body>
</html>
