<?php
// ============================================================
// NeonTV - Admin: Kanal logosu / banner yükleme -> CDN (CDN ayarlı değilse assets/channels/ klasörüne)
// POST multipart: file=<resim>  ?type=avatar|cover   (yalnızca admin)
// avatar: 400x400 · cover (banner): 1600x400, JPEG olarak yeniden kodlanır.
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/cdn_ingest.php';
error_reporting(0); ini_set('display_errors', 0);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);
if (!isAdminLoggedIn()) jsonError('Yetkisiz erişim', 401);
$type = (($_GET['type'] ?? '') === 'cover') ? 'cover' : 'avatar';
if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($_FILES['file']['tmp_name'])) jsonError('Dosya alınamadı', 400);
if ($_FILES['file']['size'] > 5 * 1024 * 1024) jsonError('Dosya 5 MB\'dan küçük olmalı', 413);

$jpg = nvImageCropJpeg($_FILES['file']['tmp_name'], $type === 'cover' ? 1600 : 400, $type === 'cover' ? 400 : 400);
if (!$jpg) jsonError('Geçerli bir resim (JPG, PNG, GIF, WEBP) seçin', 415);

$owner = preg_match('/^[0-9a-f-]{8,36}$/i', (string)($_POST['channel_id'] ?? '')) ? (string)$_POST['channel_id'] : bin2hex(random_bytes(6));
$replace = (string)($_POST['replace'] ?? '');
$url = nvCdnIngest($jpg, $type === 'cover' ? 'banner' : 'logo', $owner, $replace);
if (!$url) {
    // CDN ayarlı değil / ulaşılamadı: yerel yedek
    $dir = __DIR__ . '/../assets/channels';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) { @unlink($jpg); jsonError('Klasör oluşturulamadı', 500); }
    $name = ($type === 'cover' ? 'banner_' : 'logo_') . bin2hex(random_bytes(8)) . '.jpg';
    if (!@copy($jpg, $dir . '/' . $name)) { @unlink($jpg); jsonError('Resim kaydedilemedi (klasör yazma izni?)', 500); }
    @chmod($dir . '/' . $name, 0644);
    $url = APP_URL . '/assets/channels/' . $name;
}
@unlink($jpg);
jsonSuccess(['url' => $url], 'Yüklendi');
