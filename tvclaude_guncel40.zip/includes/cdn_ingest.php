<?php
// ============================================================
// NeonTV - Görselleri (profil resmi, kapak, kanal logosu/banner) CDN sunucusuna yükleme
// Ayar (includes/secrets.php veya ortam):  putenv('CDN_INGEST_URL=https://cdn.alanadi.com/ingest.php');
//                                         putenv('CDN_INGEST_KEY=...');   // CDN'deki CDN_INGEST_KEY ile aynı, en az 24 karakter
// Ayar yoksa ya da CDN yanıt vermezse çağıran taraf yerel depolamaya düşer (site bozulmaz).
// ============================================================

function nvCdnConfigured(): bool {
    return preg_match('#^https://#i', trim((string)getenv('CDN_INGEST_URL'))) === 1 && strlen((string)getenv('CDN_INGEST_KEY')) >= 24;
}

/** Dosyayı CDN'e yükler; başarıda herkese açık https adresi, aksi halde null. $replace: silinecek eski CDN adresi (isteğe bağlı) */
function nvCdnIngest(string $file, string $kind, string $owner, string $replace = ''): ?string {
    if (!nvCdnConfigured() || !is_file($file) || !function_exists('curl_init')) return null;
    $ch = curl_init(trim((string)getenv('CDN_INGEST_URL')));
    $opt = [
        CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30, CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_HTTPHEADER => ['X-Ingest-Key: ' . (string)getenv('CDN_INGEST_KEY'), 'Accept: application/json'],
        CURLOPT_POSTFIELDS => [
            'file' => new CURLFile($file, mime_content_type($file) ?: 'image/jpeg', basename($file)),
            'kind' => $kind, 'owner' => $owner, 'replace' => $replace,
        ],
    ];
    if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '' && file_exists(CA_BUNDLE_PATH)) $opt[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
    curl_setopt_array($ch, $opt);
    $raw = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch);
    curl_close($ch);
    $j = is_string($raw) ? json_decode($raw, true) : null;
    if ($http !== 200 || !is_array($j) || empty($j['url']) || !preg_match('#^https://[^\s]+$#', (string)$j['url'])) {
        error_log('[cdn_ingest] başarısız HTTP ' . $http . ' ' . ($err ?: (is_array($j) ? (string)($j['error'] ?? '') : '')));
        return null;
    }
    return (string)$j['url'];
}

/**
 * Resmi GD ile ortadan kırpıp tw x th JPEG yapar (metadata/gömülü kod temizlenir). Geçici JPEG yolunu döndürür, olmazsa null.
 */
function nvImageCropJpeg(string $tmp, int $tw, int $th): ?string {
    $info = @getimagesize($tmp);
    if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, IMAGETYPE_WEBP], true)) return null;
    if ($info[0] > 6000 || $info[1] > 6000 || !function_exists('imagecreatefromstring')) return null;
    $src = @imagecreatefromstring((string)file_get_contents($tmp));
    if (!$src) return null;
    $w = imagesx($src); $h = imagesy($src); $ratio = $tw / $th;
    if ($w / $h > $ratio) { $ch = $h; $cw = (int)round($h * $ratio); } else { $cw = $w; $ch = (int)round($w / $ratio); }
    $sx = (int)(($w - $cw) / 2); $sy = (int)(($h - $ch) / 2);
    $dst = imagecreatetruecolor($tw, $th);
    imagefill($dst, 0, 0, imagecolorallocate($dst, 19, 19, 31));
    imagecopyresampled($dst, $src, 0, 0, $sx, $sy, $tw, $th, $cw, $ch);
    imagedestroy($src);
    $out = tempnam(sys_get_temp_dir(), 'nvimg');
    $ok = imagejpeg($dst, $out, 84); imagedestroy($dst);
    if (!$ok) { @unlink($out); return null; }
    return $out;
}
