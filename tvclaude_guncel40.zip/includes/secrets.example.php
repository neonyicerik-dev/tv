<?php
// includes/secrets.example.php -> secrets.php olarak kopyalayın (git'e eklemeyin; Nginx/.htaccess ile erişime kapalıdır).
// PHP-FPM ortam değişkenlerini varsayılanda temizler (clear_env=yes); alternatif: www.conf içinde clear_env = no
// ve env[GEMINI_API_KEY] = ... Bu dosya o yöntem yerine kullanılabilir.
putenv('GEMINI_API_KEY=');
putenv('GIPHY_API_KEY=');
putenv('SUPABASE_SERVICE_KEY=');
putenv('CLOUDCONVERT_API_KEY=');
putenv('ALLOWED_HOSTS=neontvapp.dpdns.org,neontv.qd.je');

// Profil resmi / kapak / kanal logosu CDN'e yüklensin (CDN panelindeki CDN_INGEST_KEY ile AYNI anahtar, en az 24 karakter)
putenv('CDN_INGEST_URL=https://cdn.neontvapp.dpdns.org/ingest.php');
putenv('CDN_INGEST_KEY=');
