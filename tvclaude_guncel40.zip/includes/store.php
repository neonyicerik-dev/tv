<?php
// ============================================================
// NeonTV - Merkezi Veri Erişim Katmanı (Store)
// JSON dosyaların yerini alır → Supabase (PostgreSQL) tabanlı
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/supabase.php';

class Store {

    // --------------------------------------------------------
    // İç yardımcılar
    // --------------------------------------------------------
    private static function db(): Supabase {
        static $instance = null;
        if ($instance === null) $instance = new Supabase();
        return $instance;
    }

    /** APCu varsa kullan, yoksa statik dizi */
    /** Kalıcı önbellek dizini (APCu yoksa dosya tabanlı önbellek kullanılır) */
    private static function cacheDir(): string {
        static $dir = null;
        if ($dir !== null) return $dir;
        $d = dirname(__DIR__) . '/logs/cache';
        if (!is_dir($d)) @mkdir($d, 0755, true);
        if (!is_dir($d) || !is_writable($d)) { $d = sys_get_temp_dir() . '/neontv_cache'; if (!is_dir($d)) @mkdir($d, 0755, true); }
        return $dir = $d;
    }
    private static function cacheFile(string $key): string {
        return self::cacheDir() . '/' . md5($key) . '.cache';
    }

    private static function cacheGet(string $key): mixed {
        if (array_key_exists($key, self::$memCache)) return self::$memCache[$key];
        if (function_exists('apcu_fetch')) {
            $val = apcu_fetch($key, $ok);
            if ($ok) return $val;
        }
        $f = self::cacheFile($key);
        if (is_file($f)) {
            $raw = @file_get_contents($f);
            $pack = $raw !== false ? @unserialize($raw, ['allowed_classes' => false]) : false;
            if (is_array($pack) && isset($pack['e']) && $pack['e'] > time()) { self::$memCache[$key] = $pack['v']; return $pack['v']; }
        }
        return null;
    }

    private static function cacheSet(string $key, mixed $val, int $ttl = 60): void {
        if (function_exists('apcu_store')) {
            apcu_store($key, $val, $ttl);
        }
        self::$memCache[$key] = $val;
        $f = self::cacheFile($key); $tmp = $f . '.' . getmypid() . '.tmp';
        if (@file_put_contents($tmp, serialize(['e' => time() + $ttl, 'v' => $val]), LOCK_EX) !== false) @rename($tmp, $f);
    }

    private static function cacheDel(string $key): void {
        if (function_exists('apcu_delete')) {
            apcu_delete($key);
        }
        unset(self::$memCache[$key]);
        @unlink(self::cacheFile($key));
    }

    /** Sonucu $ttl saniye önbellekte tut (null/false sonuçlar da saklanır) */
    public static function remember(string $key, int $ttl, callable $fn): mixed {
        $hit = self::cacheGet($key);
        if (is_array($hit) && array_key_exists('_r', $hit)) return $hit['_r'];
        $val = $fn();
        self::cacheSet($key, ['_r' => $val], $ttl);
        return $val;
    }

    /** Önbellekte varsa ['_r'=>değer], yoksa null */
    public static function peek(string $key): ?array {
        $hit = self::cacheGet($key);
        return (is_array($hit) && array_key_exists('_r', $hit)) ? $hit : null;
    }
    public static function put(string $key, int $ttl, mixed $val): void {
        self::cacheSet($key, ['_r' => $val], $ttl);
    }

    public static function clearCache(string $key): void {
        self::cacheDel($key);
    }

    private static array $memCache = [];

    // --------------------------------------------------------
    // AYARLAR (site_settings tablosu)
    // --------------------------------------------------------

    /**
     * Tüm ayarları anahtar→değer dizisi olarak döndürür.
     * İstek başına bir kez çekilir (statik önbellek).
     * Veritabanına ulaşılamazsa boş dizi + error_log.
     */
    public static function getSettings(): array {
        static $settings = null;
        if ($settings !== null) return $settings;

        $cached = self::cacheGet('site_settings');
        if ($cached !== null) { $settings = $cached; return $settings; }

        try {
            $res = self::db()->select('site_settings', 'select=key,value', true);
            if ($res['status'] === 200 && is_array($res['data'])) {
                $settings = [];
                foreach ($res['data'] as $row) {
                    $settings[$row['key']] = $row['value'];
                }
                self::cacheSet('site_settings', $settings, 60);
                return $settings;
            }
        } catch (\Throwable $e) {
            error_log('[Store::getSettings] ' . $e->getMessage());
        }

        $settings = [];
        return $settings;
    }

    public static function getSetting(string $key, mixed $default = null): mixed {
        $s = self::getSettings();
        return $s[$key] ?? $default;
    }

    public static function setSetting(string $key, mixed $value): bool {
        try {
            $db = self::db();
            $res = $db->select('site_settings', 'key=eq.' . urlencode($key) . '&select=key', true);
            if (!empty($res['data'])) {
                $r = $db->update('site_settings', [
                    'value'      => $value,
                    'updated_at' => date('c'),
                ], 'key=eq.' . urlencode($key), true);
            } else {
                $r = $db->insert('site_settings', ['key' => $key, 'value' => $value], true);
            }
            // Önbellek temizle
            self::cacheDel('site_settings');
            static $settings = null;
            $settings = null; // statik önbelleği sıfırla – bir sonraki çağrıda yeniden çekilir
            return ($r['status'] < 400);
        } catch (\Throwable $e) {
            error_log('[Store::setSetting] ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Birden fazla ayarı aynı anda güncelle.
     * settings = ['key' => value, ...]
     */
    public static function setSettings(array $settings): bool {
        $ok = true;
        foreach ($settings as $k => $v) {
            if (!self::setSetting($k, $v)) $ok = false;
        }
        return $ok;
    }

    // --------------------------------------------------------
    // BAKIM MODU (çok hızlı önbellekli)
    // --------------------------------------------------------
    public static function isMaintenanceMode(): bool {
        try {
            $val = self::getSettings()['maintenance_mode'] ?? false;
            if (is_string($val)) $val = in_array(strtolower($val), ['true', '1', 'yes'], true);
            return (bool)$val;
        } catch (\Throwable $e) {
            error_log('[Store::isMaintenanceMode] ' . $e->getMessage());
            return false; // güvenli varsayılan: bakım modu kapalı
        }
    }

    // --------------------------------------------------------
    // ADMIN KULLANICILARI (admin_users tablosu)
    // --------------------------------------------------------
    public static function admins(): array {
        try {
            $res = self::db()->select('admin_users', 'select=id,username,password_hash,role,created_at,last_login_at', true);
            return $res['data'] ?? [];
        } catch (\Throwable $e) {
            error_log('[Store::admins] ' . $e->getMessage());
            return [];
        }
    }

    public static function findAdmin(string $username): ?array {
        try {
            $res = self::db()->first('admin_users', 'username=eq.' . urlencode($username) . '&select=id,username,password_hash,role,created_at', true);
            return $res ?: null;
        } catch (\Throwable $e) {
            error_log('[Store::findAdmin] ' . $e->getMessage());
            return null;
        }
    }

    public static function createAdmin(string $id, string $username, string $passwordHash, string $role = 'editor'): bool {
        try {
            $r = self::db()->insert('admin_users', [
                'id'            => $id,
                'username'      => $username,
                'password_hash' => $passwordHash,
                'role'          => $role,
                'created_at'    => date('c'),
            ], true);
            return ($r['status'] < 400);
        } catch (\Throwable $e) {
            error_log('[Store::createAdmin] ' . $e->getMessage());
            return false;
        }
    }

    public static function deleteAdmin(string $id): bool {
        try {
            $r = self::db()->delete('admin_users', 'id=eq.' . urlencode($id), true);
            return ($r['status'] < 400);
        } catch (\Throwable $e) {
            error_log('[Store::deleteAdmin] ' . $e->getMessage());
            return false;
        }
    }

    public static function updateAdminLastLogin(string $username): void {
        try {
            self::db()->update('admin_users', ['last_login_at' => date('c')], 'username=eq.' . urlencode($username), true);
        } catch (\Throwable $e) {
            error_log('[Store::updateAdminLastLogin] ' . $e->getMessage());
        }
    }

    // --------------------------------------------------------
    // AKTİVİTE LOGU (activity_log tablosu)
    // --------------------------------------------------------
    public static function logActivity(
        string $action,
        string $target = '',
        array  $details = [],
        string $admin = '',
        string $ipHash = ''
    ): void {
        if (!$admin) $admin = $_SESSION['admin_username'] ?? 'system';
        if (!$ipHash) {
            $ip = getClientIp();
            $ipHash = self::hashIp($ip);
        }

        try {
            self::db()->insert('activity_log', [
                'admin_username' => $admin,
                'action'         => $action,
                'target'         => $target,
                'details'        => $details ?: null,
                'ip_hash'        => $ipHash,
            ], true);
        } catch (\Throwable $e) {
            error_log('[Store::logActivity] ' . $e->getMessage());
        }
    }

    public static function getActivityLog(int $limit = 100, int $offset = 0): array {
        try {
            $res = self::db()->select('activity_log',
                'order=created_at.desc&limit=' . (int)$limit . '&offset=' . (int)$offset,
                true
            );
            return $res['data'] ?? [];
        } catch (\Throwable $e) {
            error_log('[Store::getActivityLog] ' . $e->getMessage());
            return [];
        }
    }

    // --------------------------------------------------------
    // ENGELLENEN IP'LER (blocked_ips tablosu)
    // --------------------------------------------------------

    /** Ham IP → DB */
    public static function blockedIps(): array {
        $cached = self::cacheGet('blocked_ips');
        if ($cached !== null) return $cached;

        try {
            $res = self::db()->select('blocked_ips', 'select=ip,reason,blocked_by,created_at,expires_at', true);
            $list = $res['data'] ?? [];
            self::cacheSet('blocked_ips', $list, 60);
            return $list;
        } catch (\Throwable $e) {
            error_log('[Store::blockedIps] ' . $e->getMessage());
            return [];
        }
    }

    public static function isIpBlocked(string $ip): bool {
        $list = self::blockedIps();
        foreach ($list as $entry) {
            $blockedIp = $entry['ip'] ?? '';
            if ($blockedIp === $ip) {
                // Süre kontrolü
                if (!empty($entry['expires_at']) && strtotime($entry['expires_at']) < time()) {
                    continue; // Süresi dolmuş
                }
                return true;
            }
            // CIDR desteği
            if (str_contains($blockedIp, '/') && ipInCidr($ip, $blockedIp)) return true;
        }
        return false;
    }

    public static function blockIp(string $ip, string $reason = '', string $admin = '', ?string $expiresAt = null): bool {
        try {
            $data = [
                'ip'         => $ip,
                'reason'     => $reason,
                'blocked_by' => $admin ?: ($_SESSION['admin_username'] ?? 'system'),
                'created_at' => date('c'),
            ];
            if ($expiresAt) $data['expires_at'] = $expiresAt;
            $r = self::db()->insert('blocked_ips', $data, true);
            self::cacheDel('blocked_ips');
            return ($r['status'] < 400);
        } catch (\Throwable $e) {
            error_log('[Store::blockIp] ' . $e->getMessage());
            return false;
        }
    }

    public static function unblockIp(string $ip): bool {
        try {
            $r = self::db()->delete('blocked_ips', 'ip=eq.' . urlencode($ip), true);
            self::cacheDel('blocked_ips');
            return ($r['status'] < 400);
        } catch (\Throwable $e) {
            error_log('[Store::unblockIp] ' . $e->getMessage());
            return false;
        }
    }

    // --------------------------------------------------------
    // ZİYARET KAYDI (ip_visits tablosu)
    // --------------------------------------------------------
    public static function logVisit(string $ipHash, string $countryCode, string $city, string $isp, string $page, string $referrer, string $ua): void {
        try {
            $db = self::db();
            $db->insert('ip_visits', [
                'ip_hash'      => $ipHash,
                'country_code' => $countryCode,
                'city'         => $city,
                'isp'          => $isp,
                'page'         => substr($page, 0, 500),
                'referrer'     => substr($referrer, 0, 500),
                'ua'           => substr($ua, 0, 300),
            ], true);
        } catch (\Throwable $e) {
            // Ziyaret kaydı sayfayı asla kırmasın
            error_log('[Store::logVisit] ' . $e->getMessage());
        }
    }

    public static function getRecentVisits(int $hours = 24, int $limit = 500): array {
        try {
            $since = gmdate('Y-m-d\TH:i:s\Z', time() - ($hours * 3600));
            $res = self::db()->select('ip_visits',
                'created_at=gte.' . urlencode($since) . '&order=created_at.desc&limit=' . (int)$limit,
                true
            );
            return $res['data'] ?? [];
        } catch (\Throwable $e) {
            error_log('[Store::getRecentVisits] ' . $e->getMessage());
            return [];
        }
    }

    // --------------------------------------------------------
    // GEO CACHE (ip_geo_cache tablosu)
    // --------------------------------------------------------
    public static function getGeoCache(string $ipHash): ?array {
        try {
            $res = self::db()->first('ip_geo_cache', 'ip_hash=eq.' . urlencode($ipHash) . '&select=data,fetched_at', true);
            if (!$res) return null;
            // 7 günden eskiyse geçersiz
            if (!empty($res['fetched_at']) && (time() - strtotime($res['fetched_at'])) > 604800) return null;
            return $res['data'] ?? null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    public static function setGeoCache(string $ipHash, array $data): void {
        try {
            $db = self::db();
            $existing = $db->first('ip_geo_cache', 'ip_hash=eq.' . urlencode($ipHash), true);
            if ($existing) {
                $db->update('ip_geo_cache', ['data' => $data, 'fetched_at' => date('c')], 'ip_hash=eq.' . urlencode($ipHash), true);
            } else {
                $db->insert('ip_geo_cache', ['ip_hash' => $ipHash, 'data' => $data, 'fetched_at' => date('c')], true);
            }
        } catch (\Throwable $e) {
            error_log('[Store::setGeoCache] ' . $e->getMessage());
        }
    }

    // --------------------------------------------------------
    // GİRİŞ DENEMELERİ (login_attempts tablosu)
    // --------------------------------------------------------

    /** Son 15 dk içindeki başarısız deneme sayısını döndürür */
    public static function countLoginAttempts(string $key): int {
        try {
            $since = gmdate('Y-m-d\TH:i:s\Z', time() - 900); // 15 dk
            $res = self::db()->select('login_attempts',
                'key=eq.' . urlencode($key) . '&created_at=gte.' . urlencode($since) . '&select=id',
                true
            );
            return count($res['data'] ?? []);
        } catch (\Throwable $e) {
            error_log('[Store::countLoginAttempts] ' . $e->getMessage());
            return 0;
        }
    }

    public static function recordLoginAttempt(string $key): void {
        try {
            self::db()->insert('login_attempts', ['key' => $key], true);
        } catch (\Throwable $e) {
            error_log('[Store::recordLoginAttempt] ' . $e->getMessage());
        }
    }

    public static function clearLoginAttempts(string $key): void {
        try {
            self::db()->delete('login_attempts', 'key=eq.' . urlencode($key), true);
        } catch (\Throwable $e) {
            error_log('[Store::clearLoginAttempts] ' . $e->getMessage());
        }
    }

    // --------------------------------------------------------
    // PREMIUM (user_premium tablosu)
    // --------------------------------------------------------
    public static function isPremium(string $userId): bool {
        try {
            $res = self::db()->first('user_premium', 'user_id=eq.' . urlencode($userId) . '&select=premium_until', true);
            if (!$res) return false;
            $until = $res['premium_until'];
            return ($until === null || strtotime($until) > time());
        } catch (\Throwable $e) {
            error_log('[Store::isPremium] ' . $e->getMessage());
            return false;
        }
    }

    /** Verilen kullanıcı ID'lerinden aktif premium olanları döndürür (id => true) */
    public static function getPremiumUserIds(array $userIds): array {
        $ids = array_values(array_unique(array_filter($userIds, fn($u) => is_string($u) && isUuid($u))));
        if (!$ids) return [];
        try {
            $res = self::db()->select('user_premium', 'user_id=in.(' . implode(',', $ids) . ')&select=user_id,premium_until', true);
            $out = [];
            foreach (($res['data'] ?? []) as $r) {
                if ($r['premium_until'] === null || strtotime($r['premium_until']) > time()) $out[$r['user_id']] = true;
            }
            return $out;
        } catch (\Throwable $e) {
            error_log('[Store::getPremiumUserIds] ' . $e->getMessage());
            return [];
        }
    }

    // --------------------------------------------------------
    // PROFİL TEMASI + AVATAR ÇERÇEVESİ (user_themes) – yalnızca aktif premium kullanıcılar için geçerli
    // --------------------------------------------------------
    /** @param array $premium getPremiumUserIds() çıktısı (verilirse ikinci sorgu yapılmaz) */
    public static function getUserThemes(array $userIds, ?array $premium = null): array {
        $ids = array_values(array_unique(array_filter($userIds, fn($u) => is_string($u) && isUuid($u))));
        if (!$ids) return [];
        try {
            $premium ??= self::getPremiumUserIds($ids);
            $ids = array_values(array_filter($ids, fn($u) => !empty($premium[$u])));
            if (!$ids) return [];
            require_once __DIR__ . '/themes.php';
            $res = self::db()->select('user_themes', 'user_id=in.(' . implode(',', $ids) . ')&select=user_id,theme,frame', true);
            $out = [];
            foreach (($res['data'] ?? []) as $r) {
                $t = nvValidKey($r['theme'] ?? null) ? ($r['theme'] ?: null) : null;
                $f = nvValidFrame($r['frame'] ?? null) ? ($r['frame'] ?: null) : null;
                if ($t || $f) $out[$r['user_id']] = ['theme' => $t, 'frame' => $f];
            }
            return $out;
        } catch (\Throwable $e) {
            error_log('[Store::getUserThemes] ' . $e->getMessage());
            return [];
        }
    }

    public static function grantPremium(string $userId, ?string $premiumUntil, string $grantedBy = '', string $note = ''): bool {
        try {
            $db = self::db();
            $existing = $db->first('user_premium', 'user_id=eq.' . urlencode($userId), true);
            $data = [
                'premium_until' => $premiumUntil,
                'granted_by'    => $grantedBy ?: ($_SESSION['admin_username'] ?? 'admin'),
                'note'          => $note,
                'updated_at'    => date('c'),
            ];
            if ($existing) {
                $r = $db->update('user_premium', $data, 'user_id=eq.' . urlencode($userId), true);
            } else {
                $data['user_id'] = $userId;
                $r = $db->insert('user_premium', $data, true);
            }
            return ($r['status'] < 400);
        } catch (\Throwable $e) {
            error_log('[Store::grantPremium] ' . $e->getMessage());
            return false;
        }
    }

    public static function revokePremium(string $userId): bool {
        try {
            $r = self::db()->delete('user_premium', 'user_id=eq.' . urlencode($userId), true);
            return ($r['status'] < 400);
        } catch (\Throwable $e) {
            error_log('[Store::revokePremium] ' . $e->getMessage());
            return false;
        }
    }

    // --------------------------------------------------------
    // YZ KOTA (ai_usage tablosu)
    // --------------------------------------------------------
    public static function getAiUsage(string $userId, string $period): array {
        try {
            $res = self::db()->first('ai_usage',
                'user_id=eq.' . urlencode($userId) . '&period=eq.' . urlencode($period),
                true
            );
            return $res ?? ['user_id' => $userId, 'period' => $period, 'used' => 0];
        } catch (\Throwable $e) {
            return ['user_id' => $userId, 'period' => $period, 'used' => 0];
        }
    }

    /** Atomik kota düşme – SQL fonksiyonu üzerinden, yoksa tablo fallback */
    public static function consumeAiQuota(string $userId, string $period, int $max): bool {
        try {
            $res = self::db()->rpc('consume_ai_quota', [
                'p_uid'    => $userId,
                'p_period' => $period,
                'p_max'    => $max,
            ], true);
            if ($res['status'] === 200 && is_bool($res['data'])) {
                return $res['data'];
            }

            // RPC yoksa doğrudan tablo üzerinden kota kontrolü (yedek çözüm)
            $db = self::db();
            $curr = $db->first('ai_usage', 'user_id=eq.' . urlencode($userId) . '&period=eq.' . urlencode($period), true);
            if ($curr) {
                $used = (int)($curr['used'] ?? 0);
                if ($used >= $max) return false;
                $r = $db->update('ai_usage', [
                    'used' => $used + 1,
                ], 'user_id=eq.' . urlencode($userId) . '&period=eq.' . urlencode($period), true);
                return ($r['status'] ?? 500) < 400;
            } else {
                $r = $db->insert('ai_usage', [
                    'user_id' => $userId,
                    'period'  => $period,
                    'used'    => 1,
                ], true);
                return ($r['status'] ?? 500) < 400;
            }
        } catch (\Throwable $e) {
            error_log('[Store::consumeAiQuota] ' . $e->getMessage());
            return false; // Güvenli taraf: kota doğrulanamıyorsa izin verme
        }
    }

    /** Hata durumunda hakkı iade et */
    public static function refundAiQuota(string $userId, string $period): void {
        try {
            self::db()->rpc('refund_ai_quota', [
                'p_uid'    => $userId,
                'p_period' => $period,
            ], true);
        } catch (\Throwable $e) {
            error_log('[Store::refundAiQuota] ' . $e->getMessage());
        }
    }

    // --------------------------------------------------------
    // IP HASH YARDIMCISI
    // --------------------------------------------------------
    public static function hashIp(string $ip): string {
        $secret = defined('IP_HASH_SECRET') ? IP_HASH_SECRET : 'neontv_default_secret_change_me';
        return hash_hmac('sha256', $ip, $secret);
    }

    // --------------------------------------------------------
    // REKLAMLAR (ads, popups tabloları)
    // --------------------------------------------------------
    public static function getActiveVideoAds(): array {
        try {
            return self::remember('ads_video', 60, function () {
                $res = self::db()->select('ads', 'type=eq.video&is_active=eq.true&select=id,type,click_url,video_url,skip_after_seconds', true);
                return is_array($res['data'] ?? null) ? $res['data'] : [];
            });
        } catch (\Throwable $e) {
            error_log('[Store::getActiveVideoAds] ' . $e->getMessage());
            return [];
        }
    }

    /** Tüm aktif banner reklamlar (ana sayfada dönüşümlü gösterilir) */
    public static function getActiveBannerAds(): array {
        try {
            $rows = self::remember('ads_banner_all', 60, function () {
                $res = self::db()->select('ads', 'type=eq.banner&is_active=eq.true&order=created_at.asc&select=id,click_url,gif_url', true);
                return is_array($res['data'] ?? null) ? $res['data'] : [];
            });
            return array_values(array_filter($rows, fn($r) => !empty($r['gif_url']) && !empty($r['click_url'])));
        } catch (\Throwable $e) {
            error_log('[Store::getActiveBannerAds] ' . $e->getMessage());
            return [];
        }
    }

    public static function getActiveBannerAd(): ?array {
        try {
            $banners = self::remember('ads_banner_pick', 60, function () {
                $res = self::db()->select('ads', 'type=eq.banner&is_active=eq.true&select=id,click_url,gif_url', true);
                return is_array($res['data'] ?? null) ? $res['data'] : [];
            });
            if (empty($banners)) return null;
            return $banners[array_rand($banners)];
        } catch (\Throwable $e) {
            error_log('[Store::getActiveBannerAd] ' . $e->getMessage());
            return null;
        }
    }

    public static function getActivePopup(): ?array {
        try {
            $res = self::remember('active_popup', 60, fn() => self::db()->first('popups', 'is_active=eq.true&select=id,title,image_url,link_url', true));
            return $res ?: null;
        } catch (\Throwable $e) {
            error_log('[Store::getActivePopup] ' . $e->getMessage());
            return null;
        }
    }

    // --------------------------------------------------------
    // KATEGORİLER (categories tablosu)
    // --------------------------------------------------------
    public static function getCategories(bool $onlyActive = true): array {
        $cacheKey = 'categories_' . ($onlyActive ? 'active' : 'all');
        $cached = self::cacheGet($cacheKey);
        if ($cached !== null) return $cached;

        try {
            $q = 'order=sort_order.asc,name.asc&select=id,name,slug,sort_order,is_active';
            if ($onlyActive) $q = 'is_active=eq.true&' . $q;
            $res = self::db()->select('categories', $q, true);
            $result = $res['data'] ?? [];
            self::cacheSet($cacheKey, $result, 120);
            return $result;
        } catch (\Throwable $e) {
            error_log('[Store::getCategories] ' . $e->getMessage());
            return [];
        }
    }
}


/**
 * Site ayarları: eski includes/settings.json (varsa) üzerine DB (site_settings) ayarları biner.
 * Admin sayfaları ve API'ler ayarları buradan okur; yazma Store::setSettings ile DB'ye yapılır.
 */
function loadSettingsCompat(): array {
    $file = __DIR__ . '/settings.json';
    $base = file_exists($file) ? (json_decode((string)@file_get_contents($file), true) ?: []) : [];
    $db   = Store::getSettings();
    return array_replace($base, is_array($db) ? $db : []);
}

/** Değişen ayarları DB'ye yazar. $old = yazmadan önceki dizi, $new = sonraki dizi. */
function saveSettingsDiff(array $old, array $new): bool {
    $diff = [];
    foreach ($new as $k => $v) {
        if (!array_key_exists($k, $old) || $old[$k] !== $v) $diff[$k] = $v;
    }
    return $diff ? Store::setSettings($diff) : true;
}
