<?php
// ============================================================
// NeonTV - Arama Sayfası
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';
require_once __DIR__ . '/includes/store.php';

$query = trim($_GET['q'] ?? '');
$page  = max(1, (int)($_GET['page'] ?? 1));

// Gelişmiş filtreler
$fCat  = trim($_GET['cat'] ?? '');
$fChan = trim($_GET['channel'] ?? '');
$fDur  = pgEnum($_GET['dur']  ?? '', ['short', 'medium', 'long'], '');
$fDate = pgEnum($_GET['date'] ?? '', ['day', 'week', 'month', 'year'], '');
$fSort = pgEnum($_GET['sort'] ?? '', ['popular', 'new'], 'popular');
if ($fChan !== '' && !isUuid($fChan)) $fChan = '';
$hasFilter = ($fCat !== '' || $fChan !== '' || $fDur !== '' || $fDate !== '');

$pageTitle = $query ? '"' . $query . '" için arama sonuçları' : 'Arama';
$metaDesc  = 'NeonTV\'de "' . $query . '" için arama sonuçları.';

$videos = [];
$total  = 0;
$db = new Supabase();

$allCats  = Store::remember('search_cats', 120, function () use ($db) { $r = $db->select('categories', 'is_active=eq.true&order=sort_order.asc&select=name,slug'); return is_array($r['data'] ?? null) ? $r['data'] : []; });
$allChans = Store::remember('search_chans', 120, function () use ($db) { $r = $db->select('channels', 'order=name.asc&select=id,name&limit=200'); return is_array($r['data'] ?? null) ? $r['data'] : []; });

if ($query || $hasFilter) {
    $where = ['status=eq.published'];
    if ($query) {
        $encodedQ = urlencode(str_replace(['(', ')', ','], ' ', $query));
        $where[] = 'or=(title.ilike.*' . $encodedQ . '*,description.ilike.*' . $encodedQ . '*)';
    }
    if ($fChan !== '') $where[] = 'channel_id=eq.' . $fChan;
    if ($fDur === 'short')  $where[] = 'duration=lt.300';
    if ($fDur === 'medium') { $where[] = 'duration=gte.300'; $where[] = 'duration=lte.1200'; }
    if ($fDur === 'long')   $where[] = 'duration=gt.1200';
    if ($fDate !== '') {
        $secs = ['day' => 86400, 'week' => 604800, 'month' => 2592000, 'year' => 31536000][$fDate];
        $where[] = 'created_at=gte.' . urlencode(gmdate('Y-m-d\TH:i:s\Z', time() - $secs));
    }
    $catEmpty = false;
    if ($fCat !== '') {
        $c = $db->first('categories', 'slug=eq.' . urlencode($fCat) . '&select=id');
        $ids = [];
        if ($c) {
            $vc = $db->select('video_categories', 'category_id=eq.' . $c['id'] . '&select=video_id&limit=1000');
            foreach (($vc['data'] ?? []) as $r) if (isUuid($r['video_id'])) $ids[] = $r['video_id'];
        }
        if ($ids) $where[] = 'id=in.(' . implode(',', $ids) . ')'; else $catEmpty = true;
    }
    if (!$catEmpty) {
        $base  = implode('&', $where);
        $order = $fSort === 'new' ? 'created_at.desc' : 'views.desc';
        $searchResult = $db->select('videos', $base . '&order=' . $order . '&limit=' . VIDEOS_PER_PAGE . '&offset=' . (($page - 1) * VIDEOS_PER_PAGE));
        $videos = $searchResult['data'] ?? [];
        if (is_array($videos)) nvFlagSubtitles($videos);
        $total  = $db->count('videos', $base . '&select=id');
    }
}

// #29 Arama günlüğü (yalnızca ilk sayfa, yanıt sonrası; kullanıcı kimliği/IP yazılmaz)
if ($query !== '' && mb_strlen($query) >= 2 && (int)($_GET['page'] ?? 1) <= 1) {
    $__q = mb_substr(mb_strtolower($query), 0, 80); $__n = is_array($videos) ? count($videos) : 0;
    register_shutdown_function(function () use ($db, $__q, $__n) {
        try { $db->insert('search_log', ['q' => $__q, 'results' => $__n], true); } catch (\Throwable $e) {}
    });
}

// "Şunu mu demek istediniz?" – sonuç yoksa başlık/etiket kelimelerine en yakın yazımı öner
$didYouMean = '';
if ($query !== '' && empty($videos) && mb_strlen($query) >= 3) {
    $dict = [];
    $dv = Store::remember('search_dict_rows', 600, function () use ($db) { $r = $db->select('videos', 'status=eq.published&select=title,tags&limit=1000'); return is_array($r['data'] ?? null) ? $r['data'] : []; });
    foreach ($dv as $row) {
        $txt = ($row['title'] ?? '') . ' ' . (is_array($row['tags'] ?? null) ? implode(' ', $row['tags']) : '');
        foreach (preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower($txt), -1, PREG_SPLIT_NO_EMPTY) as $w) {
            if (mb_strlen($w) >= 3 && mb_strlen($w) <= 30) $dict[$w] = ($dict[$w] ?? 0) + 1;
        }
    }
    $fix = []; $changed = false;
    foreach (preg_split('/\s+/u', mb_strtolower($query), -1, PREG_SPLIT_NO_EMPTY) as $qw) {
        if (isset($dict[$qw]) || mb_strlen($qw) < 3) { $fix[] = $qw; continue; }
        $bestW = $qw; $bestD = mb_strlen($qw) <= 4 ? 1 : 2; $bestF = 0;
        foreach ($dict as $w => $f) {
            if (abs(strlen($w) - strlen($qw)) > 2) continue;
            $d = levenshtein($qw, $w);
            if ($d < $bestD || ($d === $bestD && $f > $bestF && $bestW !== $qw)) { $bestD = $d; $bestW = $w; $bestF = $f; }
        }
        if ($bestW !== $qw) $changed = true;
        $fix[] = $bestW;
    }
    if ($changed) $didYouMean = implode(' ', $fix);
}

// Sayfalama bağlantıları için mevcut filtreleri koru
$qs = http_build_query(array_filter(['q' => $query, 'cat' => $fCat, 'channel' => $fChan, 'dur' => $fDur, 'date' => $fDate, 'sort' => $fSort !== 'popular' ? $fSort : ''], fn($v) => $v !== ''));

$highlightQuery = $query;
$pagination = paginate($total, VIDEOS_PER_PAGE, $page);
?>
<?php include __DIR__ . '/components/header.php'; ?>

<div class="max-w-screen-2xl mx-auto px-4 sm:px-6 py-8">

    <!-- ===== ARAMA BAŞLIĞI ===== -->
    <div class="mb-8">
        <?php if ($query || $hasFilter): ?>
        <div class="flex items-center gap-3 mb-2">
            <i class="fa-solid fa-magnifying-glass text-neon-cyan"></i>
            <h1 class="text-2xl font-bold text-white">
                <?= $query ? '"<span class="text-neon-cyan">' . e($query) . '</span>" için sonuçlar' : 'Filtre sonuçları' ?>
            </h1>
        </div>
        <p class="text-gray-500 text-sm ml-7">
            <?= $total ?> video bulundu
        </p>
        <?php else: ?>
        <h1 class="text-2xl font-bold text-white mb-6 flex items-center gap-3">
            <i class="fa-solid fa-magnifying-glass text-neon-cyan"></i>
            Video Ara
        </h1>

        <!-- Büyük Arama Kutusu -->
        <form action="" method="GET" class="max-w-2xl">
            <div class="relative">
                <input type="text" name="q" placeholder="Bir video başlığı girin..."
                       autofocus
                       class="w-full py-4 pl-6 pr-14 rounded-2xl text-white placeholder-gray-500 outline-none text-base transition-all duration-300"
                       style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);"
                       onfocus="this.style.borderColor='rgba(0,245,255,0.5)';this.style.boxShadow='0 0 0 4px rgba(0,245,255,0.08)'"
                       onblur="this.style.borderColor='rgba(255,255,255,0.1)';this.style.boxShadow='none'">
                <button type="submit" class="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl flex items-center justify-center transition-all"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                    <i class="fa-solid fa-magnifying-glass text-black text-sm"></i>
                </button>
            </div>
        </form>
        <?php endif; ?>
    </div>

    <!-- ===== GELİŞMİŞ FİLTRELER ===== -->
    <form method="GET" class="mb-8 p-4 rounded-2xl grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3"
          style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);">
        <input type="text" name="q" value="<?= e($query) ?>" placeholder="Anahtar kelime" class="col-span-2 px-3 py-2 rounded-xl text-sm text-white outline-none"
               style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
        <?php
        $sel = 'class="px-3 py-2 rounded-xl text-sm text-white outline-none" style="background:#13131f;border:1px solid rgba(255,255,255,0.1);"';
        ?>
        <select name="cat" <?= $sel ?>><option value="">Kategori: Tümü</option>
            <?php foreach ($allCats as $c): ?><option value="<?= e($c['slug']) ?>" <?= $fCat === $c['slug'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
        <select name="channel" <?= $sel ?>><option value="">Kanal: Tümü</option>
            <?php foreach ($allChans as $c): ?><option value="<?= e($c['id']) ?>" <?= $fChan === $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
        <select name="dur" <?= $sel ?>>
            <option value="">Süre: Tümü</option>
            <option value="short"  <?= $fDur === 'short'  ? 'selected' : '' ?>>5 dk altı</option>
            <option value="medium" <?= $fDur === 'medium' ? 'selected' : '' ?>>5 – 20 dk</option>
            <option value="long"   <?= $fDur === 'long'   ? 'selected' : '' ?>>20 dk üstü</option></select>
        <select name="date" <?= $sel ?>>
            <option value="">Tarih: Tümü</option>
            <option value="day"   <?= $fDate === 'day'   ? 'selected' : '' ?>>Bugün</option>
            <option value="week"  <?= $fDate === 'week'  ? 'selected' : '' ?>>Bu hafta</option>
            <option value="month" <?= $fDate === 'month' ? 'selected' : '' ?>>Bu ay</option>
            <option value="year"  <?= $fDate === 'year'  ? 'selected' : '' ?>>Bu yıl</option></select>
        <select name="sort" <?= $sel ?>>
            <option value="popular" <?= $fSort === 'popular' ? 'selected' : '' ?>>En popüler</option>
            <option value="new"     <?= $fSort === 'new'     ? 'selected' : '' ?>>En yeni</option></select>
        <button type="submit" class="px-4 py-2 rounded-xl text-sm font-bold text-black col-span-2 md:col-span-1"
                style="background:linear-gradient(135deg,#00f5ff,#bf00ff);"><i class="fa-solid fa-filter mr-1"></i> Filtrele</button>
    </form>

    <?php if (($query || $hasFilter) && empty($videos)): ?>
    <!-- Sonuç Yok -->
    <div class="text-center py-20" id="no-results">
        <div class="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4"
             style="background:rgba(191,0,255,0.05);border:1px solid rgba(191,0,255,0.15);">
            <i class="fa-solid fa-magnifying-glass text-3xl" style="color:rgba(191,0,255,0.4);"></i>
        </div>
        <h3 class="text-lg font-semibold text-gray-400 mb-2">"<?= e($query) ?>" için sonuç bulunamadı</h3>
        <?php if ($didYouMean): ?>
        <p class="text-gray-400 text-sm mb-4">Bunu mu demek istediniz: <a class="text-cyan-400 font-semibold underline" href="?q=<?= urlencode($didYouMean) ?>"><?= e($didYouMean) ?></a></p>
        <?php endif; ?>
        <p class="text-gray-600 text-sm mb-6">Farklı anahtar kelimeler deneyin.</p>
        <a href="<?= APP_URL ?>/index.php"
           class="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium"
           style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);color:#e5e7eb;">
            <i class="fa-solid fa-house text-xs"></i>
            Ana Sayfaya Dön
        </a>
    </div>

    <?php elseif (!empty($videos)): ?>
    <!-- Sonuçlar Grid -->
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4" id="search-results-grid">
        <?php foreach ($videos as $video): ?>
            <?php include __DIR__ . '/components/video_card.php'; ?>
        <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($pagination['total_pages'] > 1): ?>
    <div class="flex items-center justify-center gap-2 mt-10" id="search-pagination">
        <?php if ($pagination['has_prev']): ?>
        <a href="?<?= e($qs) ?>&page=<?= $page - 1 ?>"
           class="flex items-center gap-2 px-4 py-2 rounded-xl text-sm text-gray-300 hover:text-white transition-all"
           style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
            <i class="fa-solid fa-chevron-left text-xs"></i> Önceki
        </a>
        <?php endif; ?>

        <span class="text-sm text-gray-500">
            Sayfa <?= $page ?> / <?= $pagination['total_pages'] ?>
        </span>

        <?php if ($pagination['has_next']): ?>
        <a href="?<?= e($qs) ?>&page=<?= $page + 1 ?>"
           class="flex items-center gap-2 px-4 py-2 rounded-xl text-sm text-gray-300 hover:text-white transition-all"
           style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
            Sonraki <i class="fa-solid fa-chevron-right text-xs"></i>
        </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>

</div>

<?php if ($query !== '' && !empty($videos)): ?>
<script>
// Aranan kelimeleri sonuç başlıklarında vurgula
document.addEventListener('DOMContentLoaded', function () {
    const words = <?= json_encode(array_values(array_filter(preg_split('/\s+/u', mb_strtolower($query)), fn($w) => mb_strlen($w) >= 2)), JSON_UNESCAPED_UNICODE) ?>;
    if (!words.length) return;
    const re = new RegExp('(' + words.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'gi');
    document.querySelectorAll('#search-results-grid h3').forEach(h => {
        const t = h.textContent.trim();
        const safe = t.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        h.innerHTML = safe.replace(re, '<mark style="background:rgba(0,245,255,0.25);color:#00f5ff;border-radius:3px;padding:0 2px">$1</mark>');
    });
});
</script>
<?php endif; ?>

<?php include __DIR__ . '/components/footer.php'; ?>
