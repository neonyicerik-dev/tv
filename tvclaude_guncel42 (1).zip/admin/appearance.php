<?php
// NeonTV - Admin: Tema Sistemi (site arka planı + logo süsü)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/appearance.php';
requireAdmin(['superadmin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/appearance.php'); }
    $url = fn($k) => preg_match('#^(https?://|/)[^\s"\'<>()]+$#i', trim(input($k))) ? trim(input($k)) : '';
    $objs = nvLogoObjects();
    $ok = Store::setSettings([
        'site_bg_url'    => input('bg_clear') ? '' : $url('bg_url'),
        'site_bg_dim'    => max(0, min(95, (int)input('bg_dim'))),
        'logo_deco_type' => in_array(input('deco_type'), ['none', 'image', 'object'], true) ? input('deco_type') : 'none',
        'logo_deco_url'  => $url('deco_url'),
        'logo_deco_obj'  => isset($objs[input('deco_obj')]) ? input('deco_obj') : 'tac',
        'logo_deco_size' => max(12, min(120, (int)input('deco_size'))),
        'logo_deco_pos'  => in_array(input('deco_pos'), ['top', 'left', 'right'], true) ? input('deco_pos') : 'top',
    ]);
    logActivity('appearance_update', 'settings', 'appearance');
    setFlash($ok ? 'success' : 'error', $ok ? 'Görünüm kaydedildi.' : 'Kaydedilemedi.');
    redirect(APP_URL . '/admin/appearance.php');
}
$a = nvAppearance(); $objs = nvLogoObjects();
$adminTitle = 'Tema Sistemi'; $adminSub = 'Site arka planı ve logo süsü';
include __DIR__ . '/_top.php';
$inp = 'w-full bg-black/30 border border-gray-800 rounded-xl py-2 px-3 text-white text-sm';
?>
<form method="POST" class="space-y-6 max-w-3xl">
<?= csrfField() ?>
<section class="rounded-2xl p-5 space-y-3" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
  <h2 class="font-bold text-white"><i class="fa-solid fa-image text-cyan-400 mr-2"></i>Site arka planı</h2>
  <p class="text-xs text-gray-500">Yüklenen resim tüm sayfaların arkasında görünür. Okunabilirlik için karartma ekleyebilirsin.</p>
  <div class="flex gap-2"><input id="bg_url" name="bg_url" value="<?= e($a['bg_url']) ?>" placeholder="https://... veya yükle" class="<?= $inp ?>"><label class="px-4 py-2 rounded-xl text-sm font-semibold text-black cursor-pointer whitespace-nowrap" style="background:#00f5ff">Yükle<input type="file" accept="image/*" class="hidden" data-up="bg" data-to="bg_url"></label></div>
  <label class="block text-xs text-gray-400">Karartma: <b id="dimv"><?= (int)$a['bg_dim'] ?></b>%<input type="range" min="0" max="95" name="bg_dim" value="<?= (int)$a['bg_dim'] ?>" class="w-full" oninput="dimv.textContent=this.value"></label>
  <label class="text-xs text-gray-400 flex items-center gap-2"><input type="checkbox" name="bg_clear" value="1"> Arka planı kaldır</label>
</section>
<section class="rounded-2xl p-5 space-y-3" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
  <h2 class="font-bold text-white"><i class="fa-solid fa-star text-yellow-400 mr-2"></i>Logo teması</h2>
  <div class="flex gap-3 text-sm text-gray-300 flex-wrap">
    <?php foreach (['none' => 'Yok', 'object' => 'Hazır obje', 'image' => 'Kendi resmim'] as $k => $l): ?><label class="flex items-center gap-1"><input type="radio" name="deco_type" value="<?= $k ?>" <?= $a['deco_type'] === $k ? 'checked' : '' ?>> <?= $l ?></label><?php endforeach; ?>
  </div>
  <div class="grid grid-cols-5 gap-2">
    <?php foreach ($objs as $k => [$nm, $svg]): ?>
      <label class="rounded-xl p-2 text-center cursor-pointer text-[10px] text-gray-400" style="background:rgba(255,255,255,.04)"><input type="radio" name="deco_obj" value="<?= $k ?>" <?= $a['deco_obj'] === $k ? 'checked' : '' ?> class="hidden peer"><div class="w-8 h-8 mx-auto mb-1"><?= $svg ?></div><?= e($nm) ?></label>
    <?php endforeach; ?>
  </div>
  <div class="flex gap-2"><input id="deco_url" name="deco_url" value="<?= e($a['deco_url']) ?>" placeholder="Resim URL (şeffaf PNG önerilir)" class="<?= $inp ?>"><label class="px-4 py-2 rounded-xl text-sm font-semibold text-black cursor-pointer whitespace-nowrap" style="background:#ffd76a">Yükle<input type="file" accept="image/*" class="hidden" data-up="logo" data-to="deco_url"></label></div>
  <div class="grid sm:grid-cols-2 gap-3">
    <label class="block text-xs text-gray-400">Boyut: <b id="szv"><?= (int)$a['deco_size'] ?></b> px<input type="range" min="12" max="120" name="deco_size" value="<?= (int)$a['deco_size'] ?>" class="w-full" oninput="szv.textContent=this.value"></label>
    <label class="block text-xs text-gray-400">Konum<select name="deco_pos" class="<?= $inp ?>"><?php foreach (['top' => 'Üst (taç gibi)', 'left' => 'Sol', 'right' => 'Sağ'] as $k => $l): ?><option value="<?= $k ?>" <?= $a['deco_pos'] === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></label>
  </div>
  <p class="text-xs text-gray-500">Kaydettikten sonra sitenin üst çubuğunda logoda görünür.</p>
</section>
<button class="px-6 py-3 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff)">Kaydet</button>
</form>
<script>
document.querySelectorAll('input[data-up]').forEach(function (i) { i.onchange = async function () {
  if (!i.files[0]) return; const fd = new FormData(); fd.append('file', i.files[0]);
  try { const r = await (await fetch('<?= APP_URL ?>/api/upload_site_image.php?type=' + i.dataset.up, { method: 'POST', body: fd, credentials: 'same-origin' })).json();
    if (r.success) { document.getElementById(i.dataset.to).value = r.data.url; alert('Yüklendi. Kaydet\'e bas.'); } else alert(r.message || 'Hata'); } catch (e) { alert('Yükleme başarısız'); }
}; });
</script>
<?php include __DIR__ . '/_bottom.php'; ?>
