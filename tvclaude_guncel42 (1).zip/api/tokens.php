<?php
// Token API (giriş gerekli)
// GET                      -> cüzdan, fiyat, günlük sayaç, geçmiş
// POST {action:start_ad}   -> {session_id, ad, seconds}
// POST {action:claim, session_id} -> ödülü ver
// POST {action:buy, gift_to?:kullanıcı adı, coupon?:kod}
// POST {action:auto_renew, on:bool}
// POST {action:check_coupon, coupon}
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/tokens.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db);
$uid = $user['id'];
$c = tkCfg();

function tkState(Supabase $db, string $uid, array $c): array {
    tkAutoRenew($db, $uid);
    $w = tkWallet($db, $uid);
    $done = $db->count('ad_watch_sessions', 'user_id=eq.' . $uid . '&day=eq.' . tkToday() . '&claimed_at=not.is.null', true);
    $led = $db->select('token_ledger', 'user_id=eq.' . $uid . '&order=created_at.desc&limit=15&select=delta,reason,created_at', true)['data'] ?? [];
    $row = $db->first('user_premium', 'user_id=eq.' . $uid . '&select=premium_until', true);
    $active = $row && ($row['premium_until'] === null || strtotime($row['premium_until']) > time());
    $disc = tkDiscountActive($c);
    return [
        'balance' => $w['balance'], 'auto_renew' => $w['auto_renew'],
        'ads_today' => (int)$done, 'daily_limit' => $c['daily_limit'], 'per_ad' => $c['per_ad'], 'ad_seconds' => $c['ad_seconds'],
        'premium_active' => $active, 'premium_until' => $row['premium_until'] ?? null, 'lifetime' => $row && $row['premium_until'] === null,
        'price' => $c['price'], 'days' => $c['days'], 'final_price' => tkPrice($c),
        'discount_pct' => $disc ? $c['discount_pct'] : 0, 'discount_note' => $disc ? $c['discount_note'] : '',
        'discount_until' => $disc ? $c['discount_until'] : '',
        'ledger' => is_array($led) ? $led : [],
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') jsonSuccess(tkState($db, $uid, $c));
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);

denyIfBanned($db, $uid);
$in = inputJson() ?? [];
$act = (string)($in['action'] ?? '');

if ($act === 'start_ad') {
    $done = $db->count('ad_watch_sessions', 'user_id=eq.' . $uid . '&day=eq.' . tkToday() . '&claimed_at=not.is.null', true);
    if ($done >= $c['daily_limit']) jsonError('Bugünkü reklam limitin doldu (' . $c['daily_limit'] . '). Yarın tekrar gel.');
    // yarım kalan oturumları birikmesin: son 1 dk içinde başlatılmış açık oturum varsa yeniden kullan
    $ads = $db->select('ads', 'is_active=eq.true&select=id,type,title,click_url,video_url,gif_url', true)['data'] ?? [];
    $ads = array_values(array_filter(is_array($ads) ? $ads : [], fn($a) => ($a['type'] === 'video' && !empty($a['video_url'])) || ($a['type'] === 'banner' && !empty($a['gif_url']))));
    if (!$ads) jsonError('Şu an izlenecek reklam yok. Daha sonra tekrar dene.');
    $ad = $ads[array_rand($ads)];
    $r = $db->insert('ad_watch_sessions', ['user_id' => $uid, 'ad_id' => $ad['id']], true);
    $sid = $r['data'][0]['id'] ?? ($r['data']['id'] ?? null);
    if (!$sid || !isUuid($sid)) jsonError('Oturum başlatılamadı', 500);
    $db->rpc('increment_ad_stat', ['p_ad_id' => $ad['id'], 'p_stat' => 'impressions'], true);
    jsonSuccess(['session_id' => $sid, 'seconds' => $c['ad_seconds'], 'ad' => [
        'id' => $ad['id'], 'type' => $ad['type'], 'title' => $ad['title'] ?? '', 'click_url' => $ad['click_url'] ?? '',
        'video_url' => $ad['video_url'] ?? '', 'gif_url' => $ad['gif_url'] ?? '']]);
}

if ($act === 'claim') {
    $sid = (string)($in['session_id'] ?? ''); requireUuid($sid, 'Oturum');
    $n = tkRpcInt($db, 'nv_ad_reward', ['p_user' => $uid, 'p_session' => $sid, 'p_amount' => $c['per_ad'], 'p_limit' => $c['daily_limit'], 'p_min_seconds' => $c['ad_seconds']]);
    if ($n === -1) jsonError('Bugünkü reklam limitin doldu.');
    if ($n === -2) jsonError('Bu reklam oturumu geçersiz veya zaten kullanıldı.');
    if ($n === -3) jsonError('Reklam süresi henüz dolmadı.');
    if ($n < 0) jsonError('Ödül verilemedi', 500);
    jsonSuccess(tkState($db, $uid, $c), '+' . $c['per_ad'] . ' token kazandın!');
}

if ($act === 'auto_renew') {
    tkAdjust($db, $uid, 0, 'init'); // cüzdan satırı oluşsun
    $db->update('token_wallets', ['auto_renew' => !empty($in['on']), 'updated_at' => date('c')], 'user_id=eq.' . $uid, true);
    jsonSuccess(tkState($db, $uid, $c), !empty($in['on']) ? 'Otomatik yenileme açıldı.' : 'Otomatik yenileme kapatıldı.');
}

if ($act === 'check_coupon') {
    $code = strtoupper(trim((string)($in['coupon'] ?? '')));
    if (!preg_match('/^[A-Z0-9_-]{2,32}$/', $code)) jsonError('Geçersiz kupon kodu.');
    $cp = $db->first('premium_coupons', 'code=eq.' . urlencode($code) . '&is_active=eq.true', true);
    $ok = $cp && (empty($cp['ends_at']) || strtotime($cp['ends_at']) > time()) && (empty($cp['starts_at']) || strtotime($cp['starts_at']) <= time())
        && ($cp['max_uses'] === null || $cp['used_count'] < $cp['max_uses']);
    if (!$ok) jsonError('Kupon geçersiz veya süresi dolmuş.');
    jsonSuccess(['percent' => (int)$cp['percent'], 'description' => $cp['description'], 'final_price' => tkPrice($c, (int)$cp['percent'])]);
}

if ($act === 'buy') {
    $target = $uid; $gift = trim((string)($in['gift_to'] ?? ''));
    if ($gift !== '') {
        $p = $db->first('profiles', 'username=eq.' . urlencode($gift) . '&select=id,username', true);
        if (!$p || !isUuid($p['id'] ?? '')) jsonError('Bu kullanıcı adı bulunamadı.');
        if ($p['id'] === $uid) jsonError('Kendine hediye gönderemezsin; "Kendim için al" seçeneğini kullan.');
        $target = $p['id'];
    }
    $undo = function () use ($db, &$code, $uid, &$pct) {
        if ($code === '' || $pct < 0) return;
        $db->delete('coupon_redemptions', 'code=eq.' . urlencode($code) . '&user_id=eq.' . $uid, true);
        $cp = $db->first('premium_coupons', 'code=eq.' . urlencode($code) . '&select=used_count', true);
        if ($cp) $db->update('premium_coupons', ['used_count' => max(0, (int)$cp['used_count'] - 1)], 'code=eq.' . urlencode($code), true);
    };
    $pct = 0; $code = strtoupper(trim((string)($in['coupon'] ?? '')));
    if ($code !== '') {
        if (!preg_match('/^[A-Z0-9_-]{2,32}$/', $code)) jsonError('Geçersiz kupon kodu.');
        $pct = tkRpcInt($db, 'nv_coupon_use', ['p_user' => $uid, 'p_code' => $code]);
        if ($pct === -2) jsonError('Bu kuponu daha önce kullandın.');
        if ($pct < 0) jsonError('Kupon geçersiz veya süresi dolmuş.');
    }
    $price = tkPrice($c, $pct);
    if ($price > 0) {
        $n = tkAdjust($db, $uid, -$price, $target === $uid ? 'premium_buy' : 'premium_gift', $target);
        if ($n < 0) $undo();
        if ($n === -1) jsonError('Yeterli tokenin yok. Gerekli: ' . $price . ' token.');
        if ($n < 0) jsonError('Satın alma yapılamadı', 500);
    }
    if (!tkExtendPremium($db, $target, $c['days'], $target === $uid ? 'Token ile satın alındı' : 'Token hediyesi'))
        { if ($price > 0) tkAdjust($db, $uid, $price, 'refund'); $undo(); jsonError('Premium verilemedi, tokenlerin iade edildi.', 500); }
    if ($target !== $uid) {
        try { $db->insert('notifications', ['user_id' => $target, 'type' => 'system', 'message' => 'Sana ' . $c['days'] . ' günlük Premium hediye edildi! 🎁'], true); } catch (\Throwable $e) {}
    }
    jsonSuccess(tkState($db, $uid, $c), $target === $uid ? 'Premium aktif edildi!' : 'Hediye gönderildi!');
}
jsonError('Geçersiz işlem');
