<?php
// ============================================================
// NeonTV - Token / Mağaza yardımcıları (ayarlar site_settings'te tutulur)
// ============================================================
require_once __DIR__ . '/store.php';
require_once __DIR__ . '/supabase.php';

function tkCfg(): array {
    $g = fn(string $k, $d) => Store::getSetting($k, $d);
    $int = fn($v, $d, $min, $max) => max($min, min($max, is_numeric($v) ? (int)$v : $d));
    return [
        'price'        => $int($g('token_premium_price', 30), 30, 1, 100000),
        'days'         => $int($g('token_premium_days', 30), 30, 1, 3650),
        'per_ad'       => $int($g('token_per_ad', 2), 2, 1, 1000),
        'daily_limit'  => $int($g('token_daily_ad_limit', 10), 10, 1, 500),
        'ad_seconds'   => $int($g('token_ad_seconds', 10), 10, 3, 120),
        'discount_pct' => $int($g('token_discount_percent', 0), 0, 0, 100),
        'discount_from'  => (string)$g('token_discount_from', ''),
        'discount_until' => (string)$g('token_discount_until', ''),
        'discount_note'  => (string)$g('token_discount_note', ''),
    ];
}
/** Genel indirim şu an geçerli mi? */
function tkDiscountActive(array $c): bool {
    if ($c['discount_pct'] <= 0) return false;
    $now = time();
    if ($c['discount_from'] !== '' && ($t = strtotime($c['discount_from'])) && $now < $t) return false;
    if ($c['discount_until'] !== '' && ($t = strtotime($c['discount_until'])) && $now > $t) return false;
    return true;
}
/** Kupon yüzdesi dahil, indirimli fiyat. */
function tkPrice(array $c, int $couponPct = 0): int {
    $pct = tkDiscountActive($c) ? $c['discount_pct'] : 0;
    $pct = min(100, max($pct, 0) + max($couponPct, 0));
    return max(0, (int)ceil($c['price'] * (100 - $pct) / 100));
}
function tkToday(): string { return (new DateTime('now', new DateTimeZone('Europe/Istanbul')))->format('Y-m-d'); }

function tkRpcInt(Supabase $db, string $fn, array $p): int {
    $r = $db->rpc($fn, $p, true);
    if (($r['status'] ?? 500) >= 400) return -99;
    $d = $r['data'] ?? null;
    if (is_array($d)) $d = reset($d);
    return is_numeric($d) ? (int)$d : -99;
}
function tkAdjust(Supabase $db, string $uid, int $delta, string $reason, ?string $ref = null): int {
    return tkRpcInt($db, 'nv_token_adjust', ['p_user' => $uid, 'p_delta' => $delta, 'p_reason' => $reason, 'p_ref' => $ref]);
}
function tkWallet(Supabase $db, string $uid): array {
    $w = $db->first('token_wallets', 'user_id=eq.' . $uid . '&select=balance,auto_renew', true);
    return ['balance' => (int)($w['balance'] ?? 0), 'auto_renew' => !empty($w['auto_renew'])];
}
function tkPremiumUntil(Supabase $db, string $uid): ?string {
    $r = $db->first('user_premium', 'user_id=eq.' . $uid . '&select=premium_until', true);
    return $r['premium_until'] ?? null;
}
/** Hedef kullanıcıya N gün ekler (mevcut süre varsa üstüne). */
function tkExtendPremium(Supabase $db, string $uid, int $days, string $note): bool {
    $row = $db->first('user_premium', 'user_id=eq.' . $uid . '&select=premium_until', true);
    if ($row && ($row['premium_until'] ?? null) === null) return true; // süresiz premium: dokunma
    $cur = $row['premium_until'] ?? null;
    $base = ($cur && strtotime($cur) > time()) ? strtotime($cur) : time();
    $new = date('c', $base + $days * 86400);
    $ok = Store::grantPremium($uid, $new, 'token', $note);
    Store::clearCache('premium_' . $uid);
    return $ok;
}
/** Otomatik yenileme: premium bitmişse/bitmek üzereyse ve bakiye yeterliyse 30 gün alır. */
function tkAutoRenew(Supabase $db, string $uid): bool {
    $w = tkWallet($db, $uid);
    if (!$w['auto_renew']) return false;
    $row = $db->first('user_premium', 'user_id=eq.' . $uid . '&select=premium_until', true);
    if ($row && ($row['premium_until'] ?? null) === null) return false; // süresiz
    $until = $row['premium_until'] ?? null;
    if ($until && strtotime($until) - time() > 3600) return false; // henüz bitmiyor (1 saatten fazla var)
    $c = tkCfg(); $price = tkPrice($c);
    if ($price > 0 && $w['balance'] < $price) return false;
    if ($price > 0 && tkAdjust($db, $uid, -$price, 'auto_renew') < 0) return false;
    return tkExtendPremium($db, $uid, $c['days'], 'Token otomatik yenileme');
}
