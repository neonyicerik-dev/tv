<?php
// NeonTV - Mağaza (Premium'u token ile al / hediye et / kupon / otomatik yenileme)
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/tokens.php';
$pageTitle = 'Mağaza'; $metaDesc = 'Tokenlerinle Premium üyelik satın al veya arkadaşına hediye et.';
$c = tkCfg(); $disc = tkDiscountActive($c); $fin = tkPrice($c);
include __DIR__ . '/components/header.php'; ?>
<div class="max-w-screen-md mx-auto px-4 sm:px-6 py-8">
  <div class="flex items-center justify-between flex-wrap gap-3 mb-5">
    <h1 class="text-xl font-bold text-white"><i class="fa-solid fa-store text-cyan-400 mr-2"></i>Mağaza</h1>
    <a href="<?= APP_URL ?>/tokens.php" class="px-4 py-2 rounded-xl text-sm font-bold text-black" style="background:linear-gradient(135deg,#fbbf24,#f59e0b)"><i class="fa-solid fa-coins mr-1"></i>Token Kazan</a>
  </div>
  <div class="rounded-2xl p-6 mb-4 relative overflow-hidden" style="background:linear-gradient(135deg,rgba(0,245,255,.10),rgba(191,0,255,.12));border:1px solid rgba(255,255,255,.1)">
    <?php if ($disc): ?><span class="absolute top-3 right-3 text-xs font-black px-2 py-1 rounded-full" style="background:#ef4444;color:#fff">%<?= (int)$c['discount_pct'] ?> İNDİRİM</span><?php endif; ?>
    <h2 class="text-lg font-bold text-white mb-1"><i class="fa-solid fa-crown text-yellow-400 mr-1"></i>Premium · <?= (int)$c['days'] ?> gün</h2>
    <p class="text-sm text-gray-400 mb-3">Özel tema ve çerçeveler, erken erişim videoları ve daha fazlası.</p>
    <div class="flex items-baseline gap-3 flex-wrap">
      <?php if ($disc): ?>
        <span class="text-lg text-red-500 line-through decoration-2" id="old-price"><?= (int)$c['price'] ?> token</span>
        <span class="text-3xl font-black text-yellow-400" id="new-price"><?= (int)$fin ?> token</span>
      <?php else: ?>
        <span class="text-3xl font-black text-yellow-400" id="new-price"><?= (int)$c['price'] ?> token</span>
      <?php endif; ?>
    </div>
    <?php if ($disc && $c['discount_note'] !== ''): ?><p class="text-sm text-green-400 mt-2"><i class="fa-solid fa-tag mr-1"></i><?= e($c['discount_note']) ?><?php if ($c['discount_until'] !== '' && strtotime($c['discount_until'])): ?> <span class="text-gray-500">(<?= date('d.m.Y H:i', strtotime($c['discount_until'])) ?> tarihine kadar)</span><?php endif; ?></p><?php endif; ?>
  </div>
  <div id="sh-login" class="hidden rounded-2xl p-5 text-center text-gray-300" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">Satın almak için <a class="text-cyan-400 underline" href="<?= APP_URL ?>/auth.php">giriş yap</a>.</div>
  <div id="sh-main" class="hidden space-y-4">
    <div class="rounded-2xl p-4 flex items-center justify-between flex-wrap gap-2" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
      <div><div class="text-sm text-gray-400">Bakiyen: <b id="sh-bal" class="text-yellow-400">0</b> token</div><div class="text-xs text-gray-500" id="sh-prem"></div></div>
      <label class="flex items-center gap-2 text-sm text-gray-300 cursor-pointer"><input type="checkbox" id="sh-auto" class="accent-cyan-400"> Otomatik yenile</label>
    </div>
    <div class="rounded-2xl p-4 space-y-3" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
      <div class="flex gap-2"><input id="sh-coupon" maxlength="32" placeholder="Kupon kodu (isteğe bağlı)" class="flex-1 px-3 py-2.5 rounded-xl text-sm text-white outline-none" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1)"><button id="sh-chk" class="px-4 rounded-xl text-sm font-bold text-gray-200 bg-white/10">Uygula</button></div>
      <p id="sh-cinfo" class="text-xs text-green-400 hidden"></p>
      <div class="flex gap-2 flex-wrap">
        <button id="sh-buy" class="px-5 py-3 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff)">Kendim için al</button>
      </div>
      <div class="pt-3 border-t border-white/10"><div class="text-sm font-bold text-white mb-2"><i class="fa-solid fa-gift text-pink-400 mr-1"></i>Hediye et</div>
        <div class="flex gap-2"><input id="sh-gift" maxlength="40" placeholder="Kullanıcı adı" class="flex-1 px-3 py-2.5 rounded-xl text-sm text-white outline-none" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1)"><button id="sh-giftbtn" class="px-4 rounded-xl text-sm font-bold text-black" style="background:linear-gradient(135deg,#ff6bd6,#ff9e6b)">Hediye Gönder</button></div></div>
      <p id="sh-msg" class="text-sm text-center text-gray-300"></p>
    </div>
  </div>
</div>
<script>
window.addEventListener('load', async function () {
  const BASE = '<?= APP_URL ?>', $ = id => document.getElementById(id);
  let tok = null; try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}
  if (!tok) { $('sh-login').classList.remove('hidden'); return; }
  $('sh-main').classList.remove('hidden');
  const api = async (body) => (await fetch(BASE + '/api/tokens.php', { method: body ? 'POST' : 'GET', headers: { 'Authorization': 'Bearer ' + tok, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })).json();
  const msg = (t, ok) => { $('sh-msg').textContent = t; $('sh-msg').style.color = ok ? '#4ade80' : '#f87171'; };
  function paint(s) {
    $('sh-bal').textContent = s.balance; $('sh-auto').checked = !!s.auto_renew;
    $('sh-prem').textContent = s.lifetime ? 'Premium: süresiz' : s.premium_active ? 'Premium bitiş: ' + new Date(s.premium_until).toLocaleString('tr-TR') : 'Premium aktif değil';
  }
  const j = await api(); if (j.success) paint(j.data);
  $('sh-auto').onchange = async e => { const r = await api({ action: 'auto_renew', on: e.target.checked }); msg(r.message, r.success); if (r.success) paint(r.data); };
  $('sh-chk').onclick = async () => { const r = await api({ action: 'check_coupon', coupon: $('sh-coupon').value }); const i = $('sh-cinfo'); i.classList.remove('hidden'); i.style.color = r.success ? '#4ade80' : '#f87171';
    i.textContent = r.success ? '%' + r.data.percent + ' kupon uygulanacak → ' + r.data.final_price + ' token' + (r.data.description ? ' · ' + r.data.description : '') : r.message; };
  async function buy(gift) {
    if (gift && !$('sh-gift').value.trim()) { msg('Kullanıcı adı yaz.', false); return; }
    if (!confirm(gift ? '"' + $('sh-gift').value + '" kullanıcısına Premium hediye edilsin mi?' : 'Premium satın alınsın mı?')) return;
    const r = await api({ action: 'buy', gift_to: gift ? $('sh-gift').value.trim() : '', coupon: $('sh-coupon').value.trim() });
    msg(r.message, r.success); if (r.success) paint(r.data);
  }
  $('sh-buy').onclick = () => buy(false); $('sh-giftbtn').onclick = () => buy(true);
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
