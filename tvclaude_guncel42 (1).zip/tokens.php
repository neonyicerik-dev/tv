<?php
// NeonTV - Token Kazan (reklam izle)
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Token Kazan'; $metaDesc = 'Reklam izleyerek token kazan, tokenlerle Premium al.';
include __DIR__ . '/components/header.php'; ?>
<div class="max-w-screen-md mx-auto px-4 sm:px-6 py-8">
  <div class="flex items-center justify-between flex-wrap gap-3 mb-5">
    <h1 class="text-xl font-bold text-white"><i class="fa-solid fa-coins text-yellow-400 mr-2"></i>Token Kazan</h1>
    <a href="<?= APP_URL ?>/magaza.php" class="px-4 py-2 rounded-xl text-sm font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff)"><i class="fa-solid fa-store mr-1"></i>Mağaza</a>
  </div>
  <div id="tk-login" class="hidden rounded-2xl p-6 text-center text-gray-300" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">Token kazanmak için <a class="text-cyan-400 underline" href="<?= APP_URL ?>/auth.php">giriş yap</a>.</div>
  <div id="tk-main" class="hidden space-y-4">
    <div class="grid grid-cols-3 gap-3 text-center">
      <div class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,.08)"><div class="text-2xl font-black text-yellow-400" id="tk-bal">0</div><div class="text-xs text-gray-500">Bakiye</div></div>
      <div class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,.08)"><div class="text-2xl font-black text-cyan-400"><span id="tk-done">0</span>/<span id="tk-lim">10</span></div><div class="text-xs text-gray-500">Bugünkü reklam</div></div>
      <div class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,.08)"><div class="text-2xl font-black text-green-400">+<span id="tk-per">2</span></div><div class="text-xs text-gray-500">Reklam başı</div></div>
    </div>
    <div id="tk-stage" class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
      <div id="tk-ad" class="hidden mb-3 rounded-xl overflow-hidden bg-black relative" style="min-height:180px"></div>
      <div id="tk-bar" class="hidden h-2 rounded-full overflow-hidden mb-2" style="background:rgba(255,255,255,.08)"><div id="tk-fill" class="h-full" style="width:0;background:linear-gradient(90deg,#00f5ff,#bf00ff)"></div></div>
      <p id="tk-msg" class="text-sm text-gray-400 mb-3 text-center">Reklamı sonuna kadar izle; sekmeyi değiştirirsen sayaç durur.</p>
      <div class="text-center"><button id="tk-go" class="px-6 py-3 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#fbbf24,#f59e0b)"><i class="fa-solid fa-play mr-1"></i>Reklam İzle</button></div>
    </div>
    <div class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,.08)"><h2 class="text-sm font-bold text-white mb-2">Son hareketler</h2><div id="tk-led" class="text-xs text-gray-400 space-y-1"></div></div>
  </div>
</div>
<script>
window.addEventListener('load', async function () {
  const BASE = '<?= APP_URL ?>', $ = id => document.getElementById(id);
  let tok = null; try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}
  if (!tok) { $('tk-login').classList.remove('hidden'); return; }
  $('tk-main').classList.remove('hidden');
  const api = async (body) => (await fetch(BASE + '/api/tokens.php', { method: body ? 'POST' : 'GET', headers: { 'Authorization': 'Bearer ' + tok, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })).json();
  const REASON = { ad_reward: 'Reklam ödülü', premium_buy: 'Premium satın alma', premium_gift: 'Premium hediyesi', auto_renew: 'Otomatik yenileme', refund: 'İade' };
  function paint(s) {
    $('tk-bal').textContent = s.balance; $('tk-done').textContent = s.ads_today; $('tk-lim').textContent = s.daily_limit; $('tk-per').textContent = s.per_ad;
    $('tk-go').disabled = s.ads_today >= s.daily_limit; $('tk-go').style.opacity = $('tk-go').disabled ? .4 : 1;
    if ($('tk-go').disabled) $('tk-msg').textContent = 'Bugünkü limit doldu, yarın tekrar gel.';
    const L = $('tk-led'); L.textContent = '';
    (s.ledger || []).forEach(r => { const d = document.createElement('div'); d.textContent = new Date(r.created_at).toLocaleString('tr-TR') + ' — ' + (REASON[r.reason] || r.reason) + ': ' + (r.delta > 0 ? '+' : '') + r.delta; L.appendChild(d); });
  }
  let j = await api(); if (j.success) paint(j.data);
  let running = false;
  $('tk-go').onclick = async () => {
    if (running) return; running = true; $('tk-go').disabled = true;
    const st = await api({ action: 'start_ad' });
    if (!st.success) { $('tk-msg').textContent = st.message; running = false; $('tk-go').disabled = false; return; }
    const { session_id, seconds, ad } = st.data, box = $('tk-ad'); box.textContent = ''; box.classList.remove('hidden'); $('tk-bar').classList.remove('hidden');
    let media;
    if (ad.type === 'video') { media = document.createElement('video'); media.src = ad.video_url; media.muted = true; media.autoplay = true; media.playsInline = true; media.loop = true; media.className = 'w-full'; media.style.maxHeight = '320px'; }
    else { media = document.createElement('img'); media.src = ad.gif_url; media.className = 'w-full'; media.alt = ''; }
    box.appendChild(media);
    if (/^https:\/\//.test(ad.click_url || '')) { const a = document.createElement('a'); a.href = ad.click_url; a.target = '_blank'; a.rel = 'noopener sponsored'; a.className = 'absolute inset-0'; a.title = ad.title || ''; a.onclick = () => fetch(BASE + '/api/ads.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ad_id: ad.id, stat: 'clicks' }) }); box.appendChild(a); }
    // Sayaç yalnızca sekme görünürken ilerler
    let left = seconds, last = Date.now();
    const tick = setInterval(() => {
      const now = Date.now();
      if (document.hidden) { last = now; if (media.pause) media.pause(); $('tk-msg').textContent = 'Sekme gizli — sayaç durdu.'; return; }
      if (media.play && media.paused) media.play().catch(() => {});
      left -= (now - last) / 1000; last = now;
      $('tk-fill').style.width = Math.min(100, (seconds - left) / seconds * 100) + '%';
      $('tk-msg').textContent = 'Kalan: ' + Math.max(0, Math.ceil(left)) + ' sn';
      if (left <= 0) { clearInterval(tick); done(); }
    }, 250);
    async function done() {
      $('tk-msg').textContent = 'Token ekleniyor...';
      let r = await api({ action: 'claim', session_id });
      if (!r.success && /dolmadı/.test(r.message || '')) { await new Promise(x => setTimeout(x, 1500)); r = await api({ action: 'claim', session_id }); }
      $('tk-msg').textContent = r.message || ''; if (r.success) paint(r.data);
      box.classList.add('hidden'); $('tk-bar').classList.add('hidden'); $('tk-fill').style.width = '0'; box.textContent = '';
      running = false; if (!r.success || r.data.ads_today < r.data.daily_limit) $('tk-go').disabled = false;
    }
  };
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
