<?php
// NeonTV - Admin: Token & Premium Mağaza (fiyat, ödül, indirim, kuponlar)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/tokens.php';
requireAdmin(['superadmin']);
$db = new Supabase();
$self = APP_URL . '/admin/store.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect($self); }
    $act = input('action');
    $dt = function ($k) { $v = trim(input($k)); $t = $v !== '' ? strtotime($v) : false; return $t ? date('c', $t) : ''; };
    if ($act === 'settings') {
        $ok = Store::setSettings([
            'token_premium_price'    => max(1, (int)input('price')),
            'token_premium_days'     => max(1, (int)input('days')),
            'token_per_ad'           => max(1, (int)input('per_ad')),
            'token_daily_ad_limit'   => max(1, (int)input('daily')),
            'token_ad_seconds'       => max(3, min(120, (int)input('secs'))),
            'token_discount_percent' => max(0, min(100, (int)input('dpct'))),
            'token_discount_from'    => $dt('dfrom'),
            'token_discount_until'   => $dt('duntil'),
            'token_discount_note'    => mb_substr(trim(input('dnote')), 0, 200),
        ]);
        logActivity('store_settings', 'settings', 'token');
        setFlash($ok ? 'success' : 'error', $ok ? 'Ayarlar kaydedildi.' : 'Kaydedilemedi.');
    } elseif ($act === 'coupon_add') {
        $code = strtoupper(trim(input('code')));
        if (!preg_match('/^[A-Z0-9_-]{2,32}$/', $code)) { setFlash('error', 'Kupon kodu 2-32 karakter (A-Z, 0-9, _ -).'); redirect($self); }
        $r = $db->insert('premium_coupons', ['code' => $code, 'description' => mb_substr(trim(input('desc')), 0, 200), 'percent' => max(0, min(100, (int)input('pct'))),
            'max_uses' => input('max') !== '' ? max(1, (int)input('max')) : null, 'starts_at' => $dt('from') ?: null, 'ends_at' => $dt('to') ?: null, 'is_active' => true], true);
        setFlash(($r['status'] ?? 500) < 400 ? 'success' : 'error', ($r['status'] ?? 500) < 400 ? 'Kupon eklendi.' : 'Eklenemedi (kod zaten var mı / SQL çalıştı mı?).');
    } elseif ($act === 'coupon_toggle') {
        $code = strtoupper(trim(input('code')));
        $db->update('premium_coupons', ['is_active' => input('on') === '1'], 'code=eq.' . urlencode($code), true);
    } elseif ($act === 'coupon_del') {
        $db->delete('premium_coupons', 'code=eq.' . urlencode(strtoupper(trim(input('code')))), true);
    }
    redirect($self);
}
$c = tkCfg();
$coupons = $db->select('premium_coupons', 'order=created_at.desc&limit=200', true)['data'] ?? [];
$loc = fn($s) => $s && strtotime($s) ? date('Y-m-d\TH:i', strtotime($s)) : '';
$adminTitle = 'Token & Mağaza'; $adminSub = 'Premium fiyatı, token ödülleri, indirim ve kuponlar';
include __DIR__ . '/_top.php';
$inp = 'w-full bg-black/30 border border-gray-800 rounded-xl py-2 px-3 text-white text-sm';
$lbl = 'block text-xs text-gray-400';
?>
<div class="space-y-6 max-w-3xl">
<form method="POST" class="rounded-2xl p-5 space-y-4" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
  <?= csrfField() ?><input type="hidden" name="action" value="settings">
  <h2 class="font-bold text-white"><i class="fa-solid fa-coins text-yellow-400 mr-2"></i>Fiyat ve ödüller</h2>
  <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
    <label class="<?= $lbl ?>">Premium fiyatı (token)<input type="number" min="1" name="price" value="<?= (int)$c['price'] ?>" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Premium süresi (gün)<input type="number" min="1" name="days" value="<?= (int)$c['days'] ?>" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Reklam başı token<input type="number" min="1" name="per_ad" value="<?= (int)$c['per_ad'] ?>" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Günlük reklam limiti<input type="number" min="1" name="daily" value="<?= (int)$c['daily_limit'] ?>" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Reklam süresi (sn)<input type="number" min="3" max="120" name="secs" value="<?= (int)$c['ad_seconds'] ?>" class="<?= $inp ?>"></label>
  </div>
  <h2 class="font-bold text-white pt-2"><i class="fa-solid fa-tag text-red-400 mr-2"></i>Genel indirim</h2>
  <p class="text-xs text-gray-500">% 0 = indirim yok. Tarihler boşsa süresiz geçerli. Mağazada eski fiyat kırmızı üstü çizili, yeni fiyat yanında görünür.</p>
  <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
    <label class="<?= $lbl ?>">İndirim %<input type="number" min="0" max="100" name="dpct" value="<?= (int)$c['discount_pct'] ?>" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Başlangıç<input type="datetime-local" name="dfrom" value="<?= e($loc($c['discount_from'])) ?>" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Bitiş<input type="datetime-local" name="duntil" value="<?= e($loc($c['discount_until'])) ?>" class="<?= $inp ?>"></label>
  </div>
  <label class="<?= $lbl ?>">Açıklama (mağazada görünür)<input name="dnote" maxlength="200" value="<?= e($c['discount_note']) ?>" placeholder="Örn. Hafta sonu fırsatı!" class="<?= $inp ?>"></label>
  <button class="px-6 py-2.5 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff)">Kaydet</button>
</form>

<div class="rounded-2xl p-5 space-y-3" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
  <h2 class="font-bold text-white"><i class="fa-solid fa-ticket text-pink-400 mr-2"></i>Kuponlar</h2>
  <form method="POST" class="grid grid-cols-2 sm:grid-cols-3 gap-3">
    <?= csrfField() ?><input type="hidden" name="action" value="coupon_add">
    <label class="<?= $lbl ?>">Kod<input name="code" required maxlength="32" placeholder="YAZ2026" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">İndirim %<input type="number" name="pct" min="0" max="100" value="20" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Kullanım limiti<input type="number" name="max" min="1" placeholder="sınırsız" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Başlangıç<input type="datetime-local" name="from" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Bitiş<input type="datetime-local" name="to" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?> col-span-2 sm:col-span-3">Açıklama<input name="desc" maxlength="200" class="<?= $inp ?>"></label>
    <button class="col-span-2 sm:col-span-3 px-5 py-2.5 rounded-xl font-bold text-black" style="background:#ff6bd6">Kupon Ekle</button>
  </form>
  <div class="divide-y divide-white/5 text-sm">
  <?php foreach ($coupons as $cp): ?>
    <form method="POST" class="py-2 flex flex-wrap items-center gap-3"><?= csrfField() ?><input type="hidden" name="code" value="<?= e($cp['code']) ?>">
      <div class="flex-1 min-w-[160px]"><b class="text-white"><?= e($cp['code']) ?></b> <span class="text-yellow-400">%<?= (int)$cp['percent'] ?></span>
        <div class="text-xs text-gray-500"><?= e($cp['description']) ?> · kullanım <?= (int)$cp['used_count'] ?><?= $cp['max_uses'] ? '/' . (int)$cp['max_uses'] : '' ?><?= $cp['ends_at'] ? ' · bitiş ' . e(date('d.m.Y H:i', strtotime($cp['ends_at']))) : '' ?></div></div>
      <input type="hidden" name="on" value="<?= $cp['is_active'] ? '0' : '1' ?>"><button name="action" value="coupon_toggle" class="text-xs px-3 py-1.5 rounded-lg bg-white/10 text-gray-200"><?= $cp['is_active'] ? 'Pasifleştir' : 'Aktifleştir' ?></button>
      <button name="action" value="coupon_del" onclick="return confirm('Silinsin mi?')" class="text-xs px-3 py-1.5 text-red-400">Sil</button>
    </form>
  <?php endforeach; if (!$coupons): ?><p class="text-gray-500 text-xs py-2">Henüz kupon yok.</p><?php endif; ?>
  </div>
</div>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
