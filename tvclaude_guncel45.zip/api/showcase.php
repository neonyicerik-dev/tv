<?php
// Profil vitrini (en sevdiği 3 video). GET -> kendi vitrinim | POST {position:1-3, video:"uuid veya video linki"} | DELETE {position}
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id'];
$m = $_SERVER['REQUEST_METHOD'];
if ($m === 'POST' || $m === 'DELETE') {
    denyIfBanned($db, $uid);
    $in = inputJson() ?? []; $pos = (int)($in['position'] ?? 0);
    if ($pos < 1 || $pos > 3) jsonError('Geçersiz sıra');
    if ($m === 'DELETE') $db->delete('profile_showcase', 'user_id=eq.' . $uid . '&position=eq.' . $pos, true);
    else {
        if (!preg_match('/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i', (string)($in['video'] ?? ''), $mm)) jsonError('Geçerli bir video linki veya ID gir');
        $vid = strtolower($mm[0]);
        if (!$db->first('videos', 'id=eq.' . $vid . '&status=eq.published&select=id', true)) jsonError('Video bulunamadı');
        $db->delete('profile_showcase', 'user_id=eq.' . $uid . '&position=eq.' . $pos, true);
        $db->delete('profile_showcase', 'user_id=eq.' . $uid . '&video_id=eq.' . $vid, true); // aynı video iki kez olmasın
        $r = $db->insert('profile_showcase', ['user_id' => $uid, 'position' => $pos, 'video_id' => $vid], true);
        if (($r['status'] ?? 500) >= 400) jsonError('Kaydedilemedi (SQL 11 çalıştı mı?)', 500);
    }
}
$rows = $db->select('profile_showcase', 'user_id=eq.' . $uid . '&order=position.asc&select=position,videos(id,title)', true)['data'] ?? [];
jsonSuccess(['items' => array_map(fn($r) => ['position' => (int)$r['position'], 'id' => $r['videos']['id'] ?? '', 'title' => $r['videos']['title'] ?? ''], is_array($rows) ? $rows : [])]);
