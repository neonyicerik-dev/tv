<?php
// ============================================================
// NeonTV - Etkileşim: günlük giriş, görevler, rozetler, Premium bitiş bildirimi
// ============================================================
require_once __DIR__ . '/tokens.php';

function engCfg(): array {
    $i = fn($k, $d, $a, $b) => max($a, min($b, (int)Store::getSetting($k, $d)));
    return ['daily_base' => $i('token_daily_base', 1, 0, 100), 'daily_bonus' => $i('token_daily_bonus', 5, 0, 1000), 'bonus_every' => $i('token_daily_bonus_every', 7, 2, 60), 'quest' => $i('token_quest_reward', 1, 0, 100)];
}
function engDayStartIso(): string { return (new DateTime('today', new DateTimeZone('Europe/Istanbul')))->format('c'); }

/** Günlük giriş durumu / ödülü. $claim=true ise ödülü vermeyi dener. */
function engDaily(Supabase $db, string $uid, bool $claim): array {
    $c = engCfg(); $today = tkToday();
    $row = $db->first('user_streaks', 'user_id=eq.' . $uid, true);
    $last = $row['last_date'] ?? null; $streak = (int)($row['streak'] ?? 0); $best = (int)($row['best'] ?? 0);
    $claimed = $last === $today;
    $msg = '';
    if ($claim && !$claimed) {
        $yesterday = (new DateTime('yesterday', new DateTimeZone('Europe/Istanbul')))->format('Y-m-d');
        $newStreak = ($last === $yesterday) ? $streak + 1 : 1;
        $amt = $c['daily_base'] + (($newStreak % $c['bonus_every'] === 0) ? $c['daily_bonus'] : 0);
        $r = $amt > 0 ? tkRpcInt($db, 'nv_reward_once', ['p_user' => $uid, 'p_amount' => $amt, 'p_reason' => 'daily', 'p_ref' => $today]) : 0;
        if ($r !== -2 && $r !== -99 && $r !== -1) {
            $streak = $newStreak; $best = max($best, $streak); $claimed = true;
            $data = ['last_date' => $today, 'streak' => $streak, 'best' => $best];
            if ($row) $db->update('user_streaks', $data, 'user_id=eq.' . $uid, true); else $db->insert('user_streaks', $data + ['user_id' => $uid], true);
            $msg = '+' . $amt . ' token' . ($newStreak % $c['bonus_every'] === 0 ? ' (seri bonusu!)' : '');
        } else $claimed = true;
    }
    $cur = ($last === $today || $claimed) ? $streak : 0;
    $next = $cur + 1;
    return ['claimed' => $claimed, 'streak' => $cur, 'best' => $best, 'reward' => $c['daily_base'] + (($next % $c['bonus_every'] === 0) ? $c['daily_bonus'] : 0), 'bonus_every' => $c['bonus_every'], 'message' => $msg];
}

function engQuestDefs(): array {
    return [
        'watch3'  => ['3 video izle', 3, 'fa-play'],
        'comment' => ['1 yorum yaz', 1, 'fa-comment'],
        'rate'    => ['1 videoya puan ver', 1, 'fa-star'],
        'ads2'    => ['2 reklam izle', 2, 'fa-coins'],
    ];
}
function engQuestProgress(Supabase $db, string $uid): array {
    $s = urlencode(engDayStartIso());
    return [
        'watch3'  => $db->count('watch_history', 'user_id=eq.' . $uid . '&watched_at=gte.' . $s, true),
        'comment' => $db->count('comments', 'user_id=eq.' . $uid . '&created_at=gte.' . $s, true),
        'rate'    => $db->count('video_ratings', 'user_id=eq.' . $uid . '&created_at=gte.' . $s, true),
        'ads2'    => $db->count('ad_watch_sessions', 'user_id=eq.' . $uid . '&day=eq.' . tkToday() . '&claimed_at=not.is.null', true),
    ];
}
function engQuests(Supabase $db, string $uid): array {
    $prog = engQuestProgress($db, $uid); $today = tkToday(); $c = engCfg();
    $done = $db->select('token_ledger', 'user_id=eq.' . $uid . '&reason=eq.quest&ref=like.' . urlencode('%:' . $today) . '&select=ref', true)['data'] ?? [];
    $doneIds = array_map(fn($r) => explode(':', (string)$r['ref'])[0], is_array($done) ? $done : []);
    $out = [];
    foreach (engQuestDefs() as $id => [$title, $goal, $icon]) $out[] = ['id' => $id, 'title' => $title, 'goal' => $goal, 'icon' => $icon, 'progress' => min($goal, (int)($prog[$id] ?? 0)), 'ready' => ($prog[$id] ?? 0) >= $goal, 'claimed' => in_array($id, $doneIds, true), 'reward' => $c['quest']];
    return $out;
}
function engClaimQuest(Supabase $db, string $uid, string $id): array {
    $defs = engQuestDefs(); if (!isset($defs[$id])) return [false, 'Geçersiz görev'];
    $prog = engQuestProgress($db, $uid);
    if (($prog[$id] ?? 0) < $defs[$id][1]) return [false, 'Görev henüz tamamlanmadı'];
    $amt = engCfg()['quest']; if ($amt <= 0) return [false, 'Bu görev için ödül kapalı'];
    $r = tkRpcInt($db, 'nv_reward_once', ['p_user' => $uid, 'p_amount' => $amt, 'p_reason' => 'quest', 'p_ref' => $id . ':' . tkToday()]);
    if ($r === -2) return [false, 'Ödül zaten alındı'];
    if ($r < 0) return [false, 'Ödül verilemedi'];
    return [true, '+' . $amt . ' token'];
}

// ---------------- Rozetler ----------------
function engBadgeDefs(): array {
    return [
        'ilk_yorum' => ['İlk Yorum', '💬', 'İlk yorumunu yazdın'],
        'yorumcu10' => ['Yorumcu', '🗨️', '10 yorum yazdın'],
        'yorumcu100'=> ['Sohbet Ustası', '🏆', '100 yorum yazdın'],
        'reklam1'   => ['Destekçi', '🪙', 'İlk reklamı izledin'],
        'reklam50'  => ['Token Avcısı', '💰', '50 reklam izledin'],
        'seri7'     => ['7 Gün Seri', '🔥', '7 gün üst üste giriş yaptın'],
        'seri30'    => ['30 Gün Seri', '⚡', '30 gün üst üste giriş yaptın'],
        'premium'   => ['Premium', '👑', 'Premium üye oldun'],
        'takipci10' => ['Sevilen', '💖', '10 takipçiye ulaştın'],
        'seviye5'   => ['Seviye 5', '⭐', 'Seviye 5\'e ulaştın'],
        'yil1'      => ['1 Yıllık Üye', '🎂', 'Bir yıldır buradasın'],
    ];
}
/** Hak edilen rozetleri verir; tüm rozetleri [key=>['name','icon','desc','earned']] döndürür. */
function engBadges(Supabase $db, string $uid, bool $award = true): array {
    $have = $db->select('user_badges', 'user_id=eq.' . $uid . '&select=badge', true)['data'] ?? [];
    $have = array_flip(array_column(is_array($have) ? $have : [], 'badge'));
    if ($award) {
        $cm = $db->count('comments', 'user_id=eq.' . $uid, true);
        $ads = $db->count('ad_watch_sessions', 'user_id=eq.' . $uid . '&claimed_at=not.is.null', true);
        $fol = $db->count('user_follows', 'following_id=eq.' . $uid, true);
        $st = $db->first('user_streaks', 'user_id=eq.' . $uid . '&select=best', true); $best = (int)($st['best'] ?? 0);
        $prem = (bool)$db->first('user_premium', 'user_id=eq.' . $uid . '&select=user_id', true);
        $pr = $db->first('profiles', 'id=eq.' . $uid . '&select=created_at', true);
        require_once __DIR__ . '/xp.php'; $lvl = nvXpInfo($db, $uid)['level'];
        $ok = ['ilk_yorum' => $cm >= 1, 'yorumcu10' => $cm >= 10, 'yorumcu100' => $cm >= 100, 'reklam1' => $ads >= 1, 'reklam50' => $ads >= 50,
            'seri7' => $best >= 7, 'seri30' => $best >= 30, 'premium' => $prem, 'takipci10' => $fol >= 10, 'seviye5' => $lvl >= 5,
            'yil1' => !empty($pr['created_at']) && strtotime($pr['created_at']) < time() - 365 * 86400];
        foreach ($ok as $k => $v) if ($v && !isset($have[$k])) { $db->insert('user_badges', ['user_id' => $uid, 'badge' => $k], true); $have[$k] = 1; }
    }
    $out = [];
    foreach (engBadgeDefs() as $k => [$n, $i, $d]) $out[$k] = ['name' => $n, 'icon' => $i, 'desc' => $d, 'earned' => isset($have[$k])];
    return $out;
}
function engBadgeHtml(array $badges, bool $onlyEarned = true): string {
    $h = '';
    foreach ($badges as $b) { if ($onlyEarned && !$b['earned']) continue;
        $h .= '<span title="' . htmlspecialchars($b['name'] . ' — ' . $b['desc'], ENT_QUOTES) . '" class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs" style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12)' . ($b['earned'] ? '' : ';opacity:.35;filter:grayscale(1)') . '">' . $b['icon'] . ' ' . htmlspecialchars($b['name'], ENT_QUOTES) . '</span> '; }
    return $h;
}

// ---------------- Premium bitiş bildirimi (uygulama içi) ----------------
function engPremiumWarn(Supabase $db, string $uid, int $days = 3): bool {
    $row = $db->first('user_premium', 'user_id=eq.' . $uid . '&select=premium_until', true);
    $until = $row['premium_until'] ?? null; if (!$until) return false;
    $t = strtotime($until); if ($t <= time() || $t > time() + $days * 86400) return false;
    $r = $db->insert('premium_warnings', ['user_id' => $uid, 'premium_until' => date('c', $t)], true);
    if (($r['status'] ?? 500) >= 300) return false; // zaten uyarıldı
    $left = max(1, (int)ceil(($t - time()) / 86400));
    $db->insert('notifications', ['user_id' => $uid, 'type' => 'premium', 'message' => 'Premium üyeliğin ' . $left . ' gün içinde bitiyor (' . date('d.m.Y H:i', $t) . '). Mağazadan yenileyebilirsin.', 'link' => '/magaza.php'], true);
    return true;
}
