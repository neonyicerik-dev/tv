<?php
// POST {type:"video"|"comment", id, reason, details?}  (giriş gerekli)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id']; denyIfBanned($db, $uid);
$in = inputJson() ?? [];
$type = (string)($in['type'] ?? ''); if (!in_array($type, ['video', 'comment'], true)) jsonError('Geçersiz tür');
$id = trim((string)($in['id'] ?? '')); requireUuid($id, 'İçerik ID');
$reasons = ['Yasa dışı içerik', 'Telif hakkı ihlali', 'Reşit olmayan / uygunsuz', 'Taciz / nefret', 'Spam / reklam', 'Yanlış bilgi / bozuk video', 'Diğer'];
$reason = (string)($in['reason'] ?? ''); if (!in_array($reason, $reasons, true)) jsonError('Geçerli bir neden seç');
$details = mb_substr(trim(strip_tags((string)($in['details'] ?? ''))), 0, 500);
$exists = $type === 'video' ? $db->first('videos', 'id=eq.' . $id . '&select=id', true) : $db->first('comments', 'id=eq.' . $id . '&select=id', true);
if (!$exists) jsonError('İçerik bulunamadı', 404);
if ($db->count('content_reports', 'reporter_id=eq.' . $uid . '&created_at=gte.' . urlencode(date('c', time() - 3600)), true) >= 10) jsonError('Saatlik şikayet sınırına ulaştın.', 429);
if ($db->first('content_reports', 'reporter_id=eq.' . $uid . '&target_type=eq.' . $type . '&target_id=eq.' . $id . '&select=id', true)) jsonError('Bu içeriği zaten şikayet ettin. Teşekkürler.');
$r = $db->insert('content_reports', ['reporter_id' => $uid, 'target_type' => $type, 'target_id' => $id, 'reason' => $reason, 'details' => $details], true);
if (($r['status'] ?? 500) >= 400) jsonError('Şikayet kaydedilemedi (SQL 12 çalıştı mı?)', 500);
jsonSuccess([], 'Şikayetin alındı. İnceleyeceğiz, teşekkürler.');
