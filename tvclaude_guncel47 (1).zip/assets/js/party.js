/* NeonTV - Birlikte izleme odası (senkron oynatma)
   Oda sahibi oynat/durdur/ileri-geri/hız işlemlerini yapar; katılanlar otomatik eşitlenir.
   Sunucu: api/party.php (2 sn'de bir yoklama). window.NV_PARTY = {base, vid} video.php tarafından verilir. */
(function () {
    const P = window.NV_PARTY || {}, video = document.getElementById('main-video');
    if (!video || !P.base) return;
    let tok = null, code = '', host = false, pollT = null, pushT = null, bar = null, lastErr = 0;
    const qs = new URLSearchParams(location.search);

    async function getTok() { try { const { data } = await sbClient.auth.getSession(); return data.session ? data.session.access_token : null; } catch (e) { return null; } }
    function api(body, qsx) {
        const opt = { headers: { 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok, 'Content-Type': 'application/json' } };
        if (body) { opt.method = 'POST'; opt.body = JSON.stringify(body); }
        return fetch(P.base + '/api/party.php?token=' + encodeURIComponent(tok) + (qsx || ''), opt).then(r => r.json());
    }
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
    function roomLink() { return P.base + '/video.php?id=' + encodeURIComponent(P.vid) + '&room=' + encodeURIComponent(code); }

    function paint(msg, viewers, needTap) {
        if (!bar) {
            bar = document.createElement('div'); bar.id = 'nv-party';
            bar.style.cssText = 'position:fixed;left:50%;top:12px;transform:translateX(-50%);z-index:10000;max-width:calc(100vw - 24px);display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:center;padding:8px 12px;border-radius:14px;background:rgba(13,13,26,.95);border:1px solid rgba(251,146,60,.5);box-shadow:0 8px 30px rgba(0,0,0,.6);font-size:12px;color:#e5e7eb';
            document.body.appendChild(bar);
            bar.addEventListener('click', e => {
                const b = e.target.closest('button'); if (!b) return;
                if (b.dataset.a === 'copy') { try { navigator.clipboard.writeText(roomLink()); b.textContent = 'Kopyalandı ✓'; } catch (x) { prompt('Oda linki:', roomLink()); } }
                if (b.dataset.a === 'leave') leave();
                if (b.dataset.a === 'tap') { video.play().catch(() => {}); }
            });
        }
        const btn = 'padding:4px 10px;border-radius:999px;font-weight:700;font-size:11px;';
        bar.innerHTML = '<span style="color:#fb923c;font-weight:800"><i class="fa-solid fa-users-viewfinder"></i> Oda ' + esc(code) + '</span>' +
            '<span>' + esc(msg) + '</span>' + (viewers ? '<span style="color:#9ca3af">· ' + viewers + ' kişi</span>' : '') +
            (needTap ? '<button type="button" data-a="tap" style="' + btn + 'background:#fb923c;color:#000">▶ Katıl / Oynat</button>' : '') +
            '<button type="button" data-a="copy" style="' + btn + 'background:rgba(255,255,255,.1);color:#fff">Linki kopyala</button>' +
            '<button type="button" data-a="leave" style="' + btn + 'background:rgba(248,113,113,.2);color:#fca5a5">Çık</button>';
    }
    function leave() {
        clearInterval(pollT); clearInterval(pushT); pollT = pushT = null;
        if (bar) { bar.remove(); bar = null; }
        try { const u = new URL(location.href); u.searchParams.delete('room'); history.replaceState(null, '', u); } catch (e) {}
        code = ''; host = false;
    }
    function push() {
        if (!code || !host) return;
        api({ action: 'state', code: code, pos: video.currentTime || 0, playing: !video.paused, rate: video.playbackRate || 1 }).catch(() => {});
    }
    function startHost() {
        host = true; paint('Sen yönetiyorsun · linki arkadaşına gönder', 1);
        ['play', 'pause', 'seeked', 'ratechange'].forEach(ev => video.addEventListener(ev, push));
        pushT = setInterval(() => { if (!video.paused) push(); }, 3000);
        pollT = setInterval(async () => { try { const r = await api(null, '&code=' + encodeURIComponent(code)); if (r.success) paint('Sen yönetiyorsun · linki arkadaşına gönder', r.data.viewers); } catch (e) {} }, 5000);
        push();
    }
    async function poll() {
        let r; try { r = await api(null, '&code=' + encodeURIComponent(code)); } catch (e) { return; }
        if (!r.success) { paint(r.message || 'Oda kapandı'); clearInterval(pollT); return; }
        const d = r.data;
        if (d.video_id !== P.vid) { location.href = P.base + '/video.php?id=' + encodeURIComponent(d.video_id) + '&room=' + encodeURIComponent(code); return; }
        if (d.host) return;
        const target = d.pos + (d.playing ? d.age * d.rate : 0);
        if (Math.abs(video.currentTime - target) > 1.5) { try { video.currentTime = target; } catch (e) {} }
        if (video.playbackRate !== d.rate) video.playbackRate = d.rate;
        let tap = false;
        if (d.playing && video.paused) { try { await video.play(); } catch (e) { tap = true; } }
        else if (!d.playing && !video.paused) video.pause();
        paint(d.playing ? 'Oda sahibiyle eşitlendi' : 'Oda sahibi duraklattı', d.viewers, tap);
    }
    async function join(c) {
        code = c; tok = await getTok();
        if (!tok) { code = c; paint('Katılmak için giriş yap', 0); bar.insertAdjacentHTML('afterbegin', '<a href="' + P.base + '/auth.php" style="color:#00f5ff;font-weight:700;text-decoration:underline">Giriş yap</a>'); return; }
        const r = await api(null, '&code=' + encodeURIComponent(c)).catch(() => ({ success: false }));
        if (!r.success) { paint(r.message || 'Oda bulunamadı'); setTimeout(leave, 4000); return; }
        if (r.data.host) { startHost(); return; }
        poll(); pollT = setInterval(poll, 2000);
    }
    window.nvPartyStart = async function () {
        if (code) { return; }
        tok = await getTok();
        if (!tok) { if (confirm('Birlikte izlemek için giriş yapmalısın. Giriş sayfasına gidilsin mi?')) location.href = P.base + '/auth.php'; return; }
        const r = await api({ action: 'create', video_id: P.vid }).catch(() => ({ success: false }));
        if (!r.success) { alert(r.message || 'Oda oluşturulamadı'); return; }
        code = r.data.code;
        try { const u = new URL(location.href); u.searchParams.set('room', code); history.replaceState(null, '', u); } catch (e) {}
        startHost();
        try { navigator.clipboard.writeText(roomLink()); } catch (e) {}
    };
    window.addEventListener('load', () => { const c = (qs.get('room') || '').toUpperCase(); if (/^[A-Z2-9]{6}$/.test(c)) join(c); });
})();
