<?php
// NeonTV - Admin: 18 yaş onayı kayıtları (kapı onayı + kayıt onayı)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
requireAdmin(['superadmin']);
$db = new Supabase(); $tz = new DateTimeZone('Europe/Istanbul');
$rows = $db->select('age_confirmations', 'order=confirmed_at.desc&limit=2000&select=source,version,confirmed_at,ip_hash', true)['data'] ?? []; $rows = is_array($rows) ? $rows : [];
$total = $db->count('age_confirmations', '', true);
$by = []; foreach ($rows as $r) { $d = (new DateTime($r['confirmed_at']))->setTimezone($tz)->format('Y-m-d'); $by[$d][$r['source']] = ($by[$d][$r['source']] ?? 0) + 1; }
$adminTitle = 'Yaş Onayı Kaydı'; $adminSub = 'Toplam ' . number_format($total, 0, ',', '.') . ' onay · yalnızca tek yönlü özet saklanır';
include __DIR__ . '/_top.php';
?>
<div class="rounded-2xl overflow-x-auto max-w-3xl" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
<table class="w-full text-sm"><thead><tr class="text-left text-gray-500 text-xs"><th class="p-3">Gün</th><th class="p-3">Kapı onayı</th><th class="p-3">Kayıt onayı</th></tr></thead><tbody>
<?php foreach (array_slice($by, 0, 60, true) as $d => $x): ?><tr class="border-t border-white/5"><td class="p-3 text-white"><?= e($d) ?></td><td class="p-3 text-gray-300"><?= (int)($x['gate'] ?? 0) ?></td><td class="p-3 text-gray-300"><?= (int)($x['register'] ?? 0) ?></td></tr><?php endforeach; if (!$by) echo '<tr><td colspan="3" class="p-6 text-center text-gray-500">Kayıt yok (SQL 12 çalıştıktan sonra dolar).</td></tr>'; ?>
</tbody></table></div>
<p class="text-xs text-gray-500 mt-3 max-w-3xl">Kayıtta ayrıca her kullanıcının hesabına onay tarihi ve metin sürümü işlenir. Kayıtlar KVKK gereği uzun süre tutulmamalıdır; gerekirse Supabase'den eski satırları silebilirsin.</p>
<?php include __DIR__ . '/_bottom.php'; ?>
