<?php
// NeonTV - Admin: video bölümleri (chapters). Elle ekle, toplu yapıştır ("0:00 Giriş" satırları), sil.
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/activity_log.php';
requireAdmin(['editor', 'superadmin']);
$db = new Supabase(); $vid = trim((string)($_GET['v'] ?? ''));
if ($vid !== '' && !isUuid($vid)) $vid = '';
$self = APP_URL . '/admin/chapters.php' . ($vid ? '?v=' . $vid : '');

$parseT = function (string $s): ?int {
    if (!preg_match('/^(?:(\d+):)?(\d{1,2}):(\d{2})$|^(\d+)$/', trim($s), $m)) return null;
    if (isset($m[4]) && $m[4] !== '') return (int)$m[4];
    return ((int)$m[1]) * 3600 + ((int)$m[2]) * 60 + (int)$m[3];
};
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $vid) {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect($self); }
    $act = input('action');
    if ($act === 'add') {
        $t = $parseT((string)input('time')); $title = trim((string)input('title'));
        if ($t === null || $title === '') setFlash('error', 'Zaman (ör. 1:30) ve başlık gerekli.');
        else { $db->insert('chapters', ['video_id' => $vid, 'title' => mb_substr($title, 0, 120), 'start_time' => $t], true); logActivity('chapter_add', 'video', $vid); setFlash('success', 'Bölüm eklendi.'); }
    } elseif ($act === 'bulk') {
        $n = 0; $rows = [];
        foreach (preg_split('/\R/u', (string)input('bulk')) as $line) {
            if (!preg_match('/^\s*((?:\d+:)?\d{1,2}:\d{2})\s*[-–—:]?\s*(.+)$/u', $line, $m)) continue;
            $t = $parseT($m[1]); if ($t === null) continue;
            $rows[] = ['video_id' => $vid, 'title' => mb_substr(trim($m[2]), 0, 120), 'start_time' => $t]; if (++$n >= 60) break;
        }
        if ($rows) {
            if (input('replace') === '1') $db->delete('chapters', 'video_id=eq.' . $vid, true);
            foreach ($rows as $r) $db->insert('chapters', $r, true);
            logActivity('chapter_bulk', 'video', $vid, [], ['count' => $n]); setFlash('success', $n . ' bölüm eklendi.');
        } else setFlash('error', 'Geçerli satır bulunamadı. Biçim: 0:00 Giriş');
    } elseif ($act === 'delete') {
        $cid = trim((string)input('id')); if (isUuid($cid)) { $db->delete('chapters', 'id=eq.' . $cid . '&video_id=eq.' . $vid, true); setFlash('success', 'Bölüm silindi.'); }
    }
    redirect($self);
}
$q = trim((string)($_GET['q'] ?? '')); $found = []; $video = null; $chs = [];
if ($vid) {
    $video = $db->first('videos', 'id=eq.' . $vid . '&select=id,title,duration', true);
    $chs = $db->select('chapters', 'video_id=eq.' . $vid . '&order=start_time.asc', true)['data'] ?? []; $chs = is_array($chs) ? $chs : [];
} elseif ($q !== '') {
    $found = $db->select('videos', 'title=ilike.' . rawurlencode('*' . str_replace(['*', ',', '(', ')'], '', $q) . '*') . '&select=id,title&order=created_at.desc&limit=20', true)['data'] ?? [];
}
$adminTitle = 'Video Bölümleri'; $adminSub = 'Oynatıcıda ilerleme çubuğunda işaretler ve "Bölümler" menüsü olarak görünür';
include __DIR__ . '/_top.php';
$fmt = fn($s) => ($s >= 3600 ? floor($s / 3600) . ':' : '') . str_pad((string)floor(($s % 3600) / 60), $s >= 3600 ? 2 : 1, '0', STR_PAD_LEFT) . ':' . str_pad((string)($s % 60), 2, '0', STR_PAD_LEFT);
$card = 'background:#13131f;border:1px solid rgba(255,255,255,.08)'; $inp = 'px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-sm text-white';
?>
<?php if (!$vid): ?>
<form method="get" class="flex gap-2 mb-4"><input name="q" value="<?= e($q) ?>" placeholder="Video adı ara…" class="<?= $inp ?> w-72"><button class="px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#00f5ff">Ara</button></form>
<div class="rounded-2xl divide-y divide-white/5 max-w-2xl" style="<?= $card ?>">
<?php foreach ($found as $f): ?><a href="?v=<?= e($f['id']) ?>" class="block p-3 text-sm text-gray-200 hover:text-cyan-300"><?= e($f['title']) ?></a><?php endforeach; ?>
<?php if (!$found): ?><p class="p-4 text-sm text-gray-500"><?= $q !== '' ? 'Sonuç yok.' : 'Bölüm eklemek istediğin videoyu ara.' ?></p><?php endif; ?></div>
<?php elseif (!$video): ?><p class="text-gray-400">Video bulunamadı. <a class="text-cyan-300" href="chapters.php">Geri</a></p>
<?php else: ?>
<p class="text-white font-semibold mb-1"><?= e($video['title']) ?></p><a href="chapters.php" class="text-xs text-cyan-300">← Başka video seç</a>
<div class="grid lg:grid-cols-2 gap-5 mt-4 max-w-5xl">
  <div class="rounded-2xl p-4" style="<?= $card ?>"><h3 class="text-sm font-bold text-white mb-3">Bölümler (<?= count($chs) ?>)</h3>
    <?php foreach ($chs as $c): ?><form method="post" class="flex items-center gap-3 py-1.5 border-b border-white/5 text-sm"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e($c['id']) ?>">
      <span class="font-mono text-cyan-300 w-16"><?= e($fmt((int)$c['start_time'])) ?></span><span class="flex-1 text-gray-200 break-words"><?= e($c['title']) ?></span><button class="text-xs text-red-400" onclick="return confirm('Silinsin mi?')">Sil</button></form><?php endforeach; ?>
    <?php if (!$chs): ?><p class="text-sm text-gray-500">Henüz bölüm yok.</p><?php endif; ?></div>
  <div class="space-y-5">
    <form method="post" class="rounded-2xl p-4 flex flex-wrap gap-2 items-end" style="<?= $card ?>"><?= csrfField() ?><input type="hidden" name="action" value="add">
      <div><label class="block text-[11px] text-gray-500 mb-1">Zaman</label><input name="time" placeholder="1:30" class="<?= $inp ?> w-24"></div>
      <div class="flex-1 min-w-[140px]"><label class="block text-[11px] text-gray-500 mb-1">Başlık</label><input name="title" maxlength="120" class="<?= $inp ?> w-full"></div>
      <button class="px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#00f5ff">Ekle</button></form>
    <form method="post" class="rounded-2xl p-4" style="<?= $card ?>"><?= csrfField() ?><input type="hidden" name="action" value="bulk">
      <label class="block text-[11px] text-gray-500 mb-1">Toplu ekle (her satır: <code>0:00 Giriş</code>)</label>
      <textarea name="bulk" rows="6" class="<?= $inp ?> w-full font-mono" placeholder="0:00 Giriş&#10;2:15 Ana bölüm&#10;10:40 Final"></textarea>
      <label class="flex items-center gap-2 text-xs text-gray-400 mt-2"><input type="checkbox" name="replace" value="1"> Mevcut bölümlerin yerine koy</label>
      <button class="mt-3 px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#bf00ff;color:#fff">Toplu ekle</button></form>
  </div>
</div>
<?php endif; ?>
<?php include __DIR__ . '/_bottom.php'; ?>
