<?php
// NeonTV - Admin: Yasal bilgiler (satıcı/veri sorumlusu bilgileri; yasal metinlerde kullanılır)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/activity_log.php';
requireAdmin(['superadmin']);
$f = ['legal_company' => 'Firma / kişi unvanı', 'legal_address' => 'Açık adres', 'legal_email' => 'İletişim e-postası', 'legal_phone' => 'Telefon', 'legal_tax' => 'Vergi no / Mersis no', 'legal_kep' => 'KEP adresi'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/legal.php'); }
    $vals = []; foreach ($f as $k => $_) $vals[$k] = mb_substr(trim(input($k)), 0, 300);
    $ok = Store::setSettings($vals); logActivity('legal_update', 'settings', 'legal');
    setFlash($ok ? 'success' : 'error', $ok ? 'Kaydedildi.' : 'Kaydedilemedi.'); redirect(APP_URL . '/admin/legal.php');
}
$adminTitle = 'Yasal Bilgiler'; $adminSub = 'KVKK, mesafeli satış ve diğer yasal metinlerde görünen firma bilgileri';
include __DIR__ . '/_top.php';
$inp = 'w-full bg-black/30 border border-gray-800 rounded-xl py-2 px-3 text-white text-sm';
?>
<form method="POST" class="rounded-2xl p-5 space-y-4 max-w-2xl" style="background:#13131f;border:1px solid rgba(255,255,255,.08)"><?= csrfField() ?>
  <p class="text-xs text-gray-400">Bu bilgiler <a class="text-cyan-400" href="<?= APP_URL ?>/yasal.php" target="_blank">yasal metinlerde</a> satıcı / veri sorumlusu olarak gösterilir. Eksik bıraktığınız alanlar sayfada kırmızı uyarı olarak görünür. Metinleri yayına almadan önce bir hukukçuya gösterin.</p>
  <?php foreach ($f as $k => $l): ?><label class="block text-xs text-gray-400"><?= e($l) ?><input name="<?= $k ?>" value="<?= e((string)Store::getSetting($k, '')) ?>" maxlength="300" class="<?= $inp ?>"></label><?php endforeach; ?>
  <button class="px-6 py-2.5 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff)">Kaydet</button>
</form>
<?php include __DIR__ . '/_bottom.php'; ?>
