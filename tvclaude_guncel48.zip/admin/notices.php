<?php
// NeonTV - Admin: Duyurular (üst şerit) + toplu bildirim
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/notices.php';
requireAdmin(['editor', 'superadmin']);
$db = new Supabase(); $self = APP_URL . '/admin/notices.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect($self); }
    $act = input('action'); $list = nvNoticesAll();
    $dt = function ($k) { $v = trim(input($k)); $t = $v !== '' ? strtotime($v) : false; return $t ? date('c', $t) : ''; };
    $link = function ($v) { $v = trim($v); return preg_match('#^(https?://|/)[^\s"\'<>]+$#i', $v) ? mb_substr($v, 0, 300) : ''; };
    if ($act === 'add' || $act === 'edit') {
        $row = ['id' => $act === 'edit' ? input('id') : bin2hex(random_bytes(5)), 'text' => mb_substr(trim(input('text')), 0, 160), 'link' => $link(input('link')),
            'color' => isset(NOTICE_COLORS[input('color')]) ? input('color') : 'cyan', 'starts' => $dt('starts'), 'ends' => $dt('ends'), 'active' => input('active') === '1'];
        if ($row['text'] === '') { setFlash('error', 'Duyuru metni boş olamaz.'); redirect($self); }
        if ($act === 'edit') { foreach ($list as &$n) if (($n['id'] ?? '') === $row['id']) $n = $row; unset($n); } else $list[] = $row;
        $ok = Store::setSetting('site_notices', array_values($list)); logActivity('notice_' . $act, 'settings', $row['id']);
        setFlash($ok ? 'success' : 'error', $ok ? 'Duyuru kaydedildi.' : 'Kaydedilemedi.');
    } elseif ($act === 'toggle' || $act === 'delete') {
        $id = input('id'); $out = [];
        foreach ($list as $n) { if (($n['id'] ?? '') === $id) { if ($act === 'delete') continue; $n['active'] = empty($n['active']); } $out[] = $n; }
        Store::setSetting('site_notices', $out); logActivity('notice_' . $act, 'settings', $id);
    } elseif ($act === 'broadcast') {
        $msg = mb_substr(trim(input('message')), 0, 300); $grp = input('group');
        if ($msg === '' || !in_array($grp, ['all', 'premium', 'new7'], true)) { setFlash('error', 'Mesaj ve grup seç.'); redirect($self); }
        $ids = [];
        if ($grp === 'premium') {
            $r = $db->select('user_premium', 'or=(premium_until.is.null,premium_until.gt.' . urlencode(date('c')) . ')&select=user_id&limit=20000', true)['data'] ?? [];
            $ids = array_column(is_array($r) ? $r : [], 'user_id');
        } else {
            $q = 'select=id&limit=20000' . ($grp === 'new7' ? '&created_at=gte.' . urlencode(date('c', time() - 7 * 86400)) : '');
            $r = $db->select('profiles', $q, true)['data'] ?? []; $ids = array_column(is_array($r) ? $r : [], 'id');
        }
        $ids = array_values(array_filter(array_unique($ids), 'isUuid')); $lk = $link(input('blink')); $sent = 0;
        foreach (array_chunk($ids, 400) as $chunk) {
            $rows = array_map(fn($u) => ['user_id' => $u, 'type' => 'announcement', 'message' => $msg] + ($lk !== '' ? ['link' => $lk] : []), $chunk);
            $r = $db->insert('notifications', $rows, true); if (($r['status'] ?? 500) < 300) $sent += count($chunk);
        }
        logActivity('broadcast', 'notification', $grp, [], ['sent' => $sent], mb_substr($msg, 0, 80));
        setFlash($sent ? 'success' : 'error', $sent ? $sent . ' kullanıcıya bildirim gönderildi.' : 'Gönderilemedi veya alıcı yok.');
    }
    redirect($self);
}
$all = nvNoticesAll(); $act = array_column(nvNoticesActive(), 'id');
$loc = fn($s) => $s && strtotime($s) ? date('Y-m-d\TH:i', strtotime($s)) : '';
$adminTitle = 'Duyurular'; $adminSub = 'Sitenin üstünde küçük şerit (kullanıcı kapatamaz) ve toplu bildirim';
include __DIR__ . '/_top.php';
$inp = 'w-full bg-black/30 border border-gray-800 rounded-xl py-2 px-3 text-white text-sm'; $lbl = 'block text-xs text-gray-400';
$colors = ['cyan' => 'Camgöbeği', 'purple' => 'Mor', 'red' => 'Kırmızı', 'green' => 'Yeşil', 'yellow' => 'Sarı'];
?>
<div class="space-y-6 max-w-3xl">
<div class="rounded-2xl p-5 space-y-3" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
  <h2 class="font-bold text-white"><i class="fa-solid fa-bullhorn text-cyan-400 mr-2"></i>Yeni duyuru</h2>
  <p class="text-xs text-gray-500">Aktif duyurular tüm sayfaların en üstünde küçük bir şerit olarak görünür; kullanıcılar kapatamaz. Siz pasifleştirene, silene veya bitiş tarihi gelene kadar durur. Birden fazlası varsa sırayla döner.</p>
  <form method="POST" class="grid grid-cols-2 gap-3"><?= csrfField() ?><input type="hidden" name="action" value="add">
    <label class="<?= $lbl ?> col-span-2">Metin (en fazla 160)<input name="text" required maxlength="160" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Bağlantı (isteğe bağlı)<input name="link" placeholder="/magaza.php veya https://..." class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Renk<select name="color" class="<?= $inp ?>"><?php foreach ($colors as $k => $l): ?><option value="<?= $k ?>"><?= $l ?></option><?php endforeach; ?></select></label>
    <label class="<?= $lbl ?>">Başlangıç (boş = hemen)<input type="datetime-local" name="starts" class="<?= $inp ?>"></label>
    <label class="<?= $lbl ?>">Bitiş (boş = admin kapatana kadar)<input type="datetime-local" name="ends" class="<?= $inp ?>"></label>
    <label class="text-sm text-gray-300 flex items-center gap-2"><input type="checkbox" name="active" value="1" checked> Hemen yayınla</label>
    <button class="px-5 py-2.5 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff)">Ekle</button>
  </form>
</div>
<div class="rounded-2xl divide-y divide-white/5" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
  <?php foreach ($all as $n): $on = in_array($n['id'] ?? '', $act, true); ?>
  <div class="p-4 space-y-2">
    <div class="flex items-center gap-2 flex-wrap"><span class="text-xs font-bold px-2 py-0.5 rounded-full" style="background:<?= $on ? 'rgba(74,222,128,.2);color:#4ade80' : 'rgba(255,255,255,.08);color:#9ca3af' ?>"><?= $on ? '● yayında' : (!empty($n['active']) ? 'planlı/bitti' : 'pasif') ?></span><span class="text-sm text-white"><?= e($n['text']) ?></span></div>
    <details><summary class="text-xs text-cyan-400 cursor-pointer">Düzenle</summary>
      <form method="POST" class="grid grid-cols-2 gap-2 mt-2"><?= csrfField() ?><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="<?= e($n['id']) ?>">
        <input name="text" value="<?= e($n['text']) ?>" maxlength="160" class="<?= $inp ?> col-span-2"><input name="link" value="<?= e($n['link'] ?? '') ?>" class="<?= $inp ?>">
        <select name="color" class="<?= $inp ?>"><?php foreach ($colors as $k => $l): ?><option value="<?= $k ?>" <?= ($n['color'] ?? '') === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select>
        <input type="datetime-local" name="starts" value="<?= e($loc($n['starts'] ?? '')) ?>" class="<?= $inp ?>"><input type="datetime-local" name="ends" value="<?= e($loc($n['ends'] ?? '')) ?>" class="<?= $inp ?>">
        <label class="text-sm text-gray-300 flex items-center gap-2"><input type="checkbox" name="active" value="1" <?= !empty($n['active']) ? 'checked' : '' ?>> Aktif</label><button class="px-4 py-2 rounded-xl font-bold text-black" style="background:#00f5ff">Kaydet</button>
      </form></details>
    <form method="POST" class="flex gap-3 text-xs"><?= csrfField() ?><input type="hidden" name="id" value="<?= e($n['id']) ?>">
      <button name="action" value="toggle" class="px-3 py-1.5 rounded-lg bg-white/10 text-gray-200"><?= !empty($n['active']) ? 'Kapat (pasifleştir)' : 'Yayına al' ?></button>
      <button name="action" value="delete" onclick="return confirm('Silinsin mi?')" class="px-3 py-1.5 text-red-400">Sil</button></form>
  </div>
  <?php endforeach; if (!$all) echo '<p class="p-5 text-sm text-gray-500">Henüz duyuru yok.</p>'; ?>
</div>
<form method="POST" class="rounded-2xl p-5 space-y-3" style="background:#13131f;border:1px solid rgba(255,255,255,.08)"><?= csrfField() ?><input type="hidden" name="action" value="broadcast">
  <h2 class="font-bold text-white"><i class="fa-solid fa-bell text-yellow-400 mr-2"></i>Toplu bildirim gönder</h2>
  <p class="text-xs text-gray-500">Seçilen gruptaki kullanıcıların bildirim kutusuna düşer (e-posta gitmez). Gönderim geri alınamaz.</p>
  <div class="grid grid-cols-2 gap-3"><label class="<?= $lbl ?> col-span-2">Mesaj (en fazla 300)<textarea name="message" required maxlength="300" rows="2" class="<?= $inp ?>"></textarea></label>
    <label class="<?= $lbl ?>">Grup<select name="group" class="<?= $inp ?>"><option value="all">Tüm kullanıcılar</option><option value="premium">Premium üyeler</option><option value="new7">Son 7 gün katılanlar</option></select></label>
    <label class="<?= $lbl ?>">Bağlantı (isteğe bağlı)<input name="blink" placeholder="/magaza.php" class="<?= $inp ?>"></label></div>
  <button onclick="return confirm('Bildirim seçilen gruba gönderilsin mi?')" class="px-5 py-2.5 rounded-xl font-bold text-black" style="background:#fbbf24">Gönder</button>
</form>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
