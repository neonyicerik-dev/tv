<?php
// NeonTV - Admin: Haftanın seçkisi (landing sayfasında ve ana sayfada gösterilir)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/picks.php';
requireAdmin(['editor', 'superadmin']);
$db = new Supabase(); $self = APP_URL . '/admin/picks.php';
$cfg = nvPicksCfg();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect($self); }
    $act = input('action'); $ids = $cfg['ids']; $title = $cfg['title']; $note = $cfg['note'];
    if ($act === 'add') { $v = trim((string)input('video')); if (preg_match('/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i', $v, $m)) { $v = strtolower($m[0]); if (!in_array($v, $ids, true) && count($ids) < 12) $ids[] = $v; } }
    elseif ($act === 'remove') { $ids = array_values(array_diff($ids, [trim((string)input('id'))])); }
    elseif ($act === 'up' || $act === 'down') {
        $i = array_search(trim((string)input('id')), $ids, true);
        if ($i !== false) { $j = $act === 'up' ? $i - 1 : $i + 1; if (isset($ids[$j])) { [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]]; } }
    } elseif ($act === 'meta') { $title = mb_substr(trim((string)input('title')), 0, 60); $note = mb_substr(trim((string)input('note')), 0, 200); }
    elseif ($act === 'clear') { $ids = []; }
    Store::setSetting('weekly_picks', ['title' => $title, 'note' => $note, 'ids' => $ids, 'updated_at' => date('c')]);
    Store::clearCache('site_settings'); Store::clearCache('weekly_picks_v');
    logActivity('weekly_picks_' . $act, 'settings', 'weekly_picks');
    setFlash('success', 'Seçki güncellendi.'); redirect($self);
}
$q = trim((string)($_GET['q'] ?? '')); $found = [];
if ($q !== '') $found = $db->select('videos', 'status=eq.published&title=ilike.' . rawurlencode('*' . str_replace(['*', ',', '(', ')'], '', $q) . '*') . '&select=id,title&order=views.desc&limit=15', true)['data'] ?? [];
$vt = [];
if ($cfg['ids']) foreach ((array)($db->select('videos', 'id=in.(' . implode(',', $cfg['ids']) . ')&select=id,title,thumbnail_url,status,views', true)['data'] ?? []) as $v) $vt[$v['id']] = $v;
$adminTitle = 'Haftanın Seçkisi'; $adminSub = count($cfg['ids']) . '/12 video seçili · boşsa son 7 günün en çok izlenenleri otomatik gösterilir';
include __DIR__ . '/_top.php';
$card = 'background:#13131f;border:1px solid rgba(255,255,255,.08)'; $inp = 'px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-sm text-white';
?>
<div class="grid lg:grid-cols-2 gap-5 max-w-5xl">
  <div class="rounded-2xl p-4" style="<?= $card ?>"><h3 class="text-sm font-bold text-white mb-3">Seçili videolar</h3>
    <?php foreach ($cfg['ids'] as $i => $id): $v = $vt[$id] ?? null; ?>
    <form method="post" class="flex items-center gap-2 py-2 border-b border-white/5 text-sm"><?= csrfField() ?><input type="hidden" name="id" value="<?= e($id) ?>">
      <span class="text-gray-500 w-5"><?= $i + 1 ?></span>
      <span class="flex-1 min-w-0 truncate <?= $v && ($v['status'] ?? '') === 'published' ? 'text-gray-200' : 'text-red-300' ?>"><?= e($v['title'] ?? ($id . ' (bulunamadı)')) ?></span>
      <button name="action" value="up" class="px-2 text-gray-400">▲</button><button name="action" value="down" class="px-2 text-gray-400">▼</button>
      <button name="action" value="remove" class="px-2 text-red-400" onclick="return confirm('Çıkarılsın mı?')">✕</button></form>
    <?php endforeach; ?>
    <?php if (!$cfg['ids']): ?><p class="text-sm text-gray-500">Seçili video yok → otomatik seçki kullanılıyor.</p>
    <?php else: ?><form method="post" class="mt-3"><?= csrfField() ?><button name="action" value="clear" class="text-xs text-red-400" onclick="return confirm('Tüm seçki temizlensin mi?')">Tümünü temizle</button></form><?php endif; ?></div>
  <div class="space-y-5">
    <form method="post" class="rounded-2xl p-4 space-y-3" style="<?= $card ?>"><?= csrfField() ?><input type="hidden" name="action" value="meta">
      <div><label class="block text-[11px] text-gray-500 mb-1">Başlık</label><input name="title" maxlength="60" value="<?= e($cfg['title']) ?>" class="<?= $inp ?> w-full"></div>
      <div><label class="block text-[11px] text-gray-500 mb-1">Kısa not (isteğe bağlı)</label><input name="note" maxlength="200" value="<?= e($cfg['note']) ?>" class="<?= $inp ?> w-full"></div>
      <button class="px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#00f5ff">Kaydet</button></form>
    <div class="rounded-2xl p-4" style="<?= $card ?>"><form method="get" class="flex gap-2 mb-3"><input name="q" value="<?= e($q) ?>" placeholder="Video adı ara…" class="<?= $inp ?> flex-1"><button class="px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#bf00ff;color:#fff">Ara</button></form>
      <?php foreach ($found as $f): ?><form method="post" class="flex items-center gap-2 py-1.5 text-sm"><?= csrfField() ?><input type="hidden" name="action" value="add"><input type="hidden" name="video" value="<?= e($f['id']) ?>">
        <span class="flex-1 truncate text-gray-200"><?= e($f['title']) ?></span><button class="px-3 py-1 rounded-lg text-xs font-bold text-black" style="background:#00f5ff">Ekle</button></form><?php endforeach; ?>
      <?php if ($q !== '' && !$found): ?><p class="text-sm text-gray-500">Sonuç yok.</p><?php endif; ?></div>
  </div>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
