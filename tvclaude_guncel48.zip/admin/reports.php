<?php
// NeonTV - Admin: Şikayet kuyruğu (video ve yorum şikayetleri)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/activity_log.php';
requireAdmin(['moderator', 'superadmin']);
$db = new Supabase(); $self = APP_URL . '/admin/reports.php';
$who = $_SESSION['admin_username'] ?? 'admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect($self); }
    $id = trim(input('id')); requireUuid($id, 'Şikayet'); $act = input('action');
    $rep = $db->first('content_reports', 'id=eq.' . $id, true);
    if ($rep) {
        $status = 'resolved';
        if ($act === 'dismiss') $status = 'dismissed';
        elseif ($act === 'delete_comment' && $rep['target_type'] === 'comment') { $db->delete('comments', 'id=eq.' . $rep['target_id'], true); }
        elseif ($act === 'unpublish' && $rep['target_type'] === 'video') { $db->update('videos', ['status' => 'draft'], 'id=eq.' . $rep['target_id'], true); }
        // aynı içeriğe gelen diğer açık şikayetleri de kapat
        $db->update('content_reports', ['status' => $status, 'handled_by' => $who, 'handled_at' => date('c')], 'target_type=eq.' . $rep['target_type'] . '&target_id=eq.' . $rep['target_id'] . '&status=eq.open', true);
        logActivity('report_' . $act, $rep['target_type'], $rep['target_id']);
        setFlash('success', 'Şikayet işlendi.');
    }
    redirect($self);
}
$st = in_array($_GET['s'] ?? 'open', ['open', 'resolved', 'dismissed'], true) ? ($_GET['s'] ?? 'open') : 'open';
$rows = $db->select('content_reports', 'status=eq.' . $st . '&order=created_at.desc&limit=200', true)['data'] ?? []; $rows = is_array($rows) ? $rows : [];
// içerikleri topla
$vids = $cms = [];
foreach ($rows as $r) { if ($r['target_type'] === 'video') $vids[] = $r['target_id']; else $cms[] = $r['target_id']; }
$vt = []; if ($vids) foreach ((array)($db->select('videos', 'id=in.(' . implode(',', array_unique($vids)) . ')&select=id,title,status', true)['data'] ?? []) as $v) $vt[$v['id']] = $v;
$ct = []; if ($cms) foreach ((array)($db->select('comments', 'id=in.(' . implode(',', array_unique($cms)) . ')&select=id,content,video_id,user_id', true)['data'] ?? []) as $c) $ct[$c['id']] = $c;
$openN = $db->count('content_reports', 'status=eq.open', true);
$adminTitle = 'Şikayetler'; $adminSub = $openN . ' açık şikayet';
include __DIR__ . '/_top.php';
?>
<div class="flex gap-2 mb-4 text-sm"><?php foreach (['open' => 'Açık', 'resolved' => 'Çözüldü', 'dismissed' => 'Reddedildi'] as $k => $l): ?><a href="?s=<?= $k ?>" class="px-4 py-1.5 rounded-full" style="background:<?= $st === $k ? 'rgba(0,245,255,.2)' : 'rgba(255,255,255,.06)' ?>;color:<?= $st === $k ? '#00f5ff' : '#9ca3af' ?>"><?= $l ?></a><?php endforeach; ?></div>
<div class="rounded-2xl divide-y divide-white/5" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
<?php foreach ($rows as $r): $isV = $r['target_type'] === 'video'; $t = $isV ? ($vt[$r['target_id']] ?? null) : ($ct[$r['target_id']] ?? null); ?>
  <div class="p-4 space-y-2">
    <div class="flex items-center gap-2 flex-wrap text-xs"><span class="px-2 py-0.5 rounded-full font-bold" style="background:rgba(251,113,133,.18);color:#fb7185"><?= e($r['reason']) ?></span><span class="text-gray-500"><?= $isV ? 'Video' : 'Yorum' ?> · <?= e(date('d.m.Y H:i', strtotime($r['created_at']))) ?></span></div>
    <?php if (!$t): ?><p class="text-sm text-gray-500">İçerik artık yok (silinmiş).</p>
    <?php elseif ($isV): ?><p class="text-sm text-white"><a class="text-cyan-400" target="_blank" href="<?= APP_URL ?>/video.php?id=<?= e($t['id']) ?>"><?= e($t['title']) ?></a> <span class="text-xs text-gray-500">(<?= e($t['status']) ?>)</span></p>
    <?php else: ?><p class="text-sm text-gray-200 break-words">“<?= e(mb_substr($t['content'], 0, 300)) ?>” <a class="text-cyan-400 text-xs" target="_blank" href="<?= APP_URL ?>/video.php?id=<?= e($t['video_id']) ?>#comment-<?= e($t['id']) ?>">yoruma git</a></p><?php endif; ?>
    <?php if ($r['details'] !== ''): ?><p class="text-xs text-gray-400">Not: <?= e($r['details']) ?></p><?php endif; ?>
    <?php if ($st === 'open'): ?>
    <form method="POST" class="flex gap-2 flex-wrap text-xs"><?= csrfField() ?><input type="hidden" name="id" value="<?= e($r['id']) ?>">
      <?php if ($t && !$isV): ?><button name="action" value="delete_comment" onclick="return confirm('Yorum silinsin mi?')" class="px-3 py-1.5 rounded-lg font-bold" style="background:#dc2626;color:#fff">Yorumu sil</button><?php endif; ?>
      <?php if ($t && $isV): ?><button name="action" value="unpublish" onclick="return confirm('Video taslağa alınsın mı?')" class="px-3 py-1.5 rounded-lg font-bold" style="background:#dc2626;color:#fff">Yayından kaldır</button><?php endif; ?>
      <button name="action" value="resolve" class="px-3 py-1.5 rounded-lg bg-white/10 text-gray-200">Çözüldü</button><button name="action" value="dismiss" class="px-3 py-1.5 text-gray-400">Reddet</button></form>
    <?php else: ?><p class="text-xs text-gray-500">İşleyen: <?= e($r['handled_by'] ?? '-') ?></p><?php endif; ?>
  </div>
<?php endforeach; if (!$rows) echo '<p class="p-6 text-center text-gray-500 text-sm">Kayıt yok.</p>'; ?>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
