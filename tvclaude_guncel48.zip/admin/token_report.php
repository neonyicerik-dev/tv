<?php
// NeonTV - Admin: Token / Premium raporu + şüpheli kullanım tespiti
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/tokens.php';
requireAdmin(['moderator', 'superadmin']);
$db = new Supabase(); $c = tkCfg();
$days = 14; $tz = new DateTimeZone('Europe/Istanbul');
$since = (new DateTime('today', $tz))->modify('-' . ($days - 1) . ' days');
$led = $db->select('token_ledger', 'created_at=gte.' . urlencode($since->format('c')) . '&select=delta,reason,created_at&order=created_at.asc&limit=30000', true)['data'] ?? [];
$led = is_array($led) ? $led : [];
$by = []; for ($i = 0; $i < $days; $i++) { $d = (clone $since)->modify("+$i days")->format('Y-m-d'); $by[$d] = ['earn' => 0, 'spend' => 0, 'sales' => 0]; }
$reasons = [];
foreach ($led as $r) {
    $d = (new DateTime($r['created_at']))->setTimezone($tz)->format('Y-m-d'); if (!isset($by[$d])) continue;
    $dl = (int)$r['delta'];
    if ($dl > 0) $by[$d]['earn'] += $dl; elseif ($dl < 0) { $by[$d]['spend'] += -$dl; if (in_array($r['reason'], ['premium_buy', 'premium_gift', 'auto_renew'], true)) $by[$d]['sales']++; }
    $reasons[$r['reason']] = ($reasons[$r['reason']] ?? 0) + $dl;
}
$max = max(1, ...array_values(array_map(fn($x) => max($x["earn"], $x["spend"]), $by)));
$totBal = 0; $wal = $db->select('token_wallets', 'select=balance&limit=20000', true)['data'] ?? []; foreach ((array)$wal as $w) $totBal += (int)$w['balance'];

// Şüpheli: son 7 gün
$s7 = (new DateTime('today', $tz))->modify('-6 days')->format('Y-m-d');
$ses = $db->select('ad_watch_sessions', 'day=gte.' . $s7 . '&claimed_at=not.is.null&select=user_id,ip_hash,day&limit=30000', true)['data'] ?? [];
$ipUsers = []; $userDays = [];
foreach ((array)$ses as $r) {
    if (!empty($r['ip_hash'])) $ipUsers[$r['ip_hash']][$r['user_id']] = ($ipUsers[$r['ip_hash']][$r['user_id']] ?? 0) + 1;
    $userDays[$r['user_id']][$r['day']] = ($userDays[$r['user_id']][$r['day']] ?? 0) + 1;
}
$ipSus = array_filter($ipUsers, fn($u) => count($u) >= 3);
$heavy = []; foreach ($userDays as $u => $dd) { $full = count(array_filter($dd, fn($n) => $n >= $c['daily_limit'])); if ($full >= 5) $heavy[$u] = $full; }
$ids = array_unique(array_merge(array_keys($heavy), ...array_map('array_keys', array_values($ipSus) ?: [[]])));
$names = [];
if ($ids) { $ids = array_values(array_filter($ids, 'isUuid')); if ($ids) foreach ((array)($db->select('profiles', 'id=in.(' . implode(',', $ids) . ')&select=id,username', true)['data'] ?? []) as $p) $names[$p['id']] = $p['username']; }
$nm = fn($id) => $names[$id] ?? substr($id, 0, 8);

$adminTitle = 'Token Raporu'; $adminSub = 'Son ' . $days . ' gün token hareketleri ve şüpheli kullanım';
include __DIR__ . '/_top.php';
$R = ['ad_reward' => 'Reklam ödülü', 'daily' => 'Günlük giriş', 'quest' => 'Görev', 'premium_buy' => 'Premium alımı', 'premium_gift' => 'Hediye', 'auto_renew' => 'Otomatik yenileme', 'refund' => 'İade'];
?>
<div class="space-y-6 max-w-4xl">
<div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
  <?php foreach ([['Dolaşımdaki token', $totBal, '#fbbf24'], ['Kazanılan (' . $days . ' gün)', array_sum(array_column($by, 'earn')), '#4ade80'], ['Harcanan (' . $days . ' gün)', array_sum(array_column($by, 'spend')), '#f87171'], ['Premium satışı', array_sum(array_column($by, 'sales')), '#00f5ff']] as [$l, $v, $col]): ?>
  <div class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,.08)"><div class="text-2xl font-black" style="color:<?= $col ?>"><?= number_format((int)$v, 0, ',', '.') ?></div><div class="text-xs text-gray-500"><?= e($l) ?></div></div>
  <?php endforeach; ?>
</div>
<div class="rounded-2xl p-5" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
  <h2 class="font-bold text-white mb-3">Günlük hareket <span class="text-xs font-normal text-gray-500">(yeşil kazanılan · kırmızı harcanan)</span></h2>
  <div class="flex items-end gap-1.5" style="height:140px">
  <?php foreach ($by as $d => $x): ?>
    <div class="flex-1 flex flex-col justify-end items-center gap-0.5 h-full" title="<?= e($d) ?>: +<?= $x['earn'] ?> / -<?= $x['spend'] ?>">
      <div style="width:100%;height:<?= round($x['earn'] / $max * 45) ?>%;background:#4ade80;border-radius:3px 3px 0 0;min-height:<?= $x['earn'] ? 2 : 0 ?>px"></div>
      <div style="width:100%;height:<?= round($x['spend'] / $max * 45) ?>%;background:#f87171;border-radius:0 0 3px 3px;min-height:<?= $x['spend'] ? 2 : 0 ?>px"></div>
      <span class="text-[9px] text-gray-500"><?= e(substr($d, 8)) ?></span>
    </div>
  <?php endforeach; ?>
  </div>
</div>
<div class="rounded-2xl p-5" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
  <h2 class="font-bold text-white mb-2">Nedene göre net</h2>
  <div class="text-sm divide-y divide-white/5"><?php foreach ($reasons as $k => $v): ?><div class="flex justify-between py-1.5"><span class="text-gray-300"><?= e($R[$k] ?? $k) ?></span><b style="color:<?= $v >= 0 ? '#4ade80' : '#f87171' ?>"><?= $v > 0 ? '+' : '' ?><?= (int)$v ?></b></div><?php endforeach; if (!$reasons) echo '<p class="text-gray-500 py-2">Veri yok.</p>'; ?></div>
</div>
<div class="rounded-2xl p-5" style="background:#13131f;border:1px solid rgba(255,100,100,.25)">
  <h2 class="font-bold text-white mb-1"><i class="fa-solid fa-triangle-exclamation text-red-400 mr-2"></i>Şüpheli kullanım (son 7 gün)</h2>
  <p class="text-xs text-gray-500 mb-3">Aynı ağdan 3+ hesabın reklam ödülü alması veya günlük limiti 5+ gün doldurması. Bu kesin ihlal değildir; incelemek için.</p>
  <h3 class="text-sm text-gray-300 mb-1">Aynı ağdan çok hesap</h3>
  <?php foreach ($ipSus as $h => $us): ?><div class="text-sm py-1.5 border-t border-white/5"><span class="text-gray-500 text-xs"><?= e(substr($h, 0, 8)) ?></span> · <?= count($us) ?> hesap: <?php foreach ($us as $u => $n): ?><a class="text-cyan-400 mr-2" href="<?= APP_URL ?>/admin/users.php?q=<?= urlencode($nm($u)) ?>"><?= e($nm($u)) ?> (<?= (int)$n ?>)</a><?php endforeach; ?></div><?php endforeach; if (!$ipSus) echo '<p class="text-xs text-green-400">Şüpheli ağ yok.</p>'; ?>
  <h3 class="text-sm text-gray-300 mt-4 mb-1">Limiti sürekli dolduranlar</h3>
  <?php foreach ($heavy as $u => $n): ?><div class="text-sm py-1.5 border-t border-white/5"><a class="text-cyan-400" href="<?= APP_URL ?>/admin/users.php?q=<?= urlencode($nm($u)) ?>"><?= e($nm($u)) ?></a> · <?= (int)$n ?>/7 gün limit doldu</div><?php endforeach; if (!$heavy) echo '<p class="text-xs text-green-400">Yok.</p>'; ?>
  <?php if (!$ses): ?><p class="text-xs text-gray-500 mt-3">Henüz reklam izleme verisi yok (ağ bilgisi SQL 11 sonrası kaydedilir).</p><?php endif; ?>
</div>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
