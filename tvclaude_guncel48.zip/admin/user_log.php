<?php
// NeonTV - Admin: kullanıcı işlem günlüğü (kim ne yaptı: izledi, token kazandı, yorum yaptı…)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/userlog.php';
requireAdmin(['superadmin']);
$db = new Supabase(); $tz = new DateTimeZone('Europe/Istanbul');

$q    = trim((string)($_GET['q'] ?? ''));
$type = (string)($_GET['type'] ?? '');
$days = max(1, min(90, (int)($_GET['days'] ?? 7)));
$uidF = trim((string)($_GET['uid'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1)); $per = 50;
$txt  = trim((string)($_GET['t'] ?? ''));

// Kullanıcı adı → id
$uidList = [];
if ($uidF !== '' && isUuid($uidF)) $uidList = [$uidF];
elseif ($q !== '') {
    $r = $db->select('profiles', 'username=ilike.' . rawurlencode('*' . str_replace(['*', ',', '(', ')'], '', $q) . '*') . '&select=id&limit=50', true)['data'] ?? [];
    $uidList = array_values(array_filter(array_column(is_array($r) ? $r : [], 'id'), 'isUuid'));
}
$f = 'created_at=gte.' . rawurlencode(gmdate('Y-m-d\TH:i:s\Z', time() - $days * 86400));
if (($q !== '' || $uidF !== '') && !$uidList) $f .= '&user_id=eq.00000000-0000-0000-0000-000000000000';
elseif ($uidList) $f .= '&user_id=in.(' . implode(',', $uidList) . ')';
if ($type !== '' && isset(NV_LOG_TYPES[$type])) $f .= '&type=eq.' . $type;
if ($txt !== '') $f .= '&text=ilike.' . rawurlencode('*' . str_replace(['*', ',', '(', ')'], '', $txt) . '*');

// CSV
if (($_GET['csv'] ?? '') === '1') {
    $rows = $db->select('user_events', $f . '&order=created_at.desc&limit=5000&select=created_at,user_id,type,text', true)['data'] ?? [];
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="kullanici_log_' . date('Ymd_His') . '.csv"');
    $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF"); fputcsv($o, ['Tarih', 'Kullanıcı ID', 'Tür', 'İşlem'], ';');
    foreach ($rows as $r) fputcsv($o, [(new DateTime($r['created_at']))->setTimezone($tz)->format('d.m.Y H:i:s'), $r['user_id'], $r['type'], $r['text']], ';');
    exit;
}

$rows = $db->select('user_events', $f . '&order=created_at.desc&limit=' . ($per + 1) . '&offset=' . (($page - 1) * $per) . '&select=id,created_at,user_id,type,text', true)['data'] ?? [];
$rows = is_array($rows) ? $rows : []; $more = count($rows) > $per; $rows = array_slice($rows, 0, $per);
$ids = array_values(array_unique(array_filter(array_column($rows, 'user_id'), 'isUuid')));
$names = [];
if ($ids) { foreach (($db->select('profiles', 'id=in.(' . implode(',', $ids) . ')&select=id,username', true)['data'] ?? []) as $p) $names[$p['id']] = $p['username']; }
// Son 24 saat özet
$sum = [];
foreach (NV_LOG_TYPES as $k => $_) $sum[$k] = $db->count('user_events', 'type=eq.' . $k . '&created_at=gte.' . rawurlencode(gmdate('Y-m-d\TH:i:s\Z', time() - 86400)), true);

$qs = function (array $o = []) use ($q, $type, $days, $uidF, $txt) { return '?' . http_build_query(array_filter(array_merge(['q' => $q, 'type' => $type, 'days' => $days, 'uid' => $uidF, 't' => $txt], $o), fn($v) => $v !== '' && $v !== null)); };
$adminTitle = 'Kullanıcı Logları'; $adminSub = 'Kullanıcıların işlemleri · ' . NV_LOG_RETENTION_DAYS . ' gün saklanır, ham IP tutulmaz';
include __DIR__ . '/_top.php';
?>
<div class="flex flex-wrap gap-2 mb-4">
<?php foreach (NV_LOG_TYPES as $k => $d): ?>
  <a href="<?= e($qs(['type' => $k, 'page' => 1])) ?>" class="px-3 py-1.5 rounded-full text-xs font-semibold border <?= $type === $k ? 'text-black' : 'text-gray-300' ?>" style="<?= $type === $k ? 'background:' . $d[2] . ';border-color:' . $d[2] : 'background:#13131f;border-color:rgba(255,255,255,.1)' ?>"><i class="fa-solid <?= e($d[1]) ?> mr-1" style="<?= $type === $k ? '' : 'color:' . $d[2] ?>"></i><?= e($d[0]) ?> <span class="opacity-70">· 24s: <?= (int)$sum[$k] ?></span></a>
<?php endforeach; ?>
<?php if ($type !== ''): ?><a href="<?= e($qs(['type' => ''])) ?>" class="px-3 py-1.5 rounded-full text-xs text-pink-300 border border-pink-500/30">Filtreyi kaldır ✕</a><?php endif; ?>
</div>
<form method="get" class="flex flex-wrap gap-2 mb-4 items-end">
  <input type="hidden" name="type" value="<?= e($type) ?>">
  <div><label class="block text-[11px] text-gray-500 mb-1">Kullanıcı adı</label><input name="q" value="<?= e($q) ?>" placeholder="ör. ahmet" class="px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-sm text-white w-44"></div>
  <div><label class="block text-[11px] text-gray-500 mb-1">İşlemde ara</label><input name="t" value="<?= e($txt) ?>" placeholder="video adı, token…" class="px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-sm text-white w-52"></div>
  <div><label class="block text-[11px] text-gray-500 mb-1">Süre</label><select name="days" class="px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-sm text-white"><?php foreach ([1 => 'Son 24 saat', 7 => 'Son 7 gün', 30 => 'Son 30 gün', 90 => 'Son 90 gün'] as $d => $l): ?><option value="<?= $d ?>" <?= $days === $d ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></div>
  <button class="px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#00f5ff">Filtrele</button>
  <a href="<?= e($qs(['csv' => '1'])) ?>" class="px-4 py-2 rounded-lg text-sm text-gray-300 border border-white/10"><i class="fa-solid fa-file-csv mr-1"></i>CSV indir</a>
</form>
<div class="rounded-2xl overflow-x-auto" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">
<table class="w-full text-sm"><thead><tr class="text-left text-gray-500 text-xs"><th class="p-3 whitespace-nowrap">Zaman</th><th class="p-3">Kullanıcı</th><th class="p-3">Tür</th><th class="p-3">İşlem</th></tr></thead><tbody>
<?php if (!$rows): ?><tr><td colspan="4" class="p-6 text-center text-gray-500">Kayıt yok. (SQL 13 çalıştırıldı mı?)</td></tr><?php endif; ?>
<?php foreach ($rows as $r): $d = NV_LOG_TYPES[$r['type']] ?? [$r['type'], 'fa-circle', '#888']; $nm = $names[$r['user_id']] ?? substr($r['user_id'], 0, 8) . '…'; ?>
<tr class="border-t border-white/5 align-top">
  <td class="p-3 text-gray-400 whitespace-nowrap text-xs"><?= e((new DateTime($r['created_at']))->setTimezone($tz)->format('d.m H:i:s')) ?></td>
  <td class="p-3 whitespace-nowrap"><a class="text-cyan-300 hover:underline" href="<?= e($qs(['uid' => $r['user_id'], 'q' => '', 'page' => 1])) ?>"><?= e($nm) ?></a></td>
  <td class="p-3 whitespace-nowrap"><span class="text-xs font-semibold" style="color:<?= e($d[2]) ?>"><i class="fa-solid <?= e($d[1]) ?> mr-1"></i><?= e($d[0]) ?></span></td>
  <td class="p-3 text-gray-200 break-words"><?= e($r['text']) ?></td>
</tr>
<?php endforeach; ?>
</tbody></table></div>
<div class="flex gap-2 mt-4">
  <?php if ($page > 1): ?><a class="px-4 py-2 rounded-lg text-sm border border-white/10 text-gray-300" href="<?= e($qs(['page' => $page - 1])) ?>">← Yeni</a><?php endif; ?>
  <?php if ($more): ?><a class="px-4 py-2 rounded-lg text-sm border border-white/10 text-gray-300" href="<?= e($qs(['page' => $page + 1])) ?>">Eski →</a><?php endif; ?>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
