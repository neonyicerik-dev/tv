<?php
// POST {source:"gate"|"register"} -> 18 yaş onayını kaydeder (IP/UA yalnızca tek yönlü özet olarak)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/legal.php';
error_reporting(0); ini_set('display_errors', 0);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);
$in = inputJson() ?? []; $src = ($in['source'] ?? '') === 'register' ? 'register' : 'gate';
$ip = function_exists('getClientIp') ? getClientIp() : ($_SERVER['REMOTE_ADDR'] ?? '');
$ipHash = Store::hashIp($ip); $uaHash = Store::hashIp((string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
$rl = sys_get_temp_dir() . '/nv_age_' . substr($ipHash, 0, 16);   // aynı IP'den dakikada en fazla 1 kayıt
if (is_file($rl) && time() - (int)@filemtime($rl) < 60) jsonSuccess([], 'Tamam');
@touch($rl);
(new Supabase())->insert('age_confirmations', ['ip_hash' => $ipHash, 'ua_hash' => $uaHash, 'source' => $src, 'version' => LEGAL_VERSION], true);
jsonSuccess([], 'Tamam');
