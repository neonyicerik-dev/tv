<?php
// GET ?id=<video uuid> -> {vtt: "..."} yayında olan videonun Türkçe altyazısı (kart önizlemesi için, 5 dk önbellek)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
error_reporting(0); ini_set('display_errors', 0);
$id = trim($_GET['id'] ?? ''); requireUuid($id, 'Video ID');
$vtt = Store::remember('cardsub_' . $id, 300, function () use ($id) {
    $db = new Supabase();
    if (!$db->first('videos', 'id=eq.' . $id . '&status=eq.published&select=id', true)) return '';
    $s = $db->first('subtitles', 'video_id=eq.' . $id . '&language=eq.tr&select=content', true);
    return mb_substr((string)($s['content'] ?? ''), 0, 200000);
});
header('Cache-Control: public, max-age=300');
jsonSuccess(['vtt' => $vtt]);
