<?php
// GET -> son giriş kayıtları (cihaz etiketi, ülke, tarih; bu cihaz işaretli)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/store.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id'];
$cur = Store::hashIp((string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
$r = $db->select('login_events', 'user_id=eq.' . $uid . '&order=created_at.desc&limit=40&select=ua_hash,ua_label,country_code,created_at', true)['data'] ?? [];
$seen = []; $out = [];
foreach (is_array($r) ? $r : [] as $e) {   // aynı cihaz (ua_hash) için tek satır: en yeni giriş
    if (isset($seen[$e['ua_hash']])) continue; $seen[$e['ua_hash']] = 1;
    $out[] = ['label' => $e['ua_label'] ?: 'Cihaz', 'country' => $e['country_code'] ?? '', 'at' => $e['created_at'], 'current' => $e['ua_hash'] === $cur];
    if (count($out) >= 10) break;
}
jsonSuccess(['devices' => $out]);
