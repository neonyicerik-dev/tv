<?php
// GET -> {daily, quests, badges}; POST {action:daily} | {action:quest, id}
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/engage.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db); $uid = $user['id'];
$msg = 'Tamam';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    denyIfBanned($db, $uid);
    $in = inputJson() ?? []; $act = (string)($in['action'] ?? '');
    if ($act === 'daily') { $d = engDaily($db, $uid, true); $msg = $d['message'] ?: 'Bugünkü ödülünü zaten aldın.'; }
    elseif ($act === 'quest') { [$ok, $m] = engClaimQuest($db, $uid, (string)($in['id'] ?? '')); if (!$ok) jsonError($m); $msg = $m; }
    else jsonError('Geçersiz işlem');
}
$bal = tkWallet($db, $uid)['balance'];
jsonSuccess(['daily' => engDaily($db, $uid, false), 'quests' => engQuests($db, $uid), 'balance' => $bal,
    'badges' => array_values(engBadges($db, $uid, $_SERVER['REQUEST_METHOD'] === 'GET'))], $msg);
