<?php
// Takip ettiğin kişilerin akışı. GET ?tab=people|feed&page=1
//  people -> takip ettiklerin (kullanıcı adı, avatar)
//  feed   -> takip ettiklerinin son yorumları + profil vitrinindeki videolar
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id'];
$fl = $db->select('user_follows', 'follower_id=eq.' . $uid . '&select=following_id&order=created_at.desc&limit=500', true)['data'] ?? [];
$ids = array_values(array_filter(array_column(is_array($fl) ? $fl : [], 'following_id'), 'isUuid'));
if (!$ids) jsonSuccess(['total' => 0, 'people' => [], 'comments' => [], 'showcase' => [], 'has_more' => false]);
$in = implode(',', $ids);
$tab = ($_GET['tab'] ?? 'feed') === 'people' ? 'people' : 'feed';
if ($tab === 'people') {
    $p = $db->select('profiles', 'id=in.(' . $in . ')&select=id,username,avatar_url&order=username.asc&limit=500', true)['data'] ?? [];
    jsonSuccess(['total' => count($ids), 'people' => is_array($p) ? $p : [], 'comments' => [], 'showcase' => [], 'has_more' => false]);
}
$per = 20; $page = max(1, (int)($_GET['page'] ?? 1));
$c = $db->select('comments', 'user_id=in.(' . $in . ')&order=created_at.desc&limit=' . ($per + 1) . '&offset=' . (($page - 1) * $per)
    . '&select=id,content,created_at,user_id,video_id,profiles(username,avatar_url),videos(id,title,thumbnail_url,status)', true)['data'] ?? [];
$c = is_array($c) ? $c : []; $more = count($c) > $per; $c = array_slice($c, 0, $per);
$c = array_values(array_filter($c, fn($r) => ($r['videos']['status'] ?? '') === 'published'));
$sc = [];
if ($page === 1) {
    $s = $db->select('profile_showcase', 'user_id=in.(' . $in . ')&select=user_id,position,profiles(username),videos(id,title,thumbnail_url,status)&limit=60', true)['data'] ?? [];
    foreach ((is_array($s) ? $s : []) as $r) { if (($r['videos']['status'] ?? '') === 'published') $sc[] = ['user' => $r['profiles']['username'] ?? '', 'user_id' => $r['user_id'], 'video' => $r['videos']]; }
    $sc = array_slice($sc, 0, 24);
}
jsonSuccess(['total' => count($ids), 'people' => [], 'comments' => $c, 'showcase' => $sc, 'has_more' => $more]);
