<?php
// Birlikte izleme odası sohbeti
// GET  ?code=ABC123&after=ID  -> yeni mesajlar (en fazla 50)
// POST {code, text}           -> mesaj gönder (en fazla 300 karakter, 1,5 sn aralık)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id']; $m = $_SERVER['REQUEST_METHOD'];
$codeOk = fn($c) => is_string($c) && preg_match('/^[A-Z2-9]{6}$/', $c);
$code = strtoupper(trim((string)($m === 'GET' ? ($_GET['code'] ?? '') : (inputJson()['code'] ?? ''))));
if (!$codeOk($code)) jsonError('Geçersiz oda kodu');
$room = $db->first('watch_rooms', 'code=eq.' . $code . '&select=code,host_id', true);
if (!$room) jsonError('Oda bulunamadı', 404);
// Yalnızca odaya katılmış (members) veya sahibi
if ($room['host_id'] !== $uid && !$db->first('watch_room_members', 'code=eq.' . $code . '&user_id=eq.' . $uid . '&select=user_id', true)) jsonError('Önce odaya katılmalısın', 403);

if ($m === 'GET') {
    $after = max(0, (int)($_GET['after'] ?? 0));
    $q = 'code=eq.' . $code . '&id=gt.' . $after . '&order=id.asc&limit=50&select=id,user_id,username,body,created_at';
    // İlk yüklemede son 30 mesaj
    if ($after === 0) $q = 'code=eq.' . $code . '&order=id.desc&limit=30&select=id,user_id,username,body,created_at';
    $r = $db->select('watch_room_messages', $q, true)['data'] ?? []; $r = is_array($r) ? $r : [];
    if ($after === 0) $r = array_reverse($r);
    foreach ($r as &$x) $x['mine'] = $x['user_id'] === $uid; unset($x);
    jsonSuccess(['items' => array_map(fn($x) => ['id' => (int)$x['id'], 'u' => $x['username'], 'b' => $x['body'], 'mine' => $x['mine'], 'at' => $x['created_at']], $r)]);
}
if ($m !== 'POST') jsonError('Geçersiz metod', 405);
denyIfBanned($db, $uid);
$in = inputJson() ?? [];
$text = trim(preg_replace('/\s+/u', ' ', strip_tags((string)($in['text'] ?? ''))));
if ($text === '') jsonError('Mesaj boş');
$text = mb_substr($text, 0, 300);
$rl = sys_get_temp_dir() . '/nv_pc_' . md5($uid);
if (is_file($rl) && microtime(true) - (float)@file_get_contents($rl) < 1.5) jsonError('Biraz yavaş :)', 429);
@file_put_contents($rl, (string)microtime(true));
$p = $db->first('profiles', 'id=eq.' . $uid . '&select=username', true);
$name = $p['username'] ?? 'Kullanıcı';
$r = $db->insert('watch_room_messages', ['code' => $code, 'user_id' => $uid, 'username' => $name, 'body' => $text], true);
if (($r['status'] ?? 500) >= 400) jsonError('Gönderilemedi (SQL 14 çalıştı mı?)', 500);
// Oda başına en fazla 500 mesaj: eskileri sil (%5 olasılıkla)
if (mt_rand(1, 20) === 1) {
    $old = $db->select('watch_room_messages', 'code=eq.' . $code . '&order=id.desc&offset=500&limit=1&select=id', true)['data'] ?? [];
    if (!empty($old[0]['id'])) $db->delete('watch_room_messages', 'code=eq.' . $code . '&id=lte.' . (int)$old[0]['id'], true);
}
jsonSuccess([]);
