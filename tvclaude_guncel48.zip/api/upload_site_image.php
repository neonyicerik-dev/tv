<?php
// ============================================================
// NeonTV - Admin: site arka planı / logo süsü resmi yükleme
// POST multipart: file=<resim>  ?type=bg|logo   (yalnızca admin)
// bg  : en çok 1920px genişlik, JPEG -> CDN (yoksa assets/site/)
// logo: en çok 256px, şeffaflık korunur (PNG) -> assets/site/
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/cdn_ingest.php';
error_reporting(0); ini_set('display_errors', 0);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);
if (!isAdminLoggedIn()) jsonError('Yetkisiz erişim', 401);
$type = (($_GET['type'] ?? '') === 'logo') ? 'logo' : 'bg';
if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($_FILES['file']['tmp_name'])) jsonError('Dosya alınamadı', 400);
if ($_FILES['file']['size'] > 8 * 1024 * 1024) jsonError('Dosya 8 MB\'dan küçük olmalı', 413);

$tmp = $_FILES['file']['tmp_name'];
$info = @getimagesize($tmp);
if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, IMAGETYPE_WEBP], true) || $info[0] > 6000 || $info[1] > 6000) jsonError('Geçerli bir resim (JPG, PNG, GIF, WEBP) seçin', 415);
$src = @imagecreatefromstring((string)file_get_contents($tmp));
if (!$src) jsonError('Resim okunamadı', 415);
$w = imagesx($src); $h = imagesy($src);
$max = $type === 'bg' ? 1920 : 256;
$scale = min(1, $max / max($w, $h));
$nw = max(1, (int)round($w * $scale)); $nh = max(1, (int)round($h * $scale));
$dst = imagecreatetruecolor($nw, $nh);
if ($type === 'logo') { imagealphablending($dst, false); imagesavealpha($dst, true); imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127)); }
else imagefill($dst, 0, 0, imagecolorallocate($dst, 7, 7, 17));
imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
$out = tempnam(sys_get_temp_dir(), 'nvs');
$ok = $type === 'logo' ? imagepng($dst, $out, 6) : imagejpeg($dst, $out, 82);
imagedestroy($src); imagedestroy($dst);
if (!$ok) { @unlink($out); jsonError('Resim işlenemedi', 500); }

$url = null;
if ($type === 'bg') $url = nvCdnIngest($out, 'banner', 'sitebg_' . bin2hex(random_bytes(4)));
if (!$url) {
    $dir = __DIR__ . '/../assets/site';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) { @unlink($out); jsonError('Klasör oluşturulamadı (assets/site yazma izni?)', 500); }
    $name = $type . '_' . bin2hex(random_bytes(8)) . ($type === 'logo' ? '.png' : '.jpg');
    if (!@copy($out, $dir . '/' . $name)) { @unlink($out); jsonError('Resim kaydedilemedi (klasör yazma izni?)', 500); }
    @chmod($dir . '/' . $name, 0644);
    $url = APP_URL . '/assets/site/' . $name;
}
@unlink($out);
jsonSuccess(['url' => $url], 'Yüklendi');
