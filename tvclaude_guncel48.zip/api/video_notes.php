<?php
// Zaman damgalı video notları.
// GET ?video_id=..  -> notlar (herkese açık)   POST {video_id, at, body}   DELETE {id} (kendi notu)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $m = $_SERVER['REQUEST_METHOD'];

if ($m === 'GET') {
    $vid = trim($_GET['video_id'] ?? ''); requireUuid($vid, 'Video ID');
    $uid = null; $tok = getBearerToken(); if ($tok) { $u = $db->verifyToken($tok); if ($u && !empty($u['id'])) $uid = $u['id']; }
    $rows = $db->select('video_notes', 'video_id=eq.' . $vid . '&order=at_second.asc,created_at.asc&limit=200&select=id,user_id,at_second,body', true)['data'] ?? [];
    $rows = is_array($rows) ? $rows : [];
    $ids = array_values(array_unique(array_filter(array_column($rows, 'user_id'), 'isUuid')));
    $names = [];
    if ($ids) foreach ((array)($db->select('profiles', 'id=in.(' . implode(',', $ids) . ')&select=id,username', true)['data'] ?? []) as $p) $names[$p['id']] = $p['username'];
    jsonSuccess(['notes' => array_map(fn($r) => ['id' => $r['id'], 'at' => (int)$r['at_second'], 'body' => $r['body'], 'user' => $names[$r['user_id']] ?? 'Kullanıcı', 'mine' => $uid && $r['user_id'] === $uid], $rows)]);
}
$user = requireUserApi($db); $uid = $user['id'];
$in = inputJson() ?? [];
if ($m === 'POST') {
    denyIfBanned($db, $uid);
    $vid = trim((string)($in['video_id'] ?? '')); requireUuid($vid, 'Video ID');
    $at = max(0, min(86400, (int)($in['at'] ?? 0)));
    $body = trim(preg_replace('/\s+/u', ' ', strip_tags((string)($in['body'] ?? ''))));
    if (mb_strlen($body) < 1 || mb_strlen($body) > 200) jsonError('Not 1-200 karakter olmalı');
    if (!$db->first('videos', 'id=eq.' . $vid . '&status=eq.published&select=id', true)) jsonError('Video bulunamadı', 404);
    if ($db->count('video_notes', 'user_id=eq.' . $uid . '&video_id=eq.' . $vid, true) >= 10) jsonError('Bu videoya en fazla 10 not ekleyebilirsin.');
    if ($db->count('video_notes', 'user_id=eq.' . $uid . '&created_at=gte.' . urlencode(date('c', time() - 3600)), true) >= 20) jsonError('Saatlik not sınırına ulaştın.');
    $r = $db->insert('video_notes', ['video_id' => $vid, 'user_id' => $uid, 'at_second' => $at, 'body' => $body], true);
    if (($r['status'] ?? 500) >= 400) jsonError('Kaydedilemedi (SQL 11 çalıştı mı?)', 500);
    jsonSuccess([], 'Not eklendi');
}
if ($m === 'DELETE') {
    $id = trim((string)($in['id'] ?? '')); requireUuid($id, 'Not ID');
    $db->delete('video_notes', 'id=eq.' . $id . '&user_id=eq.' . $uid, true);
    jsonSuccess([], 'Silindi');
}
jsonError('Geçersiz metod', 405);
