<?php
// Komut satırından çalıştırılır (web'den erişilemez): Premium'u 3 gün içinde bitecek herkese uygulama içi bildirim gönderir.
// Cron örneği (her saat):  0 * * * * php /var/www/html/cron_premium_warn.php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';
require_once __DIR__ . '/includes/engage.php';
$db = new Supabase();
$until = urlencode(date('c', time() + 3 * 86400)); $now = urlencode(date('c'));
$rows = $db->select('user_premium', 'premium_until=gt.' . $now . '&premium_until=lt.' . $until . '&select=user_id&limit=2000', true)['data'] ?? [];
$n = 0; foreach ($rows as $r) if (engPremiumWarn($db, $r['user_id'])) $n++;
echo "Bildirim gönderilen: $n\n";
