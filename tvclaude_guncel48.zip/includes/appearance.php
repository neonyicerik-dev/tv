<?php
// NeonTV - Site görünümü: arka plan resmi + logo süsü (ayarlar admin/appearance.php'den)
require_once __DIR__ . '/store.php';

function nvLogoObjects(): array {
    $s = fn($inner, $vb = '0 0 24 24') => "<svg xmlns='http://www.w3.org/2000/svg' viewBox='$vb' width='100%' height='100%'>$inner</svg>";
    return [
        'tac'    => ['Taç',        $s("<path d='M3 18 L2 7 L8 12 L12 4 L16 12 L22 7 L21 18Z' fill='#ffd166' stroke='#b8860b' stroke-width='1'/><rect x='3' y='18' width='18' height='3' rx='1' fill='#f2b705'/>")],
        'yildiz' => ['Yıldız',     $s("<path d='M12 2 L14.8 8.8 L22 9.4 L16.5 14.2 L18.2 21.5 L12 17.7 L5.8 21.5 L7.5 14.2 L2 9.4 L9.2 8.8Z' fill='#ffe066' stroke='#d19a00' stroke-width='1'/>")],
        'kalp'   => ['Kalp',       $s("<path d='M12 21 C4 14 2 9 5 6 C8 3 11 5 12 7 C13 5 16 3 19 6 C22 9 20 14 12 21Z' fill='#ff4d86' stroke='#b0225a' stroke-width='1'/>")],
        'alev'   => ['Alev',       $s("<path d='M12 2 C13 7 18 9 18 15 A6 6 0 0 1 6 15 C6 12 8 11 9 9 C10 12 11 12 11 10 C11 7 11 5 12 2Z' fill='#ff7a1a' stroke='#c2410c' stroke-width='1'/><path d='M12 11 C13 14 15 14 15 17 A3 3 0 0 1 9 17 C9 15 11 14 12 11Z' fill='#ffd166'/>")],
        'simsek' => ['Şimşek',     $s("<path d='M13 2 L4 14 H11 L9 22 L20 9 H13Z' fill='#ffe94d' stroke='#c9a800' stroke-width='1'/>")],
        'ay'     => ['Ay',         $s("<path d='M17 3 A9 9 0 1 0 21 16 A7 7 0 0 1 17 3Z' fill='#fff3b0' stroke='#d8b900' stroke-width='1'/>")],
        'kulaklik'=> ['Kulaklık',  $s("<path d='M4 15 V12 A8 8 0 0 1 20 12 V15' fill='none' stroke='#9aa5b1' stroke-width='2'/><rect x='2.5' y='14' width='4' height='7' rx='1.5' fill='#ff4d86'/><rect x='17.5' y='14' width='4' height='7' rx='1.5' fill='#ff4d86'/>")],
        'sapka'  => ['Noel Şapkası',$s("<path d='M3 18 C4 8 11 3 20 5 C16 6 15 9 17 14 L21 18Z' fill='#e8242b'/><rect x='2' y='16' width='20' height='4' rx='2' fill='#fff'/><circle cx='20.5' cy='5' r='2.4' fill='#fff'/>")],
        'kedi'   => ['Kedi Kulakları',$s("<path d='M3 20 V5 L9 10 H15 L21 5 V20Z' fill='#ffb3d1' stroke='#c2185b' stroke-width='1' stroke-linejoin='round'/>")],
        'elmas'  => ['Elmas',      $s("<path d='M6 3 H18 L22 9 L12 22 L2 9Z' fill='#7df9ff' stroke='#1aa6b3' stroke-width='1'/><path d='M2 9 H22 M9 3 L7 9 L12 22 L17 9 L15 3' fill='none' stroke='#1aa6b3' stroke-width='.7'/>")],
    ];
}

function nvAppearance(): array {
    $g = fn($k, $d) => Store::getSetting($k, $d);
    $num = fn($v, $d, $a, $b) => max($a, min($b, is_numeric($v) ? (float)$v : $d));
    $safe = function ($u) { $u = trim((string)$u); return (preg_match('#^(https?://|/)[^\s"\'<>()]+$#i', $u)) ? $u : ''; };
    return [
        'bg_url'    => $safe($g('site_bg_url', '')),
        'bg_dim'    => (int)$num($g('site_bg_dim', 60), 60, 0, 95),
        'deco_type' => in_array($g('logo_deco_type', 'none'), ['none', 'image', 'object'], true) ? $g('logo_deco_type', 'none') : 'none',
        'deco_url'  => $safe($g('logo_deco_url', '')),
        'deco_obj'  => (string)$g('logo_deco_obj', 'tac'),
        'deco_size' => (int)$num($g('logo_deco_size', 28), 28, 12, 120),
        'deco_pos'  => in_array($g('logo_deco_pos', 'top'), ['top', 'left', 'right'], true) ? $g('logo_deco_pos', 'top') : 'top',
    ];
}

/** <head> içine: arka plan CSS'i */
function nvAppearanceHead(): string {
    $a = nvAppearance(); $css = '';
    if ($a['bg_url'] !== '') {
        $d = $a['bg_dim'] / 100;
        $css .= "body{background-image:linear-gradient(rgba(7,7,17,$d),rgba(7,7,17,$d)),url(\"" . $a['bg_url'] . "\")!important;background-size:cover!important;background-position:center!important;background-attachment:fixed!important;background-repeat:no-repeat!important}";
    }
    if ($a['deco_type'] !== 'none') {
        $sz = $a['deco_size'];
        $pos = ['top' => 'top:-' . round($sz * .55) . 'px;left:-' . round($sz * .15) . 'px', 'left' => 'left:-' . ($sz + 4) . 'px;top:50%;transform:translateY(-50%)', 'right' => 'right:-' . ($sz + 4) . 'px;top:50%;transform:translateY(-50%)'][$a['deco_pos']];
        $css .= "#nav-logo .nv-deco{position:absolute;width:{$sz}px;height:{$sz}px;pointer-events:none;z-index:2;$pos}#nav-logo{position:relative}#nav-logo .nv-deco img{width:100%;height:100%;object-fit:contain}";
    }
    return $css === '' ? '' : '<style id="nv-appearance">' . $css . '</style>';
}

/** Logo bağlantısının içine: süs HTML'i */
function nvLogoDeco(): string {
    $a = nvAppearance();
    if ($a['deco_type'] === 'image' && $a['deco_url'] !== '') return '<span class="nv-deco"><img src="' . htmlspecialchars($a['deco_url'], ENT_QUOTES) . '" alt=""></span>';
    if ($a['deco_type'] === 'object') { $o = nvLogoObjects(); if (isset($o[$a['deco_obj']])) return '<span class="nv-deco">' . $o[$a['deco_obj']][1] . '</span>'; }
    return '';
}
