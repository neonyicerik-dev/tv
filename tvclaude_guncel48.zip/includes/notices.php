<?php
// NeonTV - Sitenin üstündeki küçük duyuru şeridi. Kayıtlar site_settings'te 'site_notices' (liste) olarak tutulur.
// Kullanıcı kapatamaz; yalnızca admin pasifleştirir/siler (veya bitiş tarihi geçer).
require_once __DIR__ . '/store.php';

const NOTICE_COLORS = ['cyan' => ['#00f5ff', 'rgba(0,245,255,.12)'], 'purple' => ['#c084fc', 'rgba(192,132,252,.14)'], 'red' => ['#fb7185', 'rgba(251,113,133,.14)'], 'green' => ['#4ade80', 'rgba(74,222,128,.12)'], 'yellow' => ['#fbbf24', 'rgba(251,191,36,.14)']];

function nvNoticesAll(): array {
    $v = Store::getSetting('site_notices', []);
    return is_array($v) ? array_values(array_filter($v, 'is_array')) : [];
}
function nvNoticesActive(): array {
    $now = time(); $out = [];
    foreach (nvNoticesAll() as $n) {
        if (empty($n['active']) || trim((string)($n['text'] ?? '')) === '') continue;
        if (!empty($n['starts']) && ($t = strtotime($n['starts'])) && $t > $now) continue;
        if (!empty($n['ends']) && ($t = strtotime($n['ends'])) && $t < $now) continue;
        $out[] = $n;
    }
    return $out;
}
/** Tüm sayfaların en üstünde gösterilen şerit HTML'i */
function nvNoticeBar(): string {
    $list = nvNoticesActive(); if (!$list) return '';
    $h = '<div id="nv-notices" role="status" style="position:relative;z-index:60;font-size:12px;line-height:1.2">';
    foreach ($list as $i => $n) {
        [$fg, $bg] = NOTICE_COLORS[$n['color'] ?? 'cyan'] ?? NOTICE_COLORS['cyan'];
        $txt = htmlspecialchars((string)$n['text'], ENT_QUOTES);
        $link = (string)($n['link'] ?? ''); $ok = preg_match('#^(https?://|/)[^\s"\'<>]+$#i', $link);
        $inner = $ok ? '<a href="' . htmlspecialchars($link, ENT_QUOTES) . '" style="color:inherit;text-decoration:underline">' . $txt . '</a>' : $txt;
        $h .= '<div class="nv-notice" ' . ($i ? 'style="display:none;' : 'style="') . 'padding:5px 12px;text-align:center;background:' . $bg . ';color:' . $fg . ';border-bottom:1px solid ' . $fg . '33;font-weight:600">' . $inner . '</div>';
    }
    $h .= '</div>';
    if (count($list) > 1) $h .= '<script>(function(){var a=document.querySelectorAll("#nv-notices .nv-notice"),i=0;setInterval(function(){a[i].style.display="none";i=(i+1)%a.length;a[i].style.display="block";},6000);})();</script>';
    return $h;
}
