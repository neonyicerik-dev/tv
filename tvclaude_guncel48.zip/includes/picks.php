<?php
// NeonTV - Haftanın seçkisi (admin elle seçer; boşsa son 7 günün en çok izlenenleri gösterilir)
// site_settings.weekly_picks = {title, note, ids:[uuid...], updated_at}
require_once __DIR__ . '/store.php';
require_once __DIR__ . '/supabase.php';

function nvPicksCfg(): array {
    $v = Store::getSetting('weekly_picks', []);
    if (is_string($v)) $v = json_decode($v, true);
    $v = is_array($v) ? $v : [];
    $ids = array_values(array_filter(array_map('strval', (array)($v['ids'] ?? [])), 'isUuid'));
    return ['title' => trim((string)($v['title'] ?? '')) ?: 'Haftanın Seçkisi', 'note' => trim((string)($v['note'] ?? '')),
        'ids' => array_slice($ids, 0, 12), 'updated_at' => (string)($v['updated_at'] ?? '')];
}
/** Seçki videoları (sıra korunur). Yoksa son 7 gün en çok izlenenler. [videos, isManual] */
function nvPicksVideos(int $limit = 8): array {
    return Store::remember('weekly_picks_v', 120, function () use ($limit) {
        $c = nvPicksCfg(); $db = new Supabase(); $sel = 'id,title,thumbnail_url,video_url,duration,views,likes_count,created_at';
        if ($c['ids']) {
            $r = $db->select('videos', 'id=in.(' . implode(',', $c['ids']) . ')&status=eq.published&select=' . $sel, false)['data'] ?? [];
            $by = []; foreach ((is_array($r) ? $r : []) as $v) $by[$v['id']] = $v;
            $out = []; foreach ($c['ids'] as $id) if (isset($by[$id])) $out[] = $by[$id];
            if ($out) return [array_slice($out, 0, $limit), true];
        }
        $since = urlencode(gmdate('Y-m-d\TH:i:s\Z', time() - 7 * 86400));
        $r = $db->select('videos', 'status=eq.published&created_at=gte.' . $since . '&order=views.desc&limit=' . $limit . '&select=' . $sel, false)['data'] ?? [];
        if (!is_array($r) || count($r) < 3) $r = $db->select('videos', 'status=eq.published&order=views.desc&limit=' . $limit . '&select=' . $sel, false)['data'] ?? [];
        return [is_array($r) ? $r : [], false];
    });
}
