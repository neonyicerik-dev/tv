<?php
// Kısa cihaz etiketi: "Chrome · Windows" (ham UA saklanmaz)
function nvUaLabel(string $ua): string {
    $b = 'Tarayıcı'; $o = 'Bilinmeyen cihaz';
    foreach (['Edg/' => 'Edge', 'OPR/' => 'Opera', 'Firefox/' => 'Firefox', 'SamsungBrowser' => 'Samsung Internet', 'Chrome/' => 'Chrome', 'Safari/' => 'Safari'] as $k => $n) if (stripos($ua, $k) !== false) { $b = $n; break; }
    foreach (['Windows' => 'Windows', 'Android' => 'Android', 'iPhone' => 'iPhone', 'iPad' => 'iPad', 'Mac OS' => 'macOS', 'Linux' => 'Linux'] as $k => $n) if (stripos($ua, $k) !== false) { $o = $n; break; }
    return $b . ' · ' . $o;
}
