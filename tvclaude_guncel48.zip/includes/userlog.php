<?php
// ============================================================
// NeonTV - Kullanıcı işlem günlüğü (admin → Kullanıcı Logları)
// nvLog($db, $uid, 'watch', 'Videoyu izledi: X', ['video_id'=>..])
// Hata verse de asıl işlemi ASLA bozmaz. Ham IP tutulmaz (yalnızca özet).
// ============================================================
require_once __DIR__ . '/ip_log.php';

const NV_LOG_TYPES = [
    'watch'   => ['İzleme',   'fa-play',          '#00f5ff'],
    'token'   => ['Token',    'fa-coins',         '#fbbf24'],
    'premium' => ['Premium',  'fa-crown',         '#f59e0b'],
    'login'   => ['Giriş',    'fa-right-to-bracket', '#34d399'],
    'comment' => ['Yorum',    'fa-comment',       '#60a5fa'],
    'like'    => ['Beğeni',   'fa-heart',         '#f472b6'],
    'social'  => ['Takip',    'fa-user-group',    '#a78bfa'],
    'library' => ['Kütüphane','fa-bookmark',      '#2dd4bf'],
    'report'  => ['Şikayet',  'fa-flag',          '#f87171'],
    'account' => ['Hesap',    'fa-user-gear',     '#94a3b8'],
    'party'   => ['Oda',      'fa-users-viewfinder','#fb923c'],
];
const NV_LOG_RETENTION_DAYS = 90;

function nvLog($db, string $uid, string $type, string $text, array $meta = []): void {
    try {
        if (!$uid || !function_exists('isUuid') || !isUuid($uid)) return;
        $row = ['user_id' => $uid, 'type' => $type, 'text' => mb_substr($text, 0, 300), 'meta' => (object)$meta];
        try { $row['ip_hash'] = hashIp(getClientIp()); } catch (\Throwable $e) {}
        $db->insert('user_events', $row, true);
        // %1 olasılıkla eski kayıtları temizle (KVKK: sınırlı saklama)
        if (mt_rand(1, 100) === 1) {
            $db->delete('user_events', 'created_at=lt.' . gmdate('Y-m-d\TH:i:s\Z', time() - NV_LOG_RETENTION_DAYS * 86400), true);
        }
    } catch (\Throwable $e) {}
}

/** Video başlığını kısa çekip log metnine eklemek için. */
function nvVideoTitle($db, string $vid): string {
    try { $v = $db->first('videos', 'id=eq.' . $vid . '&select=title', true); return (string)($v['title'] ?? ''); } catch (\Throwable $e) { return ''; }
}

const NV_TOKEN_REASONS = [
    'daily' => 'günlük giriş ödülü', 'quest' => 'görev ödülü', 'ad' => 'reklam izleme', 'premium_buy' => 'premium satın alma',
    'premium_gift' => 'premium hediye', 'refund' => 'iade', 'auto_renew' => 'otomatik yenileme', 'admin_credit' => 'yönetici ekledi',
    'admin_debit' => 'yönetici düştü', 'coupon' => 'kupon',
];
