<?php
// NeonTV - XP / seviye. Puan: yorum×10 + takipçi×5 + izlenen reklam×3 + puanlama×2
function nvXpInfo(Supabase $db, string $uid): array {
    return Store::remember('xp_' . $uid, 120, function () use ($db, $uid) {
        $comments  = $db->count('comments', 'user_id=eq.' . $uid, true);
        $followers = $db->count('user_follows', 'following_id=eq.' . $uid, true);
        $ads       = $db->count('ad_watch_sessions', 'user_id=eq.' . $uid . '&claimed_at=not.is.null', true);
        $ratings   = $db->count('video_ratings', 'user_id=eq.' . $uid, true);
        $xp = $comments * 10 + $followers * 5 + $ads * 3 + $ratings * 2;
        $lvl = (int)floor(sqrt($xp / 20)) + 1;
        $cur = 20 * ($lvl - 1) ** 2; $next = 20 * $lvl ** 2;
        return ['xp' => $xp, 'level' => $lvl, 'cur' => $cur, 'next' => $next, 'pct' => (int)round(($xp - $cur) / max(1, $next - $cur) * 100)];
    });
}
function nvXpBadge(array $x): string {
    return '<span class="inline-flex items-center gap-2 text-xs"><b style="color:#ffd76a"><i class="fa-solid fa-bolt mr-1"></i>Seviye ' . (int)$x['level'] . '</b>'
        . '<span class="inline-block w-24 h-1.5 rounded-full overflow-hidden" style="background:rgba(255,255,255,.1)"><span class="block h-full" style="width:' . (int)$x['pct'] . '%;background:linear-gradient(90deg,#00f5ff,#bf00ff)"></span></span>'
        . '<span class="text-gray-500">' . (int)$x['xp'] . ' / ' . (int)$x['next'] . ' XP</span></span>';
}
