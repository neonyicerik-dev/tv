<?php
// ============================================================
// NeonTV - Tanıtım (landing) sayfası  ·  /landing.php
// Ana sayfa DEĞİLDİR. Canlı veriler: api/landing_stats.php (20 sn'de bir yenilenir).
// Seçki: admin → Haftanın Seçkisi. Fiyatlar: admin → Token & Mağaza.
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';
require_once __DIR__ . '/includes/store.php';
require_once __DIR__ . '/includes/ip_log.php';
require_once __DIR__ . '/includes/tokens.php';
require_once __DIR__ . '/includes/picks.php';
logVisit();

$db  = new Supabase();
$sel = 'id,title,thumbnail_url,video_url,duration,views,created_at';
$pc  = nvPicksCfg();
[$picks, $picksManual] = nvPicksVideos(8);
$trending = Store::remember('landing_trending', 120, function () use ($db, $sel) {
    $r = $db->select('videos', 'status=eq.published&order=views.desc&limit=8&select=' . $sel)['data'] ?? [];
    return is_array($r) ? $r : [];
});
$latest = Store::remember('landing_latest', 120, function () use ($db, $sel) {
    $r = $db->select('videos', 'status=eq.published&order=created_at.desc&limit=6&select=' . $sel)['data'] ?? [];
    return is_array($r) ? $r : [];
});
// Popüler etiketler (son 80 videodan, 10 dk önbellek)
$topTags = Store::remember('landing_tags', 600, function () use ($db) {
    $r = $db->select('videos', 'status=eq.published&order=created_at.desc&limit=80&select=tags')['data'] ?? [];
    $cnt = [];
    foreach ((is_array($r) ? $r : []) as $row) foreach ((array)($row['tags'] ?? []) as $t) { $t = trim((string)$t); if ($t !== '' && mb_strlen($t) <= 24) $cnt[$t] = ($cnt[$t] ?? 0) + 1; }
    arsort($cnt); return array_slice($cnt, 0, 16, true);
});
// Hero sahnesi: seçki > trend > yeni (en fazla 3 video)
$heroPool = $picks ?: ($trending ?: $latest);
$hero = array_slice($heroPool, 0, 3);
$tk = tkCfg(); $tkPrice = tkPrice($tk); $tkDisc = tkDiscountActive($tk);
$perDay = $tk['per_ad'] * $tk['daily_limit'];
$daysToPremium = $perDay > 0 ? (int)ceil($tkPrice / $perDay) : 0;
$settingsNow = Store::getSettings();
$ageGateOn = !empty($settingsNow['age_warning_enabled']);

$pageTitle = 'NeonTV - Neon ışıklı +18 video deneyimi';
$metaDesc  = 'NeonTV: birlikte izleme odaları, sahne yer imleri, token ile Premium ve neon temalı oynatıcı. 18 yaş üstü yetişkinler için.';
$ogImage   = $hero[0]['thumbnail_url'] ?? '';
$pageRobots = 'index,follow';
$pageLd = ['@context' => 'https://schema.org', '@type' => 'WebPage', 'name' => $pageTitle, 'description' => $metaDesc, 'inLanguage' => 'tr-TR',
    'isPartOf' => ['@type' => 'WebSite', 'name' => APP_NAME, 'url' => rtrim(APP_URL, '/') . '/']];

/** Video kartı: küçük resim + hover/odakta sessiz önizleme */
function lnCard(array $v, ?int $rank = null): string {
    $id = e($v['id']); $t = e($v['title']); $th = e($v['thumbnail_url'] ?? ''); $src = e($v['video_url'] ?? '');
    $dur = !empty($v['duration']) ? formatDuration((int)$v['duration']) : '';
    $h  = '<a class="ln-vcard" href="' . APP_URL . '/video.php?id=' . $id . '" data-ln-prev>';
    $h .= '<div class="ln-vthumb"><img src="' . $th . '" alt="' . $t . '" loading="lazy" decoding="async">';
    $h .= '<video muted loop playsinline preload="none" data-src="' . $src . '" tabindex="-1" aria-hidden="true"></video>';
    if ($rank !== null) $h .= '<span class="ln-rank">' . $rank . '</span>';
    if ($dur !== '') $h .= '<span class="ln-dur">' . e($dur) . '</span>';
    $h .= '<span class="ln-vplay" aria-hidden="true"><i class="fa-solid fa-play"></i></span></div>';
    $h .= '<h3>' . $t . '</h3><p><i class="fa-regular fa-eye"></i> ' . e(formatNumber((int)($v['views'] ?? 0))) . ' · ' . e(timeAgo($v['created_at'] ?? 'now')) . '</p></a>';
    return $h;
}
?>
<?php include __DIR__ . '/components/header.php'; ?>
<style id="ln-css">
/* ===== NeonTV landing — tüm sınıflar .ln- önekli, tw.css'e bağımlı değil ===== */
.ln{--c1:#00f5ff;--c2:#bf00ff;--c3:#ff2d95;--ink:#070711;--card:rgba(255,255,255,.045);--line:rgba(255,255,255,.09);--mut:#9aa0b4;
    position:relative;overflow:hidden;color:#fff;font-family:'Outfit',system-ui,sans-serif;isolation:isolate}
.ln *{box-sizing:border-box}
.ln a{color:inherit;text-decoration:none}
.ln-wrap{max-width:1200px;margin:0 auto;padding:0 20px;position:relative}
.ln-sec{padding:88px 0;position:relative}
.ln-eyebrow{display:inline-flex;align-items:center;gap:8px;font-size:12px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--c1);
    padding:6px 14px;border-radius:999px;background:rgba(0,245,255,.08);border:1px solid rgba(0,245,255,.25)}
.ln-h2{font-size:clamp(28px,4.2vw,46px);font-weight:800;line-height:1.1;letter-spacing:-.02em;margin:16px 0 12px}
.ln-lead{color:var(--mut);font-size:clamp(15px,1.6vw,18px);line-height:1.65;max-width:640px}
.ln-grad{background:linear-gradient(100deg,var(--c1),var(--c2) 55%,var(--c3));-webkit-background-clip:text;background-clip:text;color:transparent;
    background-size:200% auto;animation:ln-shine 6s linear infinite}
@keyframes ln-shine{to{background-position:200% center}}
.ln-center{text-align:center}.ln-center .ln-lead{margin:0 auto}

/* ---------- Arka plan aurora ---------- */
.ln-bg{position:absolute;inset:0;z-index:-1;pointer-events:none;overflow:hidden}
.ln-blob{position:absolute;border-radius:50%;filter:blur(90px);opacity:.5;will-change:transform;animation:ln-drift 18s ease-in-out infinite alternate}
.ln-blob.b1{width:560px;height:560px;left:-120px;top:-80px;background:radial-gradient(circle,#00f5ff 0,transparent 68%)}
.ln-blob.b2{width:640px;height:640px;right:-160px;top:120px;background:radial-gradient(circle,#bf00ff 0,transparent 68%);animation-duration:24s;animation-delay:-6s}
.ln-blob.b3{width:520px;height:520px;left:30%;top:560px;background:radial-gradient(circle,#ff2d95 0,transparent 68%);opacity:.32;animation-duration:30s;animation-delay:-12s}
@keyframes ln-drift{0%{transform:translate3d(0,0,0) scale(1)}50%{transform:translate3d(60px,40px,0) scale(1.12)}100%{transform:translate3d(-40px,90px,0) scale(.95)}}
.ln-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.045) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.045) 1px,transparent 1px);
    background-size:56px 56px;mask-image:radial-gradient(ellipse 80% 60% at 50% 18%,#000 25%,transparent 75%);-webkit-mask-image:radial-gradient(ellipse 80% 60% at 50% 18%,#000 25%,transparent 75%)}
.ln-stars{position:absolute;inset:0}
.ln-star{position:absolute;width:2px;height:2px;border-radius:50%;background:#fff;opacity:0;animation:ln-twinkle var(--d,4s) ease-in-out infinite;animation-delay:var(--l,0s)}
@keyframes ln-twinkle{0%,100%{opacity:0;transform:scale(.6)}50%{opacity:.9;transform:scale(1.4)}}

/* ---------- Hero ---------- */
.ln-hero{padding:70px 0 40px}
.ln-hero-in{display:grid;grid-template-columns:1.05fr .95fr;gap:48px;align-items:center}
.ln-live{display:inline-flex;align-items:center;gap:9px;padding:7px 14px;border-radius:999px;font-size:13px;font-weight:600;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.35);color:#86efac}
.ln-dot{width:8px;height:8px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 0 rgba(34,197,94,.7);animation:ln-pulse 1.8s infinite}
@keyframes ln-pulse{70%{box-shadow:0 0 0 10px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
.ln-h1{font-size:clamp(38px,6.4vw,76px);font-weight:900;line-height:1.02;letter-spacing:-.035em;margin:20px 0 18px}
.ln-rot{display:inline-block;position:relative;min-width:2ch}
.ln-rot::after{content:'';display:inline-block;width:3px;height:.9em;margin-left:4px;background:var(--c1);vertical-align:-.08em;animation:ln-caret .8s steps(1) infinite}
@keyframes ln-caret{50%{opacity:0}}
.ln-cta{display:flex;flex-wrap:wrap;gap:12px;margin-top:28px}
.ln-btn{position:relative;display:inline-flex;align-items:center;justify-content:center;gap:9px;padding:14px 26px;border-radius:14px;font-weight:800;font-size:16px;cursor:pointer;
    border:1px solid transparent;transition:transform .25s,box-shadow .25s,background .25s;overflow:hidden;white-space:nowrap}
.ln-btn:active{transform:scale(.97)}
.ln-btn.pri{background:linear-gradient(120deg,var(--c1),var(--c2));color:#05050c;box-shadow:0 10px 34px -8px rgba(0,245,255,.55)}
.ln-btn.pri:hover{transform:translateY(-3px);box-shadow:0 16px 40px -8px rgba(191,0,255,.6)}
.ln-btn.pri::after{content:'';position:absolute;top:0;left:-60%;width:40%;height:100%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.55),transparent);transform:skewX(-20deg);animation:ln-sweep 3.4s ease-in-out infinite}
@keyframes ln-sweep{0%,55%{left:-60%}100%{left:130%}}
.ln-btn.gho{background:var(--card);border-color:var(--line);color:#fff;backdrop-filter:blur(8px)}
.ln-btn.gho:hover{background:rgba(255,255,255,.1);transform:translateY(-3px)}
.ln-trust{display:flex;flex-wrap:wrap;gap:8px 18px;margin-top:26px;color:var(--mut);font-size:13px}
.ln-trust span{display:inline-flex;align-items:center;gap:7px}.ln-trust i{color:var(--c1)}

/* Hero sahnesi: üst üste dizilmiş video kartları */
.ln-stage{position:relative;height:460px;perspective:1100px}
.ln-sc{position:absolute;width:74%;aspect-ratio:16/9;border-radius:20px;overflow:hidden;border:1px solid rgba(255,255,255,.14);
    background:#0d0d1a;box-shadow:0 30px 70px -20px rgba(0,0,0,.8),0 0 0 1px rgba(0,245,255,.08);transition:transform .5s cubic-bezier(.2,.8,.2,1),box-shadow .4s;will-change:transform}
.ln-sc img,.ln-sc video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.ln-sc video{opacity:0;transition:opacity .5s}.ln-sc.on video{opacity:1}
.ln-sc::after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,transparent 55%,rgba(0,0,0,.78));pointer-events:none}
.ln-sc .ln-sct{position:absolute;left:14px;right:14px;bottom:12px;z-index:2;font-weight:700;font-size:14px;text-shadow:0 2px 10px #000;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}
.ln-sc.s1{left:0;top:6%;z-index:3;transform:rotateY(10deg) rotateX(2deg) translateZ(40px);animation:ln-float 7s ease-in-out infinite}
.ln-sc.s2{right:0;top:30%;z-index:2;transform:rotateY(-12deg) translateZ(10px) scale(.94);animation:ln-float 8s ease-in-out infinite -2s}
.ln-sc.s3{left:12%;bottom:0;z-index:1;transform:rotateY(8deg) translateZ(-10px) scale(.88);animation:ln-float 9s ease-in-out infinite -4s;opacity:.92}
@keyframes ln-float{0%,100%{translate:0 0}50%{translate:0 -14px}}
.ln-sc:hover{box-shadow:0 36px 80px -18px rgba(0,245,255,.4),0 0 0 1px rgba(0,245,255,.5)}
.ln-chip{position:absolute;z-index:5;display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:14px;font-size:13px;font-weight:600;
    background:rgba(13,13,26,.82);border:1px solid var(--line);backdrop-filter:blur(14px);box-shadow:0 14px 34px -10px rgba(0,0,0,.7);animation:ln-chipin .8s both,ln-float 6s ease-in-out infinite}
.ln-chip i{width:30px;height:30px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:14px}
.ln-chip.c1{right:2%;top:2%;animation-delay:.6s,0s}.ln-chip.c1 i{background:rgba(251,191,36,.18);color:#fbbf24}
.ln-chip.c2{left:-2%;bottom:30%;animation-delay:1s,-2s}.ln-chip.c2 i{background:rgba(244,114,182,.18);color:#f472b6}
.ln-chip.c3{right:6%;bottom:6%;animation-delay:1.4s,-4s}.ln-chip.c3 i{background:rgba(251,146,60,.18);color:#fb923c}
@keyframes ln-chipin{from{opacity:0;transform:translateY(20px) scale(.9)}to{opacity:1}}

/* ---------- Canlı akış şeridi ---------- */
.ln-tick{border-block:1px solid var(--line);background:rgba(255,255,255,.025);overflow:hidden;position:relative}
.ln-tick::before,.ln-tick::after{content:'';position:absolute;top:0;bottom:0;width:90px;z-index:2;pointer-events:none}
.ln-tick::before{left:0;background:linear-gradient(90deg,#070711,transparent)}.ln-tick::after{right:0;background:linear-gradient(270deg,#070711,transparent)}
.ln-tick-in{display:flex;gap:40px;padding:14px 0;width:max-content;animation:ln-marq 46s linear infinite}
.ln-tick:hover .ln-tick-in{animation-play-state:paused}
@keyframes ln-marq{to{transform:translateX(-50%)}}
.ln-ti{display:inline-flex;align-items:center;gap:10px;font-size:14px;color:#cfd3e4;white-space:nowrap}
.ln-ti b{color:#fff}.ln-ti i{color:var(--c1)}.ln-ti .vt{color:var(--c3)}.ln-ti small{color:var(--mut)}

/* ---------- Sayaçlar ---------- */
.ln-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:8px}
.ln-stat{padding:26px 22px;border-radius:22px;background:var(--card);border:1px solid var(--line);text-align:center;position:relative;overflow:hidden;transition:transform .3s,border-color .3s}
.ln-stat:hover{transform:translateY(-6px);border-color:rgba(0,245,255,.4)}
.ln-stat::before{content:'';position:absolute;inset:-40% -20% auto;height:80%;background:radial-gradient(closest-side,rgba(0,245,255,.16),transparent);opacity:0;transition:opacity .4s}
.ln-stat:hover::before{opacity:1}
.ln-stat i{font-size:22px;color:var(--c1);margin-bottom:12px;display:block}
.ln-num{font-size:clamp(30px,4vw,46px);font-weight:900;letter-spacing:-.03em;font-variant-numeric:tabular-nums}
.ln-stat p{color:var(--mut);font-size:14px;margin-top:4px}
.ln-stat.live .ln-num{color:#86efac}

/* ---------- Video vitrinleri ---------- */
.ln-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;flex-wrap:wrap;margin-bottom:30px}
.ln-nav{display:flex;gap:10px}
.ln-nb{width:46px;height:46px;border-radius:50%;background:var(--card);border:1px solid var(--line);color:#fff;font-size:15px;cursor:pointer;transition:.25s}
.ln-nb:hover{background:var(--c1);color:#000;transform:scale(1.08)}
.ln-rail{display:flex;gap:18px;overflow-x:auto;scroll-snap-type:x mandatory;padding:6px 20px 26px;margin:0 -20px;scrollbar-width:none;cursor:grab}
.ln-rail::-webkit-scrollbar{display:none}.ln-rail.drag{cursor:grabbing;scroll-snap-type:none}
.ln-rail .ln-vcard{flex:0 0 min(340px,78vw);scroll-snap-align:start}
.ln-vgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:18px}
.ln-vcard{display:block;border-radius:18px;transition:transform .3s}
.ln-vcard:hover{transform:translateY(-6px)}
.ln-vthumb{position:relative;aspect-ratio:16/9;border-radius:18px;overflow:hidden;background:#101020;border:1px solid var(--line);transition:border-color .3s,box-shadow .3s}
.ln-vcard:hover .ln-vthumb{border-color:rgba(0,245,255,.55);box-shadow:0 18px 44px -14px rgba(0,245,255,.4)}
.ln-vthumb img,.ln-vthumb video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.ln-vthumb video{opacity:0;transition:opacity .4s}.ln-vcard.on .ln-vthumb video{opacity:1}
.ln-vplay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.28);opacity:0;transition:opacity .3s}
.ln-vplay i{width:54px;height:54px;border-radius:50%;background:rgba(0,245,255,.92);color:#000;display:flex;align-items:center;justify-content:center;padding-left:3px;transform:scale(.7);transition:transform .3s}
.ln-vcard:hover .ln-vplay{opacity:1}.ln-vcard:hover .ln-vplay i{transform:scale(1)}.ln-vcard.on .ln-vplay{opacity:0}
.ln-dur{position:absolute;right:10px;bottom:10px;font-size:11px;font-weight:700;padding:3px 7px;border-radius:7px;background:rgba(0,0,0,.78)}
.ln-rank{position:absolute;left:10px;top:8px;font-size:34px;font-weight:900;line-height:1;-webkit-text-stroke:1.5px var(--c1);color:transparent;filter:drop-shadow(0 2px 10px rgba(0,0,0,.7))}
.ln-vcard h3{font-size:15px;font-weight:700;margin:12px 2px 4px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;line-height:1.35}
.ln-vcard p{font-size:12.5px;color:var(--mut);margin:0 2px;display:flex;gap:6px;align-items:center}
.ln-pick-note{margin-top:10px;display:inline-flex;gap:8px;align-items:center;color:#fcd34d;font-size:14px}
.ln-empty{padding:40px;text-align:center;color:var(--mut);border:1px dashed var(--line);border-radius:18px}

/* ---------- Özellikler ---------- */
.ln-feats{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-top:42px}
.ln-f{position:relative;padding:28px 24px;border-radius:22px;background:var(--card);border:1px solid var(--line);overflow:hidden;transition:transform .35s,border-color .35s;
    transform-style:preserve-3d}
.ln-f::before{content:'';position:absolute;left:var(--mx,50%);top:var(--my,50%);width:260px;height:260px;margin:-130px;border-radius:50%;
    background:radial-gradient(closest-side,var(--fc,rgba(0,245,255,.2)),transparent);opacity:0;transition:opacity .35s;pointer-events:none}
.ln-f:hover::before{opacity:1}.ln-f:hover{transform:translateY(-6px);border-color:var(--fb,rgba(0,245,255,.45))}
.ln-fi{width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:22px;margin-bottom:18px;background:var(--fbg,rgba(0,245,255,.12));color:var(--fcol,var(--c1));position:relative}
.ln-f h3{font-size:19px;font-weight:800;margin-bottom:8px;position:relative}
.ln-f p{color:var(--mut);font-size:14.5px;line-height:1.6;position:relative}
.ln-tag{position:absolute;right:16px;top:16px;font-size:10px;font-weight:800;letter-spacing:.08em;padding:4px 9px;border-radius:999px;background:rgba(255,45,149,.16);color:#ff7ab8;border:1px solid rgba(255,45,149,.35)}
.ln-f.pu{--fc:rgba(191,0,255,.22);--fb:rgba(191,0,255,.5);--fbg:rgba(191,0,255,.14);--fcol:#d946ef}
.ln-f.pk{--fc:rgba(255,45,149,.2);--fb:rgba(255,45,149,.5);--fbg:rgba(255,45,149,.14);--fcol:#ff4fa3}
.ln-f.yl{--fc:rgba(251,191,36,.2);--fb:rgba(251,191,36,.5);--fbg:rgba(251,191,36,.14);--fcol:#fbbf24}
.ln-f.gr{--fc:rgba(52,211,153,.2);--fb:rgba(52,211,153,.5);--fbg:rgba(52,211,153,.14);--fcol:#34d399}
.ln-f.or{--fc:rgba(251,146,60,.2);--fb:rgba(251,146,60,.5);--fbg:rgba(251,146,60,.14);--fcol:#fb923c}

/* ---------- Birlikte izleme demosu ---------- */
.ln-party{display:grid;grid-template-columns:1fr 1fr;gap:54px;align-items:center}
.ln-mock{border-radius:22px;background:#0d0d1a;border:1px solid var(--line);box-shadow:0 40px 80px -30px rgba(0,0,0,.9),0 0 60px -20px rgba(251,146,60,.35);overflow:hidden}
.ln-mock-bar{display:flex;align-items:center;gap:8px;padding:12px 16px;background:rgba(251,146,60,.1);border-bottom:1px solid rgba(251,146,60,.3);font-size:13px;font-weight:700;color:#fdba74}
.ln-mock-bar em{margin-left:auto;font-style:normal;color:#9aa0b4;font-weight:500}
.ln-mock-v{position:relative;aspect-ratio:16/9;background:linear-gradient(135deg,#1a1033,#08283a);overflow:hidden}
.ln-mock-v::before{content:'';position:absolute;inset:0;background:conic-gradient(from 0deg at 50% 50%,rgba(0,245,255,.25),rgba(191,0,255,.25),rgba(255,45,149,.25),rgba(0,245,255,.25));animation:ln-spin 10s linear infinite;filter:blur(40px)}
@keyframes ln-spin{to{transform:rotate(360deg)}}
.ln-mock-pb{position:absolute;left:14px;right:14px;bottom:14px;height:5px;border-radius:5px;background:rgba(255,255,255,.2)}
.ln-mock-pb i{display:block;height:100%;width:0;border-radius:5px;background:linear-gradient(90deg,var(--c1),var(--c2));animation:ln-prog 14s linear infinite}
@keyframes ln-prog{to{width:100%}}
.ln-mock-bm{position:absolute;bottom:11px;width:4px;height:11px;border-radius:2px;background:#f472b6}
.ln-chat{padding:14px;height:190px;display:flex;flex-direction:column;justify-content:flex-end;gap:8px;overflow:hidden}
.ln-bub{max-width:82%;padding:8px 12px;border-radius:14px;font-size:13px;line-height:1.35;background:rgba(255,255,255,.07);animation:ln-pop .45s cubic-bezier(.2,.9,.3,1.3) both}
.ln-bub b{color:#fdba74;margin-right:4px}.ln-bub.me{align-self:flex-end;background:rgba(0,245,255,.14)}.ln-bub.me b{color:#67e8f9}
@keyframes ln-pop{from{opacity:0;transform:translateY(14px) scale(.9)}to{opacity:1}}
.ln-list{list-style:none;padding:0;margin:26px 0 0;display:grid;gap:14px}
.ln-list li{display:flex;gap:14px;align-items:flex-start;color:#cfd3e4;font-size:15.5px;line-height:1.55}
.ln-list li i{flex:0 0 28px;height:28px;border-radius:9px;display:flex;align-items:center;justify-content:center;background:rgba(0,245,255,.12);color:var(--c1);font-size:13px;margin-top:2px}

/* ---------- Nasıl çalışır ---------- */
.ln-steps{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;margin-top:46px;position:relative}
.ln-steps::before{content:'';position:absolute;left:16%;right:16%;top:34px;height:2px;background:repeating-linear-gradient(90deg,rgba(0,245,255,.5) 0 8px,transparent 8px 18px);opacity:.6}
.ln-st{position:relative;text-align:center;padding:0 10px}
.ln-sn{width:68px;height:68px;margin:0 auto 20px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:26px;font-weight:900;color:#000;
    background:linear-gradient(135deg,var(--c1),var(--c2));box-shadow:0 0 0 8px rgba(0,245,255,.08),0 14px 34px -8px rgba(0,245,255,.55);position:relative;z-index:1}
.ln-st h3{font-size:20px;font-weight:800;margin-bottom:8px}.ln-st p{color:var(--mut);font-size:15px;line-height:1.6}

/* ---------- Token & Premium ---------- */
.ln-prem{display:grid;grid-template-columns:1.1fr .9fr;gap:30px;margin-top:44px;align-items:stretch}
.ln-pcard{padding:34px;border-radius:26px;background:linear-gradient(160deg,rgba(255,255,255,.07),rgba(255,255,255,.02));border:1px solid var(--line);position:relative;overflow:hidden}
.ln-pcard.glow{border-color:rgba(251,191,36,.5);box-shadow:0 0 70px -24px rgba(251,191,36,.6)}
.ln-pcard.glow::before{content:'';position:absolute;inset:-1px;border-radius:26px;padding:1px;background:conic-gradient(from var(--a,0deg),transparent 0 70%,#fbbf24 85%,transparent);
    -webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude;animation:ln-ring 5s linear infinite;pointer-events:none}
@property --a{syntax:'<angle>';initial-value:0deg;inherits:false}
@keyframes ln-ring{to{--a:360deg}}
.ln-price{display:flex;align-items:baseline;gap:10px;margin:14px 0 4px}
.ln-price b{font-size:58px;font-weight:900;letter-spacing:-.04em;color:#fde68a}.ln-price s{color:#f87171;font-size:22px}.ln-price span{color:var(--mut)}
.ln-disc{display:inline-flex;gap:8px;align-items:center;padding:6px 12px;border-radius:999px;background:rgba(239,68,68,.14);border:1px solid rgba(239,68,68,.4);color:#fca5a5;font-size:13px;font-weight:700}
.ln-calc label{display:flex;justify-content:space-between;font-size:14px;color:#cfd3e4;margin:18px 0 8px}
.ln-calc input[type=range]{width:100%;accent-color:#00f5ff;height:6px}
.ln-calc .out{margin-top:20px;padding:18px;border-radius:16px;background:rgba(0,245,255,.07);border:1px solid rgba(0,245,255,.25);text-align:center}
.ln-calc .out b{font-size:34px;font-weight:900;color:var(--c1);display:block}
.ln-pl{list-style:none;padding:0;margin:20px 0 0;display:grid;gap:11px}
.ln-pl li{display:flex;gap:11px;font-size:15px;color:#e5e7eb}.ln-pl li i{color:#34d399;margin-top:3px}

/* ---------- Yorumlar (canlı) ---------- */
.ln-cm{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:38px;min-height:140px}
.ln-cmc{padding:20px;border-radius:18px;background:var(--card);border:1px solid var(--line);animation:ln-pop .6s both;transition:transform .3s,border-color .3s}
.ln-cmc:hover{transform:translateY(-4px);border-color:rgba(255,45,149,.45)}
.ln-cmc q{display:block;quotes:none;font-size:15px;line-height:1.55;color:#e5e7eb}
.ln-cmc footer{margin-top:14px;font-size:12.5px;color:var(--mut);display:flex;justify-content:space-between;gap:10px}
.ln-cmc footer b{color:#fff}.ln-cmc footer span{color:var(--c3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:50%}

/* ---------- SSS ---------- */
.ln-faq{max-width:820px;margin:40px auto 0;display:grid;gap:12px}
.ln-q{border-radius:16px;background:var(--card);border:1px solid var(--line);overflow:hidden;transition:border-color .3s}
.ln-q.open{border-color:rgba(0,245,255,.45)}
.ln-q button{width:100%;display:flex;justify-content:space-between;align-items:center;gap:16px;padding:18px 22px;color:#fff;font-size:16.5px;font-weight:700;text-align:left;background:none;border:0;cursor:pointer}
.ln-q button i{transition:transform .35s;color:var(--c1)}.ln-q.open button i{transform:rotate(45deg)}
.ln-qa{display:grid;grid-template-rows:0fr;transition:grid-template-rows .4s ease}.ln-q.open .ln-qa{grid-template-rows:1fr}
.ln-qa>div{overflow:hidden}.ln-qa p{padding:0 22px 20px;color:var(--mut);font-size:15px;line-height:1.7}

/* ---------- Son CTA ---------- */
.ln-final{margin:20px 0 70px;padding:64px 28px;border-radius:32px;text-align:center;position:relative;overflow:hidden;border:1px solid rgba(0,245,255,.3);
    background:radial-gradient(ellipse at 20% 0,rgba(0,245,255,.22),transparent 55%),radial-gradient(ellipse at 85% 100%,rgba(191,0,255,.28),transparent 55%),#0b0b18}
.ln-final h2{font-size:clamp(30px,5vw,54px);font-weight:900;letter-spacing:-.03em;line-height:1.08;margin-bottom:14px}
.ln-final .ln-cta{justify-content:center}
.ln-small{margin-top:26px;color:var(--mut);font-size:12.5px;line-height:1.6}
.ln-small a{color:var(--c1);text-decoration:underline}

/* ---------- Scroll-in ---------- */
.ln-rv{opacity:0;transform:translateY(34px);transition:opacity .8s cubic-bezier(.2,.7,.2,1),transform .8s cubic-bezier(.2,.7,.2,1);transition-delay:var(--d,0s)}
.ln-rv.in{opacity:1;transform:none}
.ln-prog{position:fixed;left:0;top:0;height:3px;width:0;z-index:99999;background:linear-gradient(90deg,var(--c1,#00f5ff),var(--c2,#bf00ff),#ff2d95);box-shadow:0 0 12px rgba(0,245,255,.7)}
.ln-top{position:fixed;right:18px;bottom:18px;z-index:90;width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;font-size:16px;border:0;cursor:pointer;
    opacity:0;transform:translateY(20px);pointer-events:none;transition:.3s;box-shadow:0 10px 28px -6px rgba(0,245,255,.6)}
.ln-top.show{opacity:1;transform:none;pointer-events:auto}

/* ---------- Duyarlı ---------- */
@media(max-width:980px){
  .ln-hero-in,.ln-party,.ln-prem{grid-template-columns:1fr}
  .ln-stage{height:380px;max-width:560px;margin:10px auto 0;width:100%}
  .ln-feats,.ln-cm{grid-template-columns:repeat(2,1fr)}
  .ln-stats{grid-template-columns:repeat(2,1fr)}.ln-vgrid{grid-template-columns:repeat(2,1fr)}
}
@media(max-width:640px){
  .ln-sec{padding:60px 0}.ln-hero{padding:40px 0 20px}
  .ln-feats,.ln-cm,.ln-steps{grid-template-columns:1fr}.ln-steps::before{display:none}
  .ln-stage{height:300px}.ln-chip{display:none}.ln-chip.c1{display:flex;right:0}
  .ln-btn{width:100%}.ln-pcard{padding:24px}.ln-price b{font-size:46px}
}
@media(prefers-reduced-motion:reduce){
  .ln *,.ln *::before,.ln *::after{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important}
  .ln-rv{opacity:1;transform:none}.ln-tick-in{animation:none}
}

/* ---------- Çerçeve vitrini ---------- */
.ln-frames{display:grid;grid-template-columns:repeat(6,1fr);gap:16px;margin-top:40px}
.ln-fr{display:flex;flex-direction:column;align-items:center;gap:14px;padding:22px 8px 18px;border-radius:20px;background:var(--card);border:1px solid var(--line);color:#fff;cursor:pointer;transition:transform .3s,border-color .3s,background .3s}
.ln-fr:hover{transform:translateY(-6px)}.ln-fr.sel{border-color:var(--f1);background:rgba(255,255,255,.07)}
.ln-fr em{font-style:normal;font-size:13px;font-weight:700;color:#cfd3e4}
.ln-ring{position:relative;width:86px;height:86px;border-radius:50%;padding:4px;background:conic-gradient(from var(--ra,0deg),var(--f1),var(--f2),var(--f1));animation:ln-rot var(--fd,4s) linear infinite;display:block}
@property --ra{syntax:'<angle>';initial-value:0deg;inherits:false}
@keyframes ln-rot{to{--ra:360deg}}
.ln-fr.sel .ln-ring{box-shadow:0 0 28px -2px var(--f1),0 0 54px -10px var(--f2)}
.ln-av{display:flex;align-items:center;justify-content:center;width:100%;height:100%;border-radius:50%;background:#0d0d1a;font-size:30px;color:#6b7280}

/* ---------- Karşılaştırma tablosu ---------- */
.ln-cmp{max-width:820px;margin:38px auto 0;border-radius:22px;background:var(--card);border:1px solid var(--line);overflow:hidden}
.ln-cr{display:grid;grid-template-columns:1fr 110px 110px;align-items:center;gap:8px;padding:16px 22px;border-top:1px solid var(--line);font-size:15px;color:#e5e7eb}
.ln-cr.hd{border-top:0;background:rgba(255,255,255,.04);font-weight:800;font-size:13px;letter-spacing:.06em;text-transform:uppercase;color:var(--mut)}
.ln-cr span:not(:first-child){text-align:center}.ln-cr .pr{color:#fde68a;background:rgba(251,191,36,.06);margin:-16px 0;padding:16px 0}
.ln-cr.hd .pr{color:#fbbf24}.ln-cr .ok{color:#34d399}.ln-cr .no{color:#4b5563}
.ln-cr:hover:not(.hd){background:rgba(255,255,255,.03)}

/* ---------- Zaman çizelgesi ---------- */
.ln-tl{list-style:none;padding:0;margin:40px auto 0;max-width:720px;position:relative}
.ln-tl::before{content:'';position:absolute;left:23px;top:8px;bottom:8px;width:2px;background:linear-gradient(180deg,var(--c1),var(--c2),transparent)}
.ln-tli{display:flex;gap:20px;align-items:flex-start;padding:0 0 28px;position:relative}
.ln-tld{flex:0 0 48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#0d0d1a;border:2px solid var(--c1);color:var(--c1);font-size:17px;position:relative;z-index:1;box-shadow:0 0 22px -4px rgba(0,245,255,.6)}
.ln-tli small{color:var(--c1);font-weight:700;font-size:12px;letter-spacing:.1em;text-transform:uppercase}
.ln-tli p{margin-top:4px;font-size:16.5px;line-height:1.5;color:#e5e7eb}
@media(max-width:980px){.ln-frames{grid-template-columns:repeat(3,1fr)}}
@media(max-width:640px){.ln-frames{grid-template-columns:repeat(2,1fr)}.ln-cr{grid-template-columns:1fr 64px 74px;padding:14px 14px;font-size:14px}}

/* ---------- Etiket bulutu ---------- */
.ln-tags{display:flex;flex-wrap:wrap;justify-content:center;gap:10px;margin-top:34px;max-width:900px;margin-inline:auto}
.ln-tg{padding:9px 18px;border-radius:999px;font-size:14px;font-weight:700;background:var(--card);border:1px solid var(--line);color:#e5e7eb;transition:transform .25s,background .25s,border-color .25s,color .25s;
    animation:ln-float 7s ease-in-out infinite;animation-delay:var(--tl,0s)}
.ln-tg:hover{background:linear-gradient(120deg,var(--c1),var(--c2));color:#000;border-color:transparent;transform:translateY(-4px) scale(1.06)}
.ln-tg small{opacity:.6;margin-left:6px;font-weight:600}
/* ---------- Gizlilik kartları ---------- */
.ln-priv{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:38px}
.ln-pv{padding:24px 20px;border-radius:20px;background:var(--card);border:1px solid var(--line);text-align:center;transition:transform .3s,border-color .3s}
.ln-pv:hover{transform:translateY(-5px);border-color:rgba(52,211,153,.5)}
.ln-pv i{font-size:26px;color:#34d399;margin-bottom:14px;display:block}
.ln-pv h3{font-size:16.5px;font-weight:800;margin-bottom:6px}.ln-pv p{font-size:13.5px;color:var(--mut);line-height:1.55}
/* ---------- Bölüm bağlantı çubuğu ---------- */
.ln-chips{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;padding:18px 20px 0}
.ln-chips a{padding:7px 15px;border-radius:999px;font-size:13px;font-weight:700;color:#cfd3e4;background:var(--card);border:1px solid var(--line);transition:.25s}
.ln-chips a:hover{background:rgba(0,245,255,.14);border-color:rgba(0,245,255,.5);color:#fff;transform:translateY(-2px)}
@media(max-width:980px){.ln-priv{grid-template-columns:repeat(2,1fr)}}
@media(max-width:640px){.ln-priv{grid-template-columns:1fr}}

/* ---------- Klavye kısayolları ---------- */
.ln-keys{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:36px;max-width:960px;margin-inline:auto}
.ln-k{display:flex;align-items:center;gap:14px;padding:16px 18px;border-radius:16px;background:var(--card);border:1px solid var(--line);transition:transform .25s,border-color .25s}
.ln-k:hover{transform:translateY(-4px);border-color:rgba(0,245,255,.45)}
.ln-k kbd{min-width:42px;height:42px;padding:0 10px;border-radius:11px;display:inline-flex;align-items:center;justify-content:center;font:800 15px 'Outfit',sans-serif;color:#fff;
    background:linear-gradient(180deg,#252540,#14142a);border:1px solid rgba(255,255,255,.18);border-bottom-width:4px;box-shadow:0 6px 14px -6px rgba(0,0,0,.8);transition:transform .12s,border-bottom-width .12s}
.ln-k.hit kbd{transform:translateY(3px);border-bottom-width:1px;color:var(--c1)}
.ln-k span{font-size:14px;color:#cfd3e4;line-height:1.35}
@media(max-width:980px){.ln-keys{grid-template-columns:repeat(2,1fr)}}
@media(max-width:640px){.ln-keys{grid-template-columns:1fr}}
</style>
<noscript><style>
/* JavaScript kapalıysa içerik görünür kalsın */
.ln-rv{opacity:1!important;transform:none!important}
.ln-sc video,.ln-vthumb video{display:none}
.ln-q .ln-qa{grid-template-rows:1fr}
.ln-tick{display:none}
</style></noscript>
<div class="ln-prog" id="ln-prog"></div>
<main class="ln" id="ln-top-anchor">
  <div class="ln-bg" aria-hidden="true"><div class="ln-grid"></div><div class="ln-blob b1"></div><div class="ln-blob b2"></div><div class="ln-blob b3"></div><div class="ln-stars" id="ln-stars"></div></div>

  <!-- ================= HERO ================= -->
  <section class="ln-hero">
    <div class="ln-wrap ln-hero-in">
      <div>
        <span class="ln-live" id="ln-live"><span class="ln-dot"></span><span id="ln-live-t">Şu an canlı</span></span>
        <h1 class="ln-h1">Neon ışıklarda <span class="ln-grad">birlikte</span><br><span class="ln-rot" id="ln-rot" data-words='["izle.","paylaş.","keşfet.","kazan."]'>izle.</span></h1>
        <p class="ln-lead">Yetişkinler için tasarlanmış, hızlı ve temiz bir video platformu. Arkadaşınla <b>aynı anda izle</b>, en sevdiğin sahnelere <b>yer imi koy</b>, reklam izleyerek <b>token kazan</b> ve tokenlerle Premium'a geç.</p>
        <div class="ln-cta">
          <a class="ln-btn pri" href="<?= APP_URL ?>/index.php"><i class="fa-solid fa-play"></i> Hemen İzle</a>
          <a class="ln-btn gho" href="<?= APP_URL ?>/auth.php?tab=register"><i class="fa-solid fa-user-plus"></i> Ücretsiz Kayıt Ol</a>
        </div>
        <div class="ln-trust">
          <span><i class="fa-solid fa-shield-halved"></i> Yalnızca 18 yaş ve üzeri</span>
          <span><i class="fa-solid fa-lock"></i> Verilerini indir veya sil (KVKK)</span>
          <span><i class="fa-solid fa-bolt"></i> Kurulum yok, tarayıcıda çalışır</span>
        </div>
      </div>
      <div class="ln-stage" id="ln-stage" aria-label="Öne çıkan videolar">
        <?php foreach ($hero as $i => $hv): ?>
        <a class="ln-sc s<?= $i + 1 ?>" href="<?= APP_URL ?>/video.php?id=<?= e($hv['id']) ?>" data-ln-prev>
          <img src="<?= e($hv['thumbnail_url'] ?? '') ?>" alt="<?= e($hv['title']) ?>" <?= $i ? 'loading="lazy"' : 'fetchpriority="high"' ?> decoding="async">
          <video muted loop playsinline preload="none" data-src="<?= e($hv['video_url'] ?? '') ?>" tabindex="-1" aria-hidden="true"></video>
          <span class="ln-sct"><?= e($hv['title']) ?></span>
        </a>
        <?php endforeach; ?>
        <?php if (!$hero): ?><div class="ln-sc s1" style="background:linear-gradient(135deg,#1a1033,#08283a)"><span class="ln-sct">Yakında burada</span></div><?php endif; ?>
        <div class="ln-chip c1"><i class="fa-solid fa-coins"></i><span>Reklam izle<br><small style="color:#9aa0b4">+<?= (int)$tk['per_ad'] ?> token</small></span></div>
        <div class="ln-chip c2"><i class="fa-solid fa-bookmark"></i><span>Yer imi eklendi<br><small style="color:#9aa0b4">B tuşu</small></span></div>
        <div class="ln-chip c3"><i class="fa-solid fa-users-viewfinder"></i><span>Oda kuruldu<br><small style="color:#9aa0b4">Senkron izleme</small></span></div>
      </div>
    </div>
  </section>

  <!-- ================= CANLI AKIŞ ================= -->
  <div class="ln-tick" id="ln-tick" hidden aria-label="Canlı akış"><div class="ln-tick-in" id="ln-tick-in"></div></div>

  <nav class="ln-chips" aria-label="Sayfa bölümleri">
    <a href="#secki">Seçki</a><a href="#ozellikler">Özellikler</a><a href="#birlikte">Birlikte izle</a><a href="#premium">Premium</a><a href="#cerceveler">Çerçeveler</a><a href="#sss">SSS</a>
  </nav>

  <!-- ================= SAYAÇLAR ================= -->
  <section class="ln-sec" style="padding-bottom:30px">
    <div class="ln-wrap">
      <div class="ln-stats">
        <div class="ln-stat ln-rv"><i class="fa-solid fa-film"></i><div class="ln-num" data-k="videos">0</div><p>Yayındaki video</p></div>
        <div class="ln-stat ln-rv" style="--d:.08s"><i class="fa-solid fa-eye"></i><div class="ln-num" data-k="views">0</div><p>Toplam izlenme</p></div>
        <div class="ln-stat ln-rv" style="--d:.16s"><i class="fa-solid fa-user-group"></i><div class="ln-num" data-k="members">0</div><p>Üye</p></div>
        <div class="ln-stat live ln-rv" style="--d:.24s"><i class="fa-solid fa-tower-broadcast"></i><div class="ln-num" data-k="online">0</div><p>Şu an sitede</p></div>
      </div>
    </div>
  </section>

  <!-- ================= HAFTANIN SEÇKİSİ ================= -->
  <section class="ln-sec" id="secki">
    <div class="ln-wrap">
      <div class="ln-head ln-rv">
        <div>
          <span class="ln-eyebrow"><i class="fa-solid fa-star"></i> <?= $picksManual ? 'Editör seçimi' : 'Bu haftanın en çok izlenenleri' ?></span>
          <h2 class="ln-h2"><?= e($pc['title']) ?></h2>
          <?php if ($pc['note'] !== ''): ?><p class="ln-pick-note"><i class="fa-solid fa-quote-left"></i> <?= e($pc['note']) ?></p><?php endif; ?>
          <p class="ln-lead">Kartların üzerine gel (mobilde kaydırınca ekranın ortasındaki oynar) ve sessiz önizlemeyi izle.</p>
        </div>
        <div class="ln-nav"><button class="ln-nb" data-rail="ln-r1" data-dir="-1" aria-label="Geri"><i class="fa-solid fa-chevron-left"></i></button><button class="ln-nb" data-rail="ln-r1" data-dir="1" aria-label="İleri"><i class="fa-solid fa-chevron-right"></i></button></div>
      </div>
      <?php if ($picks): ?>
      <div class="ln-rail ln-rv" id="ln-r1"><?php foreach ($picks as $i => $v) echo lnCard($v, $i + 1); ?></div>
      <?php else: ?><div class="ln-empty">Seçki yakında burada olacak.</div><?php endif; ?>
    </div>
  </section>

  <!-- ================= TREND ================= -->
  <section class="ln-sec" style="padding-top:20px">
    <div class="ln-wrap">
      <div class="ln-head ln-rv">
        <div><span class="ln-eyebrow"><i class="fa-solid fa-fire"></i> Trend</span><h2 class="ln-h2">Şu an <span class="ln-grad">herkes bunu izliyor</span></h2></div>
        <a class="ln-btn gho" href="<?= APP_URL ?>/index.php?sort=views">Tümünü gör <i class="fa-solid fa-arrow-right"></i></a>
      </div>
      <div class="ln-vgrid ln-rv"><?php foreach (array_slice($trending, 0, 4) as $v) echo lnCard($v); ?></div>
      <?php if ($latest): ?>
      <div class="ln-head ln-rv" style="margin-top:56px"><div><span class="ln-eyebrow"><i class="fa-solid fa-bolt"></i> Yeni</span><h2 class="ln-h2" style="font-size:clamp(24px,3vw,34px)">Yeni eklenenler</h2></div></div>
      <div class="ln-vgrid ln-rv"><?php foreach (array_slice($latest, 0, 4) as $v) echo lnCard($v); ?></div>
      <?php endif; ?>
    </div>
  </section>

  <?php if ($topTags): ?>
  <section class="ln-sec" style="padding-top:10px">
    <div class="ln-wrap ln-center ln-rv">
      <span class="ln-eyebrow"><i class="fa-solid fa-hashtag"></i> Etiketler</span>
      <h2 class="ln-h2">Ne <span class="ln-grad">arıyorsan</span> bul</h2>
      <div class="ln-tags">
        <?php $ti = 0; foreach ($topTags as $tg => $n): ?><a class="ln-tg" style="--tl:-<?= number_format($ti++ * .45, 2) ?>s" href="<?= APP_URL ?>/index.php?tag=<?= rawurlencode($tg) ?>">#<?= e($tg) ?><small><?= (int)$n ?></small></a><?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ================= ÖZELLİKLER ================= -->
  <section class="ln-sec" id="ozellikler">
    <div class="ln-wrap">
      <div class="ln-center ln-rv"><span class="ln-eyebrow"><i class="fa-solid fa-wand-magic-sparkles"></i> Özellikler</span>
        <h2 class="ln-h2">Sadece video değil, <span class="ln-grad">bir deneyim</span></h2>
        <p class="ln-lead">İzlemeyi daha rahat, daha sosyal ve daha ödüllü yapan her şey tek yerde.</p></div>
      <div class="ln-feats">
        <?php
        $F = [
          ['fa-users-viewfinder', 'or', 'Birlikte izle', 'Oda aç, linki gönder; oynat-durdur-ileri sar herkeste aynı anda olsun. Odanın canlı sohbeti de var.', 'YENİ'],
          ['fa-bookmark', 'pk', 'Sahne yer imleri', 'İzlerken B tuşuna bas, o an kaydedilsin. İlerleme çubuğunda işaret çıkar, kütüphanenden tek tıkla o sahneye dön.', 'YENİ'],
          ['fa-up-right-and-down-left-from-center', 'pu', 'Mini oynatıcı', 'Sayfada aşağı kayarken video köşede küçülüp devam eder. Yorumları okurken izlemeyi bırakma.', 'YENİ'],
          ['fa-clock-rotate-left', '', 'Kaldığın yerden devam', 'Videoyu bıraktığın saniyeyi hatırlarız. Ana sayfada "Devam et" rafı seni bekler.', ''],
          ['fa-coins', 'yl', 'Token ve Premium', 'Reklam izleyerek token kazan, tokenlerle Premium satın al ya da arkadaşına hediye et.', ''],
          ['fa-trophy', 'gr', 'Görevler ve rozetler', 'Günlük giriş serisi, görevler ve rozetlerle ödüller topla; seviyeni profilinde göster.', ''],
          ['fa-circle-user', 'pu', '30+ profil çerçevesi', 'Neon, kristal, samuray, roket… Avatarını çerçevelerle kişiselleştir.', ''],
          ['fa-list-ul', '', 'Bölümler', 'Uzun videolarda bölüm başlıkları ilerleme çubuğunda görünür; istediğin kısma atla.', ''],
          ['fa-closed-captioning', 'gr', 'Altyazı stili', 'Boyutu, rengi ve arka planı kendine göre ayarla; tercihin hatırlanır.', ''],
          ['fa-keyboard', 'yl', 'Klavye kısayolları', 'Boşluk, ok tuşları, M, F, L, B ve daha fazlası. "?" tuşu hepsini listeler.', ''],
          ['fa-note-sticky', 'pk', 'Video notları', 'Videolara kişisel notlar al; yalnızca sen görürsün.', ''],
          ['fa-user-shield', 'or', 'Gizlilik sende', 'Verilerini tek tıkla indir ya da hesabını sil. Çerez tercihlerini istediğin an değiştir.', ''],
        ];
        foreach ($F as $i => $f): ?>
        <article class="ln-f ln-rv <?= $f[1] ?>" style="--d:<?= number_format(($i % 3) * 0.08, 2) ?>s">
          <?php if ($f[4]): ?><span class="ln-tag"><?= e($f[4]) ?></span><?php endif; ?>
          <div class="ln-fi"><i class="fa-solid <?= e($f[0]) ?>"></i></div><h3><?= e($f[2]) ?></h3><p><?= e($f[3]) ?></p>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ================= BİRLİKTE İZLEME ================= -->
  <section class="ln-sec" id="birlikte">
    <div class="ln-wrap ln-party">
      <div class="ln-rv">
        <span class="ln-eyebrow" style="color:#fb923c;background:rgba(251,146,60,.1);border-color:rgba(251,146,60,.35)"><i class="fa-solid fa-users-viewfinder"></i> Birlikte izleme</span>
        <h2 class="ln-h2">Uzaktan bile <span class="ln-grad">aynı kanepede</span></h2>
        <p class="ln-lead">Bir video aç, ayarlardan "Birlikte izle"ye bas. 6 haneli oda kodu ve link hazır; arkadaşların girince oynatma otomatik eşitlenir.</p>
        <ul class="ln-list">
          <li><i class="fa-solid fa-link"></i><span><b>Tek link:</b> giriş yapan herkes aynı odaya katılır (en fazla 30 kişi).</span></li>
          <li><i class="fa-solid fa-arrows-rotate"></i><span><b>Otomatik senkron:</b> oda sahibi durdurunca ya da ileri sarınca herkeste aynı olur.</span></li>
          <li><i class="fa-solid fa-comments"></i><span><b>Canlı sohbet:</b> izlerken oda içinde yaz, yeni mesajlar rozetle görünür.</span></li>
        </ul>
        <div class="ln-cta"><a class="ln-btn pri" href="<?= APP_URL ?>/auth.php?tab=register"><i class="fa-solid fa-door-open"></i> Oda kurmak için kayıt ol</a></div>
      </div>
      <div class="ln-mock ln-rv" style="--d:.15s" aria-hidden="true">
        <div class="ln-mock-bar"><i class="fa-solid fa-users-viewfinder"></i> Oda K7M2QX <em id="ln-viewers">3 kişi</em></div>
        <div class="ln-mock-v"><div class="ln-mock-pb"><i></i></div><span class="ln-mock-bm" style="left:34%"></span><span class="ln-mock-bm" style="left:71%"></span></div>
        <div class="ln-chat" id="ln-chat"></div>
      </div>
    </div>
  </section>

  <!-- ================= NASIL ÇALIŞIR ================= -->
  <section class="ln-sec">
    <div class="ln-wrap">
      <div class="ln-center ln-rv"><span class="ln-eyebrow"><i class="fa-solid fa-route"></i> Nasıl çalışır?</span><h2 class="ln-h2">Üç adımda <span class="ln-grad">başla</span></h2></div>
      <div class="ln-steps">
        <div class="ln-st ln-rv"><div class="ln-sn">1</div><h3>Üye ol</h3><p>E-posta ile ücretsiz kayıt ol, 18 yaş onayını ver. Bir dakikadan kısa sürer.</p></div>
        <div class="ln-st ln-rv" style="--d:.12s"><div class="ln-sn">2</div><h3>İzle ve topla</h3><p>Videoları izle, yer imi koy, reklamlardan token kazan, günlük görevleri tamamla.</p></div>
        <div class="ln-st ln-rv" style="--d:.24s"><div class="ln-sn">3</div><h3>Yüksel</h3><p>Tokenlerinle Premium al, rozetler ve çerçeveler aç, arkadaşlarınla oda kur.</p></div>
      </div>
    </div>
  </section>

  <!-- ================= TOKEN & PREMIUM ================= -->
  <section class="ln-sec" id="premium">
    <div class="ln-wrap">
      <div class="ln-center ln-rv"><span class="ln-eyebrow" style="color:#fbbf24;background:rgba(251,191,36,.1);border-color:rgba(251,191,36,.35)"><i class="fa-solid fa-crown"></i> Token &amp; Premium</span>
        <h2 class="ln-h2">Ödeme yapmadan <span class="ln-grad">Premium'a</span> ulaş</h2>
        <p class="ln-lead">Reklam izle, token kazan, tokenlerle Premium al. Kredi kartı gerekmez.</p></div>
      <div class="ln-prem">
        <div class="ln-pcard glow ln-rv">
          <span class="ln-eyebrow" style="color:#fde68a;background:rgba(251,191,36,.1);border-color:rgba(251,191,36,.3)"><i class="fa-solid fa-crown"></i> Premium · <?= (int)$tk['days'] ?> gün</span>
          <div class="ln-price"><b><?= (int)$tkPrice ?></b><span>token</span><?php if ($tkDisc && $tkPrice < $tk['price']): ?><s><?= (int)$tk['price'] ?></s><?php endif; ?></div>
          <?php if ($tkDisc && $tkPrice < $tk['price']): ?><span class="ln-disc"><i class="fa-solid fa-tags"></i> İndirim aktif<?= $tk['discount_note'] !== '' ? ' · ' . e($tk['discount_note']) : '' ?></span><?php endif; ?>
          <ul class="ln-pl">
            <li><i class="fa-solid fa-circle-check"></i> Premium'a özel erken erişimli videolar</li>
            <li><i class="fa-solid fa-circle-check"></i> Video indirme</li>
            <li><i class="fa-solid fa-circle-check"></i> Profil ve yorumlarda Premium rozeti</li>
            <li><i class="fa-solid fa-circle-check"></i> Otomatik yenileme seçeneği ve arkadaşına hediye etme</li>
          </ul>
          <div class="ln-cta"><a class="ln-btn pri" href="<?= APP_URL ?>/magaza.php"><i class="fa-solid fa-store"></i> Mağazaya git</a><a class="ln-btn gho" href="<?= APP_URL ?>/tokens.php"><i class="fa-solid fa-coins"></i> Token kazan</a></div>
        </div>
        <div class="ln-pcard ln-calc ln-rv" style="--d:.12s" data-per="<?= (int)$tk['per_ad'] ?>" data-max="<?= (int)$tk['daily_limit'] ?>" data-price="<?= (int)$tkPrice ?>" data-days="<?= (int)$tk['days'] ?>">
          <h3 style="font-size:22px;font-weight:800"><i class="fa-solid fa-calculator" style="color:var(--c1)"></i> Ne kadar sürer?</h3>
          <p style="color:var(--mut);font-size:14px;margin-top:6px">Günde kaç reklam izleyeceğini seç, Premium'a kaç günde ulaşacağını gör.</p>
          <label><span>Günlük reklam</span><b id="ln-ads-v">5</b></label>
          <input type="range" id="ln-ads" min="1" max="<?= max(1, (int)$tk['daily_limit']) ?>" value="<?= max(1, min(5, (int)$tk['daily_limit'])) ?>" aria-label="Günlük reklam sayısı">
          <div class="out"><b id="ln-out-d">–</b><span id="ln-out-t" style="color:var(--mut);font-size:14px"></span></div>
          <p style="color:var(--mut);font-size:12px;margin-top:14px;line-height:1.5">Reklam başına <?= (int)$tk['per_ad'] ?> token, günde en fazla <?= (int)$tk['daily_limit'] ?> reklam. Günlük giriş ve görev ödülleri ayrıca kazanılır.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ================= CANLI YORUMLAR ================= -->
  <section class="ln-sec" id="topluluk" hidden>
    <div class="ln-wrap">
      <div class="ln-center ln-rv"><span class="ln-eyebrow" style="color:#ff7ab8;background:rgba(255,45,149,.1);border-color:rgba(255,45,149,.35)"><i class="fa-solid fa-comments"></i> Topluluk</span>
        <h2 class="ln-h2">Şu an <span class="ln-grad">konuşulanlar</span></h2><p class="ln-lead">Sitede yazılan son yorumlar, canlı olarak.</p></div>
      <div class="ln-cm" id="ln-cm"></div>
    </div>
  </section>

  <!-- ================= ÇERÇEVE VİTRİNİ ================= -->
  <section class="ln-sec" id="cerceveler">
    <div class="ln-wrap">
      <div class="ln-center ln-rv"><span class="ln-eyebrow" style="color:#d946ef;background:rgba(191,0,255,.1);border-color:rgba(191,0,255,.35)"><i class="fa-solid fa-circle-user"></i> Profil çerçeveleri</span>
        <h2 class="ln-h2">Avatarın da <span class="ln-grad">ışık saçsın</span></h2>
        <p class="ln-lead">30'dan fazla animasyonlu çerçeve. Birine dokun, nasıl parladığını gör; yenileri mağazada ve etkinliklerde açılır.</p></div>
      <div class="ln-frames ln-rv">
        <?php
        $FR = [['Neon', '#00f5ff,#bf00ff'], ['Gün Batımı', '#ff9d00,#ff2d95'], ['Kristal', '#a5f3fc,#e879f9'], ['Orman', '#34d399,#22d3ee'], ['Lav', '#ef4444,#fbbf24'], ['Okyanus', '#3b82f6,#06b6d4']];
        foreach ($FR as $i => $fr): $cols = explode(',', $fr[1]); ?>
        <button type="button" class="ln-fr<?= $i === 0 ? ' sel' : '' ?>" style="--f1:<?= $cols[0] ?>;--f2:<?= $cols[1] ?>;--fd:<?= number_format(3 + $i * .6, 1) ?>s" aria-label="<?= e($fr[0]) ?> çerçeve örneği">
          <span class="ln-ring"><span class="ln-av"><i class="fa-solid fa-user"></i></span></span><em><?= e($fr[0]) ?></em>
        </button>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ================= ÜYE vs PREMIUM ================= -->
  <section class="ln-sec" id="karsilastir">
    <div class="ln-wrap">
      <div class="ln-center ln-rv"><span class="ln-eyebrow"><i class="fa-solid fa-scale-balanced"></i> Karşılaştırma</span><h2 class="ln-h2">Ücretsiz mi, <span class="ln-grad">Premium mu?</span></h2></div>
      <div class="ln-cmp ln-rv" role="table" aria-label="Ücretsiz ve Premium üyelik karşılaştırması">
        <div class="ln-cr hd" role="row"><span role="columnheader">Özellik</span><span role="columnheader">Ücretsiz</span><span role="columnheader" class="pr">Premium</span></div>
        <?php
        $CMP = [['Tüm herkese açık videoları izleme', 1, 1], ['Birlikte izleme odası kurma ve katılma', 1, 1], ['Sahne yer imleri ve devam et', 1, 1], ['Token kazanma ve görevler', 1, 1], ['Premium erken erişimli videolar', 0, 1], ['Video indirme', 0, 1], ['Profilde ve yorumlarda Premium rozeti', 0, 1]];
        foreach ($CMP as $row): ?>
        <div class="ln-cr" role="row"><span role="cell"><?= e($row[0]) ?></span>
          <span role="cell"><?= $row[1] ? '<i class="fa-solid fa-check ok" aria-label="Var"></i>' : '<i class="fa-solid fa-minus no" aria-label="Yok"></i>' ?></span>
          <span role="cell" class="pr"><?= $row[2] ? '<i class="fa-solid fa-check ok" aria-label="Var"></i>' : '<i class="fa-solid fa-minus no" aria-label="Yok"></i>' ?></span></div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ================= YENİLİKLER ================= -->
  <section class="ln-sec" id="yenilikler">
    <div class="ln-wrap">
      <div class="ln-center ln-rv"><span class="ln-eyebrow"><i class="fa-solid fa-rocket"></i> Yenilikler</span><h2 class="ln-h2">Durmadan <span class="ln-grad">geliştiriyoruz</span></h2></div>
      <ol class="ln-tl">
        <?php
        $TL = [
          ['Kasım 2026', 'Birlikte izleme odaları, sahne yer imleri ve oda içi canlı sohbet', 'fa-users-viewfinder'],
          ['Kasım 2026', 'Mini oynatıcı, video başına hız hatırlama ve takip akışı', 'fa-up-right-and-down-left-from-center'],
          ['Kasım 2026', 'Token mağazası, günlük görevler, rozetler ve profil vitrini', 'fa-coins'],
          ['Kasım 2026', 'KVKK araçları: veri indirme, hesap silme ve çerez tercihleri', 'fa-user-shield'],
        ];
        foreach ($TL as $i => $t): ?>
        <li class="ln-tli ln-rv" style="--d:<?= number_format($i * .08, 2) ?>s"><span class="ln-tld"><i class="fa-solid <?= e($t[2]) ?>"></i></span><div><small><?= e($t[0]) ?></small><p><?= e($t[1]) ?></p></div></li>
        <?php endforeach; ?>
      </ol>
    </div>
  </section>

  <!-- ================= KLAVYE ================= -->
  <section class="ln-sec" id="kisayollar" style="padding-top:20px">
    <div class="ln-wrap ln-center">
      <div class="ln-rv"><span class="ln-eyebrow"><i class="fa-solid fa-keyboard"></i> Kısayollar</span><h2 class="ln-h2">Elin klavyede <span class="ln-grad">kalsın</span></h2>
        <p class="ln-lead">Oynatıcıda tuşlara bas; kutular da senin basışına tepki verir.</p></div>
      <div class="ln-keys ln-rv">
        <?php foreach ([['Space', 'Oynat / durdur', ' '], ['←  →', '10 sn geri / ileri', 'ArrowRight'], ['M', 'Sesi kapat / aç', 'm'], ['F', 'Tam ekran', 'f'], ['L', 'Döngü', 'l'], ['B', 'Sahneye yer imi koy', 'b'], ['C', 'Altyazı', 'c'], ['?', 'Tüm kısayollar', '?']] as $k): ?>
        <div class="ln-k" data-key="<?= e($k[2]) ?>"><kbd><?= e($k[0]) ?></kbd><span><?= e($k[1]) ?></span></div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ================= GİZLİLİK ================= -->
  <section class="ln-sec" id="gizlilik">
    <div class="ln-wrap">
      <div class="ln-center ln-rv"><span class="ln-eyebrow" style="color:#34d399;background:rgba(52,211,153,.1);border-color:rgba(52,211,153,.35)"><i class="fa-solid fa-user-shield"></i> Gizlilik</span>
        <h2 class="ln-h2">Verilerin <span class="ln-grad">sende kalır</span></h2></div>
      <div class="ln-priv">
        <div class="ln-pv ln-rv"><i class="fa-solid fa-fingerprint"></i><h3>Ham IP yok</h3><p>Yalnızca tek yönlü özet saklanır; kim olduğun çıkarılamaz.</p></div>
        <div class="ln-pv ln-rv" style="--d:.08s"><i class="fa-solid fa-file-arrow-down"></i><h3>Verini indir</h3><p>Hesap sayfandan tüm verilerini tek tıkla dışa aktar.</p></div>
        <div class="ln-pv ln-rv" style="--d:.16s"><i class="fa-solid fa-trash-can"></i><h3>Hesabını sil</h3><p>İstediğin an kalıcı olarak sil; bağlı kayıtlar da temizlenir.</p></div>
        <div class="ln-pv ln-rv" style="--d:.24s"><i class="fa-solid fa-cookie-bite"></i><h3>Çerez tercihi</h3><p>Yalnızca zorunlu çerezlerle de kullanabilirsin; reklam çerezi yok.</p></div>
      </div>
    </div>
  </section>

  <!-- ================= SSS ================= -->
  <section class="ln-sec" id="sss">
    <div class="ln-wrap">
      <div class="ln-center ln-rv"><span class="ln-eyebrow"><i class="fa-solid fa-circle-question"></i> SSS</span><h2 class="ln-h2">Merak edilenler</h2></div>
      <div class="ln-faq ln-rv">
        <?php
        $Q = [
          ['NeonTV ücretsiz mi?', 'Evet, izlemek ve üye olmak ücretsiz. Premium isteğe bağlıdır ve para yerine reklam izleyerek kazandığın tokenlerle de alınabilir.'],
          ['Yaş sınırı var mı?', 'Evet. NeonTV yalnızca 18 yaş ve üzeri yetişkinler içindir. Siteye girişte ve kayıtta yaş onayı istenir.'],
          ['Token nasıl kazanılır?', 'Token sayfasında reklam izleyerek, her gün giriş yaparak (seri bonusuyla) ve günlük görevleri tamamlayarak token kazanırsın. Reklam başına ' . (int)$tk['per_ad'] . ' token, günde en fazla ' . (int)$tk['daily_limit'] . ' reklam.'],
          ['Birlikte izleme nasıl çalışır?', 'Bir videonun oynatıcı ayarlarından "Birlikte izle"yi seç. Oda linkini arkadaşlarına gönder. Oda sahibi oynattığında, durdurduğunda ya da ileri sardığında herkeste aynı olur. Katılmak için giriş yapmak gerekir.'],
          ['Yer imleri nerede duruyor?', 'Videoyu izlerken B tuşuna bas ya da ayarlardan "Yer imlerim"i aç. Tüm yer imlerini Kitaplığım → Yer İmleri sekmesinde görürsün; tıklayınca video o saniyeden açılır.'],
          ['Verilerim güvende mi?', 'Ham IP adresi saklanmaz, yalnızca tek yönlü özet tutulur. Hesap sayfandan tüm verilerini indirebilir veya hesabını kalıcı olarak silebilirsin. Ayrıntılar için Yasal Bilgiler sayfasına bak.'],
          ['Mobilde kullanabilir miyim?', 'Evet. Site telefon ve tabletlerde tam uyumlu çalışır. Uygulama sayfasından ana ekrana ekleme yönergelerine de ulaşabilirsin.'],
        ];
        foreach ($Q as $i => $q): ?>
        <div class="ln-q<?= $i === 0 ? ' open' : '' ?>"><button type="button" aria-expanded="<?= $i === 0 ? 'true' : 'false' ?>"><span><?= e($q[0]) ?></span><i class="fa-solid fa-plus"></i></button><div class="ln-qa"><div><p><?= e($q[1]) ?></p></div></div></div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ================= SON ÇAĞRI ================= -->
  <section class="ln-wrap">
    <div class="ln-final ln-rv">
      <h2>Hazırsan <span class="ln-grad">ışıklar açık</span></h2>
      <p class="ln-lead" style="margin:0 auto">Ücretsiz üye ol, ilk token'ını bugün kazan.</p>
      <div class="ln-cta">
        <a class="ln-btn pri" href="<?= APP_URL ?>/auth.php?tab=register"><i class="fa-solid fa-rocket"></i> Hemen Başla</a>
        <a class="ln-btn gho" href="<?= APP_URL ?>/index.php"><i class="fa-solid fa-play"></i> Videolara Göz At</a>
      </div>
      <p class="ln-small">Bu site yalnızca 18 yaş ve üzeri kişilere yöneliktir. Devam ederek <a href="<?= APP_URL ?>/yasal.php">Yasal Bilgiler</a>'i kabul etmiş olursun. Sorun mu var? <a href="<?= APP_URL ?>/iletisim.php">İletişim</a></p>
    </div>
  </section>
</main>
<button type="button" class="ln-top" id="ln-top" aria-label="Yukarı çık"><i class="fa-solid fa-arrow-up"></i></button>
<script>
/* ============================================================
   NeonTV landing — davranışlar (bağımlılık yok, ~tek dosya)
   Bölümler: yardımcılar · yıldızlar · ilerleme/yukarı · reveal · yazı döndürücü · SSS ·
   raylar · video önizleme yöneticisi · hero parallax · spot ışığı · canlı sayaçlar ·
   canlı akış/yorumlar · oda sohbeti demosu · hesaplayıcı · çerçeve vitrini
   ============================================================ */
(function () {
    'use strict';
    var BASE = <?= json_encode(rtrim(APP_URL, '/')) ?>, AGE_GATE = <?= $ageGateOn ? 'true' : 'false' ?>;
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var coarse = window.matchMedia && window.matchMedia('(hover: none)').matches;

    /* ---------- yardımcılar ---------- */
    function $(s, r) { return (r || document).querySelector(s); }
    function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function fmt(n) { return Math.round(n).toLocaleString('tr-TR'); }
    function ease(t) { return 1 - Math.pow(1 - t, 3); }
    function ageOk() {
        if (!AGE_GATE) return true;
        return /(?:^|;\s*)neontv_age_ok=1/.test(document.cookie) || (function () { try { return !!localStorage.getItem('neontv_age_ok'); } catch (e) { return false; } })();
    }
    function ago(ts) {
        var d = Math.max(0, Date.now() / 1000 - ts);
        if (d < 60) return 'az önce'; if (d < 3600) return Math.floor(d / 60) + ' dk önce';
        if (d < 86400) return Math.floor(d / 3600) + ' sa önce'; return Math.floor(d / 86400) + ' gün önce';
    }

    /* ---------- yıldız tozu ---------- */
    (function stars() {
        var box = $('#ln-stars'); if (!box || reduce) return;
        var n = window.innerWidth < 700 ? 28 : 64, frag = document.createDocumentFragment();
        for (var i = 0; i < n; i++) {
            var s = document.createElement('i'); s.className = 'ln-star';
            s.style.left = (Math.random() * 100) + '%'; s.style.top = (Math.random() * 100) + '%';
            s.style.setProperty('--d', (3 + Math.random() * 5).toFixed(1) + 's'); s.style.setProperty('--l', (-Math.random() * 8).toFixed(1) + 's');
            if (Math.random() > .8) { s.style.width = s.style.height = '3px'; s.style.background = '#67e8f9'; }
            frag.appendChild(s);
        }
        box.appendChild(frag);
    })();

    /* ---------- üst ilerleme çubuğu + yukarı çık ---------- */
    (function progress() {
        var bar = $('#ln-prog'), top = $('#ln-top'), tick = false;
        function upd() {
            var h = document.documentElement, max = h.scrollHeight - h.clientHeight, y = window.scrollY || h.scrollTop;
            if (bar) bar.style.width = (max > 0 ? Math.min(100, y / max * 100) : 0) + '%';
            if (top) top.classList.toggle('show', y > 900);
            tick = false;
        }
        window.addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(upd); } }, { passive: true });
        if (top) top.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' }); });
        upd();
    })();

    /* ---------- kaydırınca belirme ---------- */
    (function reveal() {
        var els = $$('.ln-rv');
        if (!('IntersectionObserver' in window) || reduce) { els.forEach(function (e) { e.classList.add('in'); }); return; }
        var io = new IntersectionObserver(function (es) {
            es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
        }, { threshold: .12, rootMargin: '0px 0px -40px 0px' });
        els.forEach(function (e) { io.observe(e); });
    })();

    /* ---------- başlıkta dönen kelime (daktilo) ---------- */
    (function typer() {
        var el = $('#ln-rot'); if (!el) return;
        var words; try { words = JSON.parse(el.getAttribute('data-words')); } catch (e) { return; }
        if (!words || !words.length || reduce) return;
        var wi = 0, ci = words[0].length, del = true;
        function step() {
            var w = words[wi];
            if (del) { ci--; el.textContent = w.slice(0, ci); if (ci <= 0) { del = false; wi = (wi + 1) % words.length; } setTimeout(step, 55); }
            else { var nw = words[wi]; ci++; el.textContent = nw.slice(0, ci); if (ci >= nw.length) { del = true; setTimeout(step, 1700); } else setTimeout(step, 95); }
        }
        setTimeout(step, 1800);
    })();

    /* ---------- SSS akordiyon ---------- */
    $$('.ln-q > button').forEach(function (b) {
        b.addEventListener('click', function () {
            var q = b.parentNode, open = !q.classList.contains('open');
            $$('.ln-q.open').forEach(function (o) { if (o !== q) { o.classList.remove('open'); o.firstElementChild.setAttribute('aria-expanded', 'false'); } });
            q.classList.toggle('open', open); b.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    });

    /* ---------- yatay raylar: oklar + fareyle sürükle ---------- */
    $$('.ln-nb').forEach(function (b) {
        b.addEventListener('click', function () {
            var r = document.getElementById(b.getAttribute('data-rail')); if (!r) return;
            r.scrollBy({ left: (+b.getAttribute('data-dir')) * Math.min(720, r.clientWidth * .8), behavior: reduce ? 'auto' : 'smooth' });
        });
    });
    $$('.ln-rail').forEach(function (r) {
        var down = false, sx = 0, sl = 0, moved = false;
        r.addEventListener('pointerdown', function (e) { if (e.pointerType !== 'mouse') return; down = true; moved = false; sx = e.clientX; sl = r.scrollLeft; });
        window.addEventListener('pointermove', function (e) {
            if (!down) return; var dx = e.clientX - sx; if (Math.abs(dx) > 4) { moved = true; r.classList.add('drag'); } r.scrollLeft = sl - dx;
        });
        window.addEventListener('pointerup', function () { if (down) { down = false; setTimeout(function () { r.classList.remove('drag'); }, 0); } });
        r.addEventListener('click', function (e) { if (moved) { e.preventDefault(); e.stopPropagation(); moved = false; } }, true);
    });

    /* ---------- raylar: klavye ile gezinme (odaktayken ← →) ---------- */
    $$('.ln-rail').forEach(function (r) {
        r.setAttribute('tabindex', '0'); r.setAttribute('role', 'region');
        r.addEventListener('keydown', function (e) {
            if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
            e.preventDefault(); r.scrollBy({ left: (e.key === 'ArrowRight' ? 1 : -1) * 360, behavior: reduce ? 'auto' : 'smooth' });
        });
    });

    /* ---------- video önizleme yöneticisi ----------
       Masaüstü: kartın üstüne gelince oynar. Dokunmatik: ekranın ortasına en yakın kart oynar.
       Aynı anda en fazla 2 video; sekme gizlenince hepsi durur; yaş onayı yoksa hiç başlamaz. */
    var Prev = (function () {
        var active = [], MAX = 2;
        function vid(card) { return card.querySelector('video'); }
        function play(card) {
            if (!ageOk() || card.classList.contains('on')) return;
            var v = vid(card); if (!v) return;
            if (!v.getAttribute('src')) { var s = v.getAttribute('data-src'); if (!s) return; v.src = s; v.preload = 'metadata'; }
            while (active.length >= MAX) stop(active[0]);
            var go = function () {
                try { if (v.duration && v.duration > 12) v.currentTime = Math.min(v.duration * .25, 30); } catch (e) {}
                var p = v.play(); if (p && p.then) p.then(function () { card.classList.add('on'); active.push(card); }).catch(function () { /* otomatik oynatma engellendi */ });
            };
            if (v.readyState >= 1) go(); else v.addEventListener('loadedmetadata', go, { once: true });
        }
        function stop(card) {
            var v = vid(card); if (v) { try { v.pause(); } catch (e) {} }
            card.classList.remove('on'); var i = active.indexOf(card); if (i > -1) active.splice(i, 1);
        }
        function stopAll() { active.slice().forEach(stop); }
        document.addEventListener('visibilitychange', function () { if (document.hidden) stopAll(); });
        return { play: play, stop: stop, stopAll: stopAll };
    })();
    (function bindPreviews() {
        var cards = $$('[data-ln-prev]');
        if (!coarse) {
            cards.forEach(function (c) {
                var t;
                c.addEventListener('mouseenter', function () { t = setTimeout(function () { Prev.play(c); }, 220); });
                c.addEventListener('mouseleave', function () { clearTimeout(t); Prev.stop(c); });
                c.addEventListener('focus', function () { Prev.play(c); }); c.addEventListener('blur', function () { Prev.stop(c); });
            });
        } else if ('IntersectionObserver' in window) {
            var vis = new Set(), pend = 0;
            var io = new IntersectionObserver(function (es) {
                es.forEach(function (e) { if (e.isIntersecting) vis.add(e.target); else { vis.delete(e.target); Prev.stop(e.target); } });
                if (!pend) pend = setTimeout(function () { pend = 0; pick(); }, 350);
            }, { threshold: [0, .6] });
            cards.forEach(function (c) { io.observe(c); });
            var pick = function () {
                var mid = window.innerHeight / 2, best = null, bd = 1e9;
                vis.forEach(function (c) { var r = c.getBoundingClientRect(), d = Math.abs(r.top + r.height / 2 - mid); if (r.height && d < bd) { bd = d; best = c; } });
                if (best && bd < window.innerHeight * .35) { Prev.stopAll(); Prev.play(best); } else Prev.stopAll();
            };
            window.addEventListener('scroll', function () { if (!pend) pend = setTimeout(function () { pend = 0; pick(); }, 350); }, { passive: true });
        }
        // Hero sahnesi: ilk kart sessizce kendiliğinden oynasın (yaş onayı varsa)
        var s1 = $('.ln-sc.s1[data-ln-prev]');
        if (s1) { var tryHero = function () { if (ageOk()) { s1.classList.add('on'); Prev.play(s1); if (!s1.classList.contains('on')) s1.classList.remove('on'); } }; setTimeout(tryHero, 1400); window.addEventListener('neontv-age-ok', tryHero); }
    })();

    /* ---------- hero: fare ile 3B eğim ---------- */
    (function parallax() {
        var st = $('#ln-stage'); if (!st || reduce || coarse) return;
        var cards = $$('.ln-sc', st), raf = 0, tx = 0, ty = 0;
        st.addEventListener('mousemove', function (e) {
            var r = st.getBoundingClientRect(); tx = (e.clientX - r.left) / r.width - .5; ty = (e.clientY - r.top) / r.height - .5;
            if (!raf) raf = requestAnimationFrame(apply);
        });
        st.addEventListener('mouseleave', function () { tx = ty = 0; if (!raf) raf = requestAnimationFrame(apply); });
        function apply() {
            raf = 0;
            cards.forEach(function (c, i) {
                var k = (i + 1) * 6; c.style.translate = (tx * k * -1).toFixed(1) + 'px ' + (ty * k * -1).toFixed(1) + 'px';
                c.style.rotate = (tx * (i % 2 ? -1.6 : 1.6)).toFixed(2) + 'deg';
            });
        }
    })();

    /* ---------- özellik kartlarında imleci izleyen ışık ---------- */
    $$('.ln-f').forEach(function (f) {
        f.addEventListener('mousemove', function (e) { var r = f.getBoundingClientRect(); f.style.setProperty('--mx', (e.clientX - r.left) + 'px'); f.style.setProperty('--my', (e.clientY - r.top) + 'px'); });
    });

    /* ---------- canlı sayaçlar ---------- */
    var Stats = (function () {
        var cur = {}, started = false;
        function tween(el, to) {
            var from = cur[el.getAttribute('data-k')] || 0; if (from === to && started) return;
            var t0 = performance.now(), dur = reduce ? 1 : (started ? 700 : 1600);
            cur[el.getAttribute('data-k')] = to;
            (function frame(now) {
                var p = Math.min(1, (now - t0) / dur); el.textContent = fmt(from + (to - from) * ease(p));
                if (p < 1) requestAnimationFrame(frame);
            })(t0);
        }
        function apply(d) {
            $$('.ln-num[data-k]').forEach(function (el) { var v = d[el.getAttribute('data-k')]; if (typeof v === 'number') tween(el, v); });
            var live = $('#ln-live-t');
            if (live) live.textContent = d.online > 0 ? d.online + ' kişi şu an sitede' : 'Şu an canlı';
            var vw = $('#ln-viewers'); if (vw) vw.textContent = '3 kişi';
            started = true;
        }
        return { apply: apply };
    })();

    /* ---------- canlı akış şeridi + yorum kartları ---------- */
    function renderTicker(items) {
        var box = $('#ln-tick'), inn = $('#ln-tick-in'); if (!box || !inn) return;
        if (!items.length) { box.hidden = true; return; }
        var html = items.map(function (r) {
            var href = BASE + '/video.php?id=' + encodeURIComponent(r.vid);
            return r.k === 'v'
                ? '<a class="ln-ti" href="' + href + '"><i class="fa-solid fa-circle-plus"></i><span><b>Yeni video:</b> ' + esc(r.t) + ' <small>· ' + ago(r.at) + '</small></span></a>'
                : '<a class="ln-ti" href="' + href + '"><i class="fa-solid fa-comment"></i><span><b>' + esc(r.u) + '</b> <span class="vt">' + esc(r.vt) + '</span> videosuna yazdı: “' + esc(r.t) + '” <small>· ' + ago(r.at) + '</small></span></a>';
        }).join('');
        inn.innerHTML = html + html; // sonsuz kayma için iki kopya
        box.hidden = false;
    }
    function renderComments(items) {
        var sec = $('#topluluk'), box = $('#ln-cm'); if (!sec || !box) return;
        var cs = items.filter(function (r) { return r.k === 'c' && r.t.length > 3; }).slice(0, 3);
        if (!cs.length) { sec.hidden = true; return; }
        sec.hidden = false;
        box.innerHTML = cs.map(function (r, i) {
            return '<a class="ln-cmc" style="animation-delay:' + (i * .12) + 's" href="' + BASE + '/video.php?id=' + encodeURIComponent(r.vid) + '"><q>' + esc(r.t) + '</q>' +
                '<footer><b>' + esc(r.u) + '</b><span>' + esc(r.vt) + '</span></footer></a>';
        }).join('');
    }
    function load() {
        fetch(BASE + '/api/landing_stats.php', { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
            if (!j || !j.success) return; var d = j.data || {};
            Stats.apply(d); renderTicker(d.recent || []); renderComments(d.recent || []);
        }).catch(function () { /* canlı veri alınamazsa sayfa statik kalır */ });
    }
    // Sayaçlar görünür olunca ilk yükleme; sonra 20 sn'de bir (sekme açıkken)
    (function liveInit() {
        var first = $('.ln-stats'); var started = false;
        function go() { if (started) return; started = true; load(); setInterval(function () { if (!document.hidden) load(); }, 20000); }
        if (!first || !('IntersectionObserver' in window)) { go(); return; }
        new IntersectionObserver(function (es, o) { if (es[0].isIntersecting) { o.disconnect(); go(); } }, { threshold: .1 }).observe(first);
        setTimeout(go, 3500); // hero'da hemen "kişi şu an sitede" görünsün
    })();

    /* ---------- oda sohbeti demosu (dekoratif, kayan örnek konuşma) ---------- */
    (function chatDemo() {
        var box = $('#ln-chat'); if (!box) return;
        var script = [['Ece', 'Başladı mı? 👀', 0], ['Mert', 'Evet, 2:10’dan itibaren', 0], ['Sen', 'Yer imi koydum, sonra dönelim 🔖', 1], ['Ece', 'Senkron çok iyi çalışıyor', 0], ['Sen', 'Oda sahibi durdurunca herkes durdu 😄', 1], ['Mert', 'Sonrakini ben açıyorum', 0]];
        var i = 0;
        function add() {
            var m = script[i % script.length]; i++;
            var d = document.createElement('div'); d.className = 'ln-bub' + (m[2] ? ' me' : ''); d.innerHTML = '<b>' + esc(m[0]) + '</b>' + esc(m[1]);
            box.appendChild(d); while (box.children.length > 5) box.removeChild(box.firstChild);
        }
        for (var k = 0; k < 3; k++) add();
        if (!reduce) setInterval(function () { if (!document.hidden) add(); }, 2600);
    })();

    /* ---------- premium hesaplayıcı ---------- */
    (function calc() {
        var root = $('.ln-calc'); if (!root) return;
        var per = +root.getAttribute('data-per'), price = +root.getAttribute('data-price'), days = +root.getAttribute('data-days');
        var r = $('#ln-ads'), v = $('#ln-ads-v'), od = $('#ln-out-d'), ot = $('#ln-out-t');
        function upd() {
            var n = +r.value, tokens = n * per; v.textContent = n;
            if (price <= 0 || tokens <= 0) { od.textContent = 'Hemen'; ot.textContent = 'Premium şu an ücretsiz'; return; }
            var d = Math.ceil(price / tokens);
            od.textContent = d + (d === 1 ? ' gün' : ' gün');
            ot.textContent = 'sonra ' + days + ' günlük Premium · günde ' + tokens + ' token';
        }
        r.addEventListener('input', upd); upd();
    })();

    /* ---------- çerçeve vitrini: kartlara tıklayınca halka rengi döner ---------- */
    $$('.ln-fr').forEach(function (f) {
        f.addEventListener('click', function () {
            $$('.ln-fr.sel').forEach(function (o) { o.classList.remove('sel'); });
            f.classList.add('sel');
        });
    });

    /* ---------- kısayol kutuları: gerçek tuş basışına tepki ---------- */
    (function keyDemo() {
        var boxes = $$('.ln-k'); if (!boxes.length) return;
        document.addEventListener('keydown', function (e) {
            var tg = (e.target.tagName || '').toLowerCase(); if (tg === 'input' || tg === 'textarea') return;
            var k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
            boxes.forEach(function (b) {
                var want = b.getAttribute('data-key');
                if (want === k || (want === 'ArrowRight' && k === 'ArrowLeft')) { b.classList.add('hit'); setTimeout(function () { b.classList.remove('hit'); }, 160); }
            });
        });
        boxes.forEach(function (b) { b.addEventListener('click', function () { b.classList.add('hit'); setTimeout(function () { b.classList.remove('hit'); }, 160); }); });
    })();

    /* ---------- bağlantılarda yumuşak kaydırma ---------- */
    $$('a[href^="#"]').forEach(function (a) {
        a.addEventListener('click', function (e) {
            var id = a.getAttribute('href'); if (id.length < 2) return; var t = $(id); if (!t) return;
            e.preventDefault(); t.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
        });
    });
})();
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
