-- ============================================================
-- NeonTV özellik paketi 10 (2026-11): Token sistemi, mağaza, kuponlar
-- Güvenli yeniden çalıştırılabilir. anon/authenticated erişimi KAPALI, yalnızca service_role.
-- ============================================================

CREATE TABLE IF NOT EXISTS public.token_wallets (
    user_id    uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    balance    integer NOT NULL DEFAULT 0 CHECK (balance >= 0),
    auto_renew boolean NOT NULL DEFAULT false,
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.token_ledger (
    id         bigserial PRIMARY KEY,
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    delta      integer NOT NULL,
    reason     text NOT NULL DEFAULT '',
    ref        text,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS token_ledger_user_idx ON public.token_ledger (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.ad_watch_sessions (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    ad_id      uuid,
    started_at timestamptz NOT NULL DEFAULT now(),
    claimed_at timestamptz,
    day        date NOT NULL DEFAULT ((now() AT TIME ZONE 'Europe/Istanbul')::date)
);
CREATE INDEX IF NOT EXISTS ad_watch_user_day_idx ON public.ad_watch_sessions (user_id, day);

CREATE TABLE IF NOT EXISTS public.premium_coupons (
    code        text PRIMARY KEY,
    description text NOT NULL DEFAULT '',
    percent     integer NOT NULL DEFAULT 0 CHECK (percent BETWEEN 0 AND 100),
    max_uses    integer,
    used_count  integer NOT NULL DEFAULT 0,
    starts_at   timestamptz,
    ends_at     timestamptz,
    is_active   boolean NOT NULL DEFAULT true,
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.coupon_redemptions (
    code        text NOT NULL REFERENCES public.premium_coupons(code) ON DELETE CASCADE,
    user_id     uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    redeemed_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (code, user_id)
);

-- Atomik bakiye değişimi: yetersiz bakiyede -1 döner.
CREATE OR REPLACE FUNCTION public.nv_token_adjust(p_user uuid, p_delta integer, p_reason text, p_ref text DEFAULT NULL)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE nb integer;
BEGIN
    INSERT INTO token_wallets (user_id, balance) VALUES (p_user, 0) ON CONFLICT (user_id) DO NOTHING;
    UPDATE token_wallets SET balance = balance + p_delta, updated_at = now()
     WHERE user_id = p_user AND balance + p_delta >= 0 RETURNING balance INTO nb;
    IF nb IS NULL THEN RETURN -1; END IF;
    INSERT INTO token_ledger (user_id, delta, reason, ref) VALUES (p_user, p_delta, p_reason, p_ref);
    RETURN nb;
END $$;

-- Reklam ödülü: oturum tek kullanımlık, günlük limit atomik kontrol edilir.
-- Dönüş: yeni bakiye | -1 limit doldu | -2 oturum geçersiz/kullanılmış | -3 süre dolmadı
CREATE OR REPLACE FUNCTION public.nv_ad_reward(p_user uuid, p_session uuid, p_amount integer, p_limit integer, p_min_seconds integer)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE s ad_watch_sessions%ROWTYPE; cnt integer; nb integer;
BEGIN
    PERFORM pg_advisory_xact_lock(hashtext(p_user::text));
    SELECT * INTO s FROM ad_watch_sessions WHERE id = p_session AND user_id = p_user FOR UPDATE;
    IF NOT FOUND OR s.claimed_at IS NOT NULL THEN RETURN -2; END IF;
    IF now() < s.started_at + make_interval(secs => p_min_seconds) THEN RETURN -3; END IF;
    SELECT count(*) INTO cnt FROM ad_watch_sessions WHERE user_id = p_user AND day = s.day AND claimed_at IS NOT NULL;
    IF cnt >= p_limit THEN RETURN -1; END IF;
    UPDATE ad_watch_sessions SET claimed_at = now() WHERE id = p_session;
    nb := nv_token_adjust(p_user, p_amount, 'ad_reward', p_session::text);
    RETURN nb;
END $$;

-- Kupon kullanımı: tek kullanıcı bir kuponu bir kez kullanır, limit atomik.
-- Dönüş: indirim yüzdesi | -1 geçersiz/bitmiş | -2 daha önce kullandın
CREATE OR REPLACE FUNCTION public.nv_coupon_use(p_user uuid, p_code text)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE c premium_coupons%ROWTYPE;
BEGIN
    SELECT * INTO c FROM premium_coupons WHERE code = upper(p_code) FOR UPDATE;
    IF NOT FOUND OR NOT c.is_active
       OR (c.starts_at IS NOT NULL AND now() < c.starts_at) OR (c.ends_at IS NOT NULL AND now() > c.ends_at)
       OR (c.max_uses IS NOT NULL AND c.used_count >= c.max_uses) THEN RETURN -1; END IF;
    IF EXISTS (SELECT 1 FROM coupon_redemptions WHERE code = c.code AND user_id = p_user) THEN RETURN -2; END IF;
    INSERT INTO coupon_redemptions (code, user_id) VALUES (c.code, p_user);
    UPDATE premium_coupons SET used_count = used_count + 1 WHERE code = c.code;
    RETURN c.percent;
END $$;

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['token_wallets','token_ledger','ad_watch_sessions','premium_coupons','coupon_redemptions'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('REVOKE ALL ON public.%I FROM anon, authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
  END LOOP;
END $$;
GRANT USAGE, SELECT ON SEQUENCE public.token_ledger_id_seq TO service_role;
REVOKE ALL ON FUNCTION public.nv_token_adjust(uuid,integer,text,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.nv_ad_reward(uuid,uuid,integer,integer,integer) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.nv_coupon_use(uuid,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.nv_token_adjust(uuid,integer,text,text) TO service_role;
GRANT EXECUTE ON FUNCTION public.nv_ad_reward(uuid,uuid,integer,integer,integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.nv_coupon_use(uuid,text) TO service_role;
