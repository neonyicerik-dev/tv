-- ============================================================
-- NeonTV özellik paketi 11 (2026-11): günlük giriş/görev, rozet, vitrin, video notları,
-- kampanyalar, Premium bitiş uyarısı, şüpheli token takibi. (features10 çalıştırıldıktan sonra)
-- ============================================================

ALTER TABLE public.ad_watch_sessions ADD COLUMN IF NOT EXISTS ip_hash text;
CREATE INDEX IF NOT EXISTS ad_watch_ip_idx ON public.ad_watch_sessions (ip_hash, day);

CREATE TABLE IF NOT EXISTS public.user_streaks (
    user_id   uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    last_date date NOT NULL,
    streak    integer NOT NULL DEFAULT 1,
    best      integer NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS public.user_badges (
    user_id   uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    badge     text NOT NULL,
    earned_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, badge)
);

CREATE TABLE IF NOT EXISTS public.profile_showcase (
    user_id  uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    position smallint NOT NULL CHECK (position BETWEEN 1 AND 3),
    video_id uuid NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, position)
);

CREATE TABLE IF NOT EXISTS public.video_notes (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id   uuid NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    at_second  integer NOT NULL CHECK (at_second >= 0),
    body       text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 200),
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS video_notes_video_idx ON public.video_notes (video_id, at_second);

CREATE TABLE IF NOT EXISTS public.premium_campaigns (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title      text NOT NULL,
    note       text NOT NULL DEFAULT '',
    percent    integer NOT NULL CHECK (percent BETWEEN 1 AND 100),
    starts_at  timestamptz NOT NULL,
    ends_at    timestamptz NOT NULL,
    is_active  boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.premium_warnings (
    user_id       uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    premium_until timestamptz NOT NULL,
    PRIMARY KEY (user_id, premium_until)
);

-- Aynı (kullanıcı, neden, referans) için ödül yalnızca bir kez verilir (günlük giriş, görev, rozet).
-- Dönüş: yeni bakiye | -2 daha önce alındı
CREATE OR REPLACE FUNCTION public.nv_reward_once(p_user uuid, p_amount integer, p_reason text, p_ref text)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM token_ledger WHERE user_id = p_user AND reason = p_reason AND ref = p_ref) THEN RETURN -2; END IF;
    PERFORM pg_advisory_xact_lock(hashtext(p_user::text));
    IF EXISTS (SELECT 1 FROM token_ledger WHERE user_id = p_user AND reason = p_reason AND ref = p_ref) THEN RETURN -2; END IF;
    RETURN nv_token_adjust(p_user, p_amount, p_reason, p_ref);
END $$;

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['user_streaks','user_badges','profile_showcase','video_notes','premium_campaigns','premium_warnings'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('REVOKE ALL ON public.%I FROM anon, authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
  END LOOP;
END $$;
REVOKE ALL ON FUNCTION public.nv_reward_once(uuid,integer,text,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.nv_reward_once(uuid,integer,text,text) TO service_role;
