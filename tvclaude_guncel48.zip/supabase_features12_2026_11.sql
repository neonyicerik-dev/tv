-- ============================================================
-- NeonTV özellik paketi 12 (2026-11): şikayetler, cihaz bilgisi, yaş onayı kaydı
-- ============================================================

CREATE TABLE IF NOT EXISTS public.content_reports (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    reporter_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    target_type text NOT NULL CHECK (target_type IN ('video','comment')),
    target_id   uuid NOT NULL,
    reason      text NOT NULL,
    details     text NOT NULL DEFAULT '',
    status      text NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved','dismissed')),
    handled_by  text,
    created_at  timestamptz NOT NULL DEFAULT now(),
    handled_at  timestamptz,
    UNIQUE (reporter_id, target_type, target_id)
);
CREATE INDEX IF NOT EXISTS content_reports_status_idx ON public.content_reports (status, created_at DESC);

ALTER TABLE public.login_events ADD COLUMN IF NOT EXISTS ua_label text;
ALTER TABLE public.login_events ADD COLUMN IF NOT EXISTS country_code text;

CREATE TABLE IF NOT EXISTS public.age_confirmations (
    id           bigserial PRIMARY KEY,
    ip_hash      text,
    ua_hash      text,
    source       text NOT NULL DEFAULT 'gate' CHECK (source IN ('gate','register')),
    version      text NOT NULL DEFAULT '',
    confirmed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS age_conf_time_idx ON public.age_confirmations (confirmed_at DESC);

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['content_reports','age_confirmations'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('REVOKE ALL ON public.%I FROM anon, authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
  END LOOP;
END $$;
GRANT USAGE, SELECT ON SEQUENCE public.age_confirmations_id_seq TO service_role;
