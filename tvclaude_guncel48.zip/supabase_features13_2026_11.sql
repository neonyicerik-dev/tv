-- NeonTV özellik paketi 13: kullanıcı işlem günlüğü + birlikte izleme odaları
-- Supabase → SQL Editor'da çalıştırın. Tüm tablolar yalnızca service_role erişimlidir (RLS açık, anon/authenticated yok).

-- 1) Kullanıcı işlem günlüğü (admin → Kullanıcı Logları). 90 günden eskisi otomatik silinir.
CREATE TABLE IF NOT EXISTS public.user_events (
  id         BIGSERIAL PRIMARY KEY,
  user_id    UUID NOT NULL,
  type       TEXT NOT NULL,
  text       TEXT NOT NULL,
  meta       JSONB NOT NULL DEFAULT '{}'::jsonb,
  ip_hash    TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS user_events_created_idx ON public.user_events (created_at DESC);
CREATE INDEX IF NOT EXISTS user_events_user_idx    ON public.user_events (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS user_events_type_idx    ON public.user_events (type, created_at DESC);

-- 2) Birlikte izleme odaları
CREATE TABLE IF NOT EXISTS public.watch_rooms (
  code       TEXT PRIMARY KEY,
  video_id   UUID NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
  host_id    UUID NOT NULL,
  pos        NUMERIC NOT NULL DEFAULT 0,
  playing    BOOLEAN NOT NULL DEFAULT FALSE,
  rate       NUMERIC NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS watch_rooms_host_idx ON public.watch_rooms (host_id);
CREATE TABLE IF NOT EXISTS public.watch_room_members (
  code    TEXT NOT NULL REFERENCES public.watch_rooms(code) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (code, user_id)
);

-- RLS: kimse doğrudan okuyamaz/yazamaz; yalnızca sunucu (service_role)
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['user_events','watch_rooms','watch_room_members'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('REVOKE ALL ON public.%I FROM anon, authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
  END LOOP;
END $$;
REVOKE ALL ON SEQUENCE public.user_events_id_seq FROM anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.user_events_id_seq TO service_role;
