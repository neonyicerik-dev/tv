-- NeonTV özellik paketi 14: sahne yer imleri + oda içi canlı sohbet + haftanın seçkisi (ayar JSON'u, tablo gerekmez)
-- Supabase → SQL Editor'da çalıştırın. Tablolar yalnızca service_role erişimli.

-- 1) Sahne yer imleri (kullanıcı başına video başına en fazla 30)
CREATE TABLE IF NOT EXISTS public.video_bookmarks (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL,
  video_id   UUID NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
  t          INTEGER NOT NULL CHECK (t >= 0),
  note       TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS video_bookmarks_user_idx ON public.video_bookmarks (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS video_bookmarks_vid_idx  ON public.video_bookmarks (user_id, video_id, t);

-- 2) Birlikte izleme odası sohbeti (oda silinince mesajlar da silinir)
CREATE TABLE IF NOT EXISTS public.watch_room_messages (
  id         BIGSERIAL PRIMARY KEY,
  code       TEXT NOT NULL REFERENCES public.watch_rooms(code) ON DELETE CASCADE,
  user_id    UUID NOT NULL,
  username   TEXT NOT NULL,
  body       TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS watch_room_messages_idx ON public.watch_room_messages (code, id);

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['video_bookmarks','watch_room_messages'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('REVOKE ALL ON public.%I FROM anon, authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
  END LOOP;
END $$;
REVOKE ALL ON SEQUENCE public.watch_room_messages_id_seq FROM anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.watch_room_messages_id_seq TO service_role;
