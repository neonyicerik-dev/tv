<?php
// NeonTV - Takip ettiklerim: kişi listesi + akış (son yorumlar, favori vitrinleri)
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Takip Ettiklerim'; $metaDesc = 'Takip ettiğin kişilerin son hareketleri.';
?>
<?php include __DIR__ . '/components/header.php'; ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 py-8">
    <h1 class="text-xl font-bold text-white mb-4"><i class="fa-solid fa-user-group text-pink-400 mr-2"></i>Takip Ettiklerim</h1>
    <div class="flex gap-2 mb-5 text-sm">
        <button type="button" data-t="feed" class="tk-tab px-4 py-1.5 rounded-full font-semibold">Akış</button>
        <button type="button" data-t="people" class="tk-tab px-4 py-1.5 rounded-full font-semibold">Kişiler</button>
    </div>
    <div id="tk-msg" class="text-gray-500 text-sm py-10 text-center">Yükleniyor...</div>
    <div id="tk-body"></div>
    <div class="text-center mt-6"><button id="tk-more" class="hidden px-6 py-2.5 rounded-full text-sm font-semibold text-black" style="background:#00f5ff">Daha fazla</button></div>
</div>
<style>.tk-tab{background:#13131f;color:#9ca3af;border:1px solid rgba(255,255,255,.1)}.tk-tab.on{background:#00f5ff;color:#000;border-color:#00f5ff}</style>
<script>
window.addEventListener('load', async function () {
    const BASE = '<?= APP_URL ?>', msg = document.getElementById('tk-msg'), body = document.getElementById('tk-body'), more = document.getElementById('tk-more');
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    let t = null; try { const { data } = await sbClient.auth.getSession(); t = data.session ? data.session.access_token : null; } catch (e) {}
    if (!t) { try { t = localStorage.getItem('sb_access_token'); } catch (e) {} }
    if (!t) { msg.innerHTML = 'Bu sayfa için <a class="text-cyan-400 underline" href="' + BASE + '/auth.php">giriş yap</a>.'; return; }
    let tab = 'feed', page = 1;
    const ago = s => { const d = (Date.now() - new Date(s).getTime()) / 1000; return d < 60 ? 'az önce' : d < 3600 ? Math.floor(d/60) + ' dk önce' : d < 86400 ? Math.floor(d/3600) + ' sa önce' : Math.floor(d/86400) + ' gün önce'; };
    const av = p => p.avatar_url ? '<img src="' + esc(p.avatar_url) + '" class="w-10 h-10 rounded-full object-cover" alt="">' : '<div class="w-10 h-10 rounded-full flex items-center justify-center font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff)">' + esc((p.username || 'U').charAt(0).toUpperCase()) + '</div>';
    async function load() {
        const j = await (await fetch(BASE + '/api/follow_feed.php?tab=' + tab + '&page=' + page + '&token=' + encodeURIComponent(t), { headers: { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t } })).json();
        const d = j.data || {};
        if (page === 1) body.innerHTML = '';
        if (!d.total) { msg.innerHTML = 'Henüz kimseyi takip etmiyorsun. Bir kullanıcı profilinden "Takip et" düğmesine bas.'; more.classList.add('hidden'); return; }
        msg.textContent = '';
        if (tab === 'people') {
            body.innerHTML = '<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">' + (d.people || []).map(p => '<a href="' + BASE + '/user.php?id=' + esc(p.id) + '" class="flex items-center gap-3 p-3 rounded-xl" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">' + av(p) + '<span class="text-white font-semibold truncate">' + esc(p.username) + '</span></a>').join('') + '</div>';
            more.classList.add('hidden'); return;
        }
        let h = '';
        if (page === 1 && (d.showcase || []).length) {
            h += '<h2 class="text-sm font-bold text-gray-300 mb-2">Favori vitrinleri</h2><div class="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">' + d.showcase.map(s => '<a href="' + BASE + '/video.php?id=' + esc(s.video.id) + '"><div class="rounded-xl overflow-hidden" style="aspect-ratio:16/9;background:#13131f"><img src="' + esc(s.video.thumbnail_url) + '" class="w-full h-full object-cover" loading="lazy" alt=""></div><p class="text-xs text-gray-400 mt-1 truncate"><span class="text-pink-300">' + esc(s.user) + '</span> · ' + esc(s.video.title) + '</p></a>').join('') + '</div>';
        }
        if (page === 1) h += '<h2 class="text-sm font-bold text-gray-300 mb-2">Son yorumlar</h2>';
        h += (d.comments || []).map(c => '<a href="' + BASE + '/video.php?id=' + esc(c.videos.id) + '#comment-' + esc(c.id) + '" class="flex gap-3 p-3 mb-2 rounded-xl" style="background:#13131f;border:1px solid rgba(255,255,255,.08)">' + av(c.profiles || {}) +
            '<div class="min-w-0"><p class="text-sm"><b class="text-white">' + esc((c.profiles || {}).username) + '</b> <span class="text-gray-500 text-xs">' + ago(c.created_at) + '</span></p><p class="text-sm text-gray-300 break-words">' + esc(c.content) + '</p><p class="text-xs text-cyan-400 mt-1 truncate"><i class="fa-solid fa-play mr-1"></i>' + esc(c.videos.title) + '</p></div></a>').join('');
        if (page === 1 && !(d.comments || []).length && !(d.showcase || []).length) h += '<p class="text-gray-500 text-sm">Takip ettiklerin henüz bir şey paylaşmamış.</p>';
        body.insertAdjacentHTML('beforeend', h);
        more.classList.toggle('hidden', !d.has_more);
    }
    function setTab(x) { tab = x; page = 1; document.querySelectorAll('.tk-tab').forEach(b => b.classList.toggle('on', b.dataset.t === x)); msg.textContent = 'Yükleniyor...'; load().catch(() => { msg.textContent = 'Yüklenemedi.'; }); }
    document.querySelectorAll('.tk-tab').forEach(b => b.onclick = () => setTab(b.dataset.t));
    more.onclick = () => { page++; load(); };
    setTab('feed');
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
