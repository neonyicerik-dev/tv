<?php
// NeonTV - Yasal metinler: yasal.php?s=kvkk|gizlilik|kullanim-kosullari|cerez|mesafeli-satis|on-bilgilendirme|iade|veri-silme
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/legal.php';
$docs = legalDocs(); $s = (string)($_GET['s'] ?? '');
if (!isset($docs[$s])) {
    $pageTitle = 'Yasal Bilgiler'; include __DIR__ . '/components/header.php';
    echo '<div class="max-w-screen-md mx-auto px-4 py-10"><h1 class="text-xl font-bold text-white mb-4">Yasal Bilgiler</h1><ul class="space-y-2">';
    foreach ($docs as $k => $d) echo '<li><a class="text-cyan-400 hover:underline" href="' . APP_URL . '/yasal.php?s=' . e($k) . '">' . e($d[0]) . '</a></li>';
    echo '</ul></div>'; include __DIR__ . '/components/footer.php'; exit;
}
$pageTitle = $docs[$s][0]; $metaDesc = $docs[$s][0] . ' - NeonTV';
include __DIR__ . '/components/header.php'; ?>
<style>.lg h2{font-size:1.05rem;font-weight:700;color:#fff;margin:1.4rem 0 .5rem}.lg p,.lg li{color:#cbd5e1;font-size:.9rem;line-height:1.65}.lg ul{list-style:disc;padding-left:1.3rem;margin:.4rem 0}.lg a{color:#00f5ff}.lg-t{width:100%;border-collapse:collapse;margin:.6rem 0;font-size:.85rem}.lg-t td,.lg-t th{border:1px solid rgba(255,255,255,.1);padding:7px 10px;color:#cbd5e1;text-align:left;vertical-align:top}.lg-t td:first-child{color:#9ca3af;width:32%}</style>
<div class="max-w-screen-md mx-auto px-4 sm:px-6 py-8 lg">
  <h1 class="text-2xl font-bold text-white mb-1"><?= e($docs[$s][0]) ?></h1>
  <p class="text-xs text-gray-500 mb-4">Sürüm: <?= e(LEGAL_VERSION) ?></p>
  <?= $docs[$s][1] ?>
  <p class="mt-8 text-xs text-gray-500"><a href="<?= APP_URL ?>/yasal.php">Tüm yasal metinler</a></p>
</div>
<?php include __DIR__ . '/components/footer.php'; ?>
