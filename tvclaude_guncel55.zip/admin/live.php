<?php
// NeonTV - Admin: Canlı panel (şu an çevrimiçi, son 24 saat saatlik grafik; 15 sn'de bir yenilenir)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/ip_log.php';
requireAdmin(['superadmin']);
date_default_timezone_set('Europe/Istanbul');

if (isset($_GET['data'])) {
    header('Content-Type: application/json'); header('Cache-Control: no-store');
    $d = Store::remember('admin_live', 10, function () {
        $db = new Supabase(); $now = time(); $since = gmdate('Y-m-d\TH:i:s\Z', $now - 24 * 3600);
        $sel = fn($t, $col, $extra = '') => (function () use ($db, $t, $col, $extra, $since) { $r = $db->select($t, $col . '=gte.' . $since . '&select=' . $col . $extra . '&order=' . $col . '.desc&limit=20000', true)['data'] ?? []; return is_array($r) ? $r : []; })();
        $series = ['views' => array_fill(0, 24, 0), 'users' => array_fill(0, 24, 0), 'comments' => array_fill(0, 24, 0), 'errors' => array_fill(0, 24, 0)];
        $slot = fn($ts) => 23 - (int)floor(($now - $ts) / 3600);
        $add = function (string $k, array $rows, string $col) use (&$series, $slot, $now) { foreach ($rows as $r) { $ts = strtotime($r[$col] ?? ''); if (!$ts) continue; $i = $slot($ts); if ($i >= 0 && $i < 24) $series[$k][$i]++; } };
        $views = $sel('views_log', 'created_at', ',video_id');
        $add('views', $views, 'created_at'); $add('users', $sel('profiles', 'created_at'), 'created_at'); $add('comments', $sel('comments', 'created_at'), 'created_at');
        $f = dirname(__DIR__) . '/logs/app_errors.log';
        if (is_file($f) && filesize($f) < 8 * 1048576) foreach (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $ln) { $j = json_decode($ln, true); if (!is_array($j) || empty($j['t'])) continue; $ts = strtotime($j['t']); if ($ts && $now - $ts < 86400) { $i = $slot($ts); if ($i >= 0 && $i < 24) $series['errors'][$i]++; } }
        $top = []; foreach ($views as $v) if (strtotime($v['created_at']) >= $now - 3600 && !empty($v['video_id'])) $top[$v['video_id']] = ($top[$v['video_id']] ?? 0) + 1;
        arsort($top); $top = array_slice($top, 0, 5, true); $tv = [];
        if ($top) foreach (($db->select('videos', 'id=in.(' . implode(',', array_keys($top)) . ')&select=id,title', true)['data'] ?? []) as $x) $tv[$x['id']] = $x['title'];
        $topOut = []; foreach ($top as $id => $n) $topOut[] = ['id' => $id, 'title' => $tv[$id] ?? 'Video', 'n' => $n];
        $labels = []; for ($i = 0; $i < 24; $i++) $labels[] = date('H', $now - (23 - $i) * 3600) . ':00';
        return ['online' => nvOnlineCount(300), 'series' => $series, 'labels' => $labels, 'top' => $topOut, 'at' => date('H:i:s', $now)];
    });
    echo json_encode($d, JSON_UNESCAPED_UNICODE); exit;
}
$adminTitle = 'Canlı Panel'; $adminSub = 'Son 24 saat · 15 saniyede bir otomatik yenilenir';
include __DIR__ . '/_top.php';
$card = 'background:#13131f;border:1px solid rgba(255,255,255,.08)';
?>
<div class="max-w-6xl space-y-5">
  <div class="grid grid-cols-2 md:grid-cols-4 gap-3" id="kpis"></div>
  <div class="grid lg:grid-cols-2 gap-4" id="charts"></div>
  <div class="rounded-2xl p-4" style="<?= $card ?>"><h3 class="text-sm font-bold text-white mb-2">Son 1 saatin en çok izlenenleri</h3><div id="top" class="text-sm text-gray-300"></div></div>
  <p class="text-[11px] text-gray-500">Son güncelleme: <span id="at">—</span></p>
</div>
<script>
const CH = [['views', 'İzlenme', '#00f5ff'], ['users', 'Yeni üye', '#22c55e'], ['comments', 'Yorum', '#bf00ff'], ['errors', 'Hata', '#ef4444']];
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function bars(arr, labels, col) {
    const mx = Math.max(1, ...arr), w = 100 / arr.length;
    return '<svg viewBox="0 0 100 40" preserveAspectRatio="none" style="width:100%;height:120px">' + arr.map((v, i) => { const h = v / mx * 36; return '<rect x="' + (i * w + .6) + '" y="' + (38 - h) + '" width="' + (w - 1.2) + '" height="' + Math.max(h, .4) + '" rx=".6" fill="' + col + '" opacity="' + (i === arr.length - 1 ? 1 : .65) + '"><title>' + labels[i] + ' → ' + v + '</title></rect>'; }).join('') + '</svg>' +
        '<div class="flex justify-between text-[10px] text-gray-500"><span>' + labels[0] + '</span><span>' + labels[12] + '</span><span>şimdi</span></div>';
}
async function load() {
    try {
        const j = await (await fetch('?data=1', { cache: 'no-store' })).json(), s = j.series, sum = a => a.reduce((x, y) => x + y, 0);
        document.getElementById('kpis').innerHTML = [['Şu an çevrimiçi', j.online, '#22c55e'], ['Son 1 saat izlenme', s.views[23], '#00f5ff'], ['24 saat yeni üye', sum(s.users), '#bf00ff'], ['Son 1 saat hata', s.errors[23], s.errors[23] ? '#ef4444' : '#9ca3af']]
            .map(k => '<div class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,.08)"><div class="text-[11px] text-gray-500">' + k[0] + '</div><div class="text-3xl font-black" style="color:' + k[2] + '">' + k[1] + '</div></div>').join('');
        document.getElementById('charts').innerHTML = CH.map(c => '<div class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,.08)"><div class="flex justify-between text-sm mb-2"><b class="text-white">' + c[1] + '</b><span class="text-gray-400">24 saat: ' + sum(s[c[0]]) + '</span></div>' + bars(s[c[0]], j.labels, c[2]) + '</div>').join('');
        document.getElementById('top').innerHTML = j.top.length ? j.top.map(t => '<div class="flex justify-between py-1 border-b border-white/5"><span class="truncate">' + esc(t.title) + '</span><b>' + t.n + '</b></div>').join('') : '<span class="text-gray-500">Son 1 saatte izlenme yok.</span>';
        document.getElementById('at').textContent = j.at;
    } catch (e) {}
}
load(); setInterval(() => { if (!document.hidden) load(); }, 15000);
</script>
<?php include __DIR__ . '/_bottom.php'; ?>
