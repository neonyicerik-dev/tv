<?php
// NeonTV - Admin: İzleyici tutma eğrisi (videonun hangi anında izleyici kaybı oluyor)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
requireAdmin(['editor', 'superadmin']);
$db = new Supabase(); $vid = trim((string)($_GET['id'] ?? '')); $q = trim((string)($_GET['q'] ?? ''));
$found = []; $video = null; $b = []; $chs = [];
if ($q !== '' && !isUuid($q)) $found = $db->select('videos', 'title=ilike.' . rawurlencode('*' . str_replace(['*', ',', '(', ')'], '', $q) . '*') . '&select=id,title,views&order=views.desc&limit=10', true)['data'] ?? [];
if ($q !== '' && isUuid($q)) $vid = $q;
if (isUuid($vid)) {
    $video = $db->first('videos', 'id=eq.' . $vid . '&select=id,title,duration,views', true);
    if ($video) {
        $b = array_fill(0, 100, 0);
        foreach (($db->select('video_replay_heat', 'video_id=eq.' . $vid . '&select=bucket,hits&limit=100', true)['data'] ?? []) as $r) { $i = (int)$r['bucket']; if ($i >= 0 && $i < 100) $b[$i] = (int)$r['hits']; }
        $chs = $db->select('chapters', 'video_id=eq.' . $vid . '&order=start_time.asc&select=title,start_time', true)['data'] ?? [];
    }
}
$adminTitle = 'İzleyici Tutma Eğrisi'; $adminSub = 'Her %1\'lik dilimde videoyu izleyen kişi sayısı (ilk dilime göre)';
include __DIR__ . '/_top.php';
$card = 'background:#13131f;border:1px solid rgba(255,255,255,.08)'; $inp = 'px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-sm text-white';
?>
<div class="max-w-4xl space-y-5">
  <form class="flex gap-2" method="get"><input name="q" value="<?= e($q) ?>" placeholder="Video adı ara veya ID yapıştır…" class="<?= $inp ?> flex-1"><button class="px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#00f5ff">Ara</button></form>
  <?php if ($found): ?><div class="rounded-2xl p-3" style="<?= $card ?>"><?php foreach ($found as $f): ?><a class="flex justify-between py-1.5 text-sm text-gray-200 hover:text-cyan-300" href="?id=<?= e($f['id']) ?>"><span class="truncate"><?= e($f['title']) ?></span><span class="text-gray-500"><?= (int)$f['views'] ?> izlenme</span></a><?php endforeach; ?></div><?php endif; ?>
  <?php if ($video): $start = max(1, $b[0]); $dur = (int)($video['duration'] ?? 0);
    $pct = array_map(fn($h) => min(100, round($h / $start * 100, 1)), $b);
    $drops = []; for ($i = 1; $i < 100; $i++) { $drops[] = [$i, $pct[$i - 1] - $pct[$i]]; } usort($drops, fn($x, $y) => $y[1] <=> $x[1]); $drops = array_slice(array_filter($drops, fn($d) => $d[1] > 0), 0, 5);
    $fmt = fn($p) => $dur ? gmdate($dur >= 3600 ? 'H:i:s' : 'i:s', (int)($dur * $p / 100)) : $p . '%';
    $avg = round(array_sum($pct) / 100, 1); ?>
  <div class="rounded-2xl p-4" style="<?= $card ?>"><h3 class="text-white font-bold mb-1"><?= e($video['title']) ?></h3>
    <?php if ($b[0] < 10): ?><p class="text-sm text-gray-500">Yeterli veri yok (en az 10 izleme başlangıcı gerekli). Şu an: <?= (int)$b[0] ?>.</p><?php else: ?>
    <p class="text-xs text-gray-500 mb-3"><?= (int)$b[0] ?> izleme başlangıcı · ortalama tutma %<?= $avg ?> · <b class="text-gray-300">%50 çizgisinin</b> altı çoğu izleyicinin ayrıldığı yerdir</p>
    <svg viewBox="0 0 100 50" preserveAspectRatio="none" style="width:100%;height:240px;background:rgba(255,255,255,.03);border-radius:12px">
      <line x1="0" y1="25" x2="100" y2="25" stroke="rgba(255,255,255,.12)" stroke-width=".3" stroke-dasharray="1.5 1.5"/>
      <?php foreach ($chs as $c): if ($dur && (int)$c['start_time'] > 0): $x = round((int)$c['start_time'] / $dur * 100, 2); ?><line x1="<?= $x ?>" y1="0" x2="<?= $x ?>" y2="50" stroke="#4a9bff" stroke-width=".3"><title><?= e($c['title']) ?></title></line><?php endif; endforeach; ?>
      <path d="M0,50 <?php foreach ($pct as $i => $v) echo 'L' . ($i + .5) . ',' . round(50 - $v / 2, 1) . ' '; ?>L100,50 Z" fill="rgba(74,155,255,.25)" stroke="#4a9bff" stroke-width=".6" vector-effect="non-scaling-stroke"/>
    </svg>
    <div class="flex justify-between text-[10px] text-gray-500 mt-1"><span>0:00</span><span><?= $fmt(50) ?></span><span><?= $fmt(100) ?></span></div>
    <h4 class="text-sm font-bold text-white mt-4 mb-1">En büyük 5 düşüş</h4>
    <?php foreach ($drops as $d): ?><div class="text-sm text-gray-300 py-1 border-b border-white/5">≈ <b><?= $fmt($d[0]) ?></b> civarı: <span class="text-red-300">−%<?= round($d[1], 1) ?></span> izleyici ayrıldı</div><?php endforeach; ?>
    <p class="text-[11px] text-gray-500 mt-3">Not: Aynı kişinin tekrar izlemeleri dilim başına en çok 3 sayıldığı için eğri 100'ün üstüne çıkarsa yukarıdan kırpılır; mavi çizgiler bölüm başlangıçlarıdır.</p>
    <?php endif; ?></div>
  <?php elseif (isUuid($vid)): ?><p class="text-sm text-gray-500">Video bulunamadı.</p><?php endif; ?>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
