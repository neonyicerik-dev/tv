<?php
// NeonTV - Admin: Durum sayfası ayarları, manuel olaylar, anlık kontrol
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/status_core.php';
requireAdmin(['superadmin']);
$db = new Supabase(); $self = APP_URL . '/admin/status.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect($self); }
    $act = input('action');
    if ($act === 'save') {
        foreach (['status_url' => 'status_url', 'site' => 'status_site_url', 'cdn' => 'status_cdn_url'] as $f => $k) {
            $v = rtrim(trim((string)input($f)), '/');
            if ($v !== '' && !preg_match('#^https?://[^\s"\'<>]+$#i', $v)) { setFlash('error', 'Adresler http:// veya https:// ile başlamalı.'); redirect($self); }
            Store::setSetting($k, $v);
        }
        Store::setSetting('status_banner_on', input('banner') ? '1' : '0');
        Store::clearCache('site_settings'); Store::clearCache('status_summary'); Store::clearCache('status_banner');
        setFlash('success', 'Ayarlar kaydedildi.');
    } elseif ($act === 'check') {
        $r = nvStatusRun(true); $m = [];
        foreach ($r as $k => $x) $m[] = strtoupper($k) . ': ' . ($x['ok'] ? 'çalışıyor' : 'KAPALI') . ' (' . $x['ms'] . ' ms' . ($x['code'] ? ', HTTP ' . $x['code'] : '') . ')';
        setFlash($r ? 'success' : 'error', $r ? implode(' · ', $m) : 'Önce site/CDN adresini girin.');
    } elseif ($act === 'incident') {
        $imp = in_array(input('impact'), ['minor', 'major', 'maintenance'], true) ? input('impact') : 'minor'; $t = mb_substr(trim((string)input('title')), 0, 140);
        if ($t !== '') { $db->insert('status_incidents', ['title' => $t, 'body' => mb_substr(trim((string)input('body')), 0, 800), 'impact' => $imp, 'state' => 'investigating', 'auto' => false], true); setFlash('success', 'Olay oluşturuldu.'); }
    } elseif ($act === 'state' && isUuid(input('id'))) {
        $st = in_array(input('state'), ['investigating', 'identified', 'monitoring', 'resolved'], true) ? input('state') : 'investigating';
        $u = ['state' => $st]; if ($st === 'resolved') $u['resolved_at'] = gmdate('Y-m-d\TH:i:s\Z');
        $b = trim((string)input('body')); if ($b !== '') $u['body'] = mb_substr($b, 0, 800);
        $db->update('status_incidents', $u, 'id=eq.' . input('id'), true); setFlash('success', 'Güncellendi.');
    } elseif ($act === 'del' && isUuid(input('id'))) { $db->delete('status_incidents', 'id=eq.' . input('id'), true); setFlash('success', 'Silindi.'); }
    Store::clearCache('status_summary'); Store::clearCache('status_banner');
    redirect($self);
}
$c = nvStatusCfg();
$inc = $db->select('status_incidents', 'order=started_at.desc&limit=15', true)['data'] ?? [];
$chk = $db->select('status_checks', 'order=checked_at.desc&limit=12', true)['data'] ?? [];
$adminTitle = 'Durum Sayfası'; $adminSub = 'Site ve CDN çalışma durumu · ayrı yayınlanan status/ sayfası';
include __DIR__ . '/_top.php';
$card = 'background:#13131f;border:1px solid rgba(255,255,255,.08)'; $inp = 'w-full px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-sm text-white';
?>
<div class="grid lg:grid-cols-2 gap-5 max-w-5xl">
 <div class="space-y-5">
  <form method="post" class="rounded-2xl p-4 space-y-3" style="<?= $card ?>"><?= csrfField() ?><input type="hidden" name="action" value="save">
    <div><label class="block text-[11px] text-gray-500 mb-1">Durum sayfası adresi (status/ klasörünün yayınlandığı yer)</label><input name="status_url" value="<?= e($c['status_url']) ?>" placeholder="https://status.ornek.com" class="<?= $inp ?>"></div>
    <div><label class="block text-[11px] text-gray-500 mb-1">Site adresi (izlenecek)</label><input name="site" value="<?= e($c['site']) ?>" placeholder="https://neontvapp.dpdns.org" class="<?= $inp ?>"></div>
    <div><label class="block text-[11px] text-gray-500 mb-1">CDN adresi (izlenecek)</label><input name="cdn" value="<?= e($c['cdn']) ?>" placeholder="https://cdn.neontvapp.dpdns.org" class="<?= $inp ?>"></div>
    <label class="flex items-center gap-2 text-sm text-gray-300"><input type="checkbox" name="banner" value="1" <?= $c['banner'] ? 'checked' : '' ?>> Sorun olunca sitenin üstünde uyarı şeridi göster</label>
    <button class="px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#00f5ff">Kaydet</button></form>
  <form method="post" class="rounded-2xl p-4" style="<?= $card ?>"><?= csrfField() ?><input type="hidden" name="action" value="check">
    <button class="px-4 py-2 rounded-lg text-sm font-bold text-white bg-white/10">Şimdi kontrol et</button>
    <p class="text-[11px] text-gray-500 mt-2">Otomatik kontrol: site ziyaret edildikçe (90 sn'de bir). Sürekli izleme için cron: <code class="text-gray-400">* * * * * php <?= e(dirname(__DIR__)) ?>/status/check.php</code></p>
    <?php foreach ($chk as $k): ?><div class="text-xs py-1 border-b border-white/5 flex gap-3 text-gray-400"><span class="w-10"><?= e($k['target']) ?></span><span class="<?= $k['ok'] ? 'text-green-400' : 'text-red-400' ?>"><?= $k['ok'] ? 'çalışıyor' : 'kapalı' ?></span><span><?= (int)$k['ms'] ?> ms</span><span class="ml-auto"><?= e(date('d.m H:i:s', strtotime($k['checked_at']))) ?></span></div><?php endforeach; ?></form>
 </div>
 <div class="space-y-5">
  <form method="post" class="rounded-2xl p-4 space-y-2" style="<?= $card ?>"><?= csrfField() ?><input type="hidden" name="action" value="incident">
    <h3 class="text-sm font-bold text-white">Manuel olay / bakım duyurusu</h3>
    <input name="title" maxlength="140" placeholder="Örn: Video yüklemede yavaşlık" class="<?= $inp ?>"><textarea name="body" rows="2" maxlength="800" placeholder="Açıklama" class="<?= $inp ?>"></textarea>
    <select name="impact" class="<?= $inp ?>"><option value="minor">Küçük etki</option><option value="major">Büyük kesinti</option><option value="maintenance">Planlı bakım</option></select>
    <button class="px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#00f5ff">Yayınla</button></form>
  <div class="rounded-2xl p-4" style="<?= $card ?>"><h3 class="text-sm font-bold text-white mb-2">Olaylar</h3>
   <?php foreach ($inc as $i): $open = empty($i['resolved_at']); ?>
   <form method="post" class="py-2 border-b border-white/5 text-sm space-y-1"><?= csrfField() ?><input type="hidden" name="id" value="<?= e($i['id']) ?>">
     <div class="flex gap-2"><span class="<?= $open ? 'text-yellow-300' : 'text-green-400' ?> flex-1"><?= e($i['title']) ?><?= !empty($i['auto']) ? ' <small class="text-gray-500">(otomatik)</small>' : '' ?></span><button name="action" value="del" class="text-red-400 text-xs" onclick="return confirm('Silinsin mi?')">sil</button></div>
     <div class="text-[11px] text-gray-500"><?= e(date('d.m H:i', strtotime($i['started_at']))) ?> · <?= e($i['impact']) ?> · <?= e($i['state']) ?></div>
     <?php if ($open): ?><div class="flex gap-1"><input name="body" placeholder="Güncelleme notu" class="<?= $inp ?> !py-1 text-xs"><select name="state" class="<?= $inp ?> !w-auto !py-1 text-xs"><option value="identified">Belirlendi</option><option value="monitoring">İzleniyor</option><option value="resolved">Çözüldü</option></select><button name="action" value="state" class="px-2 text-xs text-cyan-300">Uygula</button></div><?php endif; ?></form>
   <?php endforeach; if (!$inc): ?><p class="text-sm text-gray-500">Kayıtlı olay yok.</p><?php endif; ?></div>
 </div>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
