<?php
// Sahne yer imleri
// GET    ?video_id=UUID  -> bu videodaki yer imlerim
// GET    ?all=1          -> tüm yer imlerim (video bilgisiyle)
// POST   {video_id, t, note?}  -> ekle (aynı saniyenin ±2 sn'sinde varsa eklemez)
// DELETE ?id=UUID        -> sil
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/userlog.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id']; $m = $_SERVER['REQUEST_METHOD'];

if ($m === 'GET' && !empty($_GET['all'])) {
    $r = $db->select('video_bookmarks', 'user_id=eq.' . $uid . '&order=created_at.desc&limit=200&select=id,t,note,created_at,videos(id,title,thumbnail_url,duration,status)', true)['data'] ?? [];
    $out = array_values(array_filter(is_array($r) ? $r : [], fn($x) => ($x['videos']['status'] ?? '') === 'published'));
    jsonSuccess(['items' => $out]);
}
if ($m === 'GET') {
    $vid = trim($_GET['video_id'] ?? ''); requireUuid($vid, 'Video ID');
    $r = $db->select('video_bookmarks', 'user_id=eq.' . $uid . '&video_id=eq.' . $vid . '&order=t.asc&limit=30&select=id,t,note', true)['data'] ?? [];
    jsonSuccess(['items' => is_array($r) ? $r : []]);
}
if ($m === 'POST') {
    denyIfBanned($db, $uid);
    $in = inputJson() ?? []; $vid = trim((string)($in['video_id'] ?? '')); requireUuid($vid, 'Video ID');
    $t = max(0, min(86400, (int)floor((float)($in['t'] ?? 0))));
    $note = mb_substr(trim(strip_tags((string)($in['note'] ?? ''))), 0, 80);
    $cur = $db->select('video_bookmarks', 'user_id=eq.' . $uid . '&video_id=eq.' . $vid . '&select=id,t&limit=40', true)['data'] ?? [];
    $cur = is_array($cur) ? $cur : [];
    foreach ($cur as $c) { if (abs((int)$c['t'] - $t) <= 2) jsonError('Bu saniyede zaten bir yer imin var.'); }
    if (count($cur) >= 30) jsonError('Bu videoda en fazla 30 yer imi koyabilirsin.');
    $r = $db->insert('video_bookmarks', ['user_id' => $uid, 'video_id' => $vid, 't' => $t, 'note' => $note !== '' ? $note : null], true);
    if (($r['status'] ?? 500) >= 400) jsonError(($r['status'] ?? 0) == 409 || strpos(json_encode($r), 'foreign') !== false ? 'Video bulunamadı' : 'Kaydedilemedi (SQL 14 çalıştı mı?)', 500);
    $row = $r['data'][0] ?? ['id' => '', 't' => $t, 'note' => $note];
    nvLog($db, $uid, 'library', function () use ($db, $vid, $t) { $tt = nvVideoTitle($db, $vid); return 'Sahne yer imi ekledi: ' . ($tt !== '' ? $tt : $vid) . ' @' . gmdate($t >= 3600 ? 'G:i:s' : 'i:s', $t); }, ['video_id' => $vid, 't' => $t]);
    jsonSuccess(['item' => ['id' => $row['id'] ?? '', 't' => (int)($row['t'] ?? $t), 'note' => $row['note'] ?? null]]);
}
if ($m === 'DELETE') {
    $id = trim($_GET['id'] ?? ''); requireUuid($id, 'Yer imi');
    $db->delete('video_bookmarks', 'id=eq.' . $id . '&user_id=eq.' . $uid, true);
    jsonSuccess([], 'Silindi');
}
jsonError('Geçersiz metod', 405);
