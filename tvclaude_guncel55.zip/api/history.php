<?php
// ============================================================
// NeonTV - İzleme Geçmişi API
// POST   {video_id, position, duration}  -> konum kaydet
// GET    ?video_id=..                    -> o videonun kayıtlı konumu
// DELETE ?video_id=.. | ?all=1           -> sil
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/userlog.php';
error_reporting(0); ini_set('display_errors', 0);

$db   = new Supabase();
$user = requireUserApi($db);
$uid  = $user['id'];
$m    = $_SERVER['REQUEST_METHOD'];

if ($m === 'GET' && !empty($_GET['list'])) {
    $r = $db->select('watch_history', 'user_id=eq.' . $uid . '&order=watched_at.desc&limit=100&select=position_seconds,duration_seconds,watched_at,videos(id,title,thumbnail_url,duration,views,status)', true);
    $out = [];
    foreach (($r['data'] ?? []) as $row) { if (!empty($row['videos']) && ($row['videos']['status'] ?? '') === 'published') $out[] = $row; }
    jsonSuccess(['items' => $out]);
}
if ($m === 'GET') {
    $vid = trim($_GET['video_id'] ?? '');
    requireUuid($vid, 'Video ID');
    $r = $db->first('watch_history', 'user_id=eq.' . $uid . '&video_id=eq.' . $vid, true);
    jsonSuccess(['position' => (int)($r['position_seconds'] ?? 0), 'duration' => (int)($r['duration_seconds'] ?? 0)]);
}

if ($m === 'POST') {
    $in  = inputJson() ?? [];
    $vid = trim($in['video_id'] ?? '');
    requireUuid($vid, 'Video ID');
    $pos = max(0, min(86400, (int)floor((float)($in['position'] ?? 0))));
    $dur = max(0, min(86400, (int)floor((float)($in['duration'] ?? 0))));
    // Bitmeye 10 sn kala veya bitti ise konumu sıfırla (baştan başlasın)
    if ($dur > 0 && $pos >= $dur - 10) $pos = 0;
    $now = gmdate('Y-m-d\TH:i:s\Z');
    $ex  = $db->first('watch_history', 'user_id=eq.' . $uid . '&video_id=eq.' . $vid . '&select=video_id,watched_at', true);
    // Log: ilk izleme veya son kayıttan 30 dk+ sonra yeni izleme oturumu
    if (!$ex || (strtotime($ex['watched_at'] ?? '') ?: 0) < time() - 1800) {
        nvLog($db, $uid, 'watch', function () use ($db, $vid) { $tt = nvVideoTitle($db, $vid); return 'Videoyu izledi: ' . ($tt !== '' ? $tt : $vid); }, ['video_id' => $vid, 'position' => $pos]);
    }
    if ($ex) {
        $db->update('watch_history', ['position_seconds' => $pos, 'duration_seconds' => $dur, 'watched_at' => $now],
            'user_id=eq.' . $uid . '&video_id=eq.' . $vid, true);
    } else {
        $db->insert('watch_history', ['user_id' => $uid, 'video_id' => $vid, 'position_seconds' => $pos,
            'duration_seconds' => $dur, 'watched_at' => $now], true);
    }
    jsonSuccess([], 'Kaydedildi');
}

if ($m === 'DELETE') {
    if (!empty($_GET['all'])) {
        $db->delete('watch_history', 'user_id=eq.' . $uid, true);
    } else {
        $vid = trim($_GET['video_id'] ?? '');
        requireUuid($vid, 'Video ID');
        $db->delete('watch_history', 'user_id=eq.' . $uid . '&video_id=eq.' . $vid, true);
    }
    jsonSuccess([], 'Silindi');
}
jsonError('Geçersiz metod', 405);
