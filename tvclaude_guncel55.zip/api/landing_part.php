<?php
// Landing sayfası bölümleri (aşamalı yükleme). GET ?p=picks|trend|latest|tags  ->  {html}
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/picks.php';
require_once __DIR__ . '/../includes/landing_cards.php';
error_reporting(0); ini_set('display_errors', 0);
header('Cache-Control: public, max-age=30');
$p = (string)($_GET['p'] ?? '');
$sel = 'id,title,thumbnail_url,video_url,duration,views,created_at';
$db = new Supabase();
$html = Store::remember('landing_part_' . $p, 120, function () use ($p, $db, $sel) {
    $out = '';
    if ($p === 'picks') {
        [$v] = nvPicksVideos(8); foreach ($v as $i => $x) $out .= lnCard($x, $i + 1);
    } elseif ($p === 'trend' || $p === 'latest') {
        $ord = $p === 'trend' ? 'views.desc' : 'created_at.desc';
        $r = $db->select('videos', 'status=eq.published&order=' . $ord . '&limit=4&select=' . $sel)['data'] ?? [];
        foreach ((is_array($r) ? $r : []) as $x) $out .= lnCard($x);
    } elseif ($p === 'tags') {
        $r = $db->select('videos', 'status=eq.published&order=created_at.desc&limit=80&select=tags')['data'] ?? [];
        $cnt = [];
        foreach ((is_array($r) ? $r : []) as $row) foreach ((array)($row['tags'] ?? []) as $t) { $t = trim((string)$t); if ($t !== '' && mb_strlen($t) <= 24) $cnt[$t] = ($cnt[$t] ?? 0) + 1; }
        arsort($cnt); $ti = 0;
        foreach (array_slice($cnt, 0, 16, true) as $tg => $n) $out .= '<a class="ln-tg" style="--tl:-' . number_format($ti++ * .45, 2) . 's" href="' . APP_URL . '/index.php?tag=' . rawurlencode($tg) . '">#' . e($tg) . '<small>' . (int)$n . '</small></a>';
    }
    return $out;
});
if (!in_array($p, ['picks', 'trend', 'latest', 'tags'], true)) jsonError('Geçersiz bölüm');
jsonSuccess(['html' => $html]);
