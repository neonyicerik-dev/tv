<?php
// Landing sayfası canlı verileri (herkese açık, 20 sn önbellekli)
// -> {videos, members, comments, views, online, recent:[{k:'c'|'v', u, t, vid, at}]}
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/ip_log.php';
error_reporting(0); ini_set('display_errors', 0);
header('Cache-Control: public, max-age=15');
$d = Store::remember('landing_stats', 20, function () {
    $db = new Supabase();
    $views = Store::remember('landing_views_sum', 600, function () use ($db) {
        $r = $db->select('videos', 'status=eq.published&select=views&limit=5000', true)['data'] ?? [];
        $s = 0; foreach ((is_array($r) ? $r : []) as $x) $s += (int)($x['views'] ?? 0); return $s;
    });
    $cm = $db->select('comments', 'order=created_at.desc&limit=8&select=content,created_at,video_id,profiles(username),videos(id,title,status)', true)['data'] ?? [];
    $nv = $db->select('videos', 'status=eq.published&order=created_at.desc&limit=4&select=id,title,created_at', true)['data'] ?? [];
    $recent = [];
    foreach ((is_array($cm) ? $cm : []) as $c) {
        if (($c['videos']['status'] ?? '') !== 'published') continue;
        $recent[] = ['k' => 'c', 'u' => $c['profiles']['username'] ?? 'Üye', 't' => nvPlainComment((string)$c['content'], 70), 'vid' => $c['videos']['id'], 'vt' => mb_substr($c['videos']['title'], 0, 50), 'at' => strtotime($c['created_at'])];
    }
    foreach ((is_array($nv) ? $nv : []) as $v) $recent[] = ['k' => 'v', 'u' => '', 't' => mb_substr($v['title'], 0, 70), 'vid' => $v['id'], 'vt' => '', 'at' => strtotime($v['created_at'])];
    usort($recent, fn($a, $b) => $b['at'] <=> $a['at']);
    return ['videos' => $db->count('videos', 'status=eq.published', true), 'members' => $db->count('profiles', '', true),
        'comments' => $db->count('comments', '', true), 'views' => $views, 'recent' => array_slice($recent, 0, 10)];
});
$d['online'] = function_exists('nvOnlineCount') ? nvOnlineCount() : 0;
jsonSuccess($d);
