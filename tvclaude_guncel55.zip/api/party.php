<?php
// Birlikte izleme odası (senkron oynatma; basit yoklama/polling)
// POST {action:"create", video_id}            -> {code}
// GET  ?code=ABC123                            -> {video_id, pos, playing, rate, age, host, viewers}
// POST {action:"state", code, pos, playing, rate}  (yalnızca oda sahibi)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/userlog.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id'];
$m = $_SERVER['REQUEST_METHOD'];
$codeOk = fn($c) => is_string($c) && preg_match('/^[A-Z2-9]{6}$/', $c);

if ($m === 'GET') {
    $code = strtoupper(trim($_GET['code'] ?? '')); if (!$codeOk($code)) jsonError('Geçersiz oda kodu');
    $r = $db->first('watch_rooms', 'code=eq.' . $code, true);
    if (!$r) jsonError('Oda bulunamadı veya süresi doldu', 404);
    $age = max(0, time() - strtotime($r['updated_at']));
    if ($age > 6 * 3600) jsonError('Oda süresi doldu', 410);
    // Katılımcı kaydı (en fazla 30 kişi)
    $ex = $db->first('watch_room_members', 'code=eq.' . $code . '&user_id=eq.' . $uid . '&select=user_id', true);
    $now = gmdate('Y-m-d\TH:i:s\Z');
    if ($ex) $db->update('watch_room_members', ['seen_at' => $now], 'code=eq.' . $code . '&user_id=eq.' . $uid, true);
    else {
        if ($db->count('watch_room_members', 'code=eq.' . $code, true) >= 30) jsonError('Oda dolu (en fazla 30 kişi)');
        $db->insert('watch_room_members', ['code' => $code, 'user_id' => $uid], true);
        if ($uid !== $r['host_id']) nvLog($db, $uid, 'party', 'Birlikte izleme odasına katıldı: ' . $code, ['code' => $code, 'video_id' => $r['video_id']]);
    }
    $viewers = $db->count('watch_room_members', 'code=eq.' . $code . '&seen_at=gte.' . rawurlencode(gmdate('Y-m-d\TH:i:s\Z', time() - 15)), true);
    jsonSuccess(['video_id' => $r['video_id'], 'pos' => (float)$r['pos'], 'playing' => (bool)$r['playing'], 'rate' => (float)$r['rate'],
        'age' => $age, 'host' => $r['host_id'] === $uid, 'viewers' => max(1, $viewers)]);
}
if ($m !== 'POST') jsonError('Geçersiz metod', 405);
denyIfBanned($db, $uid);
$in = inputJson() ?? []; $act = $in['action'] ?? '';

if ($act === 'create') {
    $vid = trim((string)($in['video_id'] ?? '')); requireUuid($vid, 'Video ID');
    $alpha = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; $code = '';
    // Hızlı yol: tek INSERT (video yoksa FK reddeder). Temizlik ve log yanıttan SONRA yapılır.
    for ($try = 0; $try < 4; $try++) {
        $code = ''; for ($i = 0; $i < 6; $i++) $code .= $alpha[random_int(0, strlen($alpha) - 1)];
        $r = $db->insert('watch_rooms', ['code' => $code, 'video_id' => $vid, 'host_id' => $uid, 'updated_at' => gmdate('Y-m-d\TH:i:s\Z')], true);
        if (($r['status'] ?? 500) < 400) {
            nvLog($db, $uid, 'party', function () use ($db, $uid, $vid, $code) {
                // Kullanıcı başına en fazla 3 aktif oda: eskileri sil
                $mine = $db->select('watch_rooms', 'host_id=eq.' . $uid . '&order=created_at.desc&select=code', true)['data'] ?? [];
                foreach (array_slice(is_array($mine) ? $mine : [], 3) as $o) $db->delete('watch_rooms', 'code=eq.' . $o['code'], true);
                $tt = nvVideoTitle($db, $vid);
                return 'Birlikte izleme odası açtı: ' . $code . ' · ' . ($tt !== '' ? $tt : $vid);
            }, ['code' => $code, 'video_id' => $vid]);
            jsonSuccess(['code' => $code]);
        }
        if (($r['status'] ?? 0) != 409) break;
    }
    jsonError('Oda oluşturulamadı (video bulunamadı ya da SQL 13 çalışmadı)', 500);
}
if ($act === 'state') {
    $code = strtoupper(trim((string)($in['code'] ?? ''))); if (!$codeOk($code)) jsonError('Geçersiz oda kodu');
    $r = $db->first('watch_rooms', 'code=eq.' . $code . '&select=host_id', true);
    if (!$r) jsonError('Oda yok', 404);
    if ($r['host_id'] !== $uid) jsonError('Yalnızca oda sahibi kontrol edebilir', 403);
    $db->update('watch_rooms', ['pos' => max(0, min(86400, (float)($in['pos'] ?? 0))), 'playing' => !empty($in['playing']),
        'rate' => max(0.25, min(2, (float)($in['rate'] ?? 1))), 'updated_at' => gmdate('Y-m-d\TH:i:s\Z')], 'code=eq.' . $code, true);
    jsonSuccess([]);
}
jsonError('Geçersiz işlem');
