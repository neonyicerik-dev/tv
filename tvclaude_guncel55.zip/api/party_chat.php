<?php
// Birlikte izleme odası sohbeti
// GET  ?code=ABC123&after=ID  -> yeni mesajlar (en fazla 50)
// POST {code, text}           -> mesaj gönder (en fazla 300 karakter, 1,5 sn aralık)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id']; $m = $_SERVER['REQUEST_METHOD'];
const NV_ROOM_EMOJIS = ['🔥', '😂', '😮', '❤️', '👏', '😭', '👍', '💀'];
/** Odadaki son anket + oy sayıları (son 300 mesajdan). */
function nvRoomPoll(Supabase $db, string $code, string $uid): ?array {
    $r = $db->select('watch_room_messages', 'code=eq.' . $code . '&or=(body.like.::p:*,body.like.::v:*)&order=id.desc&limit=300&select=id,user_id,body', true)['data'] ?? [];
    if (!is_array($r) || !$r) return null;
    $r = array_reverse($r); $p = null;
    foreach ($r as $x) if (strncmp($x['body'], '::p:', 4) === 0) $p = $x;
    if (!$p) return null;
    $d = json_decode(substr($p['body'], 4), true); if (!is_array($d) || count($d) < 2) return null;
    $counts = array_fill(0, count($d[1]), 0); $by = [];
    foreach ($r as $x) { if ((int)$x['id'] <= (int)$p['id'] || strncmp($x['body'], '::v:', 4) !== 0) continue;
        $pt = explode(':', substr($x['body'], 4)); if ((int)($pt[0] ?? 0) === (int)$p['id']) $by[$x['user_id']] = (int)($pt[1] ?? -1); }
    foreach ($by as $ix) if (isset($counts[$ix])) $counts[$ix]++;
    return ['id' => (int)$p['id'], 'q' => $d[0], 'opts' => $d[1], 'counts' => $counts, 'mine' => $by[$uid] ?? -1];
}
$codeOk = fn($c) => is_string($c) && preg_match('/^[A-Z2-9]{6}$/', $c);
$code = strtoupper(trim((string)($m === 'GET' ? ($_GET['code'] ?? '') : (inputJson()['code'] ?? ''))));
if (!$codeOk($code)) jsonError('Geçersiz oda kodu');
$room = $db->first('watch_rooms', 'code=eq.' . $code . '&select=code,host_id', true);
if (!$room) jsonError('Oda bulunamadı', 404);
// Yalnızca odaya katılmış (members) veya sahibi
if ($room['host_id'] !== $uid && !$db->first('watch_room_members', 'code=eq.' . $code . '&user_id=eq.' . $uid . '&select=user_id', true)) jsonError('Önce odaya katılmalısın', 403);

if ($m === 'GET') {
    $after = max(0, (int)($_GET['after'] ?? 0));
    $q = 'code=eq.' . $code . '&id=gt.' . $after . '&order=id.asc&limit=50&select=id,user_id,username,body,created_at';
    // İlk yüklemede son 30 mesaj
    if ($after === 0) $q = 'code=eq.' . $code . '&order=id.desc&limit=30&select=id,user_id,username,body,created_at';
    $r = $db->select('watch_room_messages', $q, true)['data'] ?? []; $r = is_array($r) ? $r : [];
    if ($after === 0) $r = array_reverse($r);
    foreach ($r as &$x) $x['mine'] = $x['user_id'] === $uid; unset($x);
    $needPoll = $after === 0;
    foreach ($r as $x) if (strncmp($x['body'], '::p:', 4) === 0 || strncmp($x['body'], '::v:', 4) === 0) { $needPoll = true; break; }
    $poll = $needPoll ? nvRoomPoll($db, $code, $uid) : null;
    jsonSuccess(['poll' => $poll, 'poll_checked' => $needPoll, 'items' => array_map(fn($x) => ['id' => (int)$x['id'], 'u' => $x['username'], 'b' => $x['body'], 'mine' => $x['mine'], 'at' => $x['created_at']], $r)]);
}
if ($m !== 'POST') jsonError('Geçersiz metod', 405);
denyIfBanned($db, $uid);
$in = inputJson() ?? [];
$kind = 'text';
if (!empty($in['react'])) {   // emoji tepkisi
    $em = (string)$in['react']; if (!in_array($em, NV_ROOM_EMOJIS, true)) jsonError('Geçersiz tepki');
    $text = '::r:' . $em; $kind = 'react';
} elseif (!empty($in['poll'])) {   // anket (yalnızca oda sahibi)
    if ($room['host_id'] !== $uid) jsonError('Anketi yalnızca oda sahibi başlatabilir', 403);
    $q = mb_substr(trim(strip_tags((string)($in['poll']['q'] ?? ''))), 0, 80);
    $o = []; foreach ((array)($in['poll']['opts'] ?? []) as $x) { $x = mb_substr(trim(strip_tags((string)$x)), 0, 30); if ($x !== '') $o[] = $x; }
    $o = array_slice($o, 0, 4); if ($q === '' || count($o) < 2) jsonError('Soru ve en az 2 seçenek gerekli');
    $text = '::p:' . json_encode([$q, $o], JSON_UNESCAPED_UNICODE); $kind = 'poll';
} elseif (isset($in['vote'])) {   // oy
    $pl = nvRoomPoll($db, $code, $uid); if (!$pl) jsonError('Aktif anket yok');
    $ix = (int)($in['vote']['idx'] ?? -1); if ($ix < 0 || $ix >= count($pl['opts'])) jsonError('Geçersiz seçenek');
    $text = '::v:' . $pl['id'] . ':' . $ix; $kind = 'vote';
} else {
    $text = trim(preg_replace('/\s+/u', ' ', strip_tags((string)($in['text'] ?? ''))));
    if ($text === '') jsonError('Mesaj boş');
    $text = mb_substr($text, 0, 300);
    if (strncmp($text, '::', 2) === 0) $text = ltrim($text, ':');   // sistem öneklerini taklit etme
}
$rl = sys_get_temp_dir() . '/nv_pc_' . md5($uid . $kind);
$gap = $kind === 'react' ? 0.5 : 1.5;
if (is_file($rl) && microtime(true) - (float)@file_get_contents($rl) < $gap) jsonError('Biraz yavaş :)', 429);
@file_put_contents($rl, (string)microtime(true));
$p = $db->first('profiles', 'id=eq.' . $uid . '&select=username', true);
$name = $p['username'] ?? 'Kullanıcı';
$r = $db->insert('watch_room_messages', ['code' => $code, 'user_id' => $uid, 'username' => $name, 'body' => $text], true);
if (($r['status'] ?? 500) >= 400) jsonError('Gönderilemedi (SQL 14 çalıştı mı?)', 500);
// Oda başına en fazla 500 mesaj: eskileri sil (%5 olasılıkla)
if (mt_rand(1, 20) === 1) {
    $old = $db->select('watch_room_messages', 'code=eq.' . $code . '&order=id.desc&offset=500&limit=1&select=id', true)['data'] ?? [];
    if (!empty($old[0]['id'])) $db->delete('watch_room_messages', 'code=eq.' . $code . '&id=lte.' . (int)$old[0]['id'], true);
}
jsonSuccess([]);
