<?php
// Oynatıcı tercihleri (hesap bazlı, cihazlar arası): hız, ses, otomatik oynat, indirme onayı
// GET -> {prefs:{...}} · POST {prefs:{...}} -> birleştirerek kaydeder
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id'];
$row = $db->first('user_prefs', 'user_id=eq.' . $uid . '&select=prefs', true);
$cur = is_array($row['prefs'] ?? null) ? $row['prefs'] : [];
if ($_SERVER['REQUEST_METHOD'] === 'GET') jsonSuccess(['prefs' => (object)$cur]);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);
$in = (inputJson() ?? [])['prefs'] ?? []; if (!is_array($in)) jsonError('Geçersiz veri');
$clean = [];
if (isset($in['speed']))    { $v = (float)$in['speed'];  if ($v >= 0.25 && $v <= 3) $clean['speed'] = $v; }
if (isset($in['volume']))   { $v = (float)$in['volume']; if ($v >= 0 && $v <= 1) $clean['volume'] = round($v, 2); }
if (isset($in['muted']))    $clean['muted'] = $in['muted'] ? 1 : 0;
if (isset($in['autoplay'])) $clean['autoplay'] = $in['autoplay'] ? 1 : 0;
if (isset($in['dlask']) && in_array($in['dlask'], ['always', 'cellular', 'never'], true)) $clean['dlask'] = $in['dlask'];
if (!$clean) jsonSuccess([]);
$data = ['user_id' => $uid, 'prefs' => array_merge($cur, $clean), 'updated_at' => gmdate('Y-m-d\TH:i:s\Z')];
$r = $row ? $db->update('user_prefs', $data, 'user_id=eq.' . $uid, true) : $db->insert('user_prefs', $data, true);
if (($r['status'] ?? 500) >= 400) jsonError('Kaydedilemedi (SQL 16 çalıştı mı?)', 500);
jsonSuccess([]);
