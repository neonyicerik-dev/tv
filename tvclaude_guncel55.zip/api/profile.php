<?php
// POST {bio} -> kısa biyografiyi kaydet (en fazla 300 karakter)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/xp.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db);
$uid = $user['id'];
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $p = $db->first('profiles', 'id=eq.' . $uid . '&select=*', true);
    $c = $db->selectMany([
        'c' => ['comments', 'user_id=eq.' . $uid . '&select=id'],
        'f' => ['user_follows', 'following_id=eq.' . $uid . '&select=follower_id'],
        'g' => ['user_follows', 'follower_id=eq.' . $uid . '&select=following_id'],
    ], true);
    $__nm = ($p['username'] ?? '') !== '' ? $p['username'] : ($user['user_metadata']['username'] ?? explode('@', (string)($user['email'] ?? 'kullanici'))[0]);
    jsonSuccess(['url' => userUrl(['username' => $__nm, 'slug' => $p['slug'] ?? '', 'id' => $uid]), 'id' => $uid, 'username' => ($p['username'] ?? '') !== '' ? $p['username'] : ($user['user_metadata']['username'] ?? $user['user_metadata']['full_name'] ?? explode('@', (string)($user['email'] ?? 'kullanici'))[0]), 'bio' => $p['bio'] ?? '', 'avatar_url' => $p['avatar_url'] ?? '', 'cover_url' => $p['cover_url'] ?? '', 'created_at' => $p['created_at'] ?? '',
        'comments' => count($c['c'] ?? []), 'followers' => count($c['f'] ?? []), 'following' => count($c['g'] ?? []), 'xp_html' => nvXpBadge(nvXpInfo($db, $uid))]);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $in = inputJson() ?? [];
    $bio = mb_substr(trim((string)($in['bio'] ?? '')), 0, 300);
    $r = $db->update('profiles', ['bio' => $bio], 'id=eq.' . $uid, true);
    if ($r['status'] >= 400) jsonError('Kaydedilemedi (SQL güncellemesi çalıştırıldı mı?)', 500);
    jsonSuccess(['bio' => $bio]);
}
jsonError('Geçersiz metod', 405);
