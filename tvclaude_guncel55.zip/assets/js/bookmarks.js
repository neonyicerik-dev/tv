/* NeonTV - Sahne yer imleri: B tuşu / ayarlardaki düğme ile o anı kaydet.
   İlerleme çubuğunda pembe işaret çıkar, "Yer imlerim" paneli listeler. ?t=saniye ile doğrudan o ana gidilir. */
(function () {
    const P = window.NV_PARTY || {}, video = document.getElementById('main-video'), bar = document.getElementById('progress-container');
    if (!video || !P.base) return;
    let tok = null, items = [], panel = null, marks = [];
    const fmt = s => { s = Math.floor(s || 0); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };
    const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    async function getTok() { try { const { data } = await sbClient.auth.getSession(); return data.session ? data.session.access_token : null; } catch (e) { return null; } }
    function api(qs, opt) {
        opt = opt || {}; opt.headers = Object.assign({ 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok, 'Content-Type': 'application/json' }, opt.headers || {});
        return fetch(P.base + '/api/bookmarks.php?token=' + encodeURIComponent(tok) + qs, opt).then(r => r.json());
    }
    function toast(t) {
        let el = document.getElementById('nv-bm-toast');
        if (!el) { el = document.createElement('div'); el.id = 'nv-bm-toast'; el.style.cssText = 'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);z-index:10001;padding:8px 14px;border-radius:12px;background:rgba(13,13,26,.96);border:1px solid rgba(244,114,182,.5);color:#fff;font-size:13px;transition:opacity .3s'; document.body.appendChild(el); }
        el.textContent = t; el.style.opacity = '1'; clearTimeout(el._t); el._t = setTimeout(() => { el.style.opacity = '0'; }, 2200);
    }
    function paintMarks() {
        marks.forEach(m => m.remove()); marks = [];
        if (!bar || !video.duration) return;
        items.forEach(b => {
            if (b.t >= video.duration) return;
            const d = document.createElement('div'); d.className = 'bm-marker'; d.style.left = (b.t / video.duration * 100) + '%'; d.title = 'Yer imi · ' + fmt(b.t) + (b.note ? ' · ' + b.note : '');
            bar.appendChild(d); marks.push(d);
        });
    }
    function paintPanel() {
        if (!panel) return;
        panel.querySelector('.bm-list').innerHTML = items.length ? items.map(b =>
            '<div class="bm-row" data-t="' + b.t + '" data-id="' + esc(b.id) + '"><button type="button" class="bm-go"><b>' + fmt(b.t) + '</b> ' + esc(b.note || '') + '</button><button type="button" class="bm-del" aria-label="Sil">✕</button></div>').join('')
            : '<p style="color:#6b7280;font-size:12px;padding:6px 2px">Henüz yer imin yok. Videoyu izlerken <b>B</b> tuşuna bas.</p>';
    }
    function openPanel() {
        if (!panel) {
            panel = document.createElement('div'); panel.id = 'bm-panel';
            panel.innerHTML = '<div class="bm-head"><span><i class="fa-solid fa-bookmark"></i> Yer imlerim</span><button type="button" class="bm-x" aria-label="Kapat">✕</button></div><div class="bm-list"></div><button type="button" class="bm-add">+ Şu anı ekle (B)</button>';
            document.getElementById('player-container').appendChild(panel);
            panel.addEventListener('click', async e => {
                e.stopPropagation();
                if (e.target.closest('.bm-x')) { panel.style.display = 'none'; return; }
                if (e.target.closest('.bm-add')) { add(); return; }
                const row = e.target.closest('.bm-row'); if (!row) return;
                if (e.target.closest('.bm-del')) {
                    if (row.dataset.id.indexOf('tmp') === 0) return;
                    const r = await api('&id=' + encodeURIComponent(row.dataset.id), { method: 'DELETE' }).catch(() => ({}));
                    if (r.success) { items = items.filter(b => b.id !== row.dataset.id); paintPanel(); paintMarks(); }
                } else { video.currentTime = +row.dataset.t; video.play().catch(() => {}); }
            });
        }
        panel.style.display = panel.style.display === 'block' ? 'none' : 'block'; paintPanel();
    }
    // İyimser ekleme: işaret ve liste satırı ANINDA görünür, kayıt arka planda yapılır; hata olursa geri alınır.
    var busy = {};
    async function add() {
        if (!tok) tok = await getTok();
        if (!tok) { if (confirm('Yer imi için giriş yapmalısın. Giriş sayfasına gidilsin mi?')) location.href = P.base + '/auth.php'; return; }
        const t = Math.floor(video.currentTime || 0);
        if (items.some(b => Math.abs(b.t - t) <= 2)) { toast('Bu saniyede zaten bir yer imin var'); return; }
        if (busy[t]) return; busy[t] = 1;
        const tmp = { id: 'tmp' + Date.now(), t: t, note: null, pending: true };
        items.push(tmp); items.sort((a, b) => a.t - b.t); paintMarks(); paintPanel(); toast('Yer imi eklendi · ' + fmt(t));
        flash(t);
        api('', { method: 'POST', body: JSON.stringify({ video_id: P.vid, t: t }) }).then(r => {
            delete busy[t];
            if (!r || !r.success) { items = items.filter(b => b !== tmp); paintMarks(); paintPanel(); toast((r && r.message) || 'Yer imi kaydedilemedi'); return; }
            tmp.id = r.data.item.id; tmp.pending = false; paintPanel();
        }).catch(() => { delete busy[t]; items = items.filter(b => b !== tmp); paintMarks(); paintPanel(); toast('Bağlantı hatası, yer imi kaydedilemedi'); });
    }
    // Eklenen anı gösteren küçük ekran görüntüsü (video karesinden canvas ile; CORS izin vermezse atlanır)
    function flash(t) {
        try {
            const c = document.createElement('canvas'); c.width = 160; c.height = 90;
            c.getContext('2d').drawImage(video, 0, 0, 160, 90);
            c.toDataURL(); // tainted ise burada hata fırlatır
            c.style.cssText = 'position:fixed;left:16px;bottom:80px;z-index:10001;border-radius:10px;border:2px solid #f472b6;box-shadow:0 8px 24px rgba(0,0,0,.6);transition:all .6s;transform:scale(1)';
            document.body.appendChild(c);
            setTimeout(() => { c.style.opacity = '0'; c.style.transform = 'translateY(20px) scale(.8)'; }, 1400);
            setTimeout(() => c.remove(), 2100);
        } catch (e) {}
    }
    window.nvBookmarkAdd = add; window.nvBookmarkPanel = openPanel;
    document.addEventListener('keydown', e => {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        const tg = (e.target.tagName || '').toLowerCase(); if (tg === 'input' || tg === 'textarea' || e.target.isContentEditable) return;
        if (e.key === 'b' || e.key === 'B') { e.preventDefault(); add(); }
    });
    video.addEventListener('loadedmetadata', paintMarks);
    window.addEventListener('load', async () => {
        // ?t= ile doğrudan ana git (oda modunda yok sayılır)
        const tq = parseInt(new URLSearchParams(location.search).get('t') || '', 10);
        if (tq > 0 && !/[?&]room=/.test(location.search)) {
            const go = () => { try { video.currentTime = tq; } catch (e) {} };
            if (video.readyState >= 1) go(); else video.addEventListener('loadedmetadata', go, { once: true });
        }
        tok = await getTok(); if (!tok) return;
        const r = await api('&video_id=' + encodeURIComponent(P.vid)).catch(() => null);
        if (r && r.success) { items = r.data.items || []; paintMarks(); }
    });
})();
