/* NeonTV - Birlikte izleme odası (senkron oynatma)
   Oda sahibi oynat/durdur/ileri-geri/hız işlemlerini yapar; katılanlar otomatik eşitlenir.
   Sunucu: api/party.php (2 sn'de bir yoklama). window.NV_PARTY = {base, vid} video.php tarafından verilir. */
(function () {
    const P = window.NV_PARTY || {}, video = document.getElementById('main-video');
    if (!video || !P.base) return;
    let tok = null, code = '', host = false, pollT = null, pushT = null, bar = null, lastErr = 0;
    const qs = new URLSearchParams(location.search);

    async function getTok() { try { const { data } = await sbClient.auth.getSession(); return data.session ? data.session.access_token : null; } catch (e) { return null; } }
    function api(body, qsx) {
        const opt = { headers: { 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok, 'Content-Type': 'application/json' } };
        if (body) { opt.method = 'POST'; opt.body = JSON.stringify(body); }
        return fetch(P.base + '/api/party.php?token=' + encodeURIComponent(tok) + (qsx || ''), opt).then(r => r.json());
    }
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
    function roomLink() { return P.base + '/video.php?id=' + encodeURIComponent(P.vid) + '&room=' + encodeURIComponent(code); }


    // ---------------- Oda içi canlı sohbet ----------------
    let chatBox = null, chatT = null, lastId = 0, chatOpen = false, unread = 0;
    function chatApi(body, qsx) {
        const opt = { headers: { 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok, 'Content-Type': 'application/json' } };
        if (body) { opt.method = 'POST'; opt.body = JSON.stringify(body); }
        return fetch(P.base + '/api/party_chat.php?token=' + encodeURIComponent(tok) + (qsx || ''), opt).then(r => r.json());
    }
    const EMOJIS = ['🔥', '😂', '😮', '❤️', '👏', '😭', '👍', '💀'];
    function floatEmoji(em) {
        const host = document.getElementById('player-container') || document.body, e = document.createElement('div');
        e.textContent = em; e.style.cssText = 'position:absolute;bottom:70px;left:' + (8 + Math.random() * 80) + '%;font-size:' + (26 + Math.random() * 16) + 'px;pointer-events:none;z-index:48;transition:transform 2.4s ease-out,opacity 2.4s ease-in;opacity:1;will-change:transform';
        host.appendChild(e); requestAnimationFrame(() => { e.style.transform = 'translate(' + ((Math.random() - .5) * 60) + 'px,-' + (160 + Math.random() * 120) + 'px) scale(1.3)'; e.style.opacity = '0'; });
        setTimeout(() => e.remove(), 2600);
    }
    let curPoll = null;
    function paintPoll(pl) {
        curPoll = pl || null; const box = chatBox && chatBox.querySelector('.pc-poll'); if (!box) return;
        if (!pl) { box.style.display = 'none'; box.innerHTML = ''; return; }
        const tot = pl.counts.reduce((a, b) => a + b, 0) || 0;
        box.style.display = 'block';
        box.innerHTML = '<div class="pp-q">📊 ' + esc(pl.q) + '</div>' + pl.opts.map((o, i) => {
            const pc = tot ? Math.round(pl.counts[i] / tot * 100) : 0;
            return '<button type="button" data-i="' + i + '" class="pp-o' + (pl.mine === i ? ' me' : '') + '"><i style="width:' + pc + '%"></i><span>' + esc(o) + '</span><b>' + pc + '% · ' + pl.counts[i] + '</b></button>';
        }).join('') + '<div class="pp-t">' + tot + ' oy</div>';
    }
    function chatAdd(items, initial) {
        if (!chatBox || !items.length) return;
        const list = chatBox.querySelector('.pc-list'), atEnd = list.scrollTop + list.clientHeight >= list.scrollHeight - 30;
        items.forEach(m => {
            lastId = Math.max(lastId, m.id);
            const b = String(m.b || '');
            if (b.startsWith('::r:')) { if (!initial && !m.mine) floatEmoji(b.slice(4)); return; }
            if (b.startsWith('::v:')) return;
            if (b.startsWith('::p:')) { if (!initial) { const d = document.createElement('div'); d.className = 'pc-msg'; d.innerHTML = '<b>📊</b> Yeni anket başladı'; list.appendChild(d); if (!m.mine && !chatOpen) unread++; } return; }
            const d = document.createElement('div'); d.className = 'pc-msg' + (m.mine ? ' mine' : '');
            d.innerHTML = '<b>' + esc(m.u) + '</b> ' + esc(b);
            list.appendChild(d);
            if (!m.mine && !chatOpen) unread++;
        });
        while (list.children.length > 120) list.removeChild(list.firstChild);
        if (atEnd) list.scrollTop = list.scrollHeight;
        paintBadge();
    }
    function paintBadge() { const b = chatBox && chatBox.querySelector('.pc-badge'); if (b) { b.textContent = unread > 0 ? unread : ''; b.style.display = unread > 0 ? 'inline-block' : 'none'; } }
    async function chatPoll() {
        if (!code) return;
        try { const r = await chatApi(null, '&code=' + encodeURIComponent(code) + '&after=' + lastId); if (r.success) { const first = lastId === 0; chatAdd(r.data.items || [], first); if (r.data.poll_checked) paintPoll(r.data.poll); } } catch (e) {}
    }
    function startChat() {
        if (chatBox || !code) return;
        const css = document.createElement('style');
        css.textContent = '#nv-pchat{position:fixed;right:12px;bottom:12px;z-index:10000;width:min(320px,calc(100vw - 24px));font-size:13px}' +
            '#nv-pchat .pc-toggle{margin-left:auto;display:flex;align-items:center;gap:6px;padding:8px 14px;border-radius:999px;background:#fb923c;color:#000;font-weight:800;box-shadow:0 6px 20px rgba(0,0,0,.5)}' +
            '#nv-pchat .pc-badge{display:none;background:#ef4444;color:#fff;border-radius:999px;font-size:10px;padding:1px 6px}' +
            '#nv-pchat .pc-win{display:none;margin-bottom:8px;border-radius:16px;background:rgba(13,13,26,.97);border:1px solid rgba(251,146,60,.45);box-shadow:0 10px 30px rgba(0,0,0,.6);overflow:hidden}' +
            '#nv-pchat.open .pc-win{display:block}#nv-pchat .pc-list{height:240px;overflow:auto;padding:10px;display:flex;flex-direction:column;gap:6px}' +
            '#nv-pchat .pc-msg{color:#e5e7eb;word-break:break-word;line-height:1.35}#nv-pchat .pc-msg b{color:#fdba74}#nv-pchat .pc-msg.mine b{color:#67e8f9}' +
            '#nv-pchat form{display:flex;gap:6px;padding:8px;border-top:1px solid rgba(255,255,255,.08)}' +
            '#nv-pchat input{flex:1;min-width:0;padding:8px 10px;border-radius:10px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:#fff;font-size:16px}' +
            '#nv-pchat form button{padding:0 12px;border-radius:10px;background:#fb923c;color:#000;font-weight:800}' +
            '#nv-pchat .pc-em{display:flex;gap:2px;padding:6px 8px;border-top:1px solid rgba(255,255,255,.08);overflow-x:auto}#nv-pchat .pc-em button{font-size:20px;padding:2px 5px;border-radius:8px;transition:transform .12s}#nv-pchat .pc-em button:active{transform:scale(1.5)}' +
            '#nv-pchat .pc-em .pc-newpoll{margin-left:auto;font-size:11px;font-weight:700;color:#fdba74;white-space:nowrap}' +
            '#nv-pchat .pc-poll{display:none;padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.08)}#nv-pchat .pp-q{font-weight:700;color:#fff;margin-bottom:6px}' +
            '#nv-pchat .pp-o{position:relative;display:flex;justify-content:space-between;gap:8px;width:100%;margin:3px 0;padding:6px 8px;border-radius:8px;background:rgba(255,255,255,.07);color:#e5e7eb;overflow:hidden;text-align:left;font-size:12px}' +
            '#nv-pchat .pp-o i{position:absolute;left:0;top:0;bottom:0;background:rgba(251,146,60,.35);transition:width .3s}#nv-pchat .pp-o.me{outline:1px solid #fb923c}#nv-pchat .pp-o span,#nv-pchat .pp-o b{position:relative;font-weight:600}' +
            '#nv-pchat .pp-t{font-size:10px;color:#9ca3af;margin-top:2px}#nv-pchat .pp-x{color:#fb923c}';
        document.head.appendChild(css);
        chatBox = document.createElement('div'); chatBox.id = 'nv-pchat';
        chatBox.innerHTML = '<div class="pc-win"><div class="pc-poll"></div><div class="pc-list" aria-live="polite"></div><div class="pc-em">' + EMOJIS.map(e => '<button type="button" data-e="' + e + '">' + e + '</button>').join('') + (host ? '<button type="button" class="pc-newpoll">+ Anket</button>' : '') + '</div><form><input maxlength="300" placeholder="Mesaj yaz…" autocomplete="off"><button type="submit">Gönder</button></form></div>' +
            '<div style="display:flex"><button type="button" class="pc-toggle"><i class="fa-solid fa-comments"></i> Sohbet <span class="pc-badge"></span></button></div>';
        document.body.appendChild(chatBox);
        const input = chatBox.querySelector('input');
        chatBox.querySelector('.pc-toggle').onclick = () => {
            chatOpen = !chatOpen; chatBox.classList.toggle('open', chatOpen);
            if (chatOpen) { unread = 0; paintBadge(); const l = chatBox.querySelector('.pc-list'); l.scrollTop = l.scrollHeight; setTimeout(() => input.focus(), 50); }
        };
        chatBox.querySelector('.pc-em').addEventListener('click', async e => {
            const b = e.target.closest('button'); if (!b) return;
            if (b.classList.contains('pc-newpoll')) {
                const q = prompt('Anket sorusu:'); if (!q) return; const o = prompt('Seçenekler (virgülle ayır, en az 2, en çok 4):', 'Evet, Hayır'); if (!o) return;
                const r = await chatApi({ code: code, poll: { q: q, opts: o.split(',') } }).catch(() => ({})); if (r.success) chatPoll(); else chatAdd([{ id: lastId, u: 'Sistem', b: r.message || 'Anket başlatılamadı', mine: false }]);
                return;
            }
            const em = b.dataset.e; if (!em) return; floatEmoji(em); chatApi({ code: code, react: em }).catch(() => {});
        });
        chatBox.querySelector('.pc-poll').addEventListener('click', async e => {
            if (e.target.closest('.pp-x')) { e.preventDefault(); paintPoll(null); return; }
            const o = e.target.closest('.pp-o'); if (!o || !curPoll) return; const i = +o.dataset.i;
            curPoll.counts[i]++; if (curPoll.mine >= 0) curPoll.counts[curPoll.mine]--; curPoll.mine = i; paintPoll(curPoll);   // anında göster
            chatApi({ code: code, vote: { idx: i } }).then(() => chatPoll()).catch(() => {});
        });
        // Oynatıcı kısayolları sohbet yazarken tetiklenmesin
        input.addEventListener('keydown', e => e.stopPropagation());
        chatBox.querySelector('form').onsubmit = async e => {
            e.preventDefault(); const t = input.value.trim(); if (!t) return; input.value = '';
            const r = await chatApi({ code: code, text: t }).catch(() => ({ success: false }));
            if (!r.success) { chatAdd([{ id: lastId, u: 'Sistem', b: r.message || 'Gönderilemedi', mine: false }]); return; }
            chatPoll();
        };
        chatPoll(); chatT = setInterval(chatPoll, 2000);
    }
    function stopChat() { clearInterval(chatT); chatT = null; if (chatBox) { chatBox.remove(); chatBox = null; } lastId = 0; unread = 0; chatOpen = false; curPoll = null; }

    function paint(msg, viewers, needTap) {
        if (!bar) {
            bar = document.createElement('div'); bar.id = 'nv-party';
            bar.style.cssText = 'position:fixed;left:50%;top:12px;transform:translateX(-50%);z-index:10000;max-width:calc(100vw - 24px);display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:center;padding:8px 12px;border-radius:14px;background:rgba(13,13,26,.95);border:1px solid rgba(251,146,60,.5);box-shadow:0 8px 30px rgba(0,0,0,.6);font-size:12px;color:#e5e7eb';
            document.body.appendChild(bar);
            bar.addEventListener('click', e => {
                const b = e.target.closest('button'); if (!b) return;
                if (b.dataset.a === 'copy') { try { navigator.clipboard.writeText(roomLink()); b.textContent = 'Kopyalandı ✓'; } catch (x) { prompt('Oda linki:', roomLink()); } }
                if (b.dataset.a === 'leave') leave();
                if (b.dataset.a === 'tap') { video.play().catch(() => {}); }
            });
        }
        const btn = 'padding:4px 10px;border-radius:999px;font-weight:700;font-size:11px;';
        bar.innerHTML = '<span style="color:#fb923c;font-weight:800"><i class="fa-solid fa-users-viewfinder"></i> Oda ' + esc(code) + '</span>' +
            '<span>' + esc(msg) + '</span>' + (viewers ? '<span style="color:#9ca3af">· ' + viewers + ' kişi</span>' : '') +
            (needTap ? '<button type="button" data-a="tap" style="' + btn + 'background:#fb923c;color:#000">▶ Katıl / Oynat</button>' : '') +
            '<button type="button" data-a="copy" style="' + btn + 'background:rgba(255,255,255,.1);color:#fff">Linki kopyala</button>' +
            '<button type="button" data-a="leave" style="' + btn + 'background:rgba(248,113,113,.2);color:#fca5a5">Çık</button>';
        if (host && code) showLink();
    }
    function leave() {
        clearInterval(pollT); clearInterval(pushT); pollT = pushT = null;
        if (bar) { bar.remove(); bar = null; }
        try { const u = new URL(location.href); u.searchParams.delete('room'); history.replaceState(null, '', u); } catch (e) {}
        code = ''; host = false; stopChat();
    }
    function push() {
        if (!code || !host) return;
        api({ action: 'state', code: code, pos: video.currentTime || 0, playing: !video.paused, rate: video.playbackRate || 1 }).catch(() => {});
    }
    function startHost() {
        host = true; startChat(); paint('Sen yönetiyorsun · linki arkadaşına gönder', 1);
        ['play', 'pause', 'seeked', 'ratechange'].forEach(ev => video.addEventListener(ev, push));
        pushT = setInterval(() => { if (!video.paused) push(); }, 3000);
        pollT = setInterval(async () => { try { const r = await api(null, '&code=' + encodeURIComponent(code)); if (r.success) paint('Sen yönetiyorsun · linki arkadaşına gönder', r.data.viewers); } catch (e) {} }, 5000);
        push();
    }
    async function poll() {
        let r; try { r = await api(null, '&code=' + encodeURIComponent(code)); } catch (e) { return; }
        if (!r.success) { paint(r.message || 'Oda kapandı'); clearInterval(pollT); return; }
        const d = r.data;
        if (d.video_id !== P.vid) { location.href = P.base + '/video.php?id=' + encodeURIComponent(d.video_id) + '&room=' + encodeURIComponent(code); return; }
        if (d.host) return;
        const target = d.pos + (d.playing ? d.age * d.rate : 0);
        if (Math.abs(video.currentTime - target) > 1.5) { try { video.currentTime = target; } catch (e) {} }
        if (video.playbackRate !== d.rate) video.playbackRate = d.rate;
        let tap = false;
        if (d.playing && video.paused) { try { await video.play(); } catch (e) { tap = true; } }
        else if (!d.playing && !video.paused) video.pause();
        paint(d.playing ? 'Oda sahibiyle eşitlendi' : 'Oda sahibi duraklattı', d.viewers, tap);
    }
    async function join(c) {
        code = c; tok = await getTok();
        if (!tok) { code = c; paint('Katılmak için giriş yap', 0); bar.insertAdjacentHTML('afterbegin', '<a href="' + P.base + '/auth.php" style="color:#00f5ff;font-weight:700;text-decoration:underline">Giriş yap</a>'); return; }
        const r = await api(null, '&code=' + encodeURIComponent(c)).catch(() => ({ success: false }));
        if (!r.success) { paint(r.message || 'Oda bulunamadı'); setTimeout(leave, 4000); return; }
        if (r.data.host) { startHost(); return; }
        startChat(); poll(); pollT = setInterval(poll, 2000);
    }
    window.nvPartyStart = async function () {
        if (code) { return; }
        // 1) Anında geri bildirim: kullanıcı beklediğini bilsin
        paintPending('Oda oluşturuluyor…');
        tok = tok || await getTok();
        if (!tok) { dropPending(); if (confirm('Birlikte izlemek için giriş yapmalısın. Giriş sayfasına gidilsin mi?')) location.href = P.base + '/auth.php'; return; }
        const r = await api({ action: 'create', video_id: P.vid }).catch(() => ({ success: false }));
        if (!r.success) { paintPending(r.message || 'Oda oluşturulamadı', true); setTimeout(dropPending, 4000); return; }
        code = r.data.code; dropPending();
        try { const u = new URL(location.href); u.searchParams.set('room', code); history.replaceState(null, '', u); } catch (e) {}
        startHost(); showLink();
        try { navigator.clipboard.writeText(roomLink()); } catch (e) {}
    };
    // Oda adresi kutusu (oluşturulunca görünür, kopyalanabilir)
    function showLink() {
        if (!bar) return;
        let b = document.getElementById('nv-party-link');
        if (!b) {
            b = document.createElement('div'); b.id = 'nv-party-link';
            b.style.cssText = 'flex-basis:100%;display:flex;gap:6px;align-items:center';
            bar.appendChild(b);
        }
        b.innerHTML = '<input readonly value="' + esc(roomLink()) + '" style="flex:1;min-width:0;padding:6px 10px;border-radius:8px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;font-size:12px" onfocus="this.select()">';
    }
    let pend = null;
    function paintPending(msg, err) {
        if (!pend) {
            pend = document.createElement('div');
            pend.style.cssText = 'position:fixed;left:50%;top:12px;transform:translateX(-50%);z-index:10001;padding:10px 16px;border-radius:14px;background:rgba(13,13,26,.96);font-size:13px;font-weight:700;color:#fdba74;border:1px solid rgba(251,146,60,.5);display:flex;gap:10px;align-items:center';
            document.body.appendChild(pend);
        }
        pend.style.color = err ? '#fca5a5' : '#fdba74';
        pend.innerHTML = (err ? '' : '<span style="width:14px;height:14px;border-radius:50%;border:2px solid #fb923c;border-top-color:transparent;display:inline-block;animation:nvspin .7s linear infinite"></span>') + esc(msg);
        if (!document.getElementById('nv-spin-css')) { const c = document.createElement('style'); c.id = 'nv-spin-css'; c.textContent = '@keyframes nvspin{to{transform:rotate(360deg)}}'; document.head.appendChild(c); }
    }
    function dropPending() { if (pend) { pend.remove(); pend = null; } }
    window.addEventListener('load', () => { const c = (qs.get('room') || '').toUpperCase(); if (/^[A-Z2-9]{6}$/.test(c)) join(c); });
})();
