/* Oynatıcı tercihlerini hesaba eşitler (hız, ses, otomatik oynat, indirme onayı). Giriş yoksa hiçbir şey yapmaz. */
(function () {
    const KEYS = { neontv_speed: 'speed', neontv_volume: 'volume', neontv_muted: 'muted', neontv_autoplay: 'autoplay', neontv_dlask: 'dlask' };
    const B = () => (window.NV_PARTY && window.NV_PARTY.base) || '';
    const orig = Storage.prototype.setItem; let quiet = false, timer = null;
    function rd(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
    async function tok() { try { const { data } = await sbClient.auth.getSession(); return data.session ? data.session.access_token : null; } catch (e) { return null; } }
    function collect() {
        const o = {}, sp = parseFloat(rd('neontv_speed')); if (sp) o.speed = sp;
        const vo = parseFloat(rd('neontv_volume')); if (!isNaN(vo)) o.volume = vo;
        if (rd('neontv_muted') !== null) o.muted = rd('neontv_muted') === '1' ? 1 : 0;
        if (rd('neontv_autoplay') !== null) o.autoplay = rd('neontv_autoplay') === '0' ? 0 : 1;
        if (rd('neontv_dlask')) o.dlask = rd('neontv_dlask');
        return o;
    }
    async function push() {
        const t = await tok(); if (!t) return;
        fetch(B() + '/api/player_prefs.php?token=' + encodeURIComponent(t), { method: 'POST', keepalive: true, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + t }, body: JSON.stringify({ prefs: collect() }) }).catch(() => {});
    }
    Storage.prototype.setItem = function (k, v) { orig.apply(this, arguments); if (!quiet && this === window.localStorage && KEYS[k]) { clearTimeout(timer); timer = setTimeout(push, 2500); } };
    window.addEventListener('load', async function () {
        const t = await tok(); if (!t) return;
        let p = null; try { const r = await (await fetch(B() + '/api/player_prefs.php?token=' + encodeURIComponent(t), { headers: { 'Authorization': 'Bearer ' + t } })).json(); p = r.success ? r.data.prefs : null; } catch (e) {}
        if (!p || !Object.keys(p).length) { if (rd('neontv_speed') || rd('neontv_volume')) push(); return; }   // hesapta kayıt yok: bu cihazınkini yükle
        quiet = true;
        try {
            if (p.speed) localStorage.setItem('neontv_speed', String(p.speed));
            if (p.volume !== undefined) localStorage.setItem('neontv_volume', String(p.volume));
            if (p.muted !== undefined) localStorage.setItem('neontv_muted', p.muted ? '1' : '0');
            if (p.autoplay !== undefined) localStorage.setItem('neontv_autoplay', p.autoplay ? '1' : '0');
            if (p.dlask) localStorage.setItem('neontv_dlask', p.dlask);
        } catch (e) {}
        quiet = false;
        const v = document.getElementById('main-video'); if (!v) return;
        const perVid = rd('neontv_speed_v_' + (typeof VIDEO_ID !== 'undefined' ? VIDEO_ID : 'x'));
        if (p.speed && !perVid && v.playbackRate !== p.speed) { v.playbackRate = p.speed; const b = document.getElementById('speed-btn'); if (b) b.textContent = p.speed + '×'; }
        if (p.volume !== undefined && v.volume !== p.volume) v.volume = p.volume;
        if (p.muted !== undefined) v.muted = !!p.muted;
    });
})();
