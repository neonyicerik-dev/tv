#!/usr/bin/env bash
# NeonTV durum kontrolü için cron kurulumu (Debian/Ubuntu). Kullanım: sudo bash deploy/setup-status-cron.sh [/var/www/html] [www-data]
set -e
ROOT="${1:-/var/www/html}"; USR="${2:-www-data}"
[ "$(id -u)" = 0 ] || { echo "root olarak çalıştırın (sudo)."; exit 1; }
[ -f "$ROOT/status/check.php" ] || { echo "$ROOT/status/check.php bulunamadı."; exit 1; }
PHP="$(command -v php8.4 || command -v php)"; [ -n "$PHP" ] || { echo "php bulunamadı."; exit 1; }
if ! command -v cron >/dev/null 2>&1; then apt-get update -qq && apt-get install -y -qq cron; fi
mkdir -p "$ROOT/logs"; touch "$ROOT/logs/status_cron.log"; chown "$USR" "$ROOT/logs/status_cron.log"
cat > /etc/cron.d/neontv-status <<CRON
# NeonTV: her dakika site + CDN durum kontrolü
SHELL=/bin/bash
PATH=/usr/local/bin:/usr/bin:/bin
* * * * * $USR $PHP $ROOT/status/check.php >> $ROOT/logs/status_cron.log 2>&1
# günlük logu 1 MB'ı geçince sıfırla
5 4 * * * $USR [ \$(stat -c %s $ROOT/logs/status_cron.log) -gt 1048576 ] && : > $ROOT/logs/status_cron.log
CRON
chmod 644 /etc/cron.d/neontv-status
(systemctl enable --now cron 2>/dev/null || service cron start 2>/dev/null || (pgrep -x cron >/dev/null || cron)) || true
echo "Kuruldu. Deneme:"; sudo -u "$USR" "$PHP" "$ROOT/status/check.php" || echo "Uyarı: elle çalıştırma hata verdi (adresler admin panelde tanımlı mı?)"
echo "1-2 dk sonra: tail $ROOT/logs/status_cron.log"
