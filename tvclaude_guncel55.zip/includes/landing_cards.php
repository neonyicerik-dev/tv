<?php
// Landing sayfası kart HTML'i (landing.php ve api/landing_part.php ortak kullanır)
/** Video kartı: küçük resim + hover/odakta sessiz önizleme */
function lnCard(array $v, ?int $rank = null): string {
    $id = e($v['id']); $t = e($v['title']); $th = e($v['thumbnail_url'] ?? ''); $src = e($v['video_url'] ?? '');
    $dur = !empty($v['duration']) ? formatDuration((int)$v['duration']) : '';
    $h  = '<a class="ln-vcard" href="' . APP_URL . '/video.php?id=' . $id . '" data-ln-prev>';
    $h .= '<div class="ln-vthumb"><img src="' . $th . '" alt="' . $t . '" loading="lazy" decoding="async">';
    $h .= '<video muted loop playsinline preload="none" data-src="' . $src . '" tabindex="-1" aria-hidden="true"></video>';
    if ($rank !== null) $h .= '<span class="ln-rank">' . $rank . '</span>';
    if ($dur !== '') $h .= '<span class="ln-dur">' . e($dur) . '</span>';
    $h .= '<span class="ln-vplay" aria-hidden="true"><i class="fa-solid fa-play"></i></span></div>';
    $h .= '<h3>' . $t . '</h3><p><i class="fa-regular fa-eye"></i> ' . e(formatNumber((int)($v['views'] ?? 0))) . ' · ' . e(timeAgo($v['created_at'] ?? 'now')) . '</p></a>';
    return $h;
}
