<?php
// ============================================================
// NeonTV - Kullanıcı işlem günlüğü (admin → Kullanıcı Logları)
// nvLog($db, $uid, 'watch', 'Videoyu izledi: X', ['video_id'=>..])
// Hata verse de asıl işlemi ASLA bozmaz. Ham IP tutulmaz (yalnızca özet).
// ============================================================
require_once __DIR__ . '/ip_log.php';

const NV_LOG_TYPES = [
    'watch'   => ['İzleme',   'fa-play',          '#00f5ff'],
    'token'   => ['Token',    'fa-coins',         '#fbbf24'],
    'premium' => ['Premium',  'fa-crown',         '#f59e0b'],
    'login'   => ['Giriş',    'fa-right-to-bracket', '#34d399'],
    'comment' => ['Yorum',    'fa-comment',       '#60a5fa'],
    'like'    => ['Beğeni',   'fa-heart',         '#f472b6'],
    'social'  => ['Takip',    'fa-user-group',    '#a78bfa'],
    'library' => ['Kütüphane','fa-bookmark',      '#2dd4bf'],
    'report'  => ['Şikayet',  'fa-flag',          '#f87171'],
    'account' => ['Hesap',    'fa-user-gear',     '#94a3b8'],
    'party'   => ['Oda',      'fa-users-viewfinder','#fb923c'],
];
const NV_LOG_RETENTION_DAYS = 90;

/** Kuyruk: yanıt kullanıcıya gittikten SONRA (fastcgi_finish_request) yazılır; böylece log yavaşlığı isteği geciktirmez. */
$GLOBALS['__nv_log_q'] = [];
function nvLogFlush($db = null): void {
    $q = $GLOBALS['__nv_log_q'] ?? []; $GLOBALS['__nv_log_q'] = [];
    if (!$q) return;
    try {
        if (!$db) { require_once __DIR__ . '/supabase.php'; $db = new Supabase(); }
        foreach ($q as $it) {
            [$db2, $uid, $type, $text, $meta] = $it;
            if (is_callable($text)) { try { $text = (string)$text(); } catch (\Throwable $e) { $text = $type; } }
            $row = ['user_id' => $uid, 'type' => $type, 'text' => mb_substr((string)$text, 0, 300), 'meta' => (object)$meta];
            try { $row['ip_hash'] = $meta['__ip'] ?? null; unset($row['meta']->__ip); } catch (\Throwable $e) {}
            ($db2 ?: $db)->insert('user_events', $row, true);
        }
        if (mt_rand(1, 100) === 1) ($db)->delete('user_events', 'created_at=lt.' . gmdate('Y-m-d\TH:i:s\Z', time() - NV_LOG_RETENTION_DAYS * 86400), true);
    } catch (\Throwable $e) {}
}
/** $text string ya da (geç çalışan) closure olabilir. */
function nvLog($db, string $uid, string $type, $text, array $meta = []): void {
    try {
        if (!$uid || !function_exists('isUuid') || !isUuid($uid)) return;
        static $reg = false;
        try { $meta['__ip'] = hashIp(getClientIp()); } catch (\Throwable $e) {}
        $GLOBALS['__nv_log_q'][] = [$db, $uid, $type, $text, $meta];
        if (!$reg) {
            $reg = true;
            register_shutdown_function(function () {
                if (function_exists('fastcgi_finish_request')) { @fastcgi_finish_request(); }
                nvLogFlush();
            });
        }
    } catch (\Throwable $e) {}
}

/** Video başlığını kısa çekip log metnine eklemek için. */
function nvVideoTitle($db, string $vid): string {
    try { $v = $db->first('videos', 'id=eq.' . $vid . '&select=title', true); return (string)($v['title'] ?? ''); } catch (\Throwable $e) { return ''; }
}

const NV_TOKEN_REASONS = [
    'daily' => 'günlük giriş ödülü', 'quest' => 'görev ödülü', 'ad' => 'reklam izleme', 'premium_buy' => 'premium satın alma',
    'premium_gift' => 'premium hediye', 'refund' => 'iade', 'auto_renew' => 'otomatik yenileme', 'admin_credit' => 'yönetici ekledi',
    'admin_debit' => 'yönetici düştü', 'coupon' => 'kupon',
];
