<?php
// cron-job.org (veya herhangi bir HTTP cron) bu adresi dakikada bir çağırır:
//   https://status.alanadiniz.com/check.php?key=GIZLI_ANAHTAR     (ya da başlık:  X-Cron-Key: GIZLI_ANAHTAR)
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/status_core.php';
if (PHP_SAPI !== 'cli') {
    $k = (string)($_SERVER['HTTP_X_CRON_KEY'] ?? ($_GET['key'] ?? ''));
    if (NV_STATUS_CRON_KEY === '' || !hash_equals(NV_STATUS_CRON_KEY, $k)) { http_response_code(403); exit('forbidden'); }
    header('Content-Type: application/json'); header('Cache-Control: no-store'); ignore_user_abort(true); set_time_limit(40);
}
echo json_encode(nvStatusRun(true), JSON_UNESCAPED_UNICODE), PHP_EOL;
