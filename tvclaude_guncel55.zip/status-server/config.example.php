<?php
// Bu dosyayı config.php olarak kopyalayıp doldurun (config.php'yi kimseyle paylaşmayın).
// Ana sitenin Supabase bilgileri: Project Settings > API
define('NV_SUPABASE_URL', 'https://PROJE-ID.supabase.co');
define('NV_SUPABASE_SERVICE_KEY', '');      // service_role (secret) anahtarı — status_checks/status_incidents tablolarına yazmak için gerekli
define('NV_STATUS_CRON_KEY', '');           // cron-job.org'un kullanacağı gizli anahtar (uzun, rastgele)
date_default_timezone_set('Europe/Istanbul');
