<?php
// Bağımsız durum sunucusu için küçük Supabase REST istemcisi + ayar/önbellek yardımcısı (ana projeye bağımlılık yok).
class Supabase {
    private string $url, $key;
    public function __construct() { $this->url = rtrim(NV_SUPABASE_URL, '/') . '/rest/v1/'; $this->key = NV_SUPABASE_SERVICE_KEY; }
    public function request(string $method, string $path, ?array $body = null, array $extra = []): array {
        $ch = curl_init($this->url . $path);
        $h = ['apikey: ' . $this->key, 'Authorization: Bearer ' . $this->key, 'Content-Type: application/json'] + $extra;
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_HTTPHEADER => $h]);
        if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE));
        $raw = curl_exec($ch); $st = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $d = json_decode((string)$raw, true);
        return ['status' => $st, 'data' => is_array($d) ? $d : []];
    }
    public function select(string $t, string $q = '', bool $svc = true): array { return $this->request('GET', $t . ($q !== '' ? '?' . $q : '')); }
    public function first(string $t, string $q = '', bool $svc = true): ?array { $r = $this->select($t, $q . '&limit=1'); return $r['data'][0] ?? null; }
    public function insert(string $t, array $d, bool $svc = true): array { return $this->request('POST', $t, $d, ['Prefer: return=minimal']); }
    public function update(string $t, array $d, string $cond, bool $svc = true): array { return $this->request('PATCH', $t . '?' . $cond, $d, ['Prefer: return=minimal']); }
    public function delete(string $t, string $cond, bool $svc = true): array { return $this->request('DELETE', $t . '?' . $cond); }
    public function rpc(string $fn, array $p = [], bool $svc = true): array { return $this->request('POST', 'rpc/' . $fn, $p ?: new stdClass()); }
}
class Store {
    private static function f(string $k): string { return sys_get_temp_dir() . '/nvst_' . md5(NV_SUPABASE_URL . $k) . '.json'; }
    public static function remember(string $k, int $ttl, callable $fn): mixed {
        $f = self::f($k);
        if (is_file($f) && time() - filemtime($f) < $ttl) { $h = json_decode((string)@file_get_contents($f), true); if (is_array($h) && array_key_exists('_r', $h)) return $h['_r']; }
        $v = $fn(); @file_put_contents($f, json_encode(['_r' => $v]), LOCK_EX); return $v;
    }
    public static function clearCache(string $k): void { @unlink(self::f($k)); }
    public static function getSetting(string $key, mixed $default = null): mixed {
        $all = self::remember('settings', 30, function () {
            $r = (new Supabase())->select('site_settings', 'select=key,value'); $o = [];
            foreach ($r['data'] as $row) $o[$row['key']] = $row['value']; return $o;
        });
        return $all[$key] ?? $default;
    }
}
