<?php
// ============================================================
// NeonTV - Durum sayfası çekirdeği (site + status/ klasörü ortak kullanır)
// Ayarlar (admin → Durum Sayfası): status_url, status_site_url, status_cdn_url, status_banner_on
// Tablolar: status_checks, status_incidents (SQL 15). Uptime özeti RPC: nv_status_daily
// ============================================================
require_once __DIR__ . '/lib.php';

const NV_STATUS_TARGETS = ['site' => 'NeonTV (web sitesi)', 'cdn' => 'CDN (video ve görseller)'];
const NV_STATUS_STALE = 90;      // sn: bu süreden eski kontrol varsa ziyaret sırasında yenisi tetiklenir
const NV_STATUS_KEEP_DAYS = 100;

function nvStatusCfg(): array {
    $g = fn($k) => trim((string)Store::getSetting($k, ''));
    return ['status_url' => rtrim($g('status_url'), '/'), 'site' => rtrim($g('status_site_url'), '/'), 'cdn' => rtrim($g('status_cdn_url'), '/'),
        'banner' => Store::getSetting('status_banner_on', '1') !== '0'];
}

/** Tek hedefi dener. [ok, ms, http, hata] — 400+ (401 hariç) ve bağlantı hataları "kapalı". */
function nvStatusProbe(string $url): array {
    if ($url === '' || !preg_match('#^https?://#i', $url)) return [false, 0, 0, 'adres tanımsız'];
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_NOBODY => false, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3,
        CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_USERAGENT => 'NeonTV-StatusBot/1.0', CURLOPT_RANGE => '0-2047', CURLOPT_SSL_VERIFYPEER => true, CURLOPT_HEADER => true]);
    $t0 = microtime(true); $raw = (string)curl_exec($ch);
    $ms = (int)round((microtime(true) - $t0) * 1000); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
    if ($code === 0) return [false, $ms, 0, mb_substr($err ?: 'bağlantı kurulamadı', 0, 120)];
    $cf = stripos($raw, 'cf-mitigated') !== false || ($code === 403 && stripos($raw, 'cloudflare') !== false);
    $ok = $code < 400 || $code === 401;   // 403/404/5xx = sorun (Cloudflare engeli dahil)
    return [$ok, $ms, $code, $ok ? '' : ($cf ? 'Cloudflare engeli (HTTP ' . $code . ')' : 'HTTP ' . $code)];
}

/** Tüm hedefleri dener, kaydeder, otomatik olay açar/kapatır. Aynı anda tek çalışma (dosya kilidi). */
function nvStatusRun(bool $force = false): array {
    $lock = sys_get_temp_dir() . '/nv_status_run.lock';
    if (!$force && is_file($lock) && time() - filemtime($lock) < 45) return [];
    @touch($lock);
    $cfg = nvStatusCfg(); $db = new Supabase(); $out = [];
    foreach (['site', 'cdn'] as $tg) {
        if ($cfg[$tg] === '') continue;
        [$ok, $ms, $code, $err] = nvStatusProbe($cfg[$tg]);
        $db->insert('status_checks', ['target' => $tg, 'ok' => $ok, 'ms' => $ms, 'http_code' => $code ?: null, 'err' => $err ?: null], true);
        $out[$tg] = ['ok' => $ok, 'ms' => $ms, 'code' => $code, 'err' => $err];
        nvStatusAutoIncident($db, $tg);
    }
    Store::clearCache('status_summary'); Store::clearCache('status_banner');
    if (mt_rand(1, 60) === 1) $db->delete('status_checks', 'checked_at=lt.' . rawurlencode(gmdate('Y-m-d\TH:i:s\Z', time() - NV_STATUS_KEEP_DAYS * 86400)), true);
    return $out;
}

/** Son 3 kontrol üst üste başarısızsa otomatik olay açar; son 2 kontrol başarılıysa kapatır. */
function nvStatusAutoIncident(Supabase $db, string $tg): void {
    $r = $db->select('status_checks', 'target=eq.' . $tg . '&order=checked_at.desc&limit=3&select=ok', true)['data'] ?? [];
    if (!is_array($r) || !$r) return;
    $title = $tg === 'cdn' ? 'CDN yanıt vermiyor' : 'Web sitesi yanıt vermiyor';
    $open = $db->first('status_incidents', 'auto=eq.true&resolved_at=is.null&title=eq.' . rawurlencode($title), true);
    $fails = count(array_filter($r, fn($x) => empty($x['ok'])));
    if (!$open && count($r) >= 3 && $fails === 3) {
        $db->insert('status_incidents', ['title' => $title, 'body' => 'Otomatik izleme art arda başarısız yanıt aldı. İnceleniyor.', 'impact' => $tg === 'site' ? 'major' : 'minor', 'state' => 'investigating', 'auto' => true], true);
    } elseif ($open && !empty($r[0]['ok']) && !empty($r[1]['ok'] ?? true)) {
        $db->update('status_incidents', ['state' => 'resolved', 'resolved_at' => gmdate('Y-m-d\TH:i:s\Z'), 'body' => 'Servis yeniden yanıt veriyor.'], 'id=eq.' . $open['id'], true);
    }
}

/** Sayfa ve API için tüm özet (30 sn önbellekli). */
function nvStatusSummary(): array {
    return Store::remember('status_summary', 30, function () {
        $db = new Supabase(); $cfg = nvStatusCfg(); $res = ['targets' => [], 'incidents' => [], 'last_at' => 0];
        foreach (['site', 'cdn'] as $tg) {
            if ($cfg[$tg] === '') continue;
            $recent = $db->select('status_checks', 'target=eq.' . $tg . '&order=checked_at.desc&limit=48&select=ok,ms,http_code,checked_at', true)['data'] ?? [];
            $recent = is_array($recent) ? $recent : [];
            $daily = $db->rpc('nv_status_daily', ['p_target' => $tg, 'p_days' => 90], true)['data'] ?? [];
            $daily = is_array($daily) ? $daily : [];
            $win = function (int $days) use ($daily) {
                $from = date('Y-m-d', time() - ($days - 1) * 86400); $t = $o = 0;
                foreach ($daily as $d) { if ($d['day'] >= $from) { $t += (int)$d['total']; $o += (int)$d['ok']; } }
                return $t ? round($o / $t * 100, 2) : null;
            };
            $last = $recent[0] ?? null; if ($last) $res['last_at'] = max($res['last_at'], strtotime($last['checked_at']));
            $res['targets'][$tg] = ['name' => NV_STATUS_TARGETS[$tg], 'url' => $cfg[$tg],
                'up' => $last ? (bool)$last['ok'] : null, 'ms' => $last ? (int)$last['ms'] : null, 'at' => $last ? strtotime($last['checked_at']) : null,
                'u24' => $win(1), 'u7' => $win(7), 'u30' => $win(30), 'u90' => $win(90),
                'days' => array_map(fn($d) => ['d' => $d['day'], 'p' => (int)$d['total'] ? round($d['ok'] / $d['total'] * 100, 1) : null, 'ms' => (int)$d['avg_ms']], $daily),
                'spark' => array_reverse(array_map(fn($x) => $x['ok'] ? (int)$x['ms'] : -1, $recent))];
        }
        $inc = $db->select('status_incidents', 'started_at=gte.' . rawurlencode(gmdate('Y-m-d\TH:i:s\Z', time() - 14 * 86400)) . '&order=started_at.desc&limit=30', true)['data'] ?? [];
        $res['incidents'] = is_array($inc) ? $inc : [];
        return $res;
    });
}

/** Genel durum: operational | degraded | major | maintenance | unknown */
function nvStatusOverall(array $sum): string {
    foreach ($sum['incidents'] as $i) if (empty($i['resolved_at']) && ($i['impact'] ?? '') === 'maintenance') return 'maintenance';
    $t = $sum['targets']; if (!$t) return 'unknown';
    $down = 0; foreach ($t as $x) if ($x['up'] === false) $down++;
    foreach ($sum['incidents'] as $i) if (empty($i['resolved_at']) && ($i['impact'] ?? '') === 'major') return 'major';
    if ($down === count($t)) return 'major'; if ($down > 0) return 'degraded';
    foreach ($sum['incidents'] as $i) if (empty($i['resolved_at'])) return 'degraded';
    return 'operational';
}

/** Ana sitenin üstündeki otomatik uyarı çubuğu (sorun yoksa boş). Eski kontrol varsa yanıttan sonra yenisini tetikler. */
function nvStatusBarHtml(): string {
    try {
        $cfg = nvStatusCfg();
        if (!$cfg['banner'] || ($cfg['site'] === '' && $cfg['cdn'] === '')) return '';
        $d = Store::remember('status_banner', 30, function () {
            $s = nvStatusSummary(); $open = [];
            foreach ($s['incidents'] as $i) if (empty($i['resolved_at'])) $open[] = $i;
            $down = []; foreach ($s['targets'] as $k => $t) if ($t['up'] === false) $down[] = $k;
            return ['open' => $open, 'down' => $down, 'last' => $s['last_at']];
        });
        if ((time() - (int)$d['last']) > NV_STATUS_STALE) {
            static $sched = false;
            if (!$sched) { $sched = true; register_shutdown_function(function () { if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request(); try { nvStatusRun(); } catch (\Throwable $e) {} }); }
        }
        if (!$d['open'] && !$d['down']) return '';
        $inc = $d['open'][0] ?? null; $maint = $inc && ($inc['impact'] ?? '') === 'maintenance';
        $msg = $inc ? $inc['title'] : (in_array('site', $d['down'], true) ? 'Web sitesi yanıt vermiyor' : 'CDN (video/görsel sunucusu) yanıt vermiyor');
        $e = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $col = $maint ? ['#3b82f6', '#fff'] : ['#f59e0b', '#1c1300'];
        $lnk = $cfg['status_url'] !== '' ? ' <a href="' . $e($cfg['status_url']) . '" target="_blank" rel="noopener" style="color:inherit;text-decoration:underline;font-weight:800">Durum sayfası →</a>' : '';
        return '<div id="nv-status-bar" role="status" style="background:' . $col[0] . ';color:' . $col[1] . ';text-align:center;font-size:13px;font-weight:600;padding:7px 14px;line-height:1.4">'
            . ($maint ? '🛠 Planlı bakım: ' : '⚠ Bazı sorunlar yaşanabilir: ') . $e($msg) . '.' . $lnk . '</div>';
    } catch (\Throwable $e) { return ''; }
}
