<?php
// Cron ile: * * * * * php /var/www/html/status/check.php   (tarayıcıdan da çağrılabilir: ?key=STATUS_CRON_KEY)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/status_core.php';
if (PHP_SAPI !== 'cli') {
    $k = (string)getenv('STATUS_CRON_KEY');
    if ($k === '' || !hash_equals($k, (string)($_GET['key'] ?? ''))) { http_response_code(403); exit('forbidden'); }
    header('Content-Type: application/json');
}
date_default_timezone_set('Europe/Istanbul');
echo json_encode(nvStatusRun(true), JSON_UNESCAPED_UNICODE), PHP_EOL;
