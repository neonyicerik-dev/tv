<?php
// NeonTV Durum Sayfası — ana sitenin tasarımından bağımsız, aynı veritabanını okur.
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/status_core.php';
date_default_timezone_set('Europe/Istanbul');
$e = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$cfg = nvStatusCfg();
if (isset($_GET['json'])) { header('Content-Type: application/json'); header('Access-Control-Allow-Origin: *'); $s = nvStatusSummary(); echo json_encode(['overall' => nvStatusOverall($s), 'targets' => array_map(fn($t) => ['up' => $t['up'], 'ms' => $t['ms'], 'u30' => $t['u30']], $s['targets'])]); exit; }
$sum = nvStatusSummary();
if ($sum['targets'] && (time() - (int)$sum['last_at']) > NV_STATUS_STALE) {
    register_shutdown_function(function () { if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request(); try { nvStatusRun(); } catch (\Throwable $x) {} });
}
$ov = nvStatusOverall($sum);
$OV = ['operational' => ['Tüm sistemler çalışıyor', '#22c55e'], 'degraded' => ['Kısmi sorun yaşanıyor', '#f59e0b'], 'major' => ['Büyük kesinti', '#ef4444'], 'maintenance' => ['Planlı bakım', '#3b82f6'], 'unknown' => ['Durum bilgisi yok', '#6b7280']][$ov];
$IMP = ['minor' => 'Küçük etki', 'major' => 'Büyük kesinti', 'maintenance' => 'Bakım']; $ST = ['investigating' => 'İnceleniyor', 'identified' => 'Belirlendi', 'monitoring' => 'İzleniyor', 'resolved' => 'Çözüldü'];
$home = $cfg['site'] ?: '/';
if (!headers_sent()) { header('Cache-Control: public, max-age=20'); header('X-Robots-Tag: noindex'); }
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="60">
<title>NeonTV Durum</title><meta name="robots" content="noindex">
<style>:root{--bg:#0b0b14;--card:#13131f;--tx:#e5e7eb;--mu:#8b8fa3;--bd:rgba(255,255,255,.08)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.w{max-width:820px;margin:0 auto;padding:28px 16px 60px}header{display:flex;justify-content:space-between;align-items:center;margin-bottom:22px}
header a{color:#00f5ff;text-decoration:none;font-size:13px}h1{font-size:20px;margin:0;letter-spacing:.3px}h1 b{color:#00f5ff}
.hero{border-radius:16px;padding:20px 22px;color:#fff;font-weight:800;font-size:19px;margin-bottom:22px}
.card{background:var(--card);border:1px solid var(--bd);border-radius:16px;padding:18px;margin-bottom:16px}
.row{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.dot{width:10px;height:10px;border-radius:50%}
.nm{font-weight:700;flex:1}.badge{font-size:12px;font-weight:700;padding:3px 10px;border-radius:99px}
.bars{display:flex;gap:2px;height:34px;margin:14px 0 6px}.bars i{flex:1;border-radius:2px;min-width:2px}
.lg{display:flex;justify-content:space-between;color:var(--mu);font-size:11px}
.st{display:flex;gap:18px;flex-wrap:wrap;margin-top:12px;font-size:13px;color:var(--mu)}.st b{display:block;color:var(--tx);font-size:16px}
svg{display:block;width:100%;height:38px;margin-top:10px}h2{font-size:15px;margin:26px 0 10px;color:var(--mu);font-weight:700}
.inc{border-left:3px solid var(--bd);padding:2px 0 2px 12px;margin-bottom:14px}.inc small{color:var(--mu)}.inc p{margin:4px 0 0;color:#c7c9d6;font-size:14px}
footer{color:var(--mu);font-size:12px;text-align:center;margin-top:30px}</style></head><body><div class="w">
<header><h1><b>Neon</b>TV · Durum</h1><a href="<?= $e($home) ?>">← Siteye dön</a></header>
<div class="hero" style="background:<?= $OV[1] ?>"><?= $OV[0] ?></div>
<?php if (!$sum['targets']): ?><div class="card" style="color:var(--mu)">Henüz izlenen adres tanımlanmadı (Admin → Durum Sayfası).</div><?php endif; ?>
<?php foreach ($sum['targets'] as $k => $t):
  $byDay = []; foreach ($t['days'] as $d) $byDay[$d['d']] = $d;
  $up = $t['up']; $col = $up === null ? '#6b7280' : ($up ? '#22c55e' : '#ef4444'); ?>
<div class="card"><div class="row"><span class="dot" style="background:<?= $col ?>"></span><span class="nm"><?= $e($t['name']) ?></span>
  <span class="badge" style="background:<?= $col ?>22;color:<?= $col ?>"><?= $up === null ? 'Veri yok' : ($up ? 'Çalışıyor' : 'Kapalı') ?></span></div>
  <div class="bars" title="Son 90 gün"><?php for ($i = 89; $i >= 0; $i--): $day = date('Y-m-d', time() - $i * 86400); $d = $byDay[$day] ?? null; $p = $d['p'] ?? null;
    $c = $p === null ? '#2a2a3a' : ($p >= 99.5 ? '#22c55e' : ($p >= 95 ? '#f59e0b' : '#ef4444')); ?><i style="background:<?= $c ?>" title="<?= $e(date('d.m.Y', strtotime($day))) ?>: <?= $p === null ? 'veri yok' : '%' . $p ?>"></i><?php endfor; ?></div>
  <div class="lg"><span>90 gün önce</span><span>Bugün</span></div>
  <?php $sp = array_slice($t['spark'], -48); $ok = array_filter($sp, fn($v) => $v >= 0); $mx = max(1, ...($ok ?: [1])); $n = max(1, count($sp) - 1); $pts = [];
    foreach ($sp as $i => $v) if ($v >= 0) $pts[] = round($i / $n * 300, 1) . ',' . round(34 - $v / $mx * 30, 1); ?>
  <?php if (count($pts) > 1): ?><svg viewBox="0 0 300 36" preserveAspectRatio="none"><polyline points="<?= implode(' ', $pts) ?>" fill="none" stroke="#00f5ff" stroke-width="1.5" vector-effect="non-scaling-stroke"/></svg><?php endif; ?>
  <div class="st"><span><b><?= $t['ms'] !== null ? (int)$t['ms'] . ' ms' : '—' ?></b>yanıt süresi</span>
    <?php foreach (['u24' => '24 saat', 'u7' => '7 gün', 'u30' => '30 gün', 'u90' => '90 gün'] as $f => $l): ?><span><b><?= $t[$f] === null ? '—' : '%' . $t[$f] ?></b><?= $l ?></span><?php endforeach; ?></div></div>
<?php endforeach; ?>
<h2>Son 14 günün olayları</h2>
<?php foreach ($sum['incidents'] as $i): $res = !empty($i['resolved_at']); ?>
<div class="inc" style="border-color:<?= $res ? '#22c55e' : ($i['impact'] === 'maintenance' ? '#3b82f6' : '#f59e0b') ?>"><strong><?= $e($i['title']) ?></strong>
  <small> · <?= $e($IMP[$i['impact']] ?? '') ?> · <?= $e($ST[$i['state']] ?? '') ?> · <?= $e(date('d.m.Y H:i', strtotime($i['started_at']))) ?><?= $res ? ' → ' . $e(date('d.m H:i', strtotime($i['resolved_at']))) : '' ?></small>
  <?php if (!empty($i['body'])): ?><p><?= $e($i['body']) ?></p><?php endif; ?></div>
<?php endforeach; if (!$sum['incidents']): ?><p style="color:var(--mu)">Son 14 günde olay kaydedilmedi.</p><?php endif; ?>
<footer>Her dakika otomatik yenilenir · Son kontrol: <?= $sum['last_at'] ? $e(date('d.m.Y H:i:s', $sum['last_at'])) : '—' ?></footer></div></body></html>
