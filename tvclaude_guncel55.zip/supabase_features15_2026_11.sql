-- NeonTV özellik paketi 15: okunabilir adresler (/kanal/enes-batur, /user/enes-batur) + durum sayfası tabloları
-- Supabase → SQL Editor'da çalıştırın.

-- ===== 1) Slug üretimi (Türkçe karakterler dönüştürülür) =====
CREATE OR REPLACE FUNCTION public.nv_slugify(t TEXT) RETURNS TEXT
LANGUAGE sql IMMUTABLE AS $$
  SELECT COALESCE(NULLIF(trim(both '-' from regexp_replace(
    lower(translate(coalesce(t,''), 'ÇĞİIÖŞÜçğıöşüÂÎÛâîû', 'cgiiosucgiosuaiuaiu')),
    '[^a-z0-9]+', '-', 'g')), ''), 'x')
$$;

ALTER TABLE public.channels ADD COLUMN IF NOT EXISTS slug TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS slug TEXT;

-- Mevcut kayıtlar: çakışanlara -2, -3 … eklenir (eskiden oluşturulana öncelik)
WITH r AS (
  SELECT id, public.nv_slugify(name) AS s, row_number() OVER (PARTITION BY public.nv_slugify(name) ORDER BY created_at, id) AS n FROM public.channels
) UPDATE public.channels c SET slug = CASE WHEN r.n = 1 THEN r.s ELSE r.s || '-' || r.n END FROM r WHERE c.id = r.id AND c.slug IS NULL;
WITH r AS (
  SELECT id, public.nv_slugify(username) AS s, row_number() OVER (PARTITION BY public.nv_slugify(username) ORDER BY created_at, id) AS n FROM public.profiles
) UPDATE public.profiles p SET slug = CASE WHEN r.n = 1 THEN r.s ELSE r.s || '-' || r.n END FROM r WHERE p.id = r.id AND p.slug IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS channels_slug_uq ON public.channels (slug);
CREATE UNIQUE INDEX IF NOT EXISTS profiles_slug_uq ON public.profiles (slug);

-- Yeni kayıt / ad değişikliğinde otomatik slug
CREATE OR REPLACE FUNCTION public.nv_set_slug() RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE base TEXT; cand TEXT; i INT := 1; src TEXT; tbl TEXT := TG_TABLE_NAME;
BEGIN
  IF tbl = 'channels' THEN src := NEW.name; ELSE src := NEW.username; END IF;
  IF TG_OP = 'UPDATE' THEN
    IF (tbl = 'channels' AND NEW.name IS NOT DISTINCT FROM OLD.name AND NEW.slug IS NOT NULL)
       OR (tbl = 'profiles' AND NEW.username IS NOT DISTINCT FROM OLD.username AND NEW.slug IS NOT NULL) THEN RETURN NEW; END IF;
  END IF;
  base := public.nv_slugify(src); cand := base;
  LOOP
    IF tbl = 'channels' THEN
      EXIT WHEN NOT EXISTS (SELECT 1 FROM public.channels WHERE slug = cand AND id <> NEW.id);
    ELSE
      EXIT WHEN NOT EXISTS (SELECT 1 FROM public.profiles WHERE slug = cand AND id <> NEW.id);
    END IF;
    i := i + 1; cand := base || '-' || i;
  END LOOP;
  NEW.slug := cand; RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS channels_slug_trg ON public.channels;
CREATE TRIGGER channels_slug_trg BEFORE INSERT OR UPDATE OF name ON public.channels FOR EACH ROW EXECUTE FUNCTION public.nv_set_slug();
DROP TRIGGER IF EXISTS profiles_slug_trg ON public.profiles;
CREATE TRIGGER profiles_slug_trg BEFORE INSERT OR UPDATE OF username ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.nv_set_slug();

-- ===== 2) Durum sayfası =====
CREATE TABLE IF NOT EXISTS public.status_checks (
  id         BIGSERIAL PRIMARY KEY,
  target     TEXT NOT NULL CHECK (target IN ('site','cdn')),
  ok         BOOLEAN NOT NULL,
  ms         INTEGER,
  http_code  INTEGER,
  err        TEXT,
  checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS status_checks_idx ON public.status_checks (target, checked_at DESC);

CREATE TABLE IF NOT EXISTS public.status_incidents (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title       TEXT NOT NULL,
  body        TEXT,
  impact      TEXT NOT NULL DEFAULT 'minor' CHECK (impact IN ('minor','major','maintenance')),
  state       TEXT NOT NULL DEFAULT 'investigating' CHECK (state IN ('investigating','identified','monitoring','resolved')),
  started_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at TIMESTAMPTZ,
  auto        BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS status_incidents_idx ON public.status_incidents (started_at DESC);

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['status_checks','status_incidents'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('REVOKE ALL ON public.%I FROM anon, authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
  END LOOP;
END $$;
REVOKE ALL ON SEQUENCE public.status_checks_id_seq FROM anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.status_checks_id_seq TO service_role;

-- Durum sayfası: günlük çalışma özeti (90 günlük çubuk için tek sorgu)
CREATE OR REPLACE FUNCTION public.nv_status_daily(p_target TEXT, p_days INT)
RETURNS TABLE(day DATE, total INT, ok INT, avg_ms INT)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT (checked_at AT TIME ZONE 'Europe/Istanbul')::date AS day,
         count(*)::int AS total, count(*) FILTER (WHERE ok)::int AS ok,
         COALESCE(round(avg(ms) FILTER (WHERE ok))::int, 0) AS avg_ms
  FROM public.status_checks
  WHERE target = p_target AND checked_at >= now() - make_interval(days => GREATEST(1, LEAST(p_days, 120)))
  GROUP BY 1 ORDER BY 1
$$;
REVOKE ALL ON FUNCTION public.nv_status_daily(TEXT, INT) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.nv_status_daily(TEXT, INT) TO service_role;
