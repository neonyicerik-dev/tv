-- NeonTV features16: oynatıcı tercihleri (hesap bazlı). Tekrar çalıştırılabilir, RLS güvenli.
CREATE TABLE IF NOT EXISTS public.user_prefs (
    user_id    uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    prefs      jsonb NOT NULL DEFAULT '{}'::jsonb,
    updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.user_prefs ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.user_prefs FROM anon, authenticated;
GRANT ALL ON public.user_prefs TO service_role;
