<?php
// NeonTV - Veda/duyuru mesajları (admin → Kapanış Mesajları)
//   notice: +18 uyarısından sonra çıkar, "Devam et" ile kapanır, çerezle hatırlanır.
//   block : site kapalı sayfası (admin hariç kimse giremez).
// Ayar: site_farewell = {notice:{on,start,end,title,body,btn}, block:{on,start,end,title,body}}  (zamanlar İstanbul saati, "Y-m-d\TH:i")
require_once __DIR__ . '/store.php';

function nvFarewellDefaults(): array {
    $thanks = "2024'ün başından beri bize destek olduğunuz için çok teşekkür ederiz.";
    return [
        'notice' => ['on' => false, 'start' => '', 'end' => '', 'title' => 'Yakında yeni bir döneme giriyoruz', 'body' => "NeonTV'nin içerik türü çok yakında değişecek.\n" . $thanks, 'btn' => 'Devam et'],
        'block'  => ['on' => false, 'start' => '', 'end' => '', 'title' => 'İçerik türü değişimi için bakımdayız', 'body' => "Sitemiz içerik türü değişikliği nedeniyle geçici olarak kapalıdır.\n" . $thanks, 'btn' => ''],
    ];
}
function nvFarewellCfg(): array {
    $d = nvFarewellDefaults(); $s = Store::getSetting('site_farewell', []);
    if (is_string($s)) $s = json_decode($s, true);
    foreach (['notice', 'block'] as $k) if (is_array($s[$k] ?? null)) $d[$k] = array_merge($d[$k], $s[$k]);
    return $d;
}
function nvFarewellTs(string $v): ?int {
    if ($v === '') return null;
    try { return (new DateTime($v, new DateTimeZone('Europe/Istanbul')))->getTimestamp(); } catch (\Throwable $e) { return null; }
}
/** 'upcoming' | 'active' | 'ended' | 'off' */
function nvFarewellState(array $c): string {
    if (empty($c['on'])) return 'off';
    $now = time(); $a = nvFarewellTs((string)$c['start']); $b = nvFarewellTs((string)$c['end']);
    if ($a !== null && $now < $a) return 'upcoming';
    if ($b !== null && $now >= $b) return 'ended';
    return 'active';
}
function nvFarewellVersion(array $c): string { return substr(md5(($c['title'] ?? '') . '|' . ($c['body'] ?? '') . '|' . ($c['start'] ?? '')), 0, 8); }

function nvFarewellCss(): string {
    return '<style>.fw-wrap{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:18px;background:radial-gradient(900px 500px at 20% -10%,rgba(255,0,122,.16),transparent 60%),radial-gradient(800px 500px at 100% 110%,rgba(0,245,255,.12),transparent 60%),#070711;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;overflow:auto}'
        . '.fw-box{max-width:520px;width:100%;text-align:center;color:#e5e7eb;background:rgba(15,15,30,.92);border:1px solid rgba(255,255,255,.1);border-radius:24px;padding:38px 28px;box-shadow:0 30px 80px rgba(0,0,0,.55);animation:fwIn .5s cubic-bezier(.34,1.56,.64,1)}'
        . '.fw-ic{font-size:44px;margin-bottom:10px;filter:drop-shadow(0 0 16px rgba(255,0,122,.5))}.fw-box h2{margin:0 0 12px;font-size:23px;font-weight:800;color:#fff;letter-spacing:.2px}'
        . '.fw-box p{margin:0 0 6px;line-height:1.65;color:#c4c7d4;font-size:15px}.fw-btn{margin-top:22px;display:inline-block;border:0;cursor:pointer;padding:13px 34px;border-radius:14px;font-weight:800;font-size:15px;color:#000;background:linear-gradient(135deg,#00f5ff,#7df9ff);box-shadow:0 8px 28px rgba(0,245,255,.3);transition:transform .15s}.fw-btn:hover{transform:translateY(-2px)}'
        . '.fw-brand{margin-top:24px;font-size:12px;letter-spacing:3px;color:#6b7280;font-weight:700}@keyframes fwIn{from{opacity:0;transform:translateY(14px) scale(.96)}to{opacity:1;transform:none}}</style>';
}
function nvFarewellBody(array $c, string $icon, string $btn = ''): string {
    $e = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $p = ''; foreach (preg_split('/\R+/u', trim((string)$c['body'])) as $l) if (trim($l) !== '') $p .= '<p>' . $e($l) . '</p>';
    return '<div class="fw-box"><div class="fw-ic">' . $icon . '</div><h2>' . $e($c['title']) . '</h2>' . $p . $btn . '<div class="fw-brand">NEONTV</div></div>';
}

/** Site kapalı sayfası: aktifse sayfayı yazıp çıkar (admin girişi serbest; ?fw=block ile admin önizler). */
function nvFarewellEnforceBlock(): void {
    $c = nvFarewellCfg()['block']; $admin = function_exists('isAdminLoggedIn') && isAdminLoggedIn();
    $prev = $admin && (($_GET['fw'] ?? '') === 'block');
    if (!$prev && (nvFarewellState($c) !== 'active' || $admin)) return;
    while (ob_get_level()) @ob_end_clean();
    if (!headers_sent()) { http_response_code(503); header('Retry-After: 86400'); header('Content-Type: text/html; charset=utf-8'); header('Cache-Control: no-store'); }
    echo '<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>' . htmlspecialchars($c['title']) . ' · NeonTV</title>' . nvFarewellCss() . '</head><body style="margin:0"><div class="fw-wrap">' . nvFarewellBody($c, '🛠') . '</div></body></html>';
    exit;
}
/** +18 uyarısından sonra görünen "Devam et" mesajı (HTML; gösterilmeyecekse boş). */
function nvFarewellNoticeHtml(): string {
    $c = nvFarewellCfg()['notice']; $admin = function_exists('isAdminLoggedIn') && isAdminLoggedIn();
    $prev = $admin && (($_GET['fw'] ?? '') === 'notice'); $v = nvFarewellVersion($c);
    if (!$prev) { if (nvFarewellState($c) !== 'active') return ''; if (($_COOKIE['neontv_fw_ok'] ?? '') === $v) return ''; }
    $btn = '<button type="button" class="fw-btn" id="fw-go">' . htmlspecialchars($c['btn'] !== '' ? $c['btn'] : 'Devam et') . '</button>';
    $js = '<script>(function(){var m=document.getElementById("fw-notice"),b=document.getElementById("fw-go");if(!m||!b)return;document.body.style.overflow="hidden";'
        . 'b.onclick=function(){try{document.cookie="neontv_fw_ok=' . $v . '; max-age=15552000; path=/; SameSite=Lax"+(location.protocol==="https:"?"; Secure":"")}catch(e){}m.style.transition="opacity .3s";m.style.opacity="0";setTimeout(function(){m.remove();document.body.style.overflow=""},300)};})();</script>';
    return nvFarewellCss() . '<div id="fw-notice" role="dialog" aria-modal="true" class="fw-wrap" style="z-index:99990;background:rgba(7,7,17,.96)">' . nvFarewellBody($c, '💜', $btn) . '</div>' . $js;
}
