<?php
// NeonTV - Admin: İçerik üreticileri (onay kuyruğu, ayarlar, hesap yönetimi, süresi dolanları şimdi kaldır)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/creator.php';
requireAdmin(['superadmin', 'moderator']);
$db = new Supabase(); $self = APP_URL . '/admin/creators.php'; $isSuper = getAdminRole() === 'superadmin';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect($self); }
    $act = input('action'); $id = trim((string)input('id'));
    if ($act === 'settings' && $isSuper) {
        Store::setSetting('creator_auto_publish', input('auto') === '1' ? '1' : '0');
        foreach (['creator_max_active' => [1, 100], 'creator_daily_limit' => [1, 50], 'creator_max_mb' => [10, 2000], 'creator_max_min' => [1, 180], 'creator_short_sec' => [10, 180], 'creator_post_daily' => [1, 100]] as $k => [$lo, $hi]) Store::setSetting($k, (string)max($lo, min($hi, (int)input($k))));
        Store::clearCache('site_settings'); setFlash('success', 'Ayarlar kaydedildi.');
    } elseif ($act === 'approve' && isUuid($id)) {
        $db->update('videos', ['status' => 'published', 'reject_reason' => null], 'id=eq.' . $id . '&status=eq.pending', true); logActivity('creator_approve', 'video', $id); setFlash('success', 'Video yayınlandı.');
    } elseif ($act === 'reject' && isUuid($id)) {
        $v = $db->first('videos', 'id=eq.' . $id . '&select=id,cloudinary_public_id,video_url', true);
        if ($v) { $v['reject_reason'] = mb_substr(trim((string)input('reason')), 0, 200) ?: 'İçerik kurallarına uymuyor'; $db->update('videos', ['reject_reason' => $v['reject_reason']], 'id=eq.' . $id, true); nvRemoveUserVideo($db, $v, 'rejected'); $db->update('videos', ['status' => 'rejected'], 'id=eq.' . $id, true); logActivity('creator_reject', 'video', $id); setFlash('success', 'Video reddedildi ve dosyası silindi.'); }
    } elseif ($act === 'ban' && isUuid($id)) {
        $db->update('profiles', ['creator_banned' => input('on') === '1'], 'id=eq.' . $id, true); logActivity('creator_ban', 'user', $id); setFlash('success', 'Güncellendi.');
    } elseif ($act === 'post_del' && isUuid($id)) {
        $db->delete('posts', 'id=eq.' . $id, true); logActivity('post_delete', 'post', $id); setFlash('success', 'Gönderi silindi.');
    } elseif ($act === 'expire') { $n = nvExpireUserVideos($db); setFlash('success', $n . ' video kaldırıldı.'); }
    redirect($self);
}
$cfg = nvCreatorCfg();
$pending = $db->select('videos', 'status=eq.pending&order=created_at.asc&limit=50&select=id,title,description,thumbnail_url,duration,expires_at,created_at,owner_id,channels(name)', true)['data'] ?? [];
$creators = $db->select('profiles', 'is_creator=eq.true&order=creator_since.desc&limit=100&select=id,username,creator_banned,creator_since', true)['data'] ?? [];
$posts = $db->select('posts', 'order=created_at.desc&limit=20&select=id,body,image_url,created_at,author_id', true)['data'] ?? []; $posts = is_array($posts) ? $posts : [];
$pending = is_array($pending) ? $pending : []; $creators = is_array($creators) ? $creators : [];
$adminTitle = 'İçerik Üreticileri'; $adminSub = count($pending) . ' video onay bekliyor · ' . count($creators) . ' içerik üreticisi';
include __DIR__ . '/_top.php';
$card = 'background:#13131f;border:1px solid rgba(255,255,255,.08)'; $inp = 'px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-sm text-white';
?>
<div class="max-w-5xl space-y-5">
 <div class="rounded-2xl p-4" style="<?= $card ?>"><h3 class="text-sm font-bold text-white mb-3">Onay bekleyen videolar</h3>
  <?php foreach ($pending as $v): ?>
   <div class="flex flex-wrap items-center gap-3 py-3 border-b border-white/5">
    <img src="<?= e($v['thumbnail_url']) ?>" alt="" style="width:120px;aspect-ratio:16/9;object-fit:cover;border-radius:8px;background:#0b0b14">
    <div class="flex-1 min-w-0"><div class="text-white text-sm font-semibold truncate"><?= e($v['title']) ?></div>
     <div class="text-xs text-gray-500"><?= e($v['channels']['name'] ?? '') ?> · <?= (int)$v['duration'] ?> sn · yayın sonu: <?= e(date('d.m H:i', strtotime($v['expires_at']))) ?></div>
     <a class="text-xs text-cyan-300 underline" target="_blank" href="<?= APP_URL ?>/video.php?id=<?= e($v['id']) ?>">İzle (önizleme)</a></div>
    <form method="post" class="flex items-center gap-2"><?= csrfField() ?><input type="hidden" name="id" value="<?= e($v['id']) ?>">
     <button name="action" value="approve" class="px-3 py-1.5 rounded-lg text-xs font-bold text-black" style="background:#22c55e">Onayla</button>
     <input name="reason" placeholder="Red sebebi" class="<?= $inp ?> !py-1 text-xs" style="width:150px"><button name="action" value="reject" class="px-3 py-1.5 rounded-lg text-xs font-bold text-white" style="background:#ef4444" onclick="return confirm('Video reddedilip dosyası silinsin mi?')">Reddet</button></form>
   </div>
  <?php endforeach; if (!$pending): ?><p class="text-sm text-gray-500">Onay bekleyen video yok.</p><?php endif; ?></div>

 <?php if ($isSuper): ?><form method="post" class="rounded-2xl p-4 grid sm:grid-cols-2 gap-3" style="<?= $card ?>"><?= csrfField() ?><input type="hidden" name="action" value="settings">
  <h3 class="text-sm font-bold text-white sm:col-span-2">Ayarlar</h3>
  <label class="flex items-center gap-2 text-sm text-gray-200 sm:col-span-2"><input type="checkbox" name="auto" value="1" <?= $cfg['auto'] ? 'checked' : '' ?>> Videoları onaysız hemen yayınla <span class="text-[11px] text-gray-500">(kapalıyken her video önce onay bekler — yeni başlayan site için önerilir)</span></label>
  <div><label class="block text-[11px] text-gray-500 mb-1">Aynı anda en fazla aktif video</label><input type="number" name="creator_max_active" value="<?= $cfg['active'] ?>" class="<?= $inp ?> w-full"></div>
  <div><label class="block text-[11px] text-gray-500 mb-1">24 saatte en fazla yükleme</label><input type="number" name="creator_daily_limit" value="<?= $cfg['daily'] ?>" class="<?= $inp ?> w-full"></div>
  <div><label class="block text-[11px] text-gray-500 mb-1">En büyük dosya (MB) — Cloudinary planınızı aşmayın</label><input type="number" name="creator_max_mb" value="<?= $cfg['mb'] ?>" class="<?= $inp ?> w-full"></div>
  <div><label class="block text-[11px] text-gray-500 mb-1">En uzun video (dakika)</label><input type="number" name="creator_max_min" value="<?= $cfg['minutes'] ?>" class="<?= $inp ?> w-full"></div>
  <div><label class="block text-[11px] text-gray-500 mb-1">En uzun kısa video (saniye)</label><input type="number" name="creator_short_sec" value="<?= $cfg['short_sec'] ?>" class="<?= $inp ?> w-full"></div>
  <div><label class="block text-[11px] text-gray-500 mb-1">24 saatte en fazla gönderi</label><input type="number" name="creator_post_daily" value="<?= $cfg['post_daily'] ?>" class="<?= $inp ?> w-full"></div>
  <div class="sm:col-span-2 flex gap-3"><button class="px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#00f5ff">Kaydet</button></div></form><?php endif; ?>

 <div class="rounded-2xl p-4" style="<?= $card ?>"><div class="flex items-center justify-between mb-3"><h3 class="text-sm font-bold text-white">İçerik üreticileri</h3>
   <form method="post"><?= csrfField() ?><button name="action" value="expire" class="px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-white/10">Süresi dolanları şimdi kaldır</button></form></div>
  <?php foreach ($creators as $c): ?><form method="post" class="flex items-center gap-3 py-2 border-b border-white/5 text-sm"><?= csrfField() ?><input type="hidden" name="id" value="<?= e($c['id']) ?>"><input type="hidden" name="action" value="ban">
    <span class="flex-1 text-gray-200 truncate"><?= e($c['username'] ?: $c['id']) ?></span><span class="text-xs text-gray-500"><?= $c['creator_since'] ? e(date('d.m.Y', strtotime($c['creator_since']))) : '' ?></span>
    <?php if (!empty($c['creator_banned'])): ?><span class="text-xs text-red-300">kapalı</span><button name="on" value="0" class="text-xs text-green-400">Aç</button>
    <?php else: ?><button name="on" value="1" class="text-xs text-red-400" onclick="return confirm('Bu kişinin video yükleme hakkı kapatılsın mı?')">Kapat</button><?php endif; ?></form>
  <?php endforeach; if (!$creators): ?><p class="text-sm text-gray-500">Henüz içerik üreticisi yok.</p><?php endif; ?></div>
  <div class="rounded-2xl p-5 mt-5" style="background:#13131f;border:1px solid rgba(255,255,255,.08)"><h2 class="font-bold text-white mb-3">Son gönderiler</h2>
  <?php foreach ($posts as $po): ?><form method="post" class="flex items-center gap-3 py-2 border-b border-white/5 text-sm"><?= csrfField() ?><input type="hidden" name="id" value="<?= e($po['id']) ?>"><input type="hidden" name="action" value="post_del">
    <span class="flex-1 text-gray-300 truncate"><?= e(mb_substr((string)$po['body'], 0, 120) ?: '(resim)') ?></span><span class="text-xs text-gray-500"><?= e(date('d.m H:i', strtotime($po['created_at']))) ?></span>
    <button class="text-xs text-red-400" onclick="return confirm('Gönderi silinsin mi?')">Sil</button></form>
  <?php endforeach; if (!$posts): ?><p class="text-sm text-gray-500">Gönderi yok.</p><?php endif; ?></div>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
