<?php
// Gönderiler (içerik üreticilerinin metin + resim paylaşımları)
// GET ?offset=&limit=&author=<uuid> -> akış (giriş varsa liked bilgisi) · POST {action:'create',body,image_url} · POST {action:'like'|'unlike',id} · DELETE ?id=
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/creator.php';
require_once __DIR__ . '/../includes/cdn_video.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $m = $_SERVER['REQUEST_METHOD'];
$tok = getBearerToken(); $me = null;
if ($tok) { $u = $db->verifyToken($tok); if ($u && !empty($u['id']) && isUuid($u['id'])) $me = $u['id']; }
$myPost = fn($id) => $db->first('posts', 'id=eq.' . $id . '&author_id=eq.' . $me . '&select=id,image_url', true);

if ($m === 'GET') {
    $off = max(0, (int)($_GET['offset'] ?? 0)); $lim = max(1, min(20, (int)($_GET['limit'] ?? 10)));
    $q = 'status=eq.published&order=created_at.desc&limit=' . $lim . '&offset=' . $off . '&select=id,author_id,channel_id,body,image_url,likes_count,created_at';
    $a = (string)($_GET['author'] ?? ''); if ($a !== '') { requireUuid($a, 'Yazar'); $q .= '&author_id=eq.' . $a; }
    $rows = $db->select('posts', $q, true)['data'] ?? []; $rows = is_array($rows) ? $rows : [];
    $ids = array_values(array_unique(array_column($rows, 'author_id'))); $au = [];
    if ($ids) foreach (($db->select('profiles', 'id=in.(' . implode(',', $ids) . ')&select=id,username,avatar_url', true)['data'] ?? []) as $pr) $au[$pr['id']] = $pr;
    $liked = [];
    if ($me && $rows) foreach (($db->select('post_likes', 'user_id=eq.' . $me . '&post_id=in.(' . implode(',', array_column($rows, 'id')) . ')&select=post_id', true)['data'] ?? []) as $l) $liked[$l['post_id']] = true;
    foreach ($rows as &$r) { $pr = $au[$r['author_id']] ?? []; $r['author'] = ['name' => $pr['username'] ?? 'Kullanıcı', 'avatar' => $pr['avatar_url'] ?? '']; $r['liked'] = isset($liked[$r['id']]); $r['mine'] = $me && $r['author_id'] === $me; unset($r['author_id']); } unset($r);
    jsonSuccess(['items' => $rows, 'has_more' => count($rows) === $lim]);
}
if (!$me) jsonError('Giriş yapmalısın.', 401);

if ($m === 'DELETE') {
    $id = trim((string)($_GET['id'] ?? '')); requireUuid($id, 'Gönderi');
    if (!$myPost($id)) jsonError('Gönderi bulunamadı', 404);
    $db->delete('posts', 'id=eq.' . $id, true); jsonSuccess([], 'Gönderi silindi.');
}
if ($m !== 'POST') jsonError('Geçersiz metod', 405);
$in = inputJson() ?? []; $act = (string)($in['action'] ?? 'create');

if ($act === 'like' || $act === 'unlike') {
    $id = trim((string)($in['id'] ?? '')); requireUuid($id, 'Gönderi');
    if ($act === 'like') { if (!$db->first('posts', 'id=eq.' . $id . '&status=eq.published&select=id', true)) jsonError('Gönderi bulunamadı', 404); $db->insert('post_likes', ['post_id' => $id, 'user_id' => $me], true); }
    else $db->delete('post_likes', 'post_id=eq.' . $id . '&user_id=eq.' . $me, true);
    $n = $db->count('post_likes', 'post_id=eq.' . $id, true); $db->update('posts', ['likes_count' => $n], 'id=eq.' . $id, true);
    jsonSuccess(['liked' => $act === 'like', 'likes' => $n]);
}
if ($act !== 'create') jsonError('Geçersiz işlem');
denyIfBanned($db, $me);
$p = nvCreatorProfile($db, $me);
if (!$p || empty($p['is_creator']) || !empty($p['creator_banned'])) jsonError('Gönderi için içerik üreticisi hesabı gerekli.', 403);
$cfg = nvCreatorCfg();
$body = mb_substr(trim(preg_replace("/\r\n?/", "\n", strip_tags((string)($in['body'] ?? '')))), 0, 1000);
$img = (string)($in['image_url'] ?? '');
if ($img !== '') {
    $b = nvCdnBase(); $okCdn = $b !== '' && preg_match('#^' . preg_quote($b, '#') . '/f/[a-f0-9]{32}\.(jpg|png|webp)$#', $img);
    $okLocal = strncmp($img, APP_URL . '/assets/posts/' . $me . '_', strlen(APP_URL . '/assets/posts/' . $me . '_')) === 0 && preg_match('#/[0-9a-f-]{36}_[0-9a-f]{12}\.jpg$#', $img);
    if (!$okCdn && !$okLocal) jsonError('Geçersiz resim adresi.');
}
if ($body === '' && $img === '') jsonError('Bir şeyler yaz veya resim ekle.');
$today = $db->count('posts', 'author_id=eq.' . $me . '&created_at=gte.' . rawurlencode(gmdate('Y-m-d\TH:i:s\Z', time() - 86400)), true);
if ($today >= $cfg['post_daily']) jsonError('24 saatte en fazla ' . $cfg['post_daily'] . ' gönderi paylaşabilirsin.', 429);
$chan = nvCreatorChannelId($db, $me, (string)($p['username'] ?? ''));
$r = $db->insert('posts', ['author_id' => $me, 'channel_id' => $chan, 'body' => $body, 'image_url' => $img !== '' ? $img : null], true);
if (($r['status'] ?? 500) >= 400) jsonError('Paylaşılamadı (SQL 18 çalıştı mı?)', 500);
jsonSuccess(['id' => $r['data'][0]['id'] ?? null], 'Gönderi paylaşıldı.');
