<?php
// Kısa video akışı: GET ?offset=&limit=&start=<video id (ilk sırada gösterilecek)>  (giriş gerekmez; giriş varsa liked bilgisi)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase();
$off = max(0, (int)($_GET['offset'] ?? 0)); $lim = max(1, min(12, (int)($_GET['limit'] ?? 6)));
$sel = '&select=id,title,video_url,thumbnail_url,views,likes_count,comments_count,channel_id,owner_id,channels(name)';
$rows = $db->select('videos', 'is_short=eq.true&status=eq.published&removed_at=is.null&video_url=neq.&order=created_at.desc&limit=' . $lim . '&offset=' . $off . $sel, true)['data'] ?? [];
$rows = is_array($rows) ? $rows : [];
$start = trim((string)($_GET['start'] ?? ''));
if ($off === 0 && isUuid($start)) {
    $s = $db->first('videos', 'id=eq.' . $start . '&is_short=eq.true&status=eq.published&removed_at=is.null' . $sel, true);
    if ($s) { $rows = array_values(array_filter($rows, fn($r) => $r['id'] !== $s['id'])); array_unshift($rows, $s); }
}
$tok = getBearerToken(); $liked = [];
if ($tok && $rows) { $u = $db->verifyToken($tok); if ($u && !empty($u['id'])) foreach (($db->select('likes', 'user_id=eq.' . $u['id'] . '&video_id=in.(' . implode(',', array_column($rows, 'id')) . ')&select=video_id', true)['data'] ?? []) as $l) $liked[$l['video_id']] = true; }
foreach ($rows as &$r) { $r['channel'] = $r['channels']['name'] ?? ''; unset($r['channels'], $r['owner_id']); $r['liked'] = isset($liked[$r['id']]); } unset($r);
jsonSuccess(['items' => $rows, 'has_more' => count($rows) >= $lim]);
