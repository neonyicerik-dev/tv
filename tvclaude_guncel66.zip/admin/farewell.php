<?php
// NeonTV - Admin: Kapanış mesajları (1: "Devam et" duyurusu · 2: site kapalı sayfası). Zamanlanabilir, açılıp kapatılabilir.
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/farewell.php';
requireAdmin(['superadmin']);
$self = APP_URL . '/admin/farewell.php'; $cfg = nvFarewellCfg();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect($self); }
    $k = input('which') === 'block' ? 'block' : 'notice';
    $dt = function (string $f) { $v = trim((string)input($f)); return preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $v) ? $v : ''; };
    $cfg[$k] = ['on' => input('on') === '1', 'start' => $dt('start'), 'end' => $dt('end'), 'title' => mb_substr(trim((string)input('title')), 0, 120),
        'body' => mb_substr(trim((string)input('body')), 0, 800), 'btn' => mb_substr(trim((string)input('btn')), 0, 40)];
    if ($cfg[$k]['title'] === '') $cfg[$k]['title'] = nvFarewellDefaults()[$k]['title'];
    Store::setSetting('site_farewell', $cfg); Store::clearCache('site_settings');
    logActivity('farewell_' . $k, 'settings', 'site_farewell');
    setFlash('success', ($k === 'block' ? 'Site kapalı mesajı' : 'Devam et duyurusu') . ' kaydedildi.'); redirect($self);
}
$adminTitle = 'Kapanış Mesajları'; $adminSub = 'İçerik türü değişimi duyurusu ve site kapatma · zamanlanabilir';
include __DIR__ . '/_top.php';
$card = 'background:#13131f;border:1px solid rgba(255,255,255,.08)'; $inp = 'w-full px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-sm text-white';
$ST = ['off' => ['Kapalı', '#9ca3af'], 'upcoming' => ['Zamanlandı (henüz başlamadı)', '#f59e0b'], 'active' => ['ŞU AN YAYINDA', '#22c55e'], 'ended' => ['Süresi doldu', '#9ca3af']];
$blocks = [['notice', '1) Devam et duyurusu', "İlk girişte sayfa açılınca çıkar. 'Devam et' ile kapanır, çerezle hatırlanır (mesaj değişince yeniden çıkar).", '?fw=notice'],
           ['block', '2) Site kapalı (bakım) sayfası', 'Aynı mesaj, ama siteye GİRİLEMEZ (HTTP 503). Yönetici girişi açıksanız site görünür.', '?fw=block']];
?>
<div class="grid lg:grid-cols-2 gap-5 max-w-6xl">
<?php foreach ($blocks as [$k, $t, $desc, $pv]): $c = $cfg[$k]; $st = nvFarewellState($c); ?>
 <form method="post" class="rounded-2xl p-4 space-y-3" style="<?= $card ?>"><?= csrfField() ?><input type="hidden" name="which" value="<?= $k ?>">
  <div class="flex items-center justify-between gap-2"><h3 class="text-sm font-bold text-white"><?= e($t) ?></h3><span class="text-[11px] font-bold px-2 py-0.5 rounded-full" style="color:<?= $ST[$st][1] ?>;background:<?= $ST[$st][1] ?>22"><?= $ST[$st][0] ?></span></div>
  <p class="text-[11px] text-gray-500"><?= e($desc) ?></p>
  <label class="flex items-center gap-2 text-sm text-gray-200"><input type="checkbox" name="on" value="1" <?= !empty($c['on']) ? 'checked' : '' ?>> Etkin (zaman aralığında yayınla)</label>
  <div class="grid grid-cols-2 gap-2"><div><label class="block text-[11px] text-gray-500 mb-1">Başlangıç (İstanbul saati, boş = hemen)</label><input type="datetime-local" name="start" value="<?= e($c['start']) ?>" class="<?= $inp ?>"></div>
   <div><label class="block text-[11px] text-gray-500 mb-1">Bitiş (boş = süresiz)</label><input type="datetime-local" name="end" value="<?= e($c['end']) ?>" class="<?= $inp ?>"></div></div>
  <div><label class="block text-[11px] text-gray-500 mb-1">Başlık</label><input name="title" maxlength="120" value="<?= e($c['title']) ?>" class="<?= $inp ?>"></div>
  <div><label class="block text-[11px] text-gray-500 mb-1">Mesaj (her satır ayrı paragraf)</label><textarea name="body" rows="5" maxlength="800" class="<?= $inp ?>"><?= e($c['body']) ?></textarea></div>
  <?php if ($k === 'notice'): ?><div><label class="block text-[11px] text-gray-500 mb-1">Buton yazısı</label><input name="btn" maxlength="40" value="<?= e($c['btn']) ?>" class="<?= $inp ?>"></div><?php endif; ?>
  <div class="flex items-center gap-3"><button class="px-4 py-2 rounded-lg text-sm font-bold text-black" style="background:#00f5ff">Kaydet</button>
   <a href="<?= APP_URL ?>/<?= $pv ?>" target="_blank" class="text-xs text-cyan-300">Önizle (yalnızca siz görürsünüz)</a></div>
 </form>
<?php endforeach; ?>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
