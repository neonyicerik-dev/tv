<?php
// İçerik üreticisi hesabı: GET -> durum ve istatistik · POST {action:'enable', accept:true} -> hesabı oluşturur (kanal da açılır)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/creator.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id'];
$p = nvCreatorProfile($db, $uid);
$name = trim((string)($p['username'] ?? '')) ?: trim((string)($user['user_metadata']['username'] ?? $user['user_metadata']['full_name'] ?? '')) ?: preg_replace('/@.*$/', '', (string)($user['email'] ?? 'Kanal'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $in = inputJson() ?? [];
    if (($in['action'] ?? '') !== 'enable') jsonError('Geçersiz işlem');
    if (!$p) {                                            // profil satırı yoksa oluştur (giriş yapmış her kullanıcı içerik üreticisi olabilir)
        $db->insert('profiles', ['id' => $uid, 'username' => mb_substr($name, 0, 40), 'avatar_url' => (string)($user['user_metadata']['avatar_url'] ?? '')], true);
        $p = nvCreatorProfile($db, $uid);
        if (!$p) jsonError('Profil oluşturulamadı. Lütfen tekrar dene.', 500);
    }
    denyIfBanned($db, $uid);
    if (!empty($p['creator_banned'])) jsonError('İçerik üreticisi hesabın kapatıldı.', 403);
    if (empty($in['accept'])) jsonError('İçerik kurallarını kabul etmelisin.');
    if (empty($p['is_creator'])) {
        $r = $db->update('profiles', ['is_creator' => true, 'creator_since' => gmdate('Y-m-d\TH:i:s\Z')], 'id=eq.' . $uid, true);
        if (($r['status'] ?? 500) >= 400) jsonError('Hesap açılamadı (SQL 17 çalıştı mı?)', 500);
        nvCreatorChannelId($db, $uid, $name);
    }
    jsonSuccess(['is_creator' => true], 'İçerik üreticisi hesabın hazır!');
}
$cfg = nvCreatorCfg(); $out = ['uid' => $uid, 'is_creator' => !empty($p['is_creator']), 'banned' => !empty($p['creator_banned']), 'days' => NV_CREATOR_DAYS,
    'limits' => ['active' => $cfg['active'], 'daily' => $cfg['daily'], 'mb' => $cfg['mb'], 'minutes' => $cfg['minutes'], 'short_sec' => $cfg['short_sec'], 'post_daily' => $cfg['post_daily']], 'auto_publish' => $cfg['auto'], 'cdn' => (function () { require_once __DIR__ . '/../includes/cdn_video.php'; return nvCdnVideoReady(); })()];
if ($out['is_creator']) {
    $vs = $db->select('videos', 'owner_id=eq.' . $uid . '&select=status,views', true)['data'] ?? [];
    $views = 0; $active = 0; foreach (is_array($vs) ? $vs : [] as $v) { $views += (int)$v['views']; if (in_array($v['status'], ['published', 'pending'], true)) $active++; }
    $out['stats'] = ['total_videos' => count($vs), 'active' => $active, 'total_views' => $views];
}
jsonSuccess($out);
