<?php
// Yüklenen videonun yapay zeka kontrolü. POST {id, frames:[dataURL jpeg x5]} (kareler sunucuda ffmpeg yoksa kullanılır)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/moderation.php';
error_reporting(0); ini_set('display_errors', 0); @set_time_limit(150);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id'];
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);
$in = inputJson() ?? []; $id = trim((string)($in['id'] ?? '')); requireUuid($id, 'Video ID');
$v = $db->first('videos', 'id=eq.' . $id . '&owner_id=eq.' . $uid . '&select=id,title,description,video_url,duration,status,ai_checked_at', true);
if (!$v) jsonError('Video bulunamadı', 404);
if (!empty($v['ai_checked_at']) || $v['status'] !== 'published') jsonSuccess(['status' => $v['status']]);
$frames = [];
foreach (array_slice(is_array($in['frames'] ?? null) ? $in['frames'] : [], 0, 5) as $d) {
    if (!is_string($d) || !preg_match('#^data:image/jpeg;base64,([A-Za-z0-9+/=]+)$#', $d, $m) || strlen($d) > 600000) continue;
    $bin = base64_decode($m[1], true); if ($bin !== false && strlen($bin) > 500 && substr($bin, 0, 2) === "\xFF\xD8") $frames[] = $bin;
}
$server = nvFramesFromUrl((string)$v['video_url'], (int)$v['duration']);   // sunucu kareleri varsa onlara güvenilir
$res = nvModerateVideo($db, $v, $server ?: $frames);
jsonSuccess(['flagged' => $res['checked'] && !$res['ok']], $res['checked'] && !$res['ok'] ? 'Videon otomatik kontrolde şüpheli bulundu; yönetici incelemesine alındı.' : 'Kontrol tamam.');
