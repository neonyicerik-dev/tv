<?php
// İçerik üreticisi için Cloudinary yükleme imzası (yalnızca kendi klasörüne; yalnızca video/resim biçimleri)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/cloudinary.php';
require_once __DIR__ . '/../includes/creator.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id'];
denyIfBanned($db, $uid);
$p = nvCreatorProfile($db, $uid);
if (!$p || empty($p['is_creator']) || !empty($p['creator_banned'])) jsonError('Video yüklemek için içerik üreticisi hesabı gerekli.', 403);
$rl = sys_get_temp_dir() . '/nv_csign_' . md5($uid);
if (is_file($rl) && time() - (int)@filemtime($rl) < 2) jsonError('Biraz yavaş :)', 429);
@touch($rl);
$kind = (($_GET['kind'] ?? '') === 'short') ? 'short' : 'video'; $cfgc = nvCreatorCfg();
$days = (int)($_GET['days'] ?? 7); if (!isset(NV_CREATOR_DAYS[$days])) $days = 7;
require_once __DIR__ . '/../includes/cdn_video.php';
if (nvCdnVideoReady()) {   // video kendi CDN'imize, tarayıcıdan doğrudan yüklenir
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['cdn' => true, 'endpoint' => nvCdnBase() . '/ingest_video.php', 'token' => nvCdnUpToken($uid, $kind, $cfgc['mb'] * 1048576, $kind === 'short' ? $cfgc['short_sec'] : $cfgc['minutes'] * 60, $days)]);
    exit;
}
$folder = 'neontv/user/' . $uid;
$fmt = 'mp4,mov,webm,m4v';
$sig = (new Cloudinary())->generateUploadSignature(['folder' => $folder, 'allowed_formats' => $fmt]);
$sig['folder'] = $folder; $sig['allowed_formats'] = $fmt;
header('Content-Type: application/json; charset=utf-8');
echo json_encode($sig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
