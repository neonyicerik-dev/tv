<?php
// İçerik üreticisinin videoları
// GET -> kendi videoların · POST {title,description,tags,days,video_url,cloudinary_public_id,duration} -> kaydeder · DELETE ?id= -> hemen kaldırır
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/creator.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id']; $m = $_SERVER['REQUEST_METHOD'];
$p = nvCreatorProfile($db, $uid);
if (!$p || empty($p['is_creator'])) jsonError('İçerik üreticisi hesabı gerekli.', 403);
if (!empty($p['creator_banned'])) jsonError('İçerik üreticisi hesabın kapatıldı.', 403);

if ($m === 'GET') {
    $r = $db->select('videos', 'owner_id=eq.' . $uid . '&order=created_at.desc&limit=100&select=id,title,status,is_short,views,likes_count,comments_count,thumbnail_url,duration,expires_at,created_at,removed_at,reject_reason', true)['data'] ?? [];
    jsonSuccess(['items' => is_array($r) ? $r : []]);
}
if ($m === 'DELETE') {
    $id = trim((string)($_GET['id'] ?? '')); requireUuid($id, 'Video ID');
    $v = $db->first('videos', 'id=eq.' . $id . '&owner_id=eq.' . $uid . '&select=id,cloudinary_public_id,video_url,status,removed_at', true);
    if (!$v) jsonError('Video bulunamadı', 404);
    if (empty($v['removed_at'])) nvRemoveUserVideo($db, $v);
    jsonSuccess([], 'Video kaldırıldı. İzlenme sayın profilinde kalır.');
}
if ($m !== 'POST') jsonError('Geçersiz metod', 405);
denyIfBanned($db, $uid);
$in = inputJson() ?? []; $cfg = nvCreatorCfg();
$clean = fn($s, $n) => mb_substr(trim(preg_replace('/\s+/u', ' ', strip_tags((string)$s))), 0, $n);
$title = $clean($in['title'] ?? '', 100); $desc = mb_substr(trim(strip_tags((string)($in['description'] ?? ''))), 0, 1000);
if (mb_strlen($title) < 3) jsonError('Başlık en az 3 karakter olmalı.');
$days = (int)($in['days'] ?? 7); if (!isset(NV_CREATOR_DAYS[$days])) jsonError('Geçersiz yayın süresi.');
$isShort = (($in['kind'] ?? '') === 'short'); $cdnUrl = (string)($in['cdn_url'] ?? ''); $pid = ''; $url = ''; $thumb = '';
require_once __DIR__ . '/../includes/cdn_video.php';
if ($cdnUrl !== '') {                                   // kendi CDN'imiz
    if (!nvCdnIsOurVideo($cdnUrl)) jsonError('Geçersiz video adresi.');
    $url = $cdnUrl; $thumb = (string)($in['thumb_url'] ?? ''); if (!nvCdnIsOurThumb($thumb)) $thumb = '';
} else {                                                // Cloudinary (CDN ayarlı değilse yedek)
    $pid = (string)($in['cloudinary_public_id'] ?? ''); $url = (string)($in['video_url'] ?? '');
    $prefix = 'neontv/user/' . $uid . '/';
    if (strncmp($pid, $prefix, strlen($prefix)) !== 0 || !preg_match('#^[A-Za-z0-9/_-]{10,200}$#', $pid)) jsonError('Geçersiz video dosyası.');
    if (!preg_match('#^https://res\.cloudinary\.com/' . preg_quote(CLOUDINARY_CLOUD_NAME, '#') . '/video/upload/#', $url) || strpos($url, $pid) === false) jsonError('Geçersiz video adresi.');
    $thumb = 'https://res.cloudinary.com/' . CLOUDINARY_CLOUD_NAME . '/video/upload/so_2,w_640,h_360,c_fill,q_auto,f_jpg/' . $pid . '.jpg';
}
$dur = max(0, min(10800, (int)($in['duration'] ?? 0)));
$maxSec = $isShort ? $cfg['short_sec'] : $cfg['minutes'] * 60;
if ($dur > $maxSec + 1) jsonError(($isShort ? 'Net en fazla ' . $cfg['short_sec'] . ' saniye' : 'Video en fazla ' . $cfg['minutes'] . ' dakika') . ' olabilir.');
// Kotalar
$active = $db->count('videos', 'owner_id=eq.' . $uid . '&status=in.(published,pending)', true);
if ($active >= $cfg['active']) jsonError('Aynı anda en fazla ' . $cfg['active'] . ' aktif videon olabilir. Birini kaldır veya süresinin dolmasını bekle.', 429);
$today = $db->count('videos', 'owner_id=eq.' . $uid . '&created_at=gte.' . rawurlencode(gmdate('Y-m-d\TH:i:s\Z', time() - 86400)), true);
if ($today >= $cfg['daily']) jsonError('24 saatte en fazla ' . $cfg['daily'] . ' video yükleyebilirsin.', 429);
// Etiketler
$tags = []; foreach (preg_split('/[,#\s]+/u', (string)($in['tags'] ?? '')) as $t) { $t = mb_strtolower(preg_replace('/[^\p{L}\p{N}_]/u', '', $t)); if ($t !== '' && mb_strlen($t) <= 24 && !in_array($t, $tags, true)) $tags[] = $t; if (count($tags) >= 5) break; }
$tagLit = '{' . implode(',', array_map(fn($t) => '"' . $t . '"', $tags)) . '}';
$chan = nvCreatorChannelId($db, $uid, (string)($p['username'] ?? ''));
$row = ['title' => $title, 'description' => $desc, 'video_url' => $url, 'cloudinary_public_id' => $pid, 'thumbnail_url' => $thumb, 'is_short' => $isShort, 'duration' => $dur,
    'channel_id' => $chan, 'status' => 'published', 'tags' => $tagLit, 'owner_id' => $uid, 'is_user_upload' => true,
    'expires_at' => gmdate('Y-m-d\TH:i:s\Z', time() + $days * 86400)];
$r = $db->insert('videos', $row, true);
if (($r['status'] ?? 500) >= 400) jsonError('Kaydedilemedi (SQL 17 ve 18 çalıştı mı?)', 500);
Store::clearCache('home_shorts'); 
jsonSuccess(['id' => $r['data'][0]['id'] ?? null, 'status' => $row['status'], 'check' => true], 'Videon yayında! Otomatik içerik kontrolü yapılıyor.');
