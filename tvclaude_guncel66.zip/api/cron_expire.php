<?php
// Süresi dolan kullanıcı videolarını kaldırır. cron-job.org: https://alanadiniz/api/cron_expire.php?key=GIZLI (dakikada bir veya saatte bir)
// Anahtar: includes/secrets.php içinde putenv('EXPIRE_CRON_KEY=uzun-rastgele-değer');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/creator.php';
error_reporting(0); ini_set('display_errors', 0);
$k = (string)($_SERVER['HTTP_X_CRON_KEY'] ?? ($_GET['key'] ?? ''));
$want = (string)getenv('EXPIRE_CRON_KEY');
if ($want === '' || !hash_equals($want, $k)) { http_response_code(403); exit('forbidden'); }
header('Content-Type: application/json'); header('Cache-Control: no-store');
$db = new Supabase(); $total = 0;
for ($i = 0; $i < 4; $i++) { $n = nvExpireUserVideos($db); $total += $n; if ($n < 15) break; }
echo json_encode(['expired' => $total]);
