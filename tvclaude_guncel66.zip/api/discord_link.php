<?php
// Discord hesap bağlama. GET -> durum | POST {action:"code"} -> 10 dk geçerli kod | POST {action:"unlink"} -> bağı kaldır
// Kodu kullanıcı Discord'da BigNeonAI'ye "/hesabim bagla kod:XXXXXXXX" ile girer; bağlama botta (service key) yapılır.
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $user = requireUserApi($db); $uid = (string)$user['id'];

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $in = inputJson() ?? [];
    $act = (string)($in['action'] ?? '');
    if ($act === 'code') {
        $db->delete('discord_link_codes', 'user_id=eq.' . $uid, true);
        $db->delete('discord_link_codes', 'expires_at=lt.' . urlencode(gmdate('c')), true);   // süresi dolanları temizle
        $alpha = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; $code = '';
        for ($i = 0; $i < 8; $i++) $code .= $alpha[random_int(0, strlen($alpha) - 1)];
        $exp = gmdate('c', time() + 600);
        $r = $db->insert('discord_link_codes', ['code' => $code, 'user_id' => $uid, 'expires_at' => $exp], true);
        if (($r['status'] ?? 500) >= 300) jsonError('Kod oluşturulamadı. SQL 19 çalıştırıldı mı?', 500);
        jsonSuccess(['code' => $code, 'expires_at' => $exp, 'ttl' => 600]);
    }
    if ($act === 'unlink') {
        $db->delete('discord_links', 'user_id=eq.' . $uid, true);
        $db->delete('discord_link_codes', 'user_id=eq.' . $uid, true);
        jsonSuccess(['linked' => false]);
    }
    jsonError('Geçersiz işlem.', 400);
}

$r = $db->select('discord_links', 'user_id=eq.' . $uid . '&select=discord_id,linked_at&limit=1', true)['data'] ?? [];
$row = is_array($r) && $r ? $r[0] : null;
jsonSuccess(['linked' => (bool)$row, 'discord_id' => $row['discord_id'] ?? null, 'linked_at' => $row['linked_at'] ?? null]);
