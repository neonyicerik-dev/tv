<?php
// Gönderi resmi yükleme (yalnızca içerik üreticileri). POST multipart: image=<dosya>. Yeniden kodlanır (en çok 1280 px JPEG); CDN ayarlıysa CDN'e gider.
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/creator.php';
require_once __DIR__ . '/../includes/cdn_ingest.php';
error_reporting(0); ini_set('display_errors', 0);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);
$db = new Supabase(); $user = requireUserApi($db); $uid = $user['id']; denyIfBanned($db, $uid);
$p = nvCreatorProfile($db, $uid);
if (!$p || empty($p['is_creator']) || !empty($p['creator_banned'])) jsonError('Gönderi için içerik üreticisi hesabı gerekli.', 403);
$f = $_FILES['image'] ?? null;
if (!$f || $f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) jsonError('Resim alınamadı (en çok 5 MB).', 400);
if ($f['size'] > 5 * 1048576) jsonError('Resim 5 MB\'dan küçük olmalı.', 413);
$tmp = nvImageResizeJpeg($f['tmp_name'], 1280);
if (!$tmp) jsonError('Yalnızca JPG, PNG, GIF veya WEBP resim yükleyebilirsin.', 415);
$url = nvCdnConfigured() ? nvCdnIngest($tmp, 'post', $uid) : null;
if (!$url) {
    $dir = __DIR__ . '/../assets/posts'; if (!is_dir($dir) && !@mkdir($dir, 0755, true)) { @unlink($tmp); jsonError('Klasör oluşturulamadı', 500); }
    $name = $uid . '_' . bin2hex(random_bytes(6)) . '.jpg';
    if (!@copy($tmp, $dir . '/' . $name)) { @unlink($tmp); jsonError('Resim kaydedilemedi', 500); }
    @chmod($dir . '/' . $name, 0644); $url = APP_URL . '/assets/posts/' . $name;
}
@unlink($tmp);
jsonSuccess(['url' => $url]);
