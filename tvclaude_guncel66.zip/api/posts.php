<?php
// Circs (içerik üreticilerinin metin + resim paylaşımları)
// GET ?offset=&limit=&author=<uuid> -> akış (giriş varsa liked bilgisi) · POST {action:'create',body,image_url} · POST {action:'like'|'unlike',id} · DELETE ?id=
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/creator.php';
require_once __DIR__ . '/../includes/cdn_video.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase(); $m = $_SERVER['REQUEST_METHOD'];
$tok = getBearerToken(); $me = null;
if ($tok) { $u = $db->verifyToken($tok); if ($u && !empty($u['id']) && isUuid($u['id'])) $me = $u['id']; }
$myPost = fn($id) => $db->first('posts', 'id=eq.' . $id . '&author_id=eq.' . $me . '&select=id,image_url', true);

if ($m === 'GET') {
    $off = max(0, (int)($_GET['offset'] ?? 0)); $lim = max(1, min(20, (int)($_GET['limit'] ?? 10)));
    $q = 'status=eq.published&order=created_at.desc&limit=' . $lim . '&offset=' . $off . '&select=id,author_id,channel_id,body,image_url,likes_count,created_at';
    $a = (string)($_GET['author'] ?? ''); if ($a !== '') { requireUuid($a, 'Yazar'); $q .= '&author_id=eq.' . $a; }
    if ($me && $a === '') {   // Kişisel akış: beğendiğin Circ/video yazarları ve beğendiğin Circler öne çıkar
        $fav = [];
        foreach (($db->select('post_likes', 'user_id=eq.' . $me . '&select=post_id&limit=80', true)['data'] ?? []) as $l) $lp[] = $l['post_id'];
        if (!empty($lp)) foreach (($db->select('posts', 'id=in.(' . implode(',', $lp) . ')&select=author_id', true)['data'] ?? []) as $x) $fav[$x['author_id']] = ($fav[$x['author_id']] ?? 0) + 1;
        $lv = []; foreach (($db->select('likes', 'user_id=eq.' . $me . '&select=video_id&limit=80', true)['data'] ?? []) as $l) $lv[] = $l['video_id'];
        if ($lv) foreach (($db->select('videos', 'id=in.(' . implode(',', $lv) . ')&select=owner_id', true)['data'] ?? []) as $x) if (!empty($x['owner_id'])) $fav[$x['owner_id']] = ($fav[$x['owner_id']] ?? 0) + 1;
        $fol = []; foreach (($db->select('user_follows', 'follower_id=eq.' . $me . '&select=following_id&limit=100', true)['data'] ?? []) as $x) $fav[$x['following_id'] ?? ''] = ($fav[$x['following_id'] ?? ''] ?? 0) + 2;
        if ($fav) {
            $pool = $db->select('posts', 'status=eq.published&order=created_at.desc&limit=80&select=id,author_id,channel_id,body,image_url,likes_count,created_at', true)['data'] ?? []; $pool = is_array($pool) ? $pool : [];
            $n = max(1, count($pool)); $sc = [];
            foreach ($pool as $i => $r) $sc[] = [3 * min(3, $fav[$r['author_id']] ?? 0) + min(2, log10(1 + (int)$r['likes_count']) ) + ($n - $i) / $n * 2, $i, $r];
            usort($sc, fn($x, $y) => $y[0] <=> $x[0] ?: $x[1] <=> $y[1]);
            $all = array_column($sc, 2); $rows = array_slice($all, $off, $lim);
        }
    }
    if (!isset($rows)) { $rows = $db->select('posts', $q, true)['data'] ?? []; $rows = is_array($rows) ? $rows : []; }
    $ids = array_values(array_unique(array_column($rows, 'author_id'))); $au = [];
    if ($ids) foreach (($db->select('profiles', 'id=in.(' . implode(',', $ids) . ')&select=id,username,avatar_url', true)['data'] ?? []) as $pr) $au[$pr['id']] = $pr;
    $liked = [];
    if ($me && $rows) foreach (($db->select('post_likes', 'user_id=eq.' . $me . '&post_id=in.(' . implode(',', array_column($rows, 'id')) . ')&select=post_id', true)['data'] ?? []) as $l) $liked[$l['post_id']] = true;
    foreach ($rows as &$r) { $pr = $au[$r['author_id']] ?? []; $r['author'] = ['name' => $pr['username'] ?? 'Kullanıcı', 'avatar' => $pr['avatar_url'] ?? '']; $r['liked'] = isset($liked[$r['id']]); $r['mine'] = $me && $r['author_id'] === $me; unset($r['author_id']); } unset($r);
    jsonSuccess(['items' => $rows, 'has_more' => count($rows) === $lim]);
}
if (!$me) jsonError('Giriş yapmalısın.', 401);

if ($m === 'DELETE') {
    $id = trim((string)($_GET['id'] ?? '')); requireUuid($id, 'Circ');
    if (!$myPost($id)) jsonError('Circ bulunamadı', 404);
    $db->delete('posts', 'id=eq.' . $id, true); jsonSuccess([], 'Circ silindi.');
}
if ($m !== 'POST') jsonError('Geçersiz metod', 405);
$in = inputJson() ?? []; $act = (string)($in['action'] ?? 'create');

if ($act === 'like' || $act === 'unlike') {
    $id = trim((string)($in['id'] ?? '')); requireUuid($id, 'Circ');
    if ($act === 'like') { if (!$db->first('posts', 'id=eq.' . $id . '&status=eq.published&select=id', true)) jsonError('Circ bulunamadı', 404); $db->insert('post_likes', ['post_id' => $id, 'user_id' => $me], true); }
    else $db->delete('post_likes', 'post_id=eq.' . $id . '&user_id=eq.' . $me, true);
    $n = $db->count('post_likes', 'post_id=eq.' . $id, true); $db->update('posts', ['likes_count' => $n], 'id=eq.' . $id, true);
    jsonSuccess(['liked' => $act === 'like', 'likes' => $n]);
}
if ($act !== 'create') jsonError('Geçersiz işlem');
denyIfBanned($db, $me);
$p = nvCreatorProfile($db, $me);
if (!$p || empty($p['is_creator']) || !empty($p['creator_banned'])) jsonError('Circ için içerik üreticisi hesabı gerekli.', 403);
$cfg = nvCreatorCfg();
$body = mb_substr(trim(preg_replace("/\r\n?/", "\n", strip_tags((string)($in['body'] ?? '')))), 0, 1000);
$img = (string)($in['image_url'] ?? '');
if ($img !== '') {
    $b = nvCdnBase(); $okCdn = $b !== '' && preg_match('#^' . preg_quote($b, '#') . '/f/[a-f0-9]{32}\.(jpg|png|webp)$#', $img);
    $okLocal = strncmp($img, APP_URL . '/assets/posts/' . $me . '_', strlen(APP_URL . '/assets/posts/' . $me . '_')) === 0 && preg_match('#/[0-9a-f-]{36}_[0-9a-f]{12}\.jpg$#', $img);
    if (!$okCdn && !$okLocal) jsonError('Geçersiz resim adresi.');
}
if ($body === '' && $img === '') jsonError('Bir şeyler yaz veya resim ekle.');
$today = $db->count('posts', 'author_id=eq.' . $me . '&created_at=gte.' . rawurlencode(gmdate('Y-m-d\TH:i:s\Z', time() - 86400)), true);
if ($today >= $cfg['post_daily']) jsonError('24 saatte en fazla ' . $cfg['post_daily'] . ' Circ paylaşabilirsin.', 429);
$chan = nvCreatorChannelId($db, $me, (string)($p['username'] ?? ''));
$r = $db->insert('posts', ['author_id' => $me, 'channel_id' => $chan, 'body' => $body, 'image_url' => $img !== '' ? $img : null], true);
if (($r['status'] ?? 500) >= 400) jsonError('Paylaşılamadı (SQL 18 çalıştı mı?)', 500);
jsonSuccess(['id' => $r['data'][0]['id'] ?? null], 'Circ paylaşıldı.');
