<?php
// Kısa video akışı: GET ?offset=&limit=&start=<video id (ilk sırada gösterilecek)>  (giriş gerekmez; giriş varsa liked bilgisi)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
error_reporting(0); ini_set('display_errors', 0);
$db = new Supabase();
$off = max(0, (int)($_GET['offset'] ?? 0)); $lim = max(1, min(12, (int)($_GET['limit'] ?? 6)));
$sel = '&select=id,title,video_url,thumbnail_url,views,likes_count,comments_count,channel_id,owner_id,channels(name)';
$tok = getBearerToken(); $me = null;
if ($tok) { $u = $db->verifyToken($tok); if ($u && !empty($u['id']) && isUuid($u['id'])) $me = $u['id']; }
$base = 'is_short=eq.true&status=eq.published&removed_at=is.null&video_url=neq.';
$hasMore = false;
$liked = []; $likedCh = []; $likedTags = [];
if ($me) {   // Kişisel akış: beğendiğin videoların kanalı ve etiketlerine yakın olanlar öne çıkar
    foreach (($db->select('likes', 'user_id=eq.' . $me . '&select=video_id&limit=80', true)['data'] ?? []) as $l) $liked[$l['video_id']] = true;
    if ($liked) foreach (($db->select('videos', 'id=in.(' . implode(',', array_keys($liked)) . ')&select=channel_id,tags', true)['data'] ?? []) as $lv) {
        if (!empty($lv['channel_id'])) $likedCh[$lv['channel_id']] = ($likedCh[$lv['channel_id']] ?? 0) + 1;
        foreach ((array)($lv['tags'] ?? []) as $t) $likedTags[$t] = ($likedTags[$t] ?? 0) + 1;
    }
}
if ($me && ($likedCh || $likedTags)) {
    $pool = $db->select('videos', $base . '&order=created_at.desc&limit=80' . $sel . ',tags', true)['data'] ?? []; $pool = is_array($pool) ? $pool : [];
    $n = max(1, count($pool)); $scored = [];
    foreach ($pool as $i => $r) {
        $sc = 3 * min(3, $likedCh[$r['channel_id']] ?? 0) + 1.5 * min(4, array_sum(array_map(fn($t) => $likedTags[$t] ?? 0, (array)($r['tags'] ?? []))))
            + min(2, log10(1 + (int)$r['views']) / 2) + ($n - $i) / $n * 2 - (isset($liked[$r['id']]) ? 2.5 : 0);   // izlediklerini sona it
        $scored[] = [$sc, $i, $r];
    }
    usort($scored, fn($a, $b) => $b[0] <=> $a[0] ?: $a[1] <=> $b[1]);
    $all = array_column($scored, 2); $rows = array_slice($all, $off, $lim); $hasMore = count($all) > $off + $lim;
    foreach ($rows as &$r) unset($r['tags']); unset($r);
} else {
    $rows = $db->select('videos', $base . '&order=created_at.desc&limit=' . $lim . '&offset=' . $off . $sel, true)['data'] ?? [];
    $rows = is_array($rows) ? $rows : []; $hasMore = count($rows) >= $lim;
}
$start = trim((string)($_GET['start'] ?? ''));
if ($off === 0 && isUuid($start)) {
    $s = $db->first('videos', 'id=eq.' . $start . '&is_short=eq.true&status=eq.published&removed_at=is.null' . $sel, true);
    if ($s) { $rows = array_values(array_filter($rows, fn($r) => $r['id'] !== $s['id'])); array_unshift($rows, $s); }
}
$likedNow = [];
if ($me && $rows) foreach (($db->select('likes', 'user_id=eq.' . $me . '&video_id=in.(' . implode(',', array_column($rows, 'id')) . ')&select=video_id', true)['data'] ?? []) as $l) $likedNow[$l['video_id']] = true;
foreach ($rows as &$r) { $r['channel'] = $r['channels']['name'] ?? ''; unset($r['channels'], $r['owner_id']); $r['liked'] = isset($likedNow[$r['id']]); } unset($r);
jsonSuccess(['items' => $rows, 'has_more' => $hasMore]);
