<?php
// Admin: video kapak görselini (thumbnail) CDN'e yükler. POST multipart file=<resim> -> {url}. CDN ayarlı değilse 503 döner, sayfa Cloudinary'ye düşer.
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/cdn_ingest.php';
error_reporting(0); ini_set('display_errors', 0);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz metod', 405);
if (!isAdminLoggedIn()) jsonError('Yetkisiz erişim', 401);
if (!nvCdnConfigured()) jsonError('CDN ayarlı değil', 503);
if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($_FILES['file']['tmp_name'])) jsonError('Dosya alınamadı', 400);
if ($_FILES['file']['size'] > 5 * 1024 * 1024) jsonError('Dosya 5 MB\'dan küçük olmalı', 413);
$jpg = nvImageCropJpeg($_FILES['file']['tmp_name'], 1280, 720);
if (!$jpg) jsonError('Geçerli bir resim seçin', 415);
$url = nvCdnIngest($jpg, 'banner', 'thumb_' . bin2hex(random_bytes(6)));
@unlink($jpg);
if (!$url) jsonError('CDN yanıt vermedi', 503);
jsonSuccess(['url' => $url], 'Yüklendi');
