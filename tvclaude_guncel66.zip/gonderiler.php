<?php
// NeonTV - Circs: içerik üreticilerinin metin + resim paylaşımları (paylaşmak için Stüdyo)
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Circs'; $metaDesc = 'NeonTV içerik üreticilerinin Circs paylaşımları.'; $pageRobots = 'index,follow';
include __DIR__ . '/components/header.php';
?>
<style>.po-card{background:#13131f;border:1px solid rgba(255,255,255,.08);border-radius:20px;padding:16px;margin-bottom:14px}.po-av{width:40px;height:40px;border-radius:99px;object-fit:cover;background:#0b0b14;flex:none}
.po-act{display:flex;align-items:center;gap:6px;font-size:13px;color:#9ca3af;background:none;border:0;cursor:pointer}.po-act.on{color:#ff3b6b}</style>
<div class="max-w-xl mx-auto px-4 py-8">
  <div class="flex items-center justify-between mb-5"><h1 class="text-2xl font-bold text-white"><i class="fa-solid fa-newspaper mr-2" style="color:#00f5ff"></i>Circs</h1>
    <a href="<?= APP_URL ?>/studyo.php#gonderi" class="text-sm text-cyan-400 underline">Circ paylaş</a></div>
  <div id="po-list"><div class="text-gray-500 text-sm text-center py-10">Yükleniyor…</div></div>
  <div class="text-center"><button id="po-more" style="display:none" class="px-5 py-2 rounded-xl text-sm font-bold text-white bg-white/10">Daha fazla</button></div>
</div>
<script>
window.addEventListener('load', async function () {
  const BASE = <?= json_encode(APP_URL) ?>, list = document.getElementById('po-list'), more = document.getElementById('po-more');
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let tok = null; try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}
  const H = tok ? { 'Authorization': 'Bearer ' + tok, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };
  const author = new URLSearchParams(location.search).get('u') || ''; let off = 0;
  const ago = t => { const s = (Date.now() - new Date(t)) / 1000; return s < 60 ? 'az önce' : s < 3600 ? Math.floor(s / 60) + ' dk' : s < 86400 ? Math.floor(s / 3600) + ' sa' : Math.floor(s / 86400) + ' gün'; };
  async function load() {
    const r = await (await fetch(BASE + '/api/posts.php?offset=' + off + '&limit=10' + (author ? '&author=' + encodeURIComponent(author) : ''), { headers: H })).json();
    const it = (r.data && r.data.items) || []; if (!off) list.innerHTML = '';
    if (!off && !it.length) list.innerHTML = '<div class="text-gray-500 text-sm text-center py-10">Henüz Circ yok.</div>';
    it.forEach(p => {
      const d = document.createElement('div'); d.className = 'po-card';
      d.innerHTML = '<div class="flex items-center gap-3 mb-2"><img class="po-av" src="' + esc(p.author.avatar || BASE + '/assets/img/app.png') + '" alt="" onerror="this.style.visibility=\'hidden\'"><div><div class="text-white font-semibold text-sm">' + esc(p.author.name) + '</div><div class="text-[11px] text-gray-500">' + ago(p.created_at) + '</div></div>' + (p.mine ? '<button data-del class="ml-auto text-xs text-red-400">Sil</button>' : '') + '</div>' +
        (p.body ? '<div class="text-gray-200 text-sm" style="white-space:pre-wrap;word-break:break-word">' + esc(p.body) + '</div>' : '') +
        (p.image_url ? '<img src="' + esc(p.image_url) + '" alt="" loading="lazy" style="width:100%;border-radius:14px;margin-top:10px;max-height:560px;object-fit:cover">' : '') +
        '<div class="mt-3"><button data-like class="po-act' + (p.liked ? ' on' : '') + '"><i class="fa-solid fa-heart"></i> <span>' + (p.likes_count || 0) + '</span></button></div>';
      const lb = d.querySelector('[data-like]'); lb.onclick = async () => { if (!tok) { location.href = BASE + '/auth.php'; return; } const on = !lb.classList.contains('on');
        const r = await (await fetch(BASE + '/api/posts.php', { method: 'POST', headers: H, body: JSON.stringify({ action: on ? 'like' : 'unlike', id: p.id }) })).json();
        if (r.success) { lb.classList.toggle('on', r.data.liked); lb.querySelector('span').textContent = r.data.likes; } };
      const db = d.querySelector('[data-del]'); if (db) db.onclick = async () => { if (!confirm('Circ silinsin mi?')) return; await fetch(BASE + '/api/posts.php?id=' + p.id, { method: 'DELETE', headers: H }); d.remove(); };
      list.appendChild(d);
    });
    off += 10; more.style.display = (r.data && r.data.has_more) ? 'inline-block' : 'none';
  }
  more.onclick = load; load();
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
