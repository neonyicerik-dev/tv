<?php
// ============================================================
// NeonTV - Kullanıcı videolarını kendi CDN'e yükleme (tarayıcı -> CDN doğrudan)
// Gerekli (includes/secrets.php): CDN_INGEST_URL=https://cdn.../ingest.php  ve  CDN_INGEST_KEY (CDN ile aynı, 24+ karakter)
// Site, kısa ömürlü imzalı jeton üretir; CDN'deki ingest_video.php jetonu doğrular. Anahtar tarayıcıya ASLA gitmez.
// ============================================================
require_once __DIR__ . '/cdn_ingest.php';

function nvCdnBase(): string {
    $u = parse_url(trim((string)getenv('CDN_INGEST_URL')));
    return (!empty($u['scheme']) && !empty($u['host'])) ? $u['scheme'] . '://' . $u['host'] . (isset($u['port']) ? ':' . $u['port'] : '') : '';
}
function nvCdnVideoReady(): bool { return nvCdnConfigured() && nvCdnBase() !== ''; }

/** Tarayıcıya verilecek imzalı yükleme jetonu (10 dk geçerli). */
function nvCdnUpToken(string $uid, string $kind, int $maxBytes, int $maxSec, int $ttlDays): string {
    $p = rtrim(strtr(base64_encode(json_encode(['u' => $uid, 'k' => $kind, 'max' => $maxBytes, 'dur' => $maxSec, 'ttl' => $ttlDays, 'exp' => time() + 600])), '+/', '-_'), '=');
    return $p . '.' . hash_hmac('sha256', $p, (string)getenv('CDN_INGEST_KEY'));
}
function nvCdnIsOurVideo(string $url): bool {
    $b = nvCdnBase();
    return $b !== '' && (bool)preg_match('#^' . preg_quote($b, '#') . '/f/[a-f0-9]{32}\.(mp4|mov|webm|m4v)$#', $url);
}
function nvCdnIsOurThumb(string $url): bool {
    $b = nvCdnBase();
    return $b !== '' && (bool)preg_match('#^' . preg_quote($b, '#') . '/t/[0-9a-f-]{36}\.jpg$#i', $url);
}
/** CDN'deki videoyu siler (sunucudan sunucuya). Başarısız olsa bile CDN süresi dolunca kendisi siler. */
function nvCdnDeleteVideo(string $url): bool {
    if (!nvCdnVideoReady() || !nvCdnIsOurVideo($url)) return false;
    $ch = curl_init(rtrim(nvCdnBase(), '/') . '/ingest_video.php?a=delete');
    $opt = [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_HTTPHEADER => ['X-Ingest-Key: ' . (string)getenv('CDN_INGEST_KEY'), 'Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['url' => $url])];
    if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '' && file_exists(CA_BUNDLE_PATH)) $opt[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
    curl_setopt_array($ch, $opt); $raw = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($http !== 200) error_log('[cdn_video] silme HTTP ' . $http);
    return $http === 200;
}
