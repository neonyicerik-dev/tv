<?php
// ============================================================
// NeonTV - İçerik üreticisi (kullanıcı yüklemeleri) çekirdeği
// Ayarlar (admin → İçerik Üreticileri): creator_auto_publish, creator_max_active, creator_daily_limit, creator_max_mb, creator_max_min
// Videolar geçicidir: expires_at dolunca CDN/Cloudinary dosyası silinir, video siteden kalkar, izlenme sayısı satırda kalır.
// ============================================================
require_once __DIR__ . '/store.php';
require_once __DIR__ . '/supabase.php';

const NV_CREATOR_DAYS = [1 => '24 saat', 3 => '3 gün', 7 => '7 gün', 14 => '14 gün', 30 => '30 gün'];

function nvCreatorCfg(): array {
    $g = fn($k, $d) => Store::getSetting($k, $d);
    return [
        'auto'   => true, // onay yok: videolar hemen yayınlanır, yapay zeka kontrol eder
        'active' => max(1, min(100, (int)$g('creator_max_active', 10))),
        'daily'  => max(1, min(50, (int)$g('creator_daily_limit', 5))),
        'mb'     => max(10, min(2000, (int)$g('creator_max_mb', 100))),
        'minutes'=> max(1, min(180, (int)$g('creator_max_min', 10))),
        'short_sec' => max(10, min(180, (int)$g('creator_short_sec', 60))),
        'post_daily' => max(1, min(100, (int)$g('creator_post_daily', 10))),
    ];
}
/** Profil + kanal bilgisi; içerik üreticisi değilse null. */
function nvCreatorProfile(Supabase $db, string $uid): ?array {
    $p = $db->first('profiles', 'id=eq.' . $uid . '&select=id,username,is_creator,creator_banned,creator_since', true);
    return is_array($p) ? $p : null;
}
function nvCreatorChannelId(Supabase $db, string $uid, string $name = ''): ?string {
    $c = $db->first('channels', 'owner_id=eq.' . $uid . '&select=id', true);
    if ($c) return $c['id'];
    $name = trim($name) !== '' ? mb_substr(trim($name), 0, 60) : 'Kanal';
    $r = $db->insert('channels', ['name' => $name, 'description' => '', 'owner_id' => $uid], true);
    $id = $r['data'][0]['id'] ?? null;
    if (!$id) { $c = $db->first('channels', 'owner_id=eq.' . $uid . '&select=id', true); $id = $c['id'] ?? null; }
    return $id;
}
/** Videonun Cloudinary dosyasını siler, siteden kaldırır (satır ve izlenme sayısı kalır). */
function nvRemoveUserVideo(Supabase $db, array $v, string $why = 'expired'): void {
    try {
        if (!empty($v['video_url'])) { require_once __DIR__ . '/cdn_video.php'; nvCdnDeleteVideo((string)$v['video_url']); }
    } catch (\Throwable $e) { error_log('[creator] cdn silme: ' . $e->getMessage()); }
    try {
        if (!empty($v['cloudinary_public_id'])) { require_once __DIR__ . '/cloudinary.php'; (new Cloudinary())->deleteResource((string)$v['cloudinary_public_id'], 'video'); }
    } catch (\Throwable $e) { error_log('[creator] cloudinary silme: ' . $e->getMessage()); }
    $db->update('videos', ['status' => 'expired', 'video_url' => '', 'preview_clip_url' => null, 'cloudinary_public_id' => '', 'removed_at' => gmdate('Y-m-d\TH:i:s\Z'), 'reject_reason' => $why === 'expired' ? null : ($v['reject_reason'] ?? null)], 'id=eq.' . $v['id'], true);
    Store::clearCache('landing_picks'); 
}
/** Süresi dolan kullanıcı videolarını kaldırır (en çok 15 video / çalışma). */
function nvExpireUserVideos(Supabase $db): int {
    try { require_once __DIR__ . '/moderation.php'; nvModerateSweep($db); } catch (\Throwable $e) { error_log('[moderation] sweep: ' . $e->getMessage()); }
    $r = $db->select('videos', 'is_user_upload=eq.true&removed_at=is.null&expires_at=lte.' . rawurlencode(gmdate('Y-m-d\TH:i:s\Z')) . '&select=id,cloudinary_public_id,video_url,status&limit=15', true)['data'] ?? [];
    $n = 0; foreach (is_array($r) ? $r : [] as $v) { nvRemoveUserVideo($db, $v); $n++; }
    return $n;
}
