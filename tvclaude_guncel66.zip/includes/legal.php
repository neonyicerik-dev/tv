<?php
// ============================================================
// NeonTV - Yasal metinler (KVKK, gizlilik, koşullar, çerez, mesafeli satış, iade...)
// Firma bilgileri admin > Yasal Bilgiler'den girilir. Metinler genel şablondur; yayına almadan önce
// bir hukukçuya gösterilmesi önerilir.
// ============================================================
require_once __DIR__ . '/store.php';

const LEGAL_VERSION = '2026-11-19';

function legalInfo(): array {
    $g = fn($k) => trim((string)Store::getSetting($k, ''));
    $miss = '<span style="color:#f87171">[Admin → Yasal Bilgiler\'den doldurun]</span>';
    $v = fn($k) => $g($k) !== '' ? htmlspecialchars($g($k), ENT_QUOTES) : $miss;
    return ['company' => $v('legal_company'), 'address' => $v('legal_address'), 'email' => $v('legal_email'), 'phone' => $g('legal_phone') !== '' ? htmlspecialchars($g('legal_phone'), ENT_QUOTES) : '-',
        'tax' => $g('legal_tax') !== '' ? htmlspecialchars($g('legal_tax'), ENT_QUOTES) : '-', 'kep' => $g('legal_kep') !== '' ? htmlspecialchars($g('legal_kep'), ENT_QUOTES) : '-', 'complete' => $g('legal_company') !== '' && $g('legal_address') !== '' && $g('legal_email') !== ''];
}
function legalSeller(array $i): string {
    return "<table class='lg-t'><tr><td>Unvan</td><td>{$i['company']}</td></tr><tr><td>Adres</td><td>{$i['address']}</td></tr><tr><td>E-posta</td><td>{$i['email']}</td></tr><tr><td>Telefon</td><td>{$i['phone']}</td></tr><tr><td>Vergi / Mersis No</td><td>{$i['tax']}</td></tr><tr><td>KEP</td><td>{$i['kep']}</td></tr></table>";
}

function legalDocs(): array {
    $i = legalInfo(); $S = legalSeller($i); $url = APP_URL;
    require_once __DIR__ . '/tokens.php'; $c = tkCfg(); $price = (int)$c['price']; $days = (int)$c['days'];
    $contact = "<a href='$url/iletisim.php?konu=kvkk'>İletişim formu</a>";
    $docs = [];

    $docs['kvkk'] = ['KVKK Aydınlatma Metni', "
<p>6698 sayılı Kişisel Verilerin Korunması Kanunu (“KVKK”) m.10 uyarınca, kişisel verileriniz aşağıda açıklanan kapsamda işlenir.</p>
<h2>1. Veri sorumlusu</h2>$S
<h2>2. İşlenen veriler</h2>
<ul><li><b>Hesap:</b> e-posta, kullanıcı adı, şifre (yalnızca geri döndürülemez özet olarak), profil fotoğrafı/kapak/biyografi (isteğe bağlı).</li>
<li><b>Kullanım:</b> izleme geçmişi, daha sonra izle listesi, yorum, puan, beğeni, takip, abonelik, oynatma listeleri, token hareketleri ve Premium durumu, bildirim tercihleri.</li>
<li><b>Teknik:</b> IP adresinin tek yönlü özeti (hash), ülke bilgisi, tarayıcı/cihaz bilgisi ve yönlendiren sayfa.</li>
<li><b>İçerik üreticileri:</b> yüklediğiniz video ve Nets, kapak görseli, başlık/açıklama, paylaştığınız Circ metni ve resimleri, yükleme zamanı ve yayın süresi, izlenme ve beğeni sayıları. Videolar ve gönderi resimleri sitenin kendi içerik sunucusunda (CDN) saklanır.</li>
<li><b>İletişim:</b> iletişim formuna yazdığınız ad, e-posta ve mesaj.</li></ul>
<h2>3. İşleme amaçları ve hukuki sebepler</h2>
<ul><li>Üyelik ve hizmetin sunulması — sözleşmenin ifası (KVKK m.5/2-c).</li><li>Güvenlik, kötüye kullanımın (bot, sahte hesap, token suistimali) önlenmesi, hata ayıklama — meşru menfaat (m.5/2-f).</li><li>Mevzuattan doğan yükümlülükler ve yetkili makam talepleri — hukuki yükümlülük (m.5/2-ç).</li><li>Tarayıcı bildirimi gönderimi, isteğe bağlı çerez/tercihler — açık rıza (m.5/1).</li></ul>
<h2>4. Aktarım</h2>
<p>Verileriniz satılmaz. Hizmetin sağlanması için şu hizmet sağlayıcılara, hizmet amacıyla sınırlı olarak aktarılabilir: veritabanı ve kimlik doğrulama (Supabase), içerik/görsel barındırma ve dağıtım (Cloudinary, kendi CDN sunucumuz, Cloudflare), GIF araması (Giphy; yalnızca arama sözcüğü), yapay zekâ altyazı (Google Gemini; video sesi, kişisel veri içermez), yazı tipi/simge/betik dağıtımı (Google Fonts, cdnjs, jsDelivr; tarayıcınız bu sunuculara bağlanırken IP adresiniz görünür). Bu sağlayıcıların bir kısmı yurt dışındadır; aktarım KVKK m.9 kapsamında ve ilgili güvenceler çerçevesinde yapılır.</p>
<h2>5. Saklama süreleri</h2>
<ul><li>Hesap verileri: hesap silinene kadar.</li><li>Ziyaret/güvenlik kayıtları: en fazla 90 gün.</li><li>İletişim mesajları: talebin sonuçlanmasından sonra en fazla 2 yıl.</li><li>Token ve Premium işlem kayıtları: hesap silinene kadar; yasal saklama zorunluluğu varsa süresince.</li></ul>
<h2>6. Haklarınız (KVKK m.11)</h2>
<p>Verilerinizin işlenip işlenmediğini öğrenme, bilgi talep etme, amacına uygun kullanılıp kullanılmadığını öğrenme, aktarıldığı kişileri bilme, düzeltme, silme/yok etme, işlemeye itiraz etme ve zarar halinde tazminat talep etme haklarına sahipsiniz.</p>
<h2>7. Başvuru</h2>
<p>Başvurularınızı $contact üzerinden (konu: <i>Veri Silme / KVKK Başvurusu</i>) veya {$i['email']} adresine iletebilirsiniz. Başvurular en geç 30 gün içinde yanıtlanır. Hesabınızı dilediğiniz an <b>Profilim → Hesabı sil</b> ile kendiniz de kalıcı olarak silebilirsiniz.</p>"];

    $docs['gizlilik'] = ['Gizlilik Politikası', "
<p>NeonTV, <b>13 yaş ve üzeri</b> kullanıcılar içindir. Bu politika hangi verileri neden topladığımızı özetler; ayrıntılar için <a href='$url/yasal.php?s=kvkk'>KVKK Aydınlatma Metni</a>'ne bakın.</p>
<h2>Topladıklarımız</h2><ul><li>Üyelik için e-posta ve kullanıcı adı; şifreniz bize düz metin olarak ulaşmaz.</li><li>Sitede yaptığınız işlemler: izleme geçmişi, yorum, puan, token hareketleri.</li><li>Güvenlik için IP adresinin özeti (hash), ülke ve tarayıcı bilgisi. Şehir, servis sağlayıcı (ISP) gibi gereksiz bilgileri tutmuyoruz.</li></ul>
<h2>Yapmadıklarımız</h2><ul><li>Kişisel verilerinizi satmayız veya pazarlama amacıyla üçüncü kişilerle paylaşmayız.</li><li>Kredi kartı veya banka bilgisi istemeyiz (Premium yalnızca token ile alınır).</li><li>Reklam/analiz amaçlı üçüncü taraf takip çerezi kullanmayız.</li></ul>
<h2>Üçüncü taraf hizmetler</h2><p>Supabase (veritabanı/kimlik), Cloudinary ve kendi CDN sunucumuz (medya), Cloudflare (ağ ve güvenlik), Giphy (GIF arama), Google Gemini (yapay zekâ altyazı), Google Fonts/cdnjs/jsDelivr (yazı tipi, simge, betik). Siteyi kullanırken tarayıcınız bu sunuculara bağlanabilir.</p>
<h2>Güvenlik</h2><p>Site bağlantısı HTTPS ile şifrelenir; şifreler özetlenerek saklanır; yönetim paneli ayrı yetkilendirme ile korunur. Hiçbir sistem %100 güvenli olmadığından şüpheli durumları bize bildirin.</p>
<h2>Haklarınız ve silme</h2><p>Verilerinizi <b>Profilim</b> sayfasından indirebilir, hesabınızı kalıcı olarak silebilirsiniz. Ayrıntı: <a href='$url/yasal.php?s=veri-silme'>Veri Silme Talebi</a>.</p>
<h2>İletişim</h2>$S"];

    $docs['icerik-kurallari'] = ['Topluluk ve İçerik Kuralları', "
<p>NeonTV herkesin rahatça kullanabileceği bir video platformudur. İçerik üreticisi hesabıyla yüklediğiniz her video bu kurallara uymalıdır.</p>
<h2>Yasak içerikler</h2><ul>
<li>Cinsel içerik, çıplaklık, müstehcen veya pornografik görüntü ve ses; cinsel amaçlı yönlendirme.</li>
<li>18 yaşından küçüklerin istismarı veya riske atılması, çocuklara yönelik her türlü uygunsuz içerik.</li>
<li>Şiddeti, kendine zarar vermeyi, terörü, nefreti veya ayrımcılığı özendiren içerik; taciz ve tehdit.</li>
<li>Yasa dışı faaliyetleri (uyuşturucu, silah, dolandırıcılık vb.) tanıtan veya öğreten içerik.</li>
<li>Başkalarının telif hakkı bulunan eserleri izinsiz yayınlamak; başkalarının özel hayatını ifşa etmek, izinsiz çekilmiş görüntüler.</li>
<li>Yanıltıcı başlık/kapak, spam, kötü amaçlı bağlantı ve yazılım.</li></ul>
<h2>Bildirim ve kaldırma</h2><p>Kurallara aykırı bir içerik görürseniz videonun altındaki şikayet düğmesini veya <a href='$url/iletisim.php'>iletişim formunu</a> kullanın. İncelenen içerik kaldırılabilir; tekrarlayan ihlallerde içerik üreticisi hesabı kapatılır. Yetkili mercilerin hukuka uygun talepleri üzerine ilgili kayıtlar paylaşılabilir.</p>
<h2>Geçici yayın</h2><p>Videolar seçilen süre sonunda otomatik kaldırılır; kaldırılan içeriğin kopyası yayında tutulmaz.</p>
<p><small>Sürüm: " . LEGAL_VERSION . "</small></p>"];

    $docs['kullanim-kosullari'] = ['Kullanım Koşulları', "
<h2>1. Yaş sınırı</h2><p>Siteyi yalnızca 13 yaşını doldurmuş kişiler kullanabilir. Kayıt olarak 13 yaşından büyük olduğunuzu beyan edersiniz. 18 yaşından küçükler, içerik üreticisi hesabı için ebeveyn veya vasisinin izniyle hareket etmelidir.</p>
<h2>2. Hesap</h2><p>Hesap bilgilerinizin doğruluğundan ve güvenliğinden siz sorumlusunuz. Bir kişi birden fazla hesapla token toplayamaz.</p>
<h2>3. Yasaklar</h2><ul><li>Yasa dışı içerik paylaşmak; başkalarının haklarını ihlal etmek, taciz.</li><li>Bot, otomasyon, sahte hesap veya hile ile reklam izleme/token kazanma.</li><li>Sahte yorum, puan veya izlenme üretmek; ödül karşılığı yorum yazdırmak.</li><li>Siteye zarar verecek teknik girişimler.</li></ul>
<h2>4. Yorum ve puan politikası</h2><p>Sitedeki yorum ve puanlar kullanıcılara aittir; NeonTV yönetimi tarafından sahte yorum, puan veya beğeni üretilmez. Kuralları ihlal eden içerik kaldırılabilir, hesap askıya alınabilir.</p>
<h2>5. İçerik üreticileri ve kullanıcı içerikleri</h2><ul>
<li>Video, Net ve Circ paylaşımı yalnızca <b>Profilim</b> sayfasından içerik üreticisi hesabı oluşturan kullanıcılara açıktır. Videolar ve Nets seçilen süre sonunda silinir; Circs hesabınız silinene veya siz kaldırana kadar yayında kalır.</li>
<li>Yüklediğiniz içeriğin sahibi veya kullanım hakkı sahibi olduğunuzu, üçüncü kişilerin telif, kişilik ve gizlilik haklarını ihlal etmediğinizi kabul edersiniz. İçeriğiniz üzerindeki haklar size aittir; NeonTV'ye yalnızca videoyu sitede ve bağlantılı ortamlarda yayınlama, önbelleğe alma ve boyutlandırma izni verirsiniz.</li>
<li><b>Geçici yayın:</b> Yüklenen videolar yükleme sırasında seçilen süre boyunca yayında kalır; süre dolunca video ve dosyası CDN'den ve siteden kaldırılır. Kaldırılan videonun izlenme gibi toplu istatistikleri profilinizde ve site kayıtlarında kalır.</li>
<li>Yasaklı içerikler için <a href='$url/yasal.php?s=icerik-kurallari'>Topluluk ve İçerik Kuralları</a>'na bakın. Kurallara aykırı içerik bildirim üzerine veya kendiliğinden kaldırılabilir; hesap kısıtlanabilir.</li></ul>
<h2>5a. İçerik ve telif</h2><p>Hakkınızın ihlal edildiğini düşünüyorsanız <a href='$url/iletisim.php'>iletişim formundan</a> “İçerik Kaldırma / Şikayet” konusuyla başvurun; ilgili içerik incelenir.</p>
<h2>6. Token ve Premium</h2><ul><li>Token, sitedeki reklamları izleyerek veya görevlerle kazanılan sanal bir puandır; <b>parasal karşılığı yoktur</b>, nakde çevrilemez, hesaplar arasında devredilemez (Premium hediyesi hariç).</li><li>Premium şu an <b>$price token</b> karşılığında $days gün sürelidir; fiyat ve indirimler Mağaza sayfasında gösterilir. Gizli ücret yoktur.</li><li>Kural ihlalinde kazanılan tokenler ve Premium iptal edilebilir.</li></ul>
<h2>7. Sorumluluk</h2><p>Hizmet “olduğu gibi” sunulur; kesintisiz veya hatasız çalışacağı garanti edilmez. Yasaların izin verdiği ölçüde dolaylı zararlardan sorumluluk kabul edilmez.</p>
<h2>8. Değişiklik ve hukuk</h2><p>Koşullar güncellenebilir; önemli değişiklikler sitede duyurulur. Türk hukuku uygulanır; tüketici işlemlerinde Tüketici Hakem Heyetleri ve Tüketici Mahkemeleri yetkilidir.</p>
<h2>Satıcı / hizmet sağlayıcı</h2>$S"];

    $docs['cerez'] = ['Çerez Politikası', "
<p>Çerezler ve benzeri teknolojiler (localStorage) siteyi çalıştırmak ve tercihlerinizi hatırlamak için kullanılır.</p>
<table class='lg-t'><tr><th>Ad / tür</th><th>Amaç</th><th>Kategori</th><th>Süre</th></tr>
<tr><td>Oturum çerezi / giriş anahtarı (localStorage)</td><td>Giriş yapmış kalmanızı sağlar</td><td>Zorunlu</td><td>Oturum / yenileme</td></tr>
<tr><td>CSRF anahtarı (oturum çerezi)</td><td>Form güvenliği</td><td>Zorunlu</td><td>Oturum</td></tr>
<tr><td>neontv_* (localStorage)</td><td>Oynatma hızı, ses, otomatik oynat, indirme tercihi, çerez tercihi</td><td>Tercih</td><td>Siz silene kadar</td></tr></table>
<p><b>Kullanmadıklarımız:</b> reklam, profil çıkarma veya üçüncü taraf analiz çerezi kullanılmaz. Gelecekte eklenirse önce açık rızanız istenir.</p>
<p>Tarayıcınız yazı tipi, simge ve betikler için üçüncü taraf sunuculara (Google Fonts, cdnjs, jsDelivr) bağlanabilir; bu sunucular IP adresinizi görür.</p>
<h2>Tercihlerinizi yönetme</h2><p>Sayfa altındaki “Çerez tercihleri” bağlantısından seçiminizi değiştirebilir, tarayıcı ayarlarından çerezleri silebilirsiniz (zorunlu çerezler silinirse giriş yapmanız gerekir).</p>"];

    $docs['mesafeli-satis'] = ['Mesafeli Satış Sözleşmesi', "
<p>Bu sözleşme, 6502 sayılı Kanun ve Mesafeli Sözleşmeler Yönetmeliği kapsamında, internet üzerinden Premium üyelik edinen alıcı ile aşağıdaki satıcı arasında kurulur.</p>
<h2>1. Satıcı</h2>$S
<h2>2. Konu</h2><p>Alıcının NeonTV hesabına, seçtiği süre boyunca Premium üyelik avantajlarının (özel profil teması/çerçeveleri, erken erişim videoları vb.) tanımlanmasıdır.</p>
<h2>3. Bedel ve ödeme</h2><p>Premium ($days gün) <b>$price token</b> karşılığındadır; indirim ve kuponlar satın alma ekranında gösterilir. Para veya kart bilgisi tahsil edilmez, <b>gizli ücret yoktur</b>.</p>
<h2>4. İfa</h2><p>Hizmet, satın alma onayıyla birlikte <b>anında</b> hesaba tanımlanır. Hediye edilen Premium alıcı hesaba tanımlanır.</p>
<h2>5. Cayma hakkı ve iade</h2><p>Elektronik ortamda anında ifa edilen hizmetlerde, tüketicinin onayıyla ifaya başlanmışsa cayma hakkı kullanılamaz (Yönetmelik m.15/1-ğ). Alıcı, satın almadan önce bunu açıkça onaylar. Buna rağmen NeonTV, <a href='$url/yasal.php?s=iade'>14 Gün İade Politikası</a> kapsamında gönüllü iade imkânı sunar.</p>
<h2>6. Uyuşmazlık</h2><p>Şikayet ve itirazlar için Tüketici Hakem Heyetleri ve Tüketici Mahkemeleri yetkilidir.</p>
<p><small>Sürüm: " . LEGAL_VERSION . "</small></p>"];

    $docs['on-bilgilendirme'] = ['Ön Bilgilendirme Formu', "
<p>Bu form, Premium üyelik satın almadan önce 6502 sayılı Kanun ve Mesafeli Sözleşmeler Yönetmeliği uyarınca bilgilendirilmeniz için hazırlanmıştır.</p>
<h2>Satıcı</h2>$S
<h2>Hizmetin temel nitelikleri</h2><p>NeonTV Premium: profil teması ve çerçeveler, erken erişimli videolara erişim ve diğer Premium avantajları. Süre: <b>$days gün</b> (otomatik yenileme açıkça etkinleştirilmedikçe uzamaz).</p>
<h2>Toplam bedel</h2><p><b>$price token</b>" . (tkDiscountActive($c) ? " (şu an %" . (int)$c['discount_pct'] . " indirimle " . tkPrice($c) . " token)" : "") . ". Vergiler dahil; başka masraf, komisyon veya gizli ücret yoktur. Ödeme gerçek para ile yapılmaz.</p>
<h2>Ödeme ve ifa</h2><p>Bedel token bakiyenizden düşülür; hizmet satın alma anında hesabınıza tanımlanır.</p>
<h2>Cayma hakkı</h2><p>Anında ifa edilen elektronik hizmetlerde, onayınızla ifaya başlanması halinde yasal cayma hakkı kalkar. Bununla birlikte <a href='$url/yasal.php?s=iade'>14 gün iade politikamız</a> geçerlidir.</p>
<h2>Şikayet ve başvuru</h2><p>Önce $contact veya {$i['email']} üzerinden bize ulaşın. Çözüm bulunamazsa Tüketici Hakem Heyetleri ve Tüketici Mahkemeleri'ne başvurabilirsiniz.</p>"];

    $docs['iade'] = ['14 Gün İade Politikası', "
<ul><li>Premium'u token ile satın aldıktan sonraki <b>14 gün</b> içinde iade talep edebilirsiniz.</li>
<li>İade, <b>kullanılmayan süre oranında token</b> olarak bakiyenize yapılır (ör. $days günlük Premium'un 10 günü kullanıldıysa kalan günlerin token karşılığı). Kupon/indirim uygulandıysa ödediğiniz token esas alınır.</li>
<li>İade edilince Premium süreniz buna göre kısaltılır.</li>
<li>Hediye edilen Premium için talebi hediyeyi gönderen yapar; hediye alanın süresi geri alınır.</li>
<li>Para tahsil edilmediği için nakit iade yoktur.</li>
<li>Başvuru: <a href='$url/iletisim.php?konu=iade'>İletişim formu</a> (konu: İade Talebi). En geç 3 iş günü içinde yanıtlanır.</li>
<li>Kötüye kullanım (tekrarlı al-iade) halinde talep reddedilebilir.</li></ul>
<p>Bu politika, yasal haklarınızı sınırlamaz.</p>"];

    $docs['veri-silme'] = ['Veri Silme Talebi', "
<h2>1. Kendiniz silin (anında)</h2><p><a href='$url/myprofile.php'>Profilim</a> → <b>Hesabı sil</b>. Şifrenizi girip onaylayınca hesabınız ve ona bağlı veriler (yorum, puan, geçmiş, token, bildirimler) kalıcı olarak silinir. Silmeden önce <b>Verilerimi indir</b> ile bir kopya alabilirsiniz.</p>
<h2>2. Giriş yapamıyorsanız</h2><p>$contact üzerinden “Veri Silme / KVKK Başvurusu” konusuyla yazın. Hesabınıza ait e-posta adresiyle başvurmanız kimliğinizi doğrulamamız için gereklidir. En geç <b>30 gün</b> içinde yanıtlanır.</p>
<h2>3. Neler saklanabilir?</h2><p>Güvenlik ve hukuki yükümlülük gereği tutulması zorunlu kayıtlar (ör. yetkili makam talepleri) yasal süre boyunca saklanıp sonra silinir. Ziyaret kayıtları en fazla 90 gün sonra otomatik silinir.</p>"];
    return $docs;
}
