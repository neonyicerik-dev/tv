<?php
// ============================================================
// NeonTV - Yüklenen videoların yapay zeka ile kontrolü
// Başlık + 5 kare (ilk 5 sn'den 2, orta, son 5 sn'den 2) Gemini'ye verilir.
// Şüpheli bulunursa video yayından kalkar (status=pending + ai_reason) ve admin → İçerik Üreticileri'nde görünür.
// Kareler önce sunucuda ffmpeg ile alınır; ffmpeg yoksa tarayıcının gönderdiği kareler kullanılır.
// ============================================================
require_once __DIR__ . '/gemini.php';
require_once __DIR__ . '/creator.php';

function nvFfmpegPath(): ?string {
    static $p = false;
    if ($p !== false) return $p;
    $p = null;
    if (function_exists('exec') && !in_array('exec', array_map('trim', explode(',', (string)ini_get('disable_functions'))), true)) {
        $o = []; @exec('command -v ffmpeg 2>/dev/null', $o);
        if (!empty($o[0]) && is_executable($o[0])) $p = $o[0];
    }
    return $p;
}

/** Sunucuda ffmpeg ile 5 kare alır (JPEG ikili dizeleri). Olmazsa boş dizi. */
function nvFramesFromUrl(string $url, int $dur): array {
    $ff = nvFfmpegPath(); if (!$ff || !preg_match('#^https://#', $url)) return [];
    $d = max(2, $dur ?: 10);
    $times = [min(1, $d / 4), min(3.5, $d / 2), $d / 2, max($d - 3.5, $d / 2), max($d - 1, 0.5)];
    $out = [];
    foreach ($times as $t) {
        $cmd = sprintf('timeout 25 %s -v error -ss %.2f -i %s -frames:v 1 -vf scale=640:-2 -q:v 5 -f image2pipe -vcodec mjpeg - 2>/dev/null', escapeshellarg($ff), $t, escapeshellarg($url));
        $img = @shell_exec($cmd);
        if (is_string($img) && strlen($img) > 500) $out[] = $img;
    }
    return $out;
}

/** @param string[] $frames JPEG ikili dizeleri. Dönüş: ['ok'=>bool,'reason'=>string,'checked'=>bool] */
function nvAiCheckFrames(string $title, string $desc, array $frames): array {
    if (!defined('GEMINI_API_KEY') || GEMINI_API_KEY === '' || !$frames) return ['ok' => true, 'reason' => '', 'checked' => false];
    $parts = [['text' => "Bir video paylaşım sitesinde yeni yüklenen videonun başlığı ve ekran görüntüleri aşağıda (ilk 5 sn, orta, son 5 sn). Videonun herkese açık yayınlanması uygun mu?\n"
        . "Şüpheli say: cinsel/çıplaklık içerik, çocuklara yönelik uygunsuzluk, aşırı şiddet/kan, kendine zarar, terör/nefret sembolleri, uyuşturucu kullanımı özendirme, dolandırıcılık/oltalama, başlıkla alakasız kışkırtıcı içerik. Normal oyun/film/eğlence içeriği şüpheli değildir.\n"
        . "SADECE JSON döndür: {\"ok\":true|false,\"reason\":\"kısa Türkçe sebep\"}\nBaşlık: " . mb_substr($title, 0, 150) . "\nAçıklama: " . mb_substr($desc, 0, 300)]];
    foreach (array_slice($frames, 0, 5) as $f) $parts[] = ['inline_data' => ['mime_type' => 'image/jpeg', 'data' => base64_encode($f)]];
    $none = array_map(fn($c) => ['category' => $c, 'threshold' => 'BLOCK_NONE'], ['HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_DANGEROUS_CONTENT']);
    $r = geminiCall(['contents' => [['role' => 'user', 'parts' => $parts]], 'safetySettings' => $none, 'generationConfig' => ['temperature' => 0, 'maxOutputTokens' => 400, 'responseMimeType' => 'application/json']], null, 60);
    $txt = trim((string)($r['text'] ?? ''));
    if ($txt === '') {
        // Model yanıt vermediyse (güvenlik engeli dâhil) şüpheli say; sadece ağ/HTTP hatasında kontrol edilmemiş say
        if ((int)($r['http'] ?? 0) === 200) return ['ok' => false, 'reason' => 'Yapay zeka içeriği değerlendiremedi (güvenlik engeli)', 'checked' => true];
        return ['ok' => true, 'reason' => '', 'checked' => false];
    }
    $j = json_decode(preg_replace('/^```(?:json)?|```$/m', '', $txt), true);
    if (!is_array($j) || !array_key_exists('ok', $j)) return ['ok' => true, 'reason' => '', 'checked' => false];
    return ['ok' => (bool)$j['ok'], 'reason' => mb_substr((string)($j['reason'] ?? ''), 0, 200), 'checked' => true];
}

/** Videoyu kontrol eder, şüpheliyse yayından kaldırır. $frames verilmezse sunucuda ffmpeg denenir. */
function nvModerateVideo(Supabase $db, array $v, array $frames = []): array {
    if (!$frames) $frames = nvFramesFromUrl((string)($v['video_url'] ?? ''), (int)($v['duration'] ?? 0));
    $res = nvAiCheckFrames((string)$v['title'], (string)($v['description'] ?? ''), $frames);
    $now = gmdate('Y-m-d\TH:i:s\Z');
    if (!$res['checked']) return $res;
    if ($res['ok']) { $db->update('videos', ['ai_checked_at' => $now, 'ai_reason' => null], 'id=eq.' . $v['id'], true); return $res; }
    $db->update('videos', ['status' => 'pending', 'ai_checked_at' => $now, 'ai_reason' => $res['reason'] ?: 'Şüpheli içerik'], 'id=eq.' . $v['id'] . '&status=eq.published', true);
    Store::clearCache('home_shorts');
    return $res;
}

/** Tarayıcı kare göndermediyse (3 dk+ kontrolsüz) sunucuda kontrol et; her çalışmada en çok 3 video. */
function nvModerateSweep(Supabase $db): void {
    if (!nvFfmpegPath()) return;
    $since = rawurlencode(gmdate('Y-m-d\TH:i:s\Z', time() - 180));
    $r = $db->select('videos', 'is_user_upload=eq.true&status=eq.published&removed_at=is.null&ai_checked_at=is.null&created_at=lte.' . $since . '&select=id,title,description,video_url,duration&limit=3', true)['data'] ?? [];
    foreach (is_array($r) ? $r : [] as $v) {
        $res = nvModerateVideo($db, $v);
        if (!$res['checked']) $db->update('videos', ['ai_checked_at' => gmdate('Y-m-d\TH:i:s\Z')], 'id=eq.' . $v['id'], true); // tekrar tekrar denenmesin
    }
}
