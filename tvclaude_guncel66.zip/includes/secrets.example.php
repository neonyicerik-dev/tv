<?php
// includes/secrets.example.php -> secrets.php olarak kopyalayın (git'e eklemeyin; Nginx/.htaccess ile erişime kapalıdır).
// PHP-FPM ortam değişkenlerini varsayılanda temizler (clear_env=yes); alternatif: www.conf içinde clear_env = no
// ve env[GEMINI_API_KEY] = ... Bu dosya o yöntem yerine kullanılabilir.
// Supabase proje adresi (Project Settings > API > Project URL) ve anon (public) anahtarı
putenv('SUPABASE_URL=https://PROJE-ID.supabase.co');
putenv('SUPABASE_ANON_KEY=');
putenv('GEMINI_API_KEY=');
putenv('GIPHY_API_KEY=');
putenv('SUPABASE_SERVICE_KEY=');
putenv('CLOUDCONVERT_API_KEY=');
putenv('ALLOWED_HOSTS=fr1.switched.cloud');

// Profil resmi / kapak / kanal logosu CDN'e yüklensin (CDN panelindeki CDN_INGEST_KEY ile AYNI anahtar, en az 24 karakter)
putenv('CDN_INGEST_URL=https://cdn.neontvapp.dpdns.org/ingest.php');
putenv('CDN_INGEST_KEY=');

// Süresi dolan kullanıcı videolarını kaldıran cron adresi için gizli anahtar (cron-job.org: /api/cron_expire.php?key=...)
putenv('EXPIRE_CRON_KEY=');
// Durum sayfası cron anahtarı (status/check.php?key=...)
putenv('STATUS_CRON_KEY=');

// Site adresi (port veya vekil yüzünden bağlantılarda port kayboluyorsa mutlaka doldurun; sonunda / olmasın)
putenv('APP_URL=http://fr1.switched.cloud:20918');

// --- SADECE TEST SUNUCUSU: video tablosunu ayır (normal sitede bu satır OLMAMALI) ---
// putenv('VIDEOS_TABLE=videos_test');
