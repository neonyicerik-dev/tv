<?php
// ============================================================
// NeonTV - SEO / Meta etiket üretici (tek merkez)
// header.php yalnızca nvSeoHead() çağırır. Sayfalar şu değişkenlerden istediklerini tanımlar:
//   $pageTitle, $metaDesc, $ogImage, $pageRobots ('noindex,follow' vb.), $pageType ('video'|'profile'|'website'),
//   $pageNoCanonicalQuery, $pageLd (ek JSON-LD dizisi), $video (video sayfası: duration/created_at için)
// Admin → Meta Etiketler'deki ayarlar (site_settings.page_meta + seo_*) burada okunur.
// ============================================================

/** Gizli / değersiz sayfalar: arama motorları indekslemesin. */
const NV_SEO_NOINDEX = ['library', 'notifications', 'myprofile', 'auth', 'random', 'subscriptions', 'search', 'tokens', 'magaza',
    'blocks', 'takip', '404', 'player2', 'izle', 'user', 'sync', 'cc_test', 'bef'];

function nvSeoClean(string $s, int $max): string {
    $s = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($s), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
    if (mb_strlen($s) <= $max) return $s;
    $cut = mb_substr($s, 0, $max - 1);
    $sp = mb_strrpos($cut, ' ');
    if ($sp !== false && $sp > $max * 0.6) $cut = mb_substr($cut, 0, $sp);
    return rtrim($cut, " ,.;:-–—") . '…';
}
function nvSeoAbs(string $u): string {
    $u = trim($u); if ($u === '') return '';
    if (preg_match('#^https?://#i', $u)) return $u;
    if (strpos($u, '//') === 0) return 'https:' . $u;
    return rtrim(APP_URL, '/') . '/' . ltrim($u, '/');
}
function nvSeoCanonical(string $page): string {
    $base = rtrim(APP_URL, '/');
    $path = strtok($_SERVER['REQUEST_URI'] ?? '/', '?') ?: '/';
    $path = preg_replace('#/index\.php$#', '/', $path);
    $allow = ['index' => ['tag', 'page'], 'video' => ['id'], 'channel' => ['id', 'tab'], 'yasal' => ['s'], 'user' => ['id', 'u'], 'iletisim' => []];
    $keep = [];
    foreach (($allow[$page] ?? []) as $k) {
        if (!isset($_GET[$k]) || $_GET[$k] === '' || !is_string($_GET[$k])) continue;
        if ($k === 'page' && (int)$_GET[$k] <= 1) continue;
        if ($k === 'tab' && $_GET[$k] === 'videos') continue;
        $keep[$k] = $_GET[$k];
    }
    return $base . $path . ($keep ? '?' . http_build_query($keep) : '');
}

function nvSeoHead(): string {
    global $siteSettings, $currentPage, $pageTitle, $metaDesc, $ogImage, $pageRobots, $pageType, $pageLd, $video;
    $S = is_array($siteSettings ?? null) ? $siteSettings : [];
    $pm = is_array($S['page_meta'] ?? null) ? $S['page_meta'] : [];
    $page = (string)($currentPage ?? '');
    $name = APP_NAME;

    // ---------- Başlık & açıklama ----------
    $homeTitle = trim((string)($pm['index']['title'] ?? '')) ?: ($name . ' - ' . APP_TAGLINE);
    $defDesc   = trim((string)($S['seo_default_desc'] ?? '')) ?: (trim((string)($pm['index']['description'] ?? '')) ?: ($name . ' - Neon ışıklı video platformu. Videoları izleyin, paylaşın ve keşfedin.'));
    $title = isset($pageTitle) ? trim(html_entity_decode((string)$pageTitle, ENT_QUOTES | ENT_HTML5, 'UTF-8')) : '';
    $desc  = isset($metaDesc) ? trim((string)$metaDesc) : '';

    if ($page === 'index') {
        if (!empty($pm['index']['title'])) $title = $pm['index']['title']; elseif ($title === '' || $title === 'Ana Sayfa') $title = $homeTitle;
        if (!empty($pm['index']['description'])) $desc = $pm['index']['description'];
        if (!empty($_GET['tag']) && is_string($_GET['tag'])) { $title = '#' . $_GET['tag'] . ' videoları'; $desc = ''; }
        if (isset($_GET['page']) && (int)$_GET['page'] > 1) $title .= ' - Sayfa ' . (int)$_GET['page'];
    } elseif (in_array($page, ['search', 'auth'], true)) {
        if (!empty($pm[$page]['title']) && $title === '') $title = $pm[$page]['title'];
        if (!empty($pm[$page]['description']) && $desc === '') $desc = $pm[$page]['description'];
    } elseif ($page === 'video' || $page === 'channel') {
        $tf = (string)($pm[$page]['title_format'] ?? ''); $df = (string)($pm[$page]['description_format'] ?? '');
        if ($title !== '' && $tf !== '' && substr_count($tf, '%s') === 1) $title = sprintf($tf, nvSeoClean($title, 70));
        if ($page === 'channel' && $df !== '' && substr_count($df, '%s') === 1 && !empty($GLOBALS['channel']['name']) && $desc === '') $desc = sprintf($df, $GLOBALS['channel']['name']);
        elseif ($page === 'video' && $df !== '' && substr_count($df, '%s') === 1 && $desc !== '') $desc = sprintf($df, $desc);
    }
    if ($title === '') $title = $homeTitle;
    // Marka eki: zaten içeriyorsa ekleme; başlık çok uzunsa önce kısalt
    if ($page !== 'index' && stripos($title, $name) === false) $title = nvSeoClean($title, 62) . ' | ' . $name;
    else $title = nvSeoClean($title, 75);
    $desc = nvSeoClean($desc !== '' ? $desc : $defDesc, 158);

    // ---------- Robots / canonical ----------
    $robots = (string)($S['site_meta_robots'] ?? 'index,follow');
    if (!empty($pageRobots)) $robots = (string)$pageRobots;
    elseif (in_array($page, NV_SEO_NOINDEX, true)) $robots = 'noindex,follow';
    // sayfa 2+ ve etiket sayfaları: indeksle ama kopya sıralama sayfalarını engelle
    if ($page === 'index' && isset($_GET['sort'])) $robots = 'noindex,follow';
    if (stripos($robots, 'noindex') === false) $robots .= ',max-image-preview:large,max-snippet:-1,max-video-preview:-1';
    $canon = nvSeoCanonical($page);

    // ---------- Görsel ----------
    $img = trim((string)($ogImage ?? ''));
    if ($img === '' && $page === 'index') $img = trim((string)($pm['index']['og_image'] ?? ''));
    if ($img === '') $img = trim((string)($S['site_og_image'] ?? ''));
    if ($img === '') $img = '/assets/img/app.png';
    $img = nvSeoAbs($img);
    $type = (string)($pageType ?? ($page === 'video' ? 'video' : ($page === 'user' ? 'profile' : 'website')));
    $ogType = ['video' => 'video.other', 'profile' => 'profile'][$type] ?? 'website';

    $tw = trim((string)($S['seo_twitter'] ?? '')); if ($tw !== '' && $tw[0] !== '@') $tw = '@' . $tw;
    $theme = preg_match('/^#[0-9a-f]{3,8}$/i', (string)($S['seo_theme_color'] ?? '')) ? $S['seo_theme_color'] : '#070711';
    $e = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

    $h  = '<meta charset="UTF-8">' . "\n";
    $h .= '    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">' . "\n";
    $h .= '    <title>' . $e($title) . '</title>' . "\n";
    $h .= '    <meta name="description" content="' . $e($desc) . '">' . "\n";
    if ($page === 'index' && empty($_GET['tag']) && !empty($S['seo_keywords'])) $h .= '    <meta name="keywords" content="' . $e($S['seo_keywords']) . '">' . "\n";
    $h .= '    <meta name="robots" content="' . $e($robots) . '">' . "\n";
    $h .= '    <link rel="canonical" href="' . $e($canon) . '">' . "\n";
    $h .= '    <link rel="alternate" hreflang="tr" href="' . $e($canon) . '">' . "\n";
    $h .= '    <link rel="alternate" hreflang="x-default" href="' . $e($canon) . '">' . "\n";
    $h .= '    <meta name="referrer" content="strict-origin-when-cross-origin">' . "\n";
    $h .= '    <meta name="theme-color" content="' . $e($theme) . '">' . "\n";
    $h .= '    <meta name="color-scheme" content="dark">' . "\n";
    $h .= '    <meta name="application-name" content="' . $e($name) . '">' . "\n";
    $h .= '    <meta name="apple-mobile-web-app-title" content="' . $e($name) . '">' . "\n";
    $h .= '    <meta name="apple-mobile-web-app-capable" content="yes">' . "\n";
    $h .= '    <meta name="mobile-web-app-capable" content="yes">' . "\n";
    $h .= '    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">' . "\n";
    $h .= '    <meta name="format-detection" content="telephone=no">' . "\n";
    foreach (['google-site-verification' => 'seo_verif_google', 'msvalidate.01' => 'seo_verif_bing', 'yandex-verification' => 'seo_verif_yandex'] as $mn => $sk) {
        $v = trim((string)($S[$sk] ?? '')); if ($v !== '' && preg_match('/^[\w\-]{8,120}$/', $v)) $h .= '    <meta name="' . $mn . '" content="' . $e($v) . '">' . "\n";
    }
    // Open Graph
    $h .= '    <meta property="og:site_name" content="' . $e($name) . '">' . "\n";
    $h .= '    <meta property="og:locale" content="tr_TR">' . "\n";
    $h .= '    <meta property="og:type" content="' . $e($ogType) . '">' . "\n";
    $h .= '    <meta property="og:title" content="' . $e(nvSeoClean($title, 90)) . '">' . "\n";
    $h .= '    <meta property="og:description" content="' . $e($desc) . '">' . "\n";
    $h .= '    <meta property="og:url" content="' . $e($canon) . '">' . "\n";
    $h .= '    <meta property="og:image" content="' . $e($img) . '">' . "\n";
    $h .= '    <meta property="og:image:alt" content="' . $e(nvSeoClean($title, 100)) . '">' . "\n";
    if ($type === 'video' && !empty($video) && is_array($video)) {
        if (!empty($video['duration'])) $h .= '    <meta property="video:duration" content="' . (int)$video['duration'] . '">' . "\n";
        if (!empty($video['created_at'])) $h .= '    <meta property="video:release_date" content="' . $e(gmdate('c', strtotime($video['created_at']))) . '">' . "\n";
    }
    // Twitter / X
    $h .= '    <meta name="twitter:card" content="summary_large_image">' . "\n";
    if ($tw !== '') $h .= '    <meta name="twitter:site" content="' . $e($tw) . '">' . "\n";
    $h .= '    <meta name="twitter:title" content="' . $e(nvSeoClean($title, 70)) . '">' . "\n";
    $h .= '    <meta name="twitter:description" content="' . $e(nvSeoClean($desc, 200)) . '">' . "\n";
    $h .= '    <meta name="twitter:image" content="' . $e($img) . '">' . "\n";
    $h .= '    <meta name="view-transition" content="same-origin">' . "\n";

    // ---------- JSON-LD ----------
    $ld = [];
    if ($page === 'index' && empty($_GET['tag']) && (int)($_GET['page'] ?? 1) <= 1) {
        $base = rtrim(APP_URL, '/');
        $ld[] = ['@context' => 'https://schema.org', '@type' => 'WebSite', 'name' => $name, 'url' => $base . '/', 'inLanguage' => 'tr-TR',
            'potentialAction' => ['@type' => 'SearchAction', 'target' => ['@type' => 'EntryPoint', 'urlTemplate' => $base . '/search.php?q={search_term_string}'], 'query-input' => 'required name=search_term_string']];
        $ld[] = ['@context' => 'https://schema.org', '@type' => 'Organization', 'name' => $name, 'url' => $base . '/', 'logo' => nvSeoAbs('/assets/img/app.png')];
    }
    if (!empty($pageLd) && is_array($pageLd)) $ld[] = $pageLd;
    foreach ($ld as $j) $h .= '    <script type="application/ld+json">' . json_encode($j, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script>' . "\n";
    return $h;
}
