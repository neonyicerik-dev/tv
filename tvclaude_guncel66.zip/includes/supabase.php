<?php
// ============================================================
// NeonTV - Supabase REST API Helper Sınıfı
// ============================================================
require_once __DIR__ . '/config.php';

class Supabase {
    /** İstek boyunca veritabanı çağrı sayısı/süresi (yavaş istek günlüğü için) */
    public static array $stats = ['n' => 0, 'ms' => 0.0, 'slow' => '', 'slowms' => 0];
    private string $url;
    private string $anonKey;
    private string $serviceKey;

    public function __construct() {
        $this->url        = SUPABASE_URL;
        $this->anonKey    = SUPABASE_ANON_KEY;
        $this->serviceKey = SUPABASE_SERVICE_KEY;
    }

    /** Test sunucusu: secrets.php'de putenv('VIDEOS_TABLE=videos_test'); tanımlıysa `videos` tablosu yerine o tablo kullanılır (normal sitede tanımlı olmamalı). */
    private static function tbl(string $t): string {
        static $alt = null;
        if ($alt === null) { $v = trim((string)getenv('VIDEOS_TABLE')); $alt = preg_match('/^[a-z_][a-z0-9_]{0,40}$/', $v) ? $v : ''; }
        return ($t === 'videos' && $alt !== '') ? $alt : $t;
    }

    /** İstek boyunca tek curl tutamağı (bağlantı yeniden kullanılır); her çağrıda seçenekler sıfırlanır */
    private static function sharedHandle() {
        static $h = null;
        if ($h === null) $h = curl_init(); else curl_reset($h);
        return $h;
    }

    // --------------------------------------------------------
    // Ana HTTP İstek Metodu (G2: SSL doğrulama zorunlu)
    // --------------------------------------------------------
    private function request(
        string  $method,
        string  $endpoint,
        ?array  $data = null,
        bool    $useServiceKey = false,
        ?string $userToken = null,
        array   $extraHeaders = []
    ): array {
        $url    = $this->url . '/rest/v1/' . $endpoint;
        $apiKey = $useServiceKey ? $this->serviceKey : $this->anonKey;
        $bearer = $userToken ?? $apiKey;

        $headers = array_merge([
            'Content-Type: application/json',
            'Prefer: return=representation',
            'apikey: ' . $apiKey,
            'Authorization: Bearer ' . $bearer,
        ], $extraHeaders);

        // Aynı istek içinde bağlantıyı yeniden kullan (her sorguda yeni TLS el sıkışması yapma)
        $ch = self::sharedHandle();
        $opts = [
            CURLOPT_URL             => $url,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPHEADER      => $headers,
            CURLOPT_ENCODING        => '',
            CURLOPT_TCP_KEEPALIVE   => 1,
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_CONNECTTIMEOUT  => 10,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];

        // G2: Özel CA bundle yolu tanımlanmışsa kullan
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }

        curl_setopt_array($ch, $opts);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif (in_array($method, ['PATCH', 'PUT', 'DELETE'], true)) {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            if ($data !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        } elseif ($method === 'HEAD') {
            curl_setopt($ch, CURLOPT_NOBODY, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'HEAD');
        }

        $__t0 = microtime(true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        $__ms = (microtime(true) - $__t0) * 1000;
        self::$stats['n']++; self::$stats['ms'] += $__ms;
        if ($__ms > self::$stats['slowms']) { self::$stats['slowms'] = (int)$__ms; self::$stats['slow'] = $method . ' ' . (string)strtok($endpoint, '?') . ' ' . (int)$__ms . 'ms'; }

        if ($error) {
            error_log('[Supabase] cURL error: ' . $error . ' (endpoint: ' . $endpoint . ')');
            return ['data' => null, 'status' => 0, 'error' => 'Bağlantı hatası'];
        }

        $decoded = json_decode($response, true);
        if ($httpCode >= 400) {
            $msg = is_array($decoded) ? ($decoded['message'] ?? 'HTTP ' . $httpCode) : 'HTTP ' . $httpCode;
            error_log('[Supabase] HTTP ' . $httpCode . ' ' . $method . ' ' . strtok($endpoint, '?') . ': ' . $msg);
            // Hata gövdesi 'data' olarak dönmesin: çağıranlar dizi bekliyor (foreach/offset çökmesini önler)
            return ['data' => [], 'status' => $httpCode, 'error' => $msg];
        }
        return [
            'data'   => $decoded,
            'status' => $httpCode,
            'error'  => null,
        ];
    }

    // --------------------------------------------------------
    // SELECT
    // --------------------------------------------------------
    public function select(
        string  $table,
        string  $query = '',
        bool    $useServiceKey = false,
        ?string $userToken = null
    ): array {
        $endpoint = self::tbl($table) . ($query ? '?' . $query : '');
        return $this->request('GET', $endpoint, null, $useServiceKey, $userToken);
    }

    // --------------------------------------------------------
    // Paralel SELECT: [anahtar => [tablo, sorgu]] -> [anahtar => ['data'=>..,'status'=>..,'error'=>..]]
    // Birbirinden bağımsız sorgular art arda değil aynı anda gider (gecikme ~ en yavaş tek sorgu kadar olur).
    // --------------------------------------------------------
    public function selectMany(array $queries, bool $useServiceKey = false): array {
        $mh = curl_multi_init(); $hs = []; $out = [];
        $apiKey = $useServiceKey ? $this->serviceKey : $this->anonKey;
        foreach ($queries as $k => [$table, $query]) {
            $table = self::tbl($table);
            $ch = curl_init($this->url . '/rest/v1/' . $table . ($query ? '?' . $query : ''));
            $o = [CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => '', CURLOPT_TIMEOUT => 30, CURLOPT_CONNECTTIMEOUT => 10,
                  CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'apikey: ' . $apiKey, 'Authorization: Bearer ' . $apiKey]];
            if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') $o[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
            curl_setopt_array($ch, $o);
            curl_multi_add_handle($mh, $ch); $hs[$k] = $ch;
        }
        $t0 = microtime(true);
        do { $st = curl_multi_exec($mh, $running); if ($running) curl_multi_select($mh, 1.0); } while ($running && $st === CURLM_OK);
        $ms = (microtime(true) - $t0) * 1000;
        self::$stats['n'] += count($hs); self::$stats['ms'] += $ms;
        foreach ($hs as $k => $ch) {
            $raw = curl_multi_getcontent($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $dec = json_decode((string)$raw, true);
            $out[$k] = ($code >= 400 || $code === 0 || !is_array($dec))
                ? ['data' => [], 'status' => $code, 'error' => $code ? 'HTTP ' . $code : 'Bağlantı hatası']
                : ['data' => $dec, 'status' => $code, 'error' => null];
            curl_multi_remove_handle($mh, $ch); curl_close($ch);
        }
        curl_multi_close($mh);
        return $out;
    }

    // --------------------------------------------------------
    // INSERT
    // --------------------------------------------------------
    public function insert(
        string  $table,
        array   $data,
        bool    $useServiceKey = false,
        ?string $userToken = null
    ): array {
        $res = $this->request('POST', self::tbl($table), $data, $useServiceKey, $userToken);
        // Web push: yeni bildirim eklenince kullanıcıya (abonesiyse) tarayıcı bildirimi gönder
        if ($table === 'notifications' && ($res['status'] ?? 500) < 300 && !empty($data['user_id']) && function_exists('nvPushSchedule')) nvPushSchedule((string)$data['user_id']);
        return $res;
    }

    // --------------------------------------------------------
    // UPDATE
    // --------------------------------------------------------
    public function update(
        string $table,
        array  $data,
        string $condition,
        bool   $useServiceKey = false
    ): array {
        $endpoint = self::tbl($table) . '?' . $condition;
        return $this->request('PATCH', $endpoint, $data, $useServiceKey);
    }

    // --------------------------------------------------------
    // DELETE
    // --------------------------------------------------------
    public function delete(
        string  $table,
        string  $condition,
        bool    $useServiceKey = false,
        ?string $userToken = null
    ): array {
        $endpoint = self::tbl($table) . '?' . $condition;
        return $this->request('DELETE', $endpoint, null, $useServiceKey, $userToken);
    }

    // --------------------------------------------------------
    // RPC (PostgreSQL Function Call)
    // --------------------------------------------------------
    public function rpc(
        string  $function,
        array   $params = [],
        bool    $useServiceKey = false,
        ?string $userToken = null
    ): array {
        return $this->request('POST', 'rpc/' . $function, $params, $useServiceKey, $userToken);
    }

    // --------------------------------------------------------
    // Kullanıcı Token Doğrulama
    // --------------------------------------------------------
    public function verifyToken(string $token): ?array {
        // Başarılı doğrulamayı 45 sn önbellekle: her API çağrısında Supabase'e gidiş-dönüş (~300-800 ms) yapma
        if (class_exists('Store')) {
            $k = 'tok_' . hash('sha256', $token);
            $u = Store::remember($k, 45, fn() => $this->verifyTokenRemote($token));
            if (!$u) Store::clearCache($k);
            return $u ?: null;
        }
        return $this->verifyTokenRemote($token);
    }

    private function verifyTokenRemote(string $token): ?array {
        $ch = self::sharedHandle();
        $opts = [
            CURLOPT_URL             => $this->url . '/auth/v1/user',
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPHEADER      => [
                'apikey: ' . $this->anonKey,
                'Authorization: Bearer ' . $token,
            ],
            CURLOPT_TIMEOUT         => 10,
            CURLOPT_CONNECTTIMEOUT  => 5,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }
        curl_setopt_array($ch, $opts);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err      = curl_error($ch);
        if ($err) { error_log('[Supabase::verifyToken] ' . $err); return null; }
        return ($httpCode === 200) ? json_decode($response, true) : null;
    }

    // --------------------------------------------------------
    // Kullanıcı Kaydı
    // --------------------------------------------------------
    public function signUp(string $email, string $password, array $metadata = []): array {
        return $this->authRequest('/auth/v1/signup', [
            'email'    => $email,
            'password' => $password,
            'data'     => $metadata,
        ]);
    }

    // --------------------------------------------------------
    // Kullanıcı Girişi
    // --------------------------------------------------------
    public function signIn(string $email, string $password): array {
        return $this->authRequest('/auth/v1/token?grant_type=password', [
            'email'    => $email,
            'password' => $password,
        ]);
    }

    // --------------------------------------------------------
    // Auth işlemleri için ortak yardımcı
    // --------------------------------------------------------
    private function authRequest(string $path, array $body): array {
        $ch   = curl_init();
        $opts = [
            CURLOPT_URL             => $this->url . $path,
            CURLOPT_POST            => true,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_POSTFIELDS      => json_encode($body),
            CURLOPT_HTTPHEADER      => [
                'Content-Type: application/json',
                'apikey: ' . $this->anonKey,
            ],
            CURLOPT_TIMEOUT         => 15,
            CURLOPT_CONNECTTIMEOUT  => 5,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }
        curl_setopt_array($ch, $opts);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err      = curl_error($ch);
        curl_close($ch);
        if ($err) { error_log('[Supabase::authRequest] ' . $err); }
        return ['data' => json_decode($response, true), 'status' => $httpCode];
    }

    // --------------------------------------------------------
    // Yardımcı: Tek kayıt döndür
    // --------------------------------------------------------
    public function first(string $table, string $query = '', bool $useServiceKey = false): ?array {
        $result = $this->select($table, $query . '&limit=1', $useServiceKey);
        if ($result['status'] === 200 && !empty($result['data'])) {
            return $result['data'][0];
        }
        return null;
    }

    // --------------------------------------------------------
    // Yardımcı: Sayım döndür (count exact)
    // --------------------------------------------------------
    public function count(string $table, string $query = '', bool $useServiceKey = false): int {
        $endpoint = self::tbl($table) . ($query ? '?' . $query : '');
        $ch   = self::sharedHandle();
        $apiKey  = $useServiceKey ? $this->serviceKey : $this->anonKey;
        $opts = [
            CURLOPT_URL             => $this->url . '/rest/v1/' . $endpoint,
            CURLOPT_NOBODY          => true,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HEADER          => true,
            CURLOPT_HTTPHEADER      => [
                'apikey: ' . $apiKey,
                'Authorization: Bearer ' . $apiKey,
                'Prefer: count=exact',
            ],
            CURLOPT_TIMEOUT         => 10,
            CURLOPT_CONNECTTIMEOUT  => 5,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }
        curl_setopt_array($ch, $opts);
        $response = curl_exec($ch);
        // Content-Range: 0-24/47
        if (preg_match('/Content-Range:\s*\d+-\d+\/(\d+)/i', $response, $m)) {
            return (int)$m[1];
        }
        return 0;
    }

    // --------------------------------------------------------
    // Auth Admin: Kayıtlı Kullanıcıları Listele
    // --------------------------------------------------------
    public function adminListUsers(int $page = 1, int $perPage = 100): array {
        $ch = curl_init();
        $opts = [
            CURLOPT_URL             => $this->url . '/auth/v1/admin/users?page=' . $page . '&per_page=' . $perPage,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPHEADER      => [
                'apikey: ' . $this->serviceKey,
                'Authorization: Bearer ' . $this->serviceKey,
            ],
            CURLOPT_TIMEOUT         => 15,
            CURLOPT_CONNECTTIMEOUT  => 5,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '' && file_exists(CA_BUNDLE_PATH)) {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }
        curl_setopt_array($ch, $opts);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err      = curl_error($ch);
        curl_close($ch);

        if ($err || $httpCode >= 400) {
            error_log('[Supabase::adminListUsers] ' . ($err ?: 'HTTP ' . $httpCode));
            return [];
        }

        $decoded = json_decode($response, true);
        return $decoded['users'] ?? ($decoded ?: []);
    }

    // --------------------------------------------------------
    // Auth Admin: Kullanıcıyı sil (bağlı tablolar ON DELETE CASCADE ile temizlenir)
    // --------------------------------------------------------
    public function adminDeleteUser(string $userId): bool {
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $userId)) return false;
        $ch = curl_init();
        $opts = [
            CURLOPT_URL             => $this->url . '/auth/v1/admin/users/' . $userId,
            CURLOPT_CUSTOMREQUEST   => 'DELETE',
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPHEADER      => [
                'apikey: ' . $this->serviceKey,
                'Authorization: Bearer ' . $this->serviceKey,
            ],
            CURLOPT_TIMEOUT         => 20,
            CURLOPT_CONNECTTIMEOUT  => 5,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '' && file_exists(CA_BUNDLE_PATH)) {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }
        curl_setopt_array($ch, $opts);
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err      = curl_error($ch);
        curl_close($ch);
        if ($err || $httpCode >= 400) {
            error_log('[Supabase::adminDeleteUser] ' . ($err ?: 'HTTP ' . $httpCode));
            return false;
        }
        return true;
    }
}
