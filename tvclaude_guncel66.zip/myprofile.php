<?php
// ============================================================
// NeonTV - Kullanıcı Profil Sayfası
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';

// Güvenlik: Kullanıcı sayfada JS ile doğrulanacak olsa da PHP ile de session/URL kontrolü eklenebilir,
// ancak NeonTV'de ana yetkilendirme Supabase JS ile client-side yapıldığı için burada sadece temel yapı sunulacak.

$pageTitle = 'Profilim';
$needThemes = true;
?>
<?php include __DIR__ . '/components/header.php'; ?>

<div class="max-w-screen-lg mx-auto py-8 px-4 sm:px-6">
    <!-- user.php ile aynı üst başlık (herkese açık görünümün önizlemesi) -->
    <div id="me-head" class="rounded-2xl mb-6 overflow-hidden" style="background:#13131f;border:1px solid rgba(255,255,255,0.08)">
        <div id="me-cover" style="height:100px;background:linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.15));background-size:cover;background-position:center"></div>
        <div class="flex items-center gap-5 px-5 pb-5 -mt-8">
            <div id="me-avatar" class="w-24 h-24 rounded-full overflow-hidden flex items-center justify-center text-4xl font-bold bg-gray-800 shrink-0" style="border:3px solid rgba(0,245,255,0.4)">U</div>
            <div class="min-w-0 pt-8">
                <h2 id="me-name" class="text-2xl font-bold text-white">Profilim</h2>
                <p id="me-bio" class="text-sm text-gray-300 mt-1 max-w-xl whitespace-pre-wrap"></p>
                <p id="me-since" class="text-sm text-gray-400 mt-1"></p>
                <div id="me-xp" class="mt-2"></div>
                <div class="flex gap-4 text-sm text-gray-300 mt-2 flex-wrap">
                    <span><i class="fa-regular fa-comment mr-1 text-cyan-400"></i><b id="me-c">0</b> yorum</span>
                    <span><i class="fa-solid fa-user-group mr-1 text-pink-400"></i><b id="me-f">0</b> takipçi · <b id="me-g">0</b> takip</span>
                </div>
                <a id="see-profile-top" href="#" class="inline-block mt-3 text-sm font-bold text-cyan-400 hover:underline"><i class="fa-solid fa-eye mr-1"></i>Profilimi gör</a>
            </div>
        </div>
    </div>
    <div class="max-w-2xl mx-auto">
    <div class="p-6 sm:p-8 rounded-3xl" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h1 class="text-2xl font-bold text-white mb-6 flex items-center gap-3">
            <i class="fa-solid fa-user-pen" style="color:#00f5ff;"></i> Profilimi Düzenle
        </h1>

        <div id="auth-alert" class="hidden mb-6 p-4 rounded-xl text-sm font-medium border"></div>

        <form id="profile-form" class="space-y-6" onsubmit="updateProfile(event)">
            
            <!-- Profil Resmi -->
            <div class="flex flex-col items-center sm:flex-row sm:items-start gap-6 border-b border-gray-800 pb-6">
                <div class="relative group">
                    <div class="w-32 h-32 rounded-full overflow-hidden border-4 border-[#13131f] flex items-center justify-center text-4xl font-bold shrink-0 shadow-xl"
                         style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;" id="profile-avatar-wrap">
                        <img id="profile-avatar-img" src="" alt="" class="w-full h-full object-cover hidden">
                        <span id="profile-avatar-initial">U</span>
                    </div>
                    
                    <label class="absolute bottom-0 right-0 w-10 h-10 rounded-full flex items-center justify-center cursor-pointer transition-transform hover:scale-110"
                           style="background:#00f5ff;color:#000;box-shadow:0 0 15px rgba(0,245,255,0.5);" title="Fotoğraf Değiştir">
                        <i class="fa-solid fa-camera"></i>
                        <input type="file" class="hidden" id="avatar-upload" accept="image/*" onchange="handleAvatarUpload(this)">
                    </label>
                </div>
                
                <div class="flex-1 text-center sm:text-left pt-2">
                    <h3 class="text-lg font-bold text-white mb-1">Profil Fotoğrafı</h3>
                    <p class="text-sm text-gray-500 mb-3">En iyi görünüm için kare bir fotoğraf (JPEG, PNG) yükleyin.</p>
                    <div id="avatar-upload-status" class="text-xs font-semibold text-cyan-400 items-center justify-center sm:justify-start gap-2" style="display:none;">
                        <i class="fa-solid fa-spinner fa-spin"></i> Yükleniyor... <span id="avatar-upload-pct">0%</span>
                    </div>
                    <input type="hidden" id="avatar-url-input">
                </div>
            </div>

            <!-- Kapak Resmi -->
            <div class="border-b border-gray-800 pb-6">
                <h3 class="text-lg font-bold text-white mb-2">Kapak Resmi</h3>
                <div class="rounded-xl overflow-hidden mb-3" style="height:110px;background:linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.15));">
                    <img id="cover-img" src="" alt="" class="w-full h-full object-cover hidden">
                </div>
                <label class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold cursor-pointer text-black" style="background:#00f5ff;">
                    <i class="fa-solid fa-image"></i> Kapak Yükle
                    <input type="file" class="hidden" id="cover-upload" accept="image/*" onchange="handleCoverUpload(this)">
                </label>
                <span id="cover-status" class="text-xs text-gray-400 ml-3"></span>
                <p class="text-xs text-gray-500 mt-2">Geniş bir resim seçin (4:1 oranında kırpılır).</p>
            </div>

            <!-- Biyografi -->
            <div>
                <label class="block text-sm font-medium text-gray-400 mb-1.5">Kısa Biyografi</label>
                <textarea id="profile-bio" maxlength="300" rows="3" placeholder="Kendinden kısaca bahset (en fazla 300 karakter)"
                          class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 px-4 text-white text-sm focus:outline-none focus:border-cyan-500"></textarea>
            </div>

            <!-- Kullanıcı Bilgileri -->
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-400 mb-1.5">Kullanıcı Adı</label>
                    <div class="relative">
                        <i class="fa-solid fa-user absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
                        <input type="text" id="profile-username" class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 pl-10 pr-4 text-white focus:outline-none focus:border-cyan-500 transition-colors" placeholder="Kullanıcı adınız">
                    </div>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-400 mb-1.5">E-posta Adresi (Değiştirilemez)</label>
                    <div class="relative">
                        <i class="fa-solid fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-600"></i>
                        <input type="email" id="profile-email" class="w-full bg-black/50 border border-gray-900 rounded-xl py-3 pl-10 pr-4 text-gray-500 cursor-not-allowed" disabled>
                    </div>
                </div>
            </div>

            <!-- Şifre Değiştirme -->
            <div class="pt-4 border-t border-gray-800">
                <h3 class="text-sm font-bold text-white mb-4">Şifre Değiştir <span class="text-xs text-gray-500 font-normal">(İsteğe bağlı)</span></h3>
                
                <div>
                    <label class="block text-sm font-medium text-gray-400 mb-1.5">Yeni Şifre</label>
                    <div class="relative">
                        <i class="fa-solid fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
                        <input type="password" id="profile-password" class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 pl-10 pr-12 text-white focus:outline-none focus:border-cyan-500 transition-colors" placeholder="Değiştirmek istemiyorsanız boş bırakın">
                        <button type="button" class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white" onclick="togglePass('profile-password', this)">
                            <i class="fa-regular fa-eye"></i>
                        </button>
                    </div>
                    <p class="text-xs text-gray-500 mt-1.5">En az 6 karakter uzunluğunda olmalıdır.</p>
                </div>
            </div>

            <!-- Kaydet -->
            <div class="pt-4 flex justify-end">
                <button type="submit" id="profile-save-btn" class="px-8 py-3 rounded-xl font-bold text-black transition-all hover:scale-105"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);box-shadow:0 0 20px rgba(0,245,255,0.3);">
                    Değişiklikleri Kaydet
                </button>
            </div>
        </form>
    </div>

    <!-- ===== İÇERİK ÜRETİCİSİ ===== -->
    <div class="p-6 sm:p-8 rounded-3xl mt-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h2 class="text-xl font-bold text-white mb-1 flex items-center gap-3"><i class="fa-solid fa-clapperboard" style="color:#00f5ff;"></i> İçerik Üreticisi</h2>
        <p class="text-sm text-gray-500 mb-4">İçerik üreticisi hesabı oluşturarak kendi videolarını yükleyebilirsin. Videolar seçtiğin süre sonunda kaldırılır, izlenme sayın profilinde kalır.</p>
        <a href="<?= APP_URL ?>/studyo.php" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold text-black" style="background:#00f5ff;"><i class="fa-solid fa-video"></i> Stüdyoya git</a>
    </div>

    <!-- ===== PREMIUM: PROFİL TEMASI + AVATAR ÇERÇEVESİ ===== -->
    <div id="theme-card" class="p-6 sm:p-8 rounded-3xl mt-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h2 class="text-xl font-bold text-white mb-1 flex items-center gap-3 flex-wrap">
            <i class="fa-solid fa-palette" style="color:#bf00ff;"></i> Profil Teması ve Çerçeve
            <span class="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full" style="background:linear-gradient(135deg,#ffd76a,#ff9d00);color:#000"><i class="fa-solid fa-crown text-[8px]"></i>Premium</span>
        </h2>
        <p class="text-sm text-gray-500 mb-4">Animasyonlu bir tema seç; profiline giren herkes görür. Seçtiğin çerçeve yorumlarda ve profilinde avatarının etrafında görünür.</p>
        <div id="theme-lock" class="hidden mb-4 p-3 rounded-xl text-sm" style="background:rgba(255,215,106,0.08);border:1px solid rgba(255,215,106,0.3);color:#ffd76a;">
            <i class="fa-solid fa-lock mr-2"></i>Bu özellik Premium üyelere özeldir. Aşağıdaki temalara göz atabilirsin; seçmek için Premium gerekir.
        </div>
        <div id="theme-msg" class="hidden mb-4 p-3 rounded-xl text-sm border"></div>

        <div id="theme-preview" class="nvt rounded-2xl mb-5 p-4 flex items-center gap-4" style="--nvt-base:#0b0b12;min-height:96px;border:1px solid rgba(255,255,255,0.08)">
            <span id="tp-frame" class="nvf nvf-lg" style="font-size:64px"><span id="tp-avatar" class="nvf-in" style="display:flex;width:64px;height:64px;border-radius:50%;overflow:hidden;align-items:center;justify-content:center;font-weight:800;font-size:24px;background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000"></span></span>
            <div class="min-w-0"><div id="tp-name" class="text-xl font-bold text-white truncate">Kullanıcı</div><div class="text-xs text-gray-300">Canlı önizleme</div></div>
        </div>

        <h3 class="text-sm font-bold text-white mb-2">Tema</h3>
        <div id="theme-grid" class="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6"></div>

        <h3 class="text-sm font-bold text-white mb-2">Avatar çerçevesi</h3>
        <div id="frame-grid" class="grid grid-cols-3 sm:grid-cols-4 gap-3 mb-6"></div>

        <div class="flex gap-3 justify-end">
            <button type="button" id="theme-clear" class="px-4 py-2.5 rounded-xl text-sm font-semibold text-gray-300" style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12)">Temayı kaldır</button>
            <button type="button" id="theme-save" class="px-6 py-2.5 rounded-xl text-sm font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Kaydet</button>
        </div>
    </div>

    <!-- ===== DISCORD BAĞLA ===== -->
    <div id="dc-card" class="p-6 sm:p-8 rounded-3xl mt-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h2 class="text-xl font-bold text-white mb-1 flex items-center gap-3"><i class="fa-brands fa-discord" style="color:#5865f2;"></i> Discord Hesabını Bağla</h2>
        <p class="text-sm text-gray-500 mb-4">Bağlarsan Discord sunucumuzdaki <strong class="text-gray-300">BigNeonAI</strong> botuna kendi hesabını (jeton, premium, seviye vb.) sorabilirsin. Bot yalnızca sana ait bilgileri, sadece sana özel olarak gösterir.</p>
        <div id="dc-state" class="text-sm text-gray-400 mb-3">Yükleniyor...</div>
        <div id="dc-code-box" class="hidden mb-3 p-4 rounded-xl text-center" style="background:rgba(88,101,242,.1);border:1px solid rgba(88,101,242,.4)">
            <div class="text-xs text-gray-400 mb-1">Discord'da şu komutu yaz (10 dakika geçerli):</div>
            <code id="dc-cmd" class="text-lg font-bold text-white select-all"></code>
        </div>
        <button type="button" id="dc-code-btn" class="px-5 py-2.5 rounded-xl text-sm font-bold text-white" style="background:#5865f2;"><i class="fa-solid fa-link mr-2"></i>Bağlama kodu oluştur</button>
        <button type="button" id="dc-unlink-btn" class="hidden px-5 py-2.5 rounded-xl text-sm font-bold text-white ml-2" style="background:#dc2626;"><i class="fa-solid fa-link-slash mr-2"></i>Bağlantıyı kaldır</button>
    </div>

    <!-- ===== GİZLİLİK VE VERİLERİM (KVKK) ===== -->
    <div id="privacy-card" class="p-6 sm:p-8 rounded-3xl mt-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h2 class="text-xl font-bold text-white mb-1 flex items-center gap-3"><i class="fa-solid fa-user-shield" style="color:#00f5ff;"></i> Gizlilik ve Verilerim</h2>
        <p class="text-sm text-gray-500 mb-4">KVKK kapsamında hesabına ait verilerin bir kopyasını indirebilir veya hesabını kalıcı olarak silebilirsin.</p>
        <div id="privacy-msg" class="hidden mb-4 p-3 rounded-xl text-sm border"></div>
        <button type="button" id="export-btn" class="px-5 py-2.5 rounded-xl text-sm font-bold text-black" style="background:#00f5ff;"><i class="fa-solid fa-download mr-2"></i>Verilerimi indir (JSON)</button>

        <div class="mt-6 pt-5" style="border-top:1px solid rgba(239,68,68,0.25)">
            <h3 class="text-sm font-bold text-red-400 mb-1"><i class="fa-solid fa-triangle-exclamation mr-2"></i>Hesabı sil</h3>
            <p class="text-xs text-gray-500 mb-3">Bu işlem <strong class="text-gray-300">geri alınamaz</strong>. Yorumların, puanların, listelerin, aboneliklerin ve diğer tüm verilerin silinir. Premium üyeliğin de sona erer.</p>
            <input type="password" id="del-pass" placeholder="Şifren" autocomplete="current-password" class="w-full mb-2 bg-black/30 border border-gray-800 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none focus:border-red-500">
            <input type="text" id="del-confirm" placeholder='Onaylamak için "HESABIMI SİL" yaz' autocomplete="off" class="w-full mb-3 bg-black/30 border border-gray-800 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none focus:border-red-500">
            <button type="button" id="del-btn" disabled class="px-5 py-2.5 rounded-xl text-sm font-bold text-white disabled:opacity-40" style="background:#dc2626;"><i class="fa-solid fa-trash mr-2"></i>Hesabımı kalıcı olarak sil</button>
        </div>
    </div>
</div>

<script>


async function handleCoverUpload(input) {
    const f = input.files && input.files[0]; if (!f) return;
    const st = document.getElementById('cover-status');
    st.textContent = 'Yükleniyor...';
    try {
        const { data: { session } } = await sbClient.auth.getSession();
        const fd = new FormData(); fd.append('cover', f);
        const r = await fetch('<?= APP_URL ?>/api/upload_avatar.php?type=cover&token=' + encodeURIComponent(session.access_token), { method: 'POST', headers: { 'Authorization': 'Bearer ' + session.access_token }, body: fd });
        const j = await r.json();
        if (!j.success) { st.textContent = j.message || 'Yüklenemedi'; return; }
        const img = document.getElementById('cover-img'); img.src = j.data.url; img.classList.remove('hidden');
        st.textContent = 'Kapak güncellendi.';
    } catch (e) { st.textContent = 'Yüklenemedi'; }
    input.value = '';
}
async function saveBio() {
    const { data: { session } } = await sbClient.auth.getSession();
    const bio = document.getElementById('profile-bio').value;
    await fetch('<?= APP_URL ?>/api/profile.php?token=' + encodeURIComponent(session.access_token), { method: 'POST', headers: { 'Authorization': 'Bearer ' + session.access_token, 'Content-Type': 'application/json' }, body: JSON.stringify({ bio }) });
}
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const { data: { session } } = await sbClient.auth.getSession(); if (!session) return;
        const j = await (await fetch('<?= APP_URL ?>/api/profile.php?token=' + encodeURIComponent(session.access_token), { headers: { 'Authorization': 'Bearer ' + session.access_token } })).json();
        if (j.success) {
            document.getElementById('profile-bio').value = j.data.bio || '';
            if (j.data.cover_url) { const img = document.getElementById('cover-img'); img.src = j.data.cover_url; img.classList.remove('hidden'); }
        }
    } catch (e) {}
});


// ============================================================
// Premium tema + çerçeve seçici
// ============================================================
(function () {
    const BASE = '<?= APP_URL ?>';
    const $ = id => document.getElementById(id);
    let themes = [], frames = [], cur = { theme: '', frame: '' }, isPrem = false;
    const msg = (text, ok) => { const el = $('theme-msg'); el.className = 'mb-4 p-3 rounded-xl text-sm border ' + (ok ? 'bg-green-500/10 border-green-500/40 text-green-400' : 'bg-red-500/10 border-red-500/40 text-red-400'); el.textContent = text; el.classList.remove('hidden'); };
    async function token() { const { data: { session } } = await sbClient.auth.getSession(); return session ? session.access_token : null; }

    function paintPreview() {
        const pv = $('theme-preview');
        pv.className = 'nvt rounded-2xl mb-5 p-4 flex items-center gap-4' + (cur.theme ? ' nvt-' + cur.theme : '');
        const fr = $('tp-frame'); fr.className = 'nvf nvf-lg' + (cur.frame ? ' nvf-' + cur.frame : '');
        const av = $('tp-avatar'); av.textContent = '';
        const url = ($('avatar-url-input') || {}).value, name = (($('profile-username') || {}).value || 'Kullanıcı').trim() || 'Kullanıcı';
        if (url) { const im = document.createElement('img'); im.src = url; im.alt = ''; im.style.cssText = 'width:100%;height:100%;object-fit:cover'; av.appendChild(im); } else av.textContent = name.charAt(0).toUpperCase();
        const nm = $('tp-name'); nm.textContent = name; nm.className = 'text-xl font-bold truncate ' + (cur.theme ? 'nvt-name' : 'text-white');
        document.querySelectorAll('#theme-grid .nvt-tile').forEach(t => t.classList.toggle('sel', t.dataset.k === cur.theme));
        document.querySelectorAll('#frame-grid .nvt-tile').forEach(t => t.classList.toggle('sel', t.dataset.k === cur.frame));
    }
    function build() {
        const tg = $('theme-grid'), fg = $('frame-grid'); tg.textContent = ''; fg.textContent = '';
        const none = (label) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'nvt-tile' + (isPrem ? '' : ' locked'); b.dataset.k = ''; const box = document.createElement('div'); box.className = 'nvt'; box.style.cssText = '--nvt-base:#13131f;display:flex;align-items:center;justify-content:center;color:#6b7280'; box.textContent = '—'; const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = label; b.append(box, nm); return b; };
        const t0 = none('Yok'); t0.onclick = () => { if (!isPrem) return; cur.theme = ''; paintPreview(); }; tg.appendChild(t0);
        const f0 = none('Yok'); f0.onclick = () => { if (!isPrem) return; cur.frame = ''; paintPreview(); }; fg.appendChild(f0);
        themes.forEach(t => {
            const b = document.createElement('button'); b.type = 'button'; b.className = 'nvt-tile' + (isPrem ? '' : ' locked'); b.dataset.k = t.key; b.title = t.desc;
            const box = document.createElement('div'); box.className = 'nvt nvt-' + t.key;
            const nm = document.createElement('div'); nm.className = 'nm';
            const ic = document.createElement('i'); ic.className = 'fa-solid ' + t.icon; ic.style.color = t.colors[0];
            nm.append(ic, document.createTextNode(t.name)); b.append(box, nm);
            b.onclick = () => { if (!isPrem) { msg('Tema seçmek için Premium üye olmalısın.', false); return; } cur.theme = t.key; cur.frame = cur.frame && frames.some(f => f.key === cur.frame && f.group === 'obj') ? cur.frame : t.key; paintPreview(); };
            tg.appendChild(b);
        });
        let lastGroup = '';
        frames.forEach(fr => {
            if (fr.group !== lastGroup) {
                lastGroup = fr.group; const h = document.createElement('div'); h.className = 'col-span-full text-xs font-bold text-gray-400 mt-2'; h.textContent = fr.group === 'obj' ? 'Objeli çerçeveler (taç, kanat, boynuz…)' : 'Halka çerçeveler'; fg.appendChild(h);
            }
            const fb = document.createElement('button'); fb.type = 'button'; fb.className = 'nvt-tile fr' + (isPrem ? '' : ' locked'); fb.dataset.k = fr.key; fb.title = fr.name;
            const wrap = document.createElement('span'); wrap.className = 'nvf nvf-sm nvf-' + fr.key; wrap.style.fontSize = '36px'; wrap.style.alignSelf = 'center';
            const inn = document.createElement('span'); inn.className = 'nvf-in'; inn.style.cssText = 'display:block;width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#00f5ff,#bf00ff)';
            wrap.appendChild(inn);
            const lab = document.createElement('div'); lab.className = 'nm'; lab.style.cssText = 'font-size:10px;justify-content:center;text-align:center'; lab.textContent = fr.name;
            fb.append(wrap, lab);
            fb.onclick = () => { if (!isPrem) { msg('Çerçeve seçmek için Premium üye olmalısın.', false); return; } cur.frame = fr.key; paintPreview(); };
            fg.appendChild(fb);
        });
        paintPreview();
    }
    async function init() {
        try {
            const t = await token(); if (!t) return;
            const r = await fetch(BASE + '/api/theme.php?token=' + encodeURIComponent(t), { headers: { 'Authorization': 'Bearer ' + t } });
            const j = await r.json(); if (!j.success) return;
            themes = j.data.themes || []; frames = j.data.frames || []; isPrem = !!j.data.is_premium; cur = { theme: j.data.theme || '', frame: j.data.frame || '' };
            $('theme-lock').classList.toggle('hidden', isPrem);
            $('theme-save').disabled = $('theme-clear').disabled = !isPrem;
            $('theme-save').style.opacity = $('theme-clear').style.opacity = isPrem ? '1' : '.5';
            build();
            ['avatar-url-input', 'profile-username'].forEach(id => { const el = $(id); if (el) { el.addEventListener('input', paintPreview); } });
            setInterval(paintPreview, 2500); // avatar yüklemesi sonrası önizlemeyi güncelle
        } catch (e) { /* sessiz */ }
    }
    async function save(clear) {
        const t = await token(); if (!t) return;
        const body = clear ? { theme: '', frame: '' } : { theme: cur.theme, frame: cur.frame };
        try {
            const r = await fetch(BASE + '/api/theme.php?token=' + encodeURIComponent(t), { method: 'POST', headers: { 'Authorization': 'Bearer ' + t, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
            const j = await r.json();
            if (j.success) { if (clear) cur = { theme: '', frame: '' }; paintPreview(); msg(clear ? 'Tema kaldırıldı.' : 'Tema kaydedildi. Profilinde ve yorumlarında görünecek.', true); }
            else msg(j.message || 'Kaydedilemedi.', false);
        } catch (e) { msg('Bağlantı hatası.', false); }
    }
    document.addEventListener('DOMContentLoaded', () => { $('theme-save').onclick = () => save(false); $('theme-clear').onclick = () => save(true); init(); });
})();

// ============================================================
// Discord bağlama
// ============================================================
(function () {
    const BASE = '<?= APP_URL ?>';
    const $ = id => document.getElementById(id);
    async function call(body) {
        const { data: { session } } = await sbClient.auth.getSession(); if (!session) throw new Error('Oturum yok');
        const r = await fetch(BASE + '/api/discord_link.php', { method: body ? 'POST' : 'GET', headers: Object.assign({ 'Authorization': 'Bearer ' + session.access_token }, body ? { 'Content-Type': 'application/json' } : {}), body: body ? JSON.stringify(body) : undefined });
        return r.json();
    }
    function show(d) {
        const linked = !!(d && d.linked);
        $('dc-state').innerHTML = linked ? '<span class="text-green-400"><i class="fa-solid fa-circle-check mr-1"></i>Bağlı</span> <span class="text-gray-500">(Discord ID: ' + String(d.discord_id).replace(/[^0-9]/g, '') + ')</span>' : 'Henüz bağlı değil.';
        $('dc-unlink-btn').classList.toggle('hidden', !linked);
        $('dc-code-btn').innerHTML = '<i class="fa-solid fa-link mr-2"></i>' + (linked ? 'Başka hesaba bağla' : 'Bağlama kodu oluştur');
    }
    document.addEventListener('DOMContentLoaded', async () => {
        if (!$('dc-card')) return;
        try { const j = await call(); show(j.success ? j.data : null); } catch (e) { $('dc-state').textContent = 'Durum alınamadı.'; }
        $('dc-code-btn').onclick = async () => {
            const b = $('dc-code-btn'); b.disabled = true;
            try {
                const j = await call({ action: 'code' });
                if (!j.success) { $('dc-state').textContent = j.message || 'Kod oluşturulamadı.'; }
                else { $('dc-cmd').textContent = '/hesabim bagla kod:' + j.data.code; $('dc-code-box').classList.remove('hidden'); }
            } catch (e) { $('dc-state').textContent = 'Bağlantı hatası.'; }
            b.disabled = false;
        };
        $('dc-unlink-btn').onclick = async () => {
            if (!confirm('Discord bağlantısı kaldırılsın mı?')) return;
            try { await call({ action: 'unlink' }); $('dc-code-box').classList.add('hidden'); show({ linked: false }); } catch (e) {}
        };
    });
})();

// ============================================================
// Gizlilik: veri indirme + hesap silme
// ============================================================
(function () {
    const BASE = '<?= APP_URL ?>';
    const $ = id => document.getElementById(id);
    const pm = (text, ok) => { const el = $('privacy-msg'); el.className = 'mb-4 p-3 rounded-xl text-sm border ' + (ok ? 'bg-green-500/10 border-green-500/40 text-green-400' : 'bg-red-500/10 border-red-500/40 text-red-400'); el.textContent = text; el.classList.remove('hidden'); };
    async function token() { const { data: { session } } = await sbClient.auth.getSession(); return session ? session.access_token : null; }
    document.addEventListener('DOMContentLoaded', () => {
        $('export-btn').onclick = async () => {
            const b = $('export-btn'); b.disabled = true;
            try {
                const t = await token(); if (!t) { pm('Oturum bulunamadı.', false); b.disabled = false; return; }
                const r = await fetch(BASE + '/api/account.php?action=export', { headers: { 'Authorization': 'Bearer ' + t } });
                if (!r.ok) { let m = 'İndirilemedi.'; try { m = (await r.json()).message || m; } catch (e) {} pm(m, false); b.disabled = false; return; }
                const blob = await r.blob(); const a = document.createElement('a');
                a.href = URL.createObjectURL(blob); a.download = 'neontv-verilerim.json'; document.body.appendChild(a); a.click(); a.remove();
                setTimeout(() => URL.revokeObjectURL(a.href), 4000); pm('Verilerin indirildi.', true);
            } catch (e) { pm('Bağlantı hatası.', false); }
            b.disabled = false;
        };
        const chk = () => { $('del-btn').disabled = !($('del-pass').value && $('del-confirm').value.trim().toLocaleUpperCase('tr-TR') === 'HESABIMI SİL'); };
        $('del-pass').addEventListener('input', chk); $('del-confirm').addEventListener('input', chk);
        $('del-btn').onclick = async () => {
            if (!confirm('Hesabın ve tüm verilerin kalıcı olarak silinecek. Emin misin?')) return;
            const b = $('del-btn'); b.disabled = true;
            try {
                const t = await token(); if (!t) { pm('Oturum bulunamadı.', false); return; }
                const r = await fetch(BASE + '/api/account.php', { method: 'POST', headers: { 'Authorization': 'Bearer ' + t, 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'delete', password: $('del-pass').value, confirm: $('del-confirm').value.trim() }) });
                const j = await r.json();
                if (j.success) { try { await sbClient.auth.signOut(); } catch (e) {} location.href = BASE + '/index.php'; return; }
                pm(j.message || 'Silinemedi.', false);
            } catch (e) { pm('Bağlantı hatası.', false); }
            chk();
        };
    });
})();

function togglePass(id, btn) {
    const el = document.getElementById(id);
    const isPass = el.type === 'password';
    el.type = isPass ? 'text' : 'password';
    btn.innerHTML = `<i class="fa-regular fa-${isPass ? 'eye-slash' : 'eye'}"></i>`;
}

function showMsg(msg, type) {
    const el = document.getElementById('auth-alert');
    const bg = type === 'error' ? 'bg-red-500/10 border-red-500/50 text-red-400' : 'bg-green-500/10 border-green-500/50 text-green-400';
    const ic = type === 'error' ? 'fa-triangle-exclamation' : 'fa-circle-check';
    el.className = `mb-6 p-4 rounded-xl text-sm font-medium border flex items-center gap-3 ${bg}`;
    el.innerHTML = `<i class="fa-solid ${ic}"></i>`;
    const span = document.createElement('span');
    span.textContent = msg;
    el.appendChild(span);
    el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Supabase session'ı kontrol et ve formu doldur
document.addEventListener('DOMContentLoaded', async () => {
    const { data: { session } } = await sbClient.auth.getSession();
    
    if (!session) {
        window.location.href = '<?= APP_URL ?>/auth.php';
        return;
    }
    
    const user = session.user;
    const meta = user.user_metadata || {};
    
    document.getElementById('profile-email').value = user.email || '';
    document.getElementById('profile-username').value = meta.username || user.email.split('@')[0] || '';
    
    if (meta.avatar_url) {
        document.getElementById('avatar-url-input').value = meta.avatar_url;
        const img = document.getElementById('profile-avatar-img');
        img.src = meta.avatar_url;
        img.classList.remove('hidden');
        document.getElementById('profile-avatar-initial').classList.add('hidden');
    } else {
        const username = meta.username || user.email.split('@')[0] || 'U';
        document.getElementById('profile-avatar-initial').textContent = username.charAt(0).toUpperCase();
    }
});

// Profil resmi yükleme (sunucuda assets/profiles/ klasörüne)
async function handleAvatarUpload(input) {
    const file = input.files[0];
    if (!file) return;
    const statusEl = document.getElementById('avatar-upload-status');
    const setBusy = (b) => { statusEl.style.display = b ? 'flex' : 'none'; };

    if (!file.type.startsWith('image/')) {
        alert('Lütfen geçerli bir resim dosyası seçin.');
        input.value = '';
        return;
    }
    if (file.size > 5 * 1024 * 1024) {
        alert('Dosya boyutu 5MB\'dan küçük olmalıdır.');
        input.value = '';
        return;
    }

    setBusy(true);
    document.getElementById('avatar-upload-pct').textContent = '0%';

    try {
        const { data: { session } } = await sbClient.auth.getSession();
        if (!session) {
            alert('Oturum bulunamadı. Lütfen tekrar giriş yapın.');
            setBusy(false);
            return;
        }

        const fd = new FormData();
        fd.append('avatar', file);

        const xhr = new XMLHttpRequest();
        xhr.upload.onprogress = e => {
            if (!e.lengthComputable) return;
            document.getElementById('avatar-upload-pct').textContent = Math.round(e.loaded / e.total * 100) + '%';
        };
        xhr.onload = () => {
            let res = null;
            try { res = JSON.parse(xhr.responseText); } catch (e) {}
            if (res && res.success && res.data && res.data.url) {
                const url = res.data.url;
                document.getElementById('avatar-url-input').value = url;
                const img = document.getElementById('profile-avatar-img');
                img.src = url;
                img.classList.remove('hidden');
                document.getElementById('profile-avatar-initial').classList.add('hidden');
                showMsg('Fotoğraf yüklendi. Kalıcı olması için "Değişiklikleri Kaydet"e basın.', 'success');
            } else {
                alert((res && res.message) ? res.message : 'Resim yüklenemedi (HTTP ' + xhr.status + ').');
            }
            setBusy(false);
            input.value = '';
        };
        xhr.onerror = () => {
            alert('Ağ bağlantı hatası. İnternet bağlantınızı kontrol edin.');
            setBusy(false);
        };
        xhr.open('POST', '<?= APP_URL ?>/api/upload_avatar.php');
        xhr.setRequestHeader('Authorization', 'Bearer ' + session.access_token);
        xhr.send(fd);
    } catch (err) {
        alert('Yükleme hatası: ' + err.message);
        setBusy(false);
    }
}

// Profili kaydet
async function updateProfile(e) {
    e.preventDefault();
    
    const btn = document.getElementById('profile-save-btn');
    const oldHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Kaydediliyor...';
    
    const username = document.getElementById('profile-username').value.trim();
    const avatar_url = document.getElementById('avatar-url-input').value.trim();
    const password = document.getElementById('profile-password').value;
    
    if (!username) {
        showMsg('Kullanıcı adı boş bırakılamaz.', 'error');
        btn.disabled = false; btn.innerHTML = oldHtml;
        return;
    }
    if (password && password.length < 6) {
        showMsg('Şifre en az 6 karakter olmalıdır.', 'error');
        btn.disabled = false; btn.innerHTML = oldHtml;
        return;
    }
    
    try {
        const updates = { data: { username, avatar_url } };
        
        // Önce metadata'yı (username ve avatar) güncelle
        const { error: metaError } = await sbClient.auth.updateUser(updates);
        
        if (metaError) {
            showMsg('Profil bilgileri güncellenemedi: ' + metaError.message, 'error');
            btn.disabled = false; btn.innerHTML = oldHtml;
            return;
        }

        await saveBio();

        // public.profiles tablosunu da güncelle
        const { data: { session: curSession } } = await sbClient.auth.getSession();
        const { error: profileError } = await sbClient.from('profiles').update({
            username: username,
            avatar_url: avatar_url
        }).eq('id', curSession.user.id);

        if (profileError) {
            console.error("Profiles tablosu güncellenemedi:", profileError);
        }
        
        // Eğer şifre girilmişse şifreyi de güncelle
        if (password) {
            const { error: passError } = await sbClient.auth.updateUser({ password });
            if (passError) {
                showMsg('Profil güncellendi ancak şifre değiştirilemedi: ' + passError.message, 'error');
                btn.disabled = false; btn.innerHTML = oldHtml;
                return;
            }
            document.getElementById('profile-password').value = '';
        }
        
        showMsg('Profil başarıyla güncellendi!', 'success');
        
        // Header'daki UI'ı güncellemek için global fonksiyonu çağır (footer.php içinde)
        const { data: { session: newSession } } = await sbClient.auth.getSession();
        if (typeof updateAuthUI === 'function') {
            updateAuthUI(newSession);
        }
        
    } catch (err) {
        showMsg('Bir hata oluştu.', 'error');
    }
    
    btn.disabled = false;
    btn.innerHTML = oldHtml;
}
</script>

</div><!-- /max-w-2xl -->
<div style="max-width:42rem;margin:0 auto 24px;padding:0 16px">
  <div class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,0.08)">
    <h2 class="text-sm font-bold text-white mb-1">Favori videoların (profil vitrini)</h2>
    <p class="text-xs text-gray-500 mb-3">En sevdiğin 3 videoyu profilinde göster. Video linkini veya ID'sini yapıştır.</p>
    <div id="sc-slots" class="space-y-2"></div>
    <p id="sc-msg" class="text-xs mt-2 text-gray-400"></p>
    <p class="text-xs text-gray-500 mt-3">Profil adresin: <a id="my-handle" href="#" class="text-cyan-400 break-all"></a></p>
  </div>
</div>
<div style="max-width:42rem;margin:0 auto 24px;padding:0 16px">
  <div class="rounded-2xl p-4" style="background:#13131f;border:1px solid rgba(255,255,255,0.08)">
    <h2 class="text-sm font-bold text-white mb-1"><i class="fa-solid fa-laptop text-cyan-400 mr-2"></i>Giriş yaptığın cihazlar</h2>
    <p class="text-xs text-gray-500 mb-3">Son girişlerin. Tanımadığın bir cihaz görürsen diğer oturumları kapat ve şifreni değiştir.</p>
    <div id="dv-list" class="space-y-1.5 text-sm"></div>
    <button id="dv-out" type="button" class="mt-3 px-4 py-2 rounded-xl text-xs font-bold" style="background:rgba(248,113,113,.15);color:#f87171">Diğer tüm oturumları kapat</button>
    <p id="dv-msg" class="text-xs mt-2 text-gray-400"></p>
  </div>
</div>
<div style="max-width:42rem;margin:0 auto 32px;padding:0 16px;text-align:center">
  <a id="see-profile" href="#" class="inline-flex items-center gap-2 px-5 py-3 rounded-xl font-bold" style="background:linear-gradient(135deg,#7df9ff,#a78bfa);color:#00121a"><i class="fa-solid fa-eye"></i> Profilimi Gör</a>
</div>
<script>
window.addEventListener('load', async function(){try{var r=await sbClient.auth.getSession();var u=r&&r.data&&r.data.session&&r.data.session.user;if(u)document.getElementById('see-profile').href='<?= APP_URL ?>/user/'+encodeURIComponent(u.id);else document.getElementById('see-profile').style.display='none';}catch(e){document.getElementById('see-profile').style.display='none';}});
</script>

<script>
window.addEventListener('load', async function(){
  try{
    var s=(await sbClient.auth.getSession()).data.session; if(!s) return; var uid=s.user.id;
    var set=function(i,t){var e=document.getElementById(i); if(e) e.textContent=t;};
    ['see-profile-top','see-profile'].forEach(function(i){var a=document.getElementById(i); if(a){a.href='<?= APP_URL ?>/user/'+encodeURIComponent(uid);a.style.display='';}});
    var j=await (await fetch('<?= APP_URL ?>/api/profile.php',{headers:{'Authorization':'Bearer '+s.access_token}})).json();
    var p=(j&&j.success&&j.data)||{};
    if(p.url){['see-profile-top','see-profile'].forEach(function(i){var a=document.getElementById(i); if(a) a.href=p.url;});}
    var nm=p.username||(s.user.user_metadata&&s.user.user_metadata.username)||(s.user.email||'Kullanıcı').split('@')[0]; set('me-name',nm); set('me-bio',p.bio||'');
    if(p.created_at) set('me-since','Üyelik: '+new Date(p.created_at).toLocaleDateString('tr-TR'));
    var av=document.getElementById('me-avatar');
    if(p.avatar_url){var im=document.createElement('img');im.src=p.avatar_url;im.className='w-full h-full object-cover';im.alt='';av.textContent='';av.appendChild(im);} else av.textContent=nm.charAt(0).toUpperCase();
    if(p.cover_url) document.getElementById('me-cover').style.backgroundImage='url("'+String(p.cover_url).replace(/"/g,'%22')+'")';
    if(p.xp_html) document.getElementById('me-xp').innerHTML=p.xp_html;
    set('me-c',p.comments!=null?p.comments:'–'); set('me-f',p.followers!=null?p.followers:'–'); set('me-g',p.following!=null?p.following:'–');
  }catch(e){}
});
</script>
<script>
window.addEventListener('load', async function(){
  try{
    var s=(await sbClient.auth.getSession()).data.session; if(!s) return;
    var H={'Authorization':'Bearer '+s.access_token,'Content-Type':'application/json'}, box=document.getElementById('sc-slots'), msg=document.getElementById('sc-msg');
    var call=async function(m,b){return (await fetch('<?= APP_URL ?>/api/showcase.php',{method:m,headers:H,body:b?JSON.stringify(b):undefined})).json();};
    var move=async function(from,to){
      var cur=window._scItems||[]; var order=cur.map(function(x){return x.position;});
      var i=order.indexOf(from), j=order.indexOf(to); if(i<0||j<0) return;
      order.splice(j,0,order.splice(i,1)[0]);
      var r=await call('POST',{reorder:order}); msg.textContent=r.success?'Sıra kaydedildi.':(r.message||'Hata'); msg.style.color=r.success?'#4ade80':'#f87171';
      if(r.success) draw(r.data.items);
    };
    var draw=function(items){
      window._scItems=items;
      box.textContent='';
      for(var pos=1;pos<=3;pos++){(function(pos){
        var it=items.find(function(x){return x.position===pos;});
        var row=document.createElement('div'); row.style.cssText='display:flex;gap:8px;align-items:center';
        var lab=document.createElement('span'); lab.textContent=pos+'.'; lab.style.cssText='color:#6b7280;font-size:13px;width:16px';
        var inp=document.createElement('input'); inp.placeholder='Video linki veya ID'; inp.value=it?it.title:''; inp.style.cssText='flex:1;min-width:0;padding:8px 10px;border-radius:10px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#fff;font-size:13px'; if(it) inp.readOnly=true;
        var b=document.createElement('button'); b.style.cssText='padding:7px 12px;border-radius:10px;font-size:12px;font-weight:700;color:#000;background:'+(it?'#f87171':'#00f5ff'); b.textContent=it?'Kaldır':'Ekle';
        b.onclick=async function(){var r=it?await call('DELETE',{position:pos}):await call('POST',{position:pos,video:inp.value}); msg.textContent=r.success?'Kaydedildi.':(r.message||'Hata'); msg.style.color=r.success?'#4ade80':'#f87171'; if(r.success) draw(r.data.items);};
        row.append(lab,inp,b);
        if(it){
          row.draggable=true; row.dataset.pos=pos; row.style.cursor='grab';
          row.addEventListener('dragstart',function(e){window._scDrag=pos;e.dataTransfer.effectAllowed='move';row.style.opacity='.4';});
          row.addEventListener('dragend',function(){row.style.opacity='1';});
          row.addEventListener('dragover',function(e){e.preventDefault();});
          row.addEventListener('drop',function(e){e.preventDefault();if(window._scDrag&&window._scDrag!==pos)move(window._scDrag,pos);});
          var mk=function(t,from,to){var a=document.createElement('button');a.type='button';a.textContent=t;a.setAttribute('aria-label',t==='▲'?'Yukarı taşı':'Aşağı taşı');a.style.cssText='padding:6px 8px;border-radius:8px;font-size:11px;background:rgba(255,255,255,.08);color:#e5e7eb';a.onclick=function(){move(from,to);};return a;};
          var ctl=document.createElement('span');ctl.style.cssText='display:flex;gap:4px';
          var ix=items.indexOf(it);
          if(ix>0) ctl.appendChild(mk('▲',pos,items[ix-1].position));
          if(ix<items.length-1) ctl.appendChild(mk('▼',pos,items[ix+1].position));
          row.insertBefore(ctl,b);
        }
        box.appendChild(row);
      })(pos);}
    };
    var r=await call('GET'); draw(r.success?r.data.items:[]);
    var j=await (await fetch('<?= APP_URL ?>/api/profile.php',{headers:H})).json();
    if(j.success&&j.data.username){var a=document.getElementById('my-handle'); a.href='<?= APP_URL ?>/@'+encodeURIComponent(j.data.username); a.textContent='<?= APP_URL ?>/@'+j.data.username;}
  }catch(e){}
});
</script>
<script>
window.addEventListener('load', async function(){
  try{
    var s=(await sbClient.auth.getSession()).data.session; if(!s) return;
    var L=document.getElementById('dv-list'), M=document.getElementById('dv-msg');
    var j=await (await fetch('<?= APP_URL ?>/api/devices.php',{headers:{'Authorization':'Bearer '+s.access_token}})).json();
    ((j.success&&j.data.devices)||[]).forEach(function(d){var r=document.createElement('div'); r.style.cssText='display:flex;justify-content:space-between;gap:8px;padding:7px 10px;border-radius:10px;background:rgba(255,255,255,.04);color:#e5e7eb'; var a=document.createElement('span'); a.textContent=d.label+(d.country?' · '+d.country:'')+(d.current?'  (bu cihaz)':''); var b=document.createElement('span'); b.style.cssText='color:#6b7280;font-size:12px'; b.textContent=new Date(d.at).toLocaleString('tr-TR'); r.append(a,b); L.appendChild(r);});
    if(!L.children.length) L.textContent='Kayıt yok.';
    document.getElementById('dv-out').onclick=async function(){ if(!confirm('Bu cihaz dışındaki tüm oturumlar kapatılsın mı?')) return; var r=await sbClient.auth.signOut({scope:'others'}); M.textContent=r.error?'Kapatılamadı, tekrar dene.':'Diğer oturumlar kapatıldı.'; M.style.color=r.error?'#f87171':'#4ade80'; };
  }catch(e){}
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
