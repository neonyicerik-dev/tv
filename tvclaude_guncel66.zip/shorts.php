<?php
// NeonTV - Nets: dikey, kaydırmalı akış (kullanıcı yüklemeleri; süresi dolanlar akıştan kalkar)
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Nets'; $metaDesc = 'Kaydır, izle: NeonTV içerik üreticilerinin Netleri.'; $pageRobots = 'index,follow';
include __DIR__ . '/components/header.php';
?>
<style>
#sh-feed{height:calc(100dvh - 64px);overflow-y:scroll;scroll-snap-type:y mandatory;background:#05050a;scrollbar-width:none;overscroll-behavior:contain}
#sh-feed::-webkit-scrollbar{display:none}
.sh-slide{position:relative;height:calc(100dvh - 64px);scroll-snap-align:start;scroll-snap-stop:always;display:flex;justify-content:center;background:#000}
.sh-box{position:relative;height:100%;aspect-ratio:9/16;max-width:100%;background:#0b0b14}
.sh-box video{width:100%;height:100%;object-fit:cover;background:#000;cursor:pointer}
.sh-info{position:absolute;left:0;right:64px;bottom:0;padding:48px 14px 16px;background:linear-gradient(transparent,rgba(0,0,0,.75));pointer-events:none}
.sh-act{position:absolute;right:8px;bottom:70px;display:flex;flex-direction:column;gap:16px;align-items:center}
.sh-act button,.sh-act a{width:46px;height:46px;border-radius:99px;background:rgba(255,255,255,.14);backdrop-filter:blur(6px);color:#fff;border:0;display:flex;align-items:center;justify-content:center;font-size:18px;cursor:pointer}
.sh-act .on{color:#ff3b6b}.sh-n{font-size:11px;color:#fff;text-align:center;margin-top:-12px;text-shadow:0 1px 3px #000}
.sh-bar{position:absolute;left:0;right:0;bottom:0;height:3px;background:rgba(255,255,255,.15)}.sh-bar i{display:block;height:100%;width:0;background:#00f5ff}
.sh-pause{position:absolute;inset:0;display:none;align-items:center;justify-content:center;font-size:54px;color:rgba(255,255,255,.85);pointer-events:none}
@media(min-width:768px){.sh-slide{padding:10px 0}}
</style>
<div id="sh-feed"><div id="sh-msg" style="height:100%;display:flex;align-items:center;justify-content:center;color:#8b8fa3;font-size:14px">Yükleniyor…</div></div>
<script>
window.addEventListener('load', async function () {
  const BASE = <?= json_encode(APP_URL) ?>, feed = document.getElementById('sh-feed');
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let tok = null; try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}
  const H = tok ? { 'Authorization': 'Bearer ' + tok } : {};
  const start = new URLSearchParams(location.search).get('v') || '';
  let offset = 0, more = true, busy = false, muted = true, active = null; const slides = [];
  const fmt = n => n >= 1e6 ? (n / 1e6).toFixed(1) + ' Mn' : n >= 1e3 ? (n / 1e3).toFixed(1) + ' B' : String(n || 0);

  async function load() {
    if (busy || !more) return; busy = true;
    try {
      const r = await (await fetch(BASE + '/api/shorts.php?offset=' + offset + '&limit=6' + (offset === 0 && start ? '&start=' + encodeURIComponent(start) : ''), { headers: H })).json();
      const it = (r.data && r.data.items) || []; more = !!(r.data && r.data.has_more);
      if (offset === 0) feed.innerHTML = '';
      if (offset === 0 && !it.length) { feed.innerHTML = '<div style="height:100%;display:flex;flex-direction:column;gap:10px;align-items:center;justify-content:center;color:#8b8fa3;font-size:14px;text-align:center;padding:20px">Henüz Net yok.<a class="text-cyan-400 underline" href="' + BASE + '/studyo.php">İlk Netyu sen yükle</a></div>'; more = false; return; }
      offset += 6; it.forEach(add); io();
    } catch (e) { if (offset === 0) feed.innerHTML = '<div style="height:100%;display:flex;align-items:center;justify-content:center;color:#fca5a5">Yüklenemedi.</div>'; }
    busy = false;
  }
  function add(v) {
    const d = document.createElement('div'); d.className = 'sh-slide'; d.dataset.id = v.id;
    d.innerHTML = '<div class="sh-box"><video playsinline loop muted preload="none" poster="' + esc(v.thumbnail_url) + '" data-src="' + esc(v.video_url) + '"></video><div class="sh-pause"><i class="fa-solid fa-play"></i></div>' +
      '<div class="sh-info"><div class="text-white font-bold text-sm">' + (v.channel ? '@' + esc(v.channel) : '') + '</div><div class="text-white text-sm mt-1" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' + esc(v.title) + '</div><div class="text-[11px] text-gray-300 mt-1"><i class="fa-regular fa-eye"></i> <span class="sh-v">' + fmt(v.views) + '</span></div></div>' +
      '<div class="sh-act"><button data-like title="Beğen" class="' + (v.liked ? 'on' : '') + '"><i class="fa-solid fa-heart"></i></button><div class="sh-n"><span class="sh-l">' + fmt(v.likes_count) + '</span></div>' +
      '<a href="' + BASE + '/video.php?id=' + v.id + '#comments" title="Yorumlar"><i class="fa-solid fa-comment"></i></a><div class="sh-n">' + fmt(v.comments_count) + '</div>' +
      '<button data-share title="Paylaş"><i class="fa-solid fa-share"></i></button><button data-mute title="Ses"><i class="fa-solid fa-volume-xmark"></i></button></div>' +
      '<div class="sh-bar"><i></i></div></div>';
    const vid = d.querySelector('video'), bar = d.querySelector('.sh-bar i'), ps = d.querySelector('.sh-pause');
    vid.onclick = () => { if (vid.paused) { vid.play(); ps.style.display = 'none'; } else { vid.pause(); ps.style.display = 'flex'; } };
    vid.ontimeupdate = () => { if (vid.duration) bar.style.width = (vid.currentTime / vid.duration * 100) + '%'; if (!d._v && vid.currentTime > 2) { d._v = 1; fetch(BASE + '/api/views.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ video_id: v.id }) }).catch(() => {}); } };
    d.querySelector('[data-mute]').onclick = () => { muted = !muted; document.querySelectorAll('.sh-box video').forEach(x => x.muted = muted); document.querySelectorAll('[data-mute] i').forEach(i => i.className = 'fa-solid ' + (muted ? 'fa-volume-xmark' : 'fa-volume-high')); };
    d.querySelector('[data-share]').onclick = async () => { const u = BASE + '/shorts.php?v=' + v.id; try { if (navigator.share) await navigator.share({ title: v.title, url: u }); else { await navigator.clipboard.writeText(u); alert('Bağlantı kopyalandı'); } } catch (e) {} };
    const lb = d.querySelector('[data-like]'); lb.onclick = async () => {
      if (!tok) { location.href = BASE + '/auth.php'; return; } const on = !lb.classList.contains('on'); lb.classList.toggle('on', on);
      const n = d.querySelector('.sh-l'), cur = parseInt(n.dataset.n || v.likes_count || 0, 10) + (on ? 1 : -1); n.dataset.n = cur; n.textContent = fmt(Math.max(0, cur));
      fetch(BASE + '/api/likes.php?video_id=' + v.id, { method: on ? 'POST' : 'DELETE', headers: Object.assign({ 'Content-Type': 'application/json' }, H), body: JSON.stringify({ video_id: v.id }) }).catch(() => {});
    };
    feed.appendChild(d); slides.push(d);
  }
  let obs = null;
  function io() {
    if (obs) obs.disconnect();
    obs = new IntersectionObserver(es => es.forEach(e => {
      const d = e.target, vid = d.querySelector('video');
      if (e.isIntersecting && e.intersectionRatio > 0.6) {
        active = d; if (!vid.src) vid.src = vid.dataset.src; vid.muted = muted; vid.play().catch(() => {}); d.querySelector('.sh-pause').style.display = 'none';
        const i = slides.indexOf(d), nx = slides[i + 1]; if (nx) { const nv = nx.querySelector('video'); if (!nv.src) { nv.preload = 'metadata'; nv.src = nv.dataset.src; } }
        if (i >= slides.length - 3) load();
        history.replaceState(null, '', BASE + '/shorts.php?v=' + d.dataset.id);
      } else if (!e.isIntersecting || e.intersectionRatio < 0.3) { vid.pause(); }
    }), { root: feed, threshold: [0.3, 0.6, 0.9] });
    slides.forEach(s => obs.observe(s));
  }
  document.addEventListener('keydown', e => { if (!active) return; if (e.key === 'ArrowDown') { e.preventDefault(); active.nextElementSibling && active.nextElementSibling.scrollIntoView({ behavior: 'smooth' }); } if (e.key === 'ArrowUp') { e.preventDefault(); active.previousElementSibling && active.previousElementSibling.scrollIntoView({ behavior: 'smooth' }); } });
  load();
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
