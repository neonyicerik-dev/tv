-- NeonTV features17: içerik üreticisi hesapları ve kullanıcı yüklemeleri (geçici videolar). Tekrar çalıştırılabilir, RLS güvenli.

-- 1) Profil: içerik üreticisi durumu
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_creator      boolean NOT NULL DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS creator_since   timestamptz;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS creator_banned  boolean NOT NULL DEFAULT false;

-- 2) Kanal sahibi (içerik üreticisinin kendi kanalı)
ALTER TABLE public.channels ADD COLUMN IF NOT EXISTS owner_id uuid;
CREATE UNIQUE INDEX IF NOT EXISTS channels_owner_uidx ON public.channels (owner_id) WHERE owner_id IS NOT NULL;

-- 3) Videolar: sahip, kullanıcı yüklemesi bayrağı, kaldırılma bilgisi
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS owner_id         uuid;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS is_user_upload   boolean NOT NULL DEFAULT false;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS removed_at       timestamptz;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS reject_reason    text;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS expires_at       timestamptz;
CREATE INDEX IF NOT EXISTS videos_owner_idx   ON public.videos (owner_id, created_at DESC) WHERE owner_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS videos_expire_idx  ON public.videos (expires_at) WHERE is_user_upload AND removed_at IS NULL;

-- 4) Durum kuralı: yeni durumlar (pending = onay bekliyor, rejected = reddedildi, expired = süresi doldu / kaldırıldı)
DO $$
DECLARE c record;
BEGIN
  FOR c IN SELECT conname FROM pg_constraint
           WHERE conrelid = 'public.videos'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) ILIKE '%status%'
  LOOP
    EXECUTE format('ALTER TABLE public.videos DROP CONSTRAINT %I', c.conname);
  END LOOP;
END $$;
ALTER TABLE public.videos ADD CONSTRAINT videos_status_check
  CHECK (status IN ('published','draft','private','scheduled','pending','rejected','expired'));
