-- NeonTV features18: kısa videolar + gönderiler. Tekrar çalıştırılabilir, RLS güvenli.
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS is_short boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS videos_short_idx ON public.videos (created_at DESC) WHERE is_short AND status = 'published';

CREATE TABLE IF NOT EXISTS public.posts (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id   uuid NOT NULL,
  channel_id  uuid,
  body        text NOT NULL DEFAULT '' CHECK (char_length(body) <= 1000),
  image_url   text,
  status      text NOT NULL DEFAULT 'published' CHECK (status IN ('published','hidden')),
  likes_count integer NOT NULL DEFAULT 0,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS posts_feed_idx   ON public.posts (created_at DESC) WHERE status = 'published';
CREATE INDEX IF NOT EXISTS posts_author_idx ON public.posts (author_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.post_likes (
  post_id    uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (post_id, user_id)
);

ALTER TABLE public.posts      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.post_likes ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.posts      FROM anon, authenticated;
REVOKE ALL ON public.post_likes FROM anon, authenticated;
GRANT ALL ON public.posts      TO service_role;
GRANT ALL ON public.post_likes TO service_role;
