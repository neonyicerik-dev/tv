-- NeonTV features19: Discord hesap bağlama (BigNeonAI botu kullanıcının kendi verilerini gösterebilsin).
-- Tekrar çalıştırılabilir, RLS güvenli (yalnızca service_role erişir).
CREATE TABLE IF NOT EXISTS public.discord_links (
  user_id    uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  discord_id text NOT NULL UNIQUE,
  linked_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.discord_link_codes (
  code       text PRIMARY KEY,
  user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS discord_link_codes_user_idx ON public.discord_link_codes (user_id);

ALTER TABLE public.discord_links      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.discord_link_codes ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.discord_links      FROM anon, authenticated;
REVOKE ALL ON public.discord_link_codes FROM anon, authenticated;
GRANT ALL ON public.discord_links      TO service_role;
GRANT ALL ON public.discord_link_codes TO service_role;
