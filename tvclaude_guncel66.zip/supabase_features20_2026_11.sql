-- NeonTV features20: Ultron (Discord moderasyon botu) tabloları. Tekrar çalıştırılabilir, RLS güvenli (sadece service_role).
CREATE TABLE IF NOT EXISTS public.ultron_mods (
  discord_id text PRIMARY KEY,
  added_by   text NOT NULL DEFAULT '',
  note       text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.ultron_memory (          -- uzun süreli notlar ("şunu hatırla")
  id         bigserial PRIMARY KEY,
  scope      text NOT NULL DEFAULT 'global',               -- 'global' veya 'u:<discord_id>'
  content    text NOT NULL CHECK (char_length(content) <= 500),
  created_by text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ultron_memory_scope_idx ON public.ultron_memory (scope, id DESC);

CREATE TABLE IF NOT EXISTS public.ultron_chat (            -- sohbet geçmişi (kısa süreli hafıza)
  id         bigserial PRIMARY KEY,
  user_id    text NOT NULL,
  channel_id text NOT NULL,
  role       text NOT NULL CHECK (role IN ('user','model')),
  text       text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ultron_chat_key_idx ON public.ultron_chat (user_id, channel_id, id DESC);

CREATE TABLE IF NOT EXISTS public.ultron_tasks (           -- uzun süren işler için görev sistemi
  id         bigserial PRIMARY KEY,
  owner_id   text NOT NULL,
  owner_tag  text NOT NULL DEFAULT '',
  guild_id   text NOT NULL,
  channel_id text,
  title      text NOT NULL,
  goal       text NOT NULL,
  plan       jsonb NOT NULL DEFAULT '[]'::jsonb,            -- [{ "t": "adım", "done": false }]
  notes      jsonb NOT NULL DEFAULT '[]'::jsonb,            -- ilerleme notları
  status     text NOT NULL DEFAULT 'bekliyor' CHECK (status IN ('bekliyor','calisiyor','tamam','iptal','hata','duraklatildi')),
  result     text,
  slices     integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ultron_tasks_status_idx ON public.ultron_tasks (status, id);

CREATE TABLE IF NOT EXISTS public.ultron_config (          -- video seçici kanalı vb. ayarlar
  key        text PRIMARY KEY,
  value      text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['ultron_mods','ultron_memory','ultron_chat','ultron_tasks','ultron_config'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('REVOKE ALL ON public.%I FROM anon, authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
  END LOOP;
END $$;
GRANT USAGE, SELECT ON SEQUENCE public.ultron_memory_id_seq, public.ultron_chat_id_seq, public.ultron_tasks_id_seq TO service_role;
