-- KidNeon (Node.js) tabloları: tüm ayarlar sunucu id + sunucu adıyla saklanır.
-- Bot service_role anahtarıyla erişir (RLS'yi aşar); herkese açık erişim YOK.
create table if not exists public.kidneon_settings (
  guild_id text not null, key text not null, value text,
  guild_name text, updated_at timestamptz default now(),
  primary key (guild_id, key));
create table if not exists public.kidneon_levels (
  guild_id text not null, user_id text not null, xp int not null default 0, level int not null default 0, guild_name text,
  primary key (guild_id, user_id));
create table if not exists public.kidneon_level_roles (
  guild_id text not null, level int not null, role_id text not null, guild_name text,
  primary key (guild_id, level));
create table if not exists public.kidneon_boosts (
  guild_id text not null, user_id text not null, count int not null default 0, guild_name text,
  primary key (guild_id, user_id));
create table if not exists public.kidneon_rooms (
  channel_id text primary key, guild_id text not null, owner_id text not null, kind text not null, guild_name text);
create table if not exists public.kidneon_role_info (
  guild_id text not null, role_id text not null, description text default '', hidden boolean default false, guild_name text,
  primary key (guild_id, role_id));
create table if not exists public.kidneon_tickets (
  channel_id text primary key, guild_id text not null, owner_id text not null, guild_name text);
create table if not exists public.kidneon_pending_roles (
  guild_id text not null, user_id text not null, role_id text not null, minutes int, due_at timestamptz not null, guild_name text,
  primary key (guild_id, user_id));

do $$ declare t text; begin
  foreach t in array array['kidneon_settings','kidneon_levels','kidneon_level_roles','kidneon_boosts','kidneon_rooms','kidneon_role_info','kidneon_tickets','kidneon_pending_roles'] loop
    execute format('alter table public.%I enable row level security', t);
    revoke all on public.kidneon_settings, public.kidneon_levels, public.kidneon_level_roles, public.kidneon_boosts, public.kidneon_rooms, public.kidneon_role_info, public.kidneon_tickets, public.kidneon_pending_roles from anon, authenticated;
  end loop;
end $$;
