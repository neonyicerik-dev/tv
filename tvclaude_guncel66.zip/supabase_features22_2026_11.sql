-- Yapay zeka video kontrolü: şüpheli videolar status='pending' + ai_reason ile admin listesine düşer
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS ai_reason text;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS ai_checked_at timestamptz;
CREATE INDEX IF NOT EXISTS videos_ai_unchecked_idx ON public.videos (created_at) WHERE is_user_upload AND ai_checked_at IS NULL;
-- Eski kayıtlarda NULL kalmış is_short değerlerini düzelt (anasayfa listesi için)
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS is_short boolean NOT NULL DEFAULT false;
UPDATE public.videos SET is_short = false WHERE is_short IS NULL;
-- Onay bekleyen kullanıcı videolarını yayına al (onay sistemi kalktı; AI işaretlileri hariç)
UPDATE public.videos SET status = 'published' WHERE status = 'pending' AND is_user_upload AND ai_reason IS NULL AND removed_at IS NULL;
