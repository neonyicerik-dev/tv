-- TEST SUNUCUSU için ayrı video tablosu (normal sitenin `videos` tablosuna dokunmaz).
-- Test sitesinin includes/secrets.php dosyasına:  putenv('VIDEOS_TABLE=videos_test');
CREATE TABLE IF NOT EXISTS public.videos_test (LIKE public.videos INCLUDING ALL);
ALTER TABLE public.videos_test ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='videos_test' AND policyname='videos_test_read') THEN
    CREATE POLICY videos_test_read ON public.videos_test FOR SELECT TO anon, authenticated USING (status = 'published');
  END IF;
END $$;
GRANT SELECT ON public.videos_test TO anon, authenticated;
GRANT ALL ON public.videos_test TO service_role;

-- Test tablosuna normal siteden SEÇTİĞİN videoları kopyala (aynı id'ler korunur; beğeni/yorum bağlantıları bozulmaz).
-- Örnek: etiketinde '+18' OLMAYANLARI kopyala (kendi ölçütünle değiştir):
-- INSERT INTO public.videos_test SELECT * FROM public.videos WHERE NOT ('+18' = ANY(tags)) ON CONFLICT (id) DO NOTHING;
