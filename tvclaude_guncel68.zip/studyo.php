<?php
// NeonTV - İçerik Üreticisi Stüdyosu: hesabı oluştur, geçici video yükle, videolarını ve izlenmelerini gör
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'İçerik Üreticisi Stüdyosu'; $metaDesc = 'Video yükle ve izlenmelerini takip et.'; $pageRobots = 'noindex,nofollow';
include __DIR__ . '/components/header.php';
?>
<style>
.st-card{background:#13131f;border:1px solid rgba(255,255,255,.08);border-radius:20px;padding:20px}
.st-in{width:100%;padding:10px 14px;border-radius:12px;background:rgba(0,0,0,.4);border:1px solid rgba(255,255,255,.12);color:#fff;font-size:14px;outline:none}
.st-in:focus{border-color:#00f5ff}.st-lb{display:block;font-size:11px;color:#8b8fa3;margin:10px 0 4px;font-weight:600}
.st-btn{padding:11px 22px;border-radius:12px;font-weight:800;font-size:14px;color:#000;background:linear-gradient(135deg,#00f5ff,#7df9ff);border:0;cursor:pointer}.st-btn:disabled{opacity:.5;cursor:default}
.st-pill{font-size:11px;font-weight:700;padding:2px 9px;border-radius:99px}
.st-row{display:flex;gap:12px;align-items:center;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.06)}
.st-th{width:112px;aspect-ratio:16/9;border-radius:10px;object-fit:cover;background:#0b0b14;flex:none}
</style>
<div class="max-w-3xl mx-auto px-4 sm:px-6 py-8" id="st-root">
  <h1 class="text-2xl font-bold text-white mb-1"><i class="fa-solid fa-clapperboard mr-2" style="color:#00f5ff"></i>İçerik Üreticisi Stüdyosu</h1>
  <p class="text-sm text-gray-400 mb-6">Videoların seçtiğin süre boyunca yayında kalır, süre dolunca siteden kaldırılır. İzlenme sayın profilinde durur.</p>
  <div id="st-msg" class="text-gray-500 text-sm py-10 text-center">Yükleniyor...</div>
  <div id="st-body" style="display:none"></div>
</div>
<script>
window.addEventListener('load', async function () {
  const BASE = <?= json_encode(APP_URL) ?>, CLOUD = <?= json_encode(CLOUDINARY_CLOUD_NAME) ?>, msg = document.getElementById('st-msg'), body = document.getElementById('st-body');
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let tok = null; try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}
  if (!tok) { msg.innerHTML = 'Bu sayfa için <a class="text-cyan-400 underline" href="' + BASE + '/auth.php">giriş yap</a>.'; return; }
  const H = { 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok };
  const api = (p, o) => fetch(BASE + '/api/' + p + (p.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(tok), Object.assign({ headers: Object.assign({ 'Content-Type': 'application/json' }, H) }, o || {})).then(r => r.json());
  const ST = { published: ['Yayında', '#22c55e'], pending: ['İncelemede', '#f59e0b'], rejected: ['Reddedildi', '#ef4444'], expired: ['Süresi doldu', '#9ca3af'], private: ['Gizli', '#9ca3af'], draft: ['Taslak', '#9ca3af'], scheduled: ['Zamanlandı', '#3b82f6'] };
  const left = e => { if (!e) return ''; const d = (new Date(e).getTime() - Date.now()) / 3600000; return d <= 0 ? 'süre doldu' : d < 48 ? Math.ceil(d) + ' saat kaldı' : Math.ceil(d / 24) + ' gün kaldı'; };
  let info = null;

  async function render() {
    const j = await api('creator.php'); if (!j.success) { msg.textContent = j.message || 'Hata'; return; } info = j.data; msg.style.display = 'none'; body.style.display = 'block';
    if (info.banned) { body.innerHTML = '<div class="st-card" style="color:#fca5a5">İçerik üreticisi hesabın kapatıldı. Bilgi için <a class="underline" href="' + BASE + '/iletisim.php">iletişime geç</a>.</div>'; return; }
    if (!info.is_creator) {
      body.innerHTML = '<div class="st-card"><h2 class="text-lg font-bold text-white mb-2">İçerik üreticisi ol</h2>' +
        '<p class="text-sm text-gray-300 mb-3">Hesabını içerik üreticisine çevirerek video yükleyebilirsin. Kendi kanalın otomatik açılır.</p>' +
        '<ul class="text-sm text-gray-400 mb-4" style="list-style:disc;padding-left:20px;line-height:1.7"><li>Her video, seçtiğin süre (24 saat – 30 gün) sonunda otomatik kaldırılır.</li><li>En fazla ' + info.limits.mb + ' MB ve ' + info.limits.minutes + ' dakikalık videolar yüklenebilir.</li><li>' + 'Videoların onay beklemeden hemen yayınlanır; yüklemeden sonra yapay zeka başlık ve karelerini kontrol eder, şüpheli görürse videoyu yönetici incelemesine alır.' + '</li></ul>' +
        '<label class="flex items-start gap-2 text-sm text-gray-300 mb-4"><input type="checkbox" id="st-acc" class="mt-1"><span><a class="text-cyan-400 underline" href="' + BASE + '/yasal.php?s=icerik-kurallari" target="_blank">Topluluk ve İçerik Kuralları</a>\'nı okudum, kabul ediyorum; yüklediğim içeriğin haklarına sahibim.</span></label>' +
        '<button class="st-btn" id="st-en">İçerik üreticisi hesabı oluştur</button> <span id="st-em" class="text-sm text-red-300 ml-2"></span></div>';
      document.getElementById('st-en').onclick = async function () {
        const em = document.getElementById('st-em'); em.textContent = '';
        if (!document.getElementById('st-acc').checked) { em.textContent = 'Kuralları kabul etmelisin.'; return; }
        this.disabled = true; const r = await api('creator.php', { method: 'POST', body: JSON.stringify({ action: 'enable', accept: true }) });
        if (r.success) render(); else { em.textContent = r.message || 'Hata'; this.disabled = false; }
      }; return;
    }
    const s = info.stats || {}, L = info.limits;
    body.innerHTML = '<div class="grid grid-cols-3 gap-3 mb-5">' + [['Toplam izlenme', (s.total_views || 0).toLocaleString('tr-TR')], ['Aktif video', (s.active || 0) + '/' + L.active], ['Toplam video', s.total_videos || 0]].map(x => '<div class="st-card text-center"><div class="text-2xl font-black text-white">' + x[1] + '</div><div class="text-[11px] text-gray-500">' + x[0] + '</div></div>').join('') + '</div>' +
      '<div class="st-card mb-5"><h2 class="text-lg font-bold text-white mb-1">Video yükle</h2><p class="text-[11px] text-gray-500 mb-2">MP4, MOV, WEBM · en fazla ' + L.mb + ' MB · en fazla ' + L.minutes + ' dk · günde ' + L.daily + ' video</p>' +
      '<label class="st-lb">Tür</label><select id="st-kind" class="st-in"><option value="video">Video (yatay/dikey, en fazla ' + L.minutes + ' dk)</option><option value="short">Net (dikey, en fazla ' + L.short_sec + ' sn) — Nets akışında yayınlanır</option></select>' +
      '<label class="st-lb">Video dosyası</label><input type="file" id="st-file" accept="video/mp4,video/quicktime,video/webm,.mp4,.mov,.webm,.m4v" class="st-in">' +
      '<label class="st-lb">Başlık</label><input id="st-title" maxlength="100" class="st-in" placeholder="Videonun başlığı">' +
      '<label class="st-lb">Açıklama (isteğe bağlı)</label><textarea id="st-desc" rows="3" maxlength="1000" class="st-in"></textarea>' +
      '<div class="grid grid-cols-2 gap-3"><div><label class="st-lb">Etiketler (virgülle, en çok 5)</label><input id="st-tags" class="st-in" placeholder="komedi, gündem"></div>' +
      '<div><label class="st-lb">Yayında kalma süresi</label><select id="st-days" class="st-in">' + Object.entries(info.days).map(([d, l]) => '<option value="' + d + '"' + (d == 7 ? ' selected' : '') + '>' + l + '</option>').join('') + '</select></div></div>' +
      '<div id="st-prog" style="display:none;margin-top:14px"><div style="height:8px;border-radius:99px;background:rgba(255,255,255,.1);overflow:hidden"><div id="st-bar" style="height:100%;width:0;background:linear-gradient(90deg,#00f5ff,#bf00ff);transition:width .2s"></div></div><div id="st-pt" class="text-xs text-gray-400 mt-1"></div></div>' +
      '<div class="mt-4"><button class="st-btn" id="st-up">Yükle ve yayınla</button> <span id="st-um" class="text-sm ml-2"></span></div></div>' +
      '<div class="st-card mb-5"><h2 class="text-lg font-bold text-white mb-1">Videolarım</h2><div id="st-list" class="text-sm text-gray-500">Yükleniyor…</div></div>' +
      '<div class="st-card" id="gonderi"><h2 class="text-lg font-bold text-white mb-1">Circ paylaş</h2><p class="text-[11px] text-gray-500 mb-2">Metin ve isteğe bağlı resim · günde ' + L.post_daily + ' Circ · <a class="text-cyan-400 underline" href="' + BASE + '/gonderiler.php">Circs sayfası</a></p>' +
      '<textarea id="po-body" rows="3" maxlength="1000" class="st-in" placeholder="Takipçilerine bir şey söyle…"></textarea>' +
      '<label class="st-lb">Resim (isteğe bağlı, en çok 5 MB)</label><input type="file" id="po-img" accept="image/jpeg,image/png,image/webp,image/gif" class="st-in">' +
      '<div class="mt-3"><button class="st-btn" id="po-send">Paylaş</button> <span id="po-m" class="text-sm ml-2"></span></div>' +
      '<div id="po-list" class="mt-4 text-sm text-gray-500"></div></div>';
    document.getElementById('st-up').onclick = upload; document.getElementById('po-send').onclick = sendPost; loadList(); loadPosts();
  }

  async function loadList() {
    const j = await api('creator_videos.php'), el = document.getElementById('st-list'); if (!j.success) { el.textContent = j.message || 'Hata'; return; }
    const it = j.data.items; if (!it.length) { el.textContent = 'Henüz video yüklemedin.'; return; }
    el.innerHTML = it.map(v => { const st = ST[v.status] || [v.status, '#9ca3af'], gone = v.status === 'expired';
      return '<div class="st-row"><img class="st-th" src="' + esc(gone ? '' : v.thumbnail_url) + '" alt="" onerror="this.style.visibility=\'hidden\'"><div style="min-width:0;flex:1"><div class="text-white font-semibold truncate">' + esc(v.title) + '</div>' +
        '<div class="text-xs text-gray-400 mt-0.5"><span class="st-pill" style="background:' + st[1] + '22;color:' + st[1] + '">' + st[0] + '</span> · ' + (v.views || 0).toLocaleString('tr-TR') + ' izlenme' + (!gone && v.expires_at ? ' · ' + left(v.expires_at) : '') + '</div>' +
        (v.status === 'rejected' && v.reject_reason ? '<div class="text-xs text-red-300 mt-0.5">Sebep: ' + esc(v.reject_reason) + '</div>' : '') + (v.status === 'pending' ? '<div class="text-xs text-amber-300 mt-0.5">Otomatik kontrolde şüpheli bulundu, yönetici inceliyor.</div>' : '') + '</div>' +
        (v.status === 'published' ? '<a class="text-cyan-400 text-xs underline" href="' + BASE + (v.is_short ? '/shorts.php?v=' : '/video.php?id=') + v.id + '">Aç</a>' : '') +
        (!gone ? '<button class="text-red-400 text-xs" data-del="' + v.id + '">Kaldır</button>' : '') + '</div>'; }).join('');
    el.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { if (!confirm('Video hemen kaldırılsın mı? Bu geri alınamaz; izlenme sayın kalır.')) return; await api('creator_videos.php?id=' + b.dataset.del, { method: 'DELETE' }); render(); });
  }

  // Yapay zeka kontrolü için 5 kare: ilk 5 sn'den 2, ortadan 1, son 5 sn'den 2
  async function grabFrames(f) {
    const u = URL.createObjectURL(f), v = document.createElement('video'); v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = u;
    try {
      await new Promise((res, rej) => { v.onloadedmetadata = res; v.onerror = rej; setTimeout(rej, 15000); });
      const d = isFinite(v.duration) && v.duration > 0 ? v.duration : 10, ts = [Math.min(1, d / 4), Math.min(3.5, d / 2), d / 2, Math.max(d - 3.5, d / 2), Math.max(d - 1, 0.5)], out = [];
      const c = document.createElement('canvas'), k = Math.min(1, 640 / (v.videoWidth || 640)); c.width = Math.round((v.videoWidth || 640) * k); c.height = Math.round((v.videoHeight || 360) * k);
      for (const t of ts) {
        try {
          await new Promise((res, rej) => { v.onseeked = res; v.onerror = rej; setTimeout(res, 6000); v.currentTime = Math.min(t, Math.max(0, d - 0.1)); });
          c.getContext('2d').drawImage(v, 0, 0, c.width, c.height); const j = c.toDataURL('image/jpeg', 0.7); if (j.length > 2000) out.push(j);
        } catch (e) {}
      }
      return out;
    } catch (e) { return []; } finally { URL.revokeObjectURL(u); }
  }

  async function upload() {
    const f = document.getElementById('st-file').files[0], um = document.getElementById('st-um'), btn = document.getElementById('st-up');
    const title = document.getElementById('st-title').value.trim(), kind = document.getElementById('st-kind').value, days = +document.getElementById('st-days').value; um.style.color = '#fca5a5'; um.textContent = '';
    if (!f) { um.textContent = 'Bir video seç.'; return; } if (title.length < 3) { um.textContent = 'Başlık en az 3 karakter olmalı.'; return; }
    if (f.size > info.limits.mb * 1048576) { um.textContent = 'Dosya ' + info.limits.mb + ' MB sınırını aşıyor.'; return; }
    btn.disabled = true; document.getElementById('st-prog').style.display = 'block'; const bar = document.getElementById('st-bar'), pt = document.getElementById('st-pt');
    try {
      const meta = await new Promise(res => { const v = document.createElement('video'), u = URL.createObjectURL(f); v.preload = 'metadata'; v.onloadedmetadata = () => { res({ d: v.duration, w: v.videoWidth, h: v.videoHeight }); URL.revokeObjectURL(u); }; v.onerror = () => { res(null); URL.revokeObjectURL(u); }; v.src = u; });
      if (meta && isFinite(meta.d)) {
        if (kind === 'short' && meta.d > info.limits.short_sec + 1) throw new Error('Net en fazla ' + info.limits.short_sec + ' saniye olabilir.');
        if (kind === 'short' && meta.w > meta.h * 1.05) throw new Error('Net dikey (veya kare) olmalı.');
        if (kind === 'video' && meta.d > info.limits.minutes * 60 + 1) throw new Error('Video en fazla ' + info.limits.minutes + ' dakika olabilir.');
      }
      const sg = await api('creator_sign.php?kind=' + kind + '&days=' + days); if (sg.error || sg.success === false) throw new Error(sg.message || 'İmza alınamadı');
      const base = { title: title, description: document.getElementById('st-desc').value, tags: document.getElementById('st-tags').value, days: days, kind: kind };
      let body;
      if (sg.cdn) {                                   // tarayıcı -> kendi CDN'imiz (parçalı, devam edebilir)
        const cx = (a, o, raw) => fetch(sg.endpoint + '?a=' + a, Object.assign({ method: 'POST', headers: Object.assign({ 'X-Up-Token': sg.token }, raw ? {} : { 'Content-Type': 'application/json' }) }, o)).then(r => r.json());
        const ini = await cx('init', { body: JSON.stringify({ filename: f.name, size: f.size }) }); if (!ini.upload_id) throw new Error(ini.error || 'CDN yüklemesi başlatılamadı');
        const CH = Math.min(ini.chunk || 8388608, 8388608); let off = 0, fail = 0;
        while (off < f.size) {
          const end = Math.min(off + CH, f.size); pt.textContent = 'Yükleniyor… ' + Math.round(off / f.size * 100) + '%'; bar.style.width = Math.round(off / f.size * 95) + '%';
          let r; try { r = await fetch(sg.endpoint + '?a=chunk&id=' + ini.upload_id + '&offset=' + off, { method: 'POST', headers: { 'X-Up-Token': sg.token, 'Content-Type': 'application/octet-stream' }, body: f.slice(off, end) }).then(x => x.json()); } catch (e) { r = { error: 'ağ' }; }
          if (r.offset !== undefined && r.ok !== false) { off = r.offset; fail = 0; } else if (r.offset !== undefined) { off = r.offset; } else { if (++fail > 4) throw new Error(r.error || 'Yükleme kesildi'); await new Promise(z => setTimeout(z, 1500 * fail)); }
        }
        pt.textContent = 'İşleniyor…'; bar.style.width = '97%';
        const fin = await cx('finish', { body: JSON.stringify({ id: ini.upload_id }) }); if (!fin.url) throw new Error(fin.error || 'Video işlenemedi');
        body = Object.assign(base, { cdn_url: fin.url, thumb_url: fin.thumb, duration: fin.duration || Math.round(meta && meta.d || 0) });
      } else {                                         // yedek: Cloudinary
        const CH = 6 * 1048576, n = Math.max(1, Math.ceil(f.size / CH)), uid = 'ntu_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10); let res = null;
        for (let i = 0; i < n; i++) {
          const a = i * CH, b = Math.min(a + CH, f.size), fd = new FormData();
          fd.append('file', f.slice(a, b)); fd.append('timestamp', sg.timestamp); fd.append('signature', sg.signature); fd.append('api_key', sg.api_key); fd.append('folder', sg.folder); fd.append('allowed_formats', sg.allowed_formats);
          pt.textContent = 'Yükleniyor… ' + Math.round(i / n * 100) + '%'; bar.style.width = Math.round(i / n * 95) + '%';
          const r = await (await fetch('https://api.cloudinary.com/v1_1/' + CLOUD + '/video/upload', { method: 'POST', headers: { 'X-Unique-Upload-Id': uid, 'Content-Range': 'bytes ' + a + '-' + (b - 1) + '/' + f.size }, body: fd })).json();
          if (r.error) throw new Error(r.error.message || 'Yükleme hatası'); if (r.secure_url) res = r;
        }
        if (!res) throw new Error('Video adresi alınamadı'); body = Object.assign(base, { video_url: res.secure_url, cloudinary_public_id: res.public_id, duration: Math.round(res.duration || 0) });
      }
      bar.style.width = '98%'; pt.textContent = 'Kaydediliyor…';
      const sv = await api('creator_videos.php', { method: 'POST', body: JSON.stringify(body) });
      if (!sv.success) throw new Error(sv.message || 'Kaydedilemedi');
      bar.style.width = '99%'; pt.textContent = 'İçerik kontrol ediliyor…';
      let msgTxt = sv.message || 'Tamam', flagged = false;
      try {
        const fr = await grabFrames(f), mr = await api('creator_moderate.php', { method: 'POST', body: JSON.stringify({ id: sv.data.id, frames: fr }) });
        if (mr.success && mr.data && mr.data.flagged) { flagged = true; msgTxt = mr.message; }
      } catch (e) {}
      bar.style.width = '100%'; pt.textContent = ''; um.style.color = flagged ? '#fbbf24' : '#4ade80'; um.textContent = flagged ? msgTxt : 'Videon yayında!'; setTimeout(render, flagged ? 3500 : 1200);
    } catch (e) { um.textContent = e.message || 'Hata'; btn.disabled = false; document.getElementById('st-prog').style.display = 'none'; }
  }

  async function sendPost() {
    const m = document.getElementById('po-m'), btn = document.getElementById('po-send'), body = document.getElementById('po-body').value.trim(), f = document.getElementById('po-img').files[0]; m.style.color = '#fca5a5'; m.textContent = '';
    if (!body && !f) { m.textContent = 'Bir şeyler yaz veya resim ekle.'; return; } btn.disabled = true;
    try {
      let img = '';
      if (f) { const fd = new FormData(); fd.append('image', f); const r = await (await fetch(BASE + '/api/post_image.php', { method: 'POST', headers: H, body: fd })).json(); if (!r.success) throw new Error(r.message || 'Resim yüklenemedi'); img = r.data.url; }
      const r = await api('posts.php', { method: 'POST', body: JSON.stringify({ action: 'create', body: body, image_url: img }) }); if (!r.success) throw new Error(r.message || 'Paylaşılamadı');
      document.getElementById('po-body').value = ''; document.getElementById('po-img').value = ''; m.style.color = '#4ade80'; m.textContent = r.message || 'Paylaşıldı'; loadPosts();
    } catch (e) { m.textContent = e.message || 'Hata'; } btn.disabled = false;
  }
  async function loadPosts() {
    const el = document.getElementById('po-list'); if (!el) return; const r = await api('posts.php?limit=20&author=' + info.uid); const it = (r.data && r.data.items) || [];
    el.innerHTML = it.length ? it.map(p => '<div class="st-row"><div style="flex:1;min-width:0" class="text-gray-300">' + esc((p.body || '(resim)').slice(0, 90)) + '<div class="text-[11px] text-gray-500">' + (p.likes_count || 0) + ' beğeni</div></div><button class="text-red-400 text-xs" data-pd="' + p.id + '">Sil</button></div>').join('') : 'Henüz hiç Circ yok.';
    el.querySelectorAll('[data-pd]').forEach(b => b.onclick = async () => { if (!confirm('Circ silinsin mi?')) return; await api('posts.php?id=' + b.dataset.pd, { method: 'DELETE' }); loadPosts(); });
  }
  render();
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
