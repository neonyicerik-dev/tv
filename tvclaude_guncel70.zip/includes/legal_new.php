<?php
// ============================================================
// NeonTV - Kullanım Koşulları ve Gizlilik Politikası (Türkçe + İngilizce)
// Genel şablondur; yayına almadan önce bir hukukçuya gösterilmesi önerilir.
// Yer tutucular: {{SELLER}} firma tablosu, {{EMAIL}} iletişim e-postası, {{VERSION}}, {{PRICE}}, {{DAYS}}, {{URL}}
// ============================================================
const LEGAL_CONTACT_EMAIL = 'destek@neont.cu.ma';

function legalNewDocs(string $lang, string $sellerHtml, int $price, int $days): array {
    $d = [];
    $d['tr'] = [];
    $d['en'] = [];

    // ================= TÜRKÇE — KULLANIM KOŞULLARI =================
    $d['tr']['kullanim-kosullari'] = ['Kullanım Koşulları', <<<'T'
<p class="text-xs text-gray-500">Yürürlük ve son güncelleme: 28 Kasım 2026 · Sürüm {{VERSION}}</p>
<h2>1. Sözleşme ve hizmet sağlayıcı</h2>
<p>Bu Koşullar; NeonTV web sitesinin, hesabınızın ve sitede sunulan video, Flicks, Net ve Circ paylaşımı, yorum, token/Premium, bildirim, yapay zekâ özellikleri ve NeonTV Discord topluluğunun (birlikte “Hizmet”) kullanımını düzenler. Hizmeti aşağıdaki kişi işletir (“NeonTV”, “biz”):</p>
{{SELLER}}
<p>Hesap oluşturarak, giriş yaparak veya Hizmeti kullanarak bu Koşulları kabul etmiş ve <a href="{{URL}}/yasal.php?s=gizlilik&lang=tr">Gizlilik Politikası</a>'nı okuduğunuzu onaylamış olursunuz. Kabul etmiyorsanız Hizmeti kullanmayın.</p>

<h2>2. Yaş sınırı</h2>
<p>Hizmeti yalnızca 13 yaşını doldurmuş kişiler kullanabilir; bulunduğunuz yerde daha yüksek bir yaş sınırı varsa o geçerlidir. 18 yaşından küçükler, içerik üreticisi hesabı için ebeveyn veya vasisinin izniyle hareket etmelidir ve ebeveyn/vasi kullanımdan sorumludur. Hizmet, uygun yaşın altındaki çocuklara yönelik değildir; uygun olmayan yaşta bir kullanıcı tespit edersek hesabı kapatabilir ve ilgili kişisel verileri silebiliriz.</p>

<h2>3. Hesap ve güvenlik</h2>
<p>Üyelik için e-posta adresi, kullanıcı adı ve şifre kullanılır. Hesap bilgilerinizin doğruluğundan, şifrenizin ve oturumlarınızın güvenliğinden siz sorumlusunuz. Yetkisiz erişim şüphesini hemen {{EMAIL}} adresine bildirin. Hesaplar satılamaz, devredilemez, herkese açık paylaşılamaz veya kısıtlamaları aşmak için kullanılamaz. İsteğe bağlı olarak hesabınıza Discord hesabınızı bağlayabilirsiniz; bağlantıyı profilinizden istediğiniz an kaldırabilirsiniz.</p>

<h2>4. Hizmet</h2>
<p>NeonTV'de videolar izleyebilir, yorum yapabilir, puan verebilir, listeler oluşturabilir ve içerik üreticisi hesabı açarak üç tür içerik paylaşabilirsiniz: <b>Flicks</b> (yatay/uzun videolar), <b>Nets</b> (dikey kısa videolar) ve <b>Circs</b> (metin ve resim paylaşımları). Hizmet ücretsizdir; bazı özellikler token veya Premium gerektirir (bölüm 6). Özellikler, limitler (dosya boyutu, süre, günlük paylaşım sayısı) ve kotalar zamanla değişebilir. Gösterilen bir limit azami miktardır, sürekli performans veya erişim vaadi değildir.</p>

<h2>5. İçerik üreticileri ve kullanıcı içerikleri</h2>
<ul>
<li><b>Mülkiyet.</b> Yüklediğiniz içeriğin hakları size aittir. NeonTV'ye yalnızca içeriği Hizmeti çalıştırmak, güvenliğini sağlamak ve göstermek için gerektiği ölçüde saklama, kopyalama, boyutlandırma, önbelleğe alma ve yayınlama konusunda sınırlı, münhasır olmayan bir lisans verirsiniz.</li>
<li><b>Haklar.</b> İçeriği yayınlamak için gerekli tüm haklara sahip olduğunuzu; üçüncü kişilerin telif, kişilik ve gizlilik haklarını ihlal etmediğinizi kabul edersiniz.</li>
<li><b>Geçici yayın.</b> Flicks ve Nets, yükleme sırasında seçtiğiniz süre (24 saat – 30 gün) sonunda siteden ve içerik sunucusundan otomatik silinir. İzlenme gibi toplu istatistikler kayıtlarda kalır. Circs, siz silene veya hesabınız silinene kadar yayında kalır. Hizmeti tek yedeğiniz olarak kullanmayın.</li>
<li><b>Onaysız yayın ve otomatik kontrol.</b> Flicks ve Nets önceden onay beklemeden yayınlanır. Yükleme sonrası otomatik sistemler başlığı, açıklamayı ve videodan alınan birkaç ekran görüntüsünü (başlangıç, orta ve bitiş bölümlerinden) güvenlik açısından kontrol eder. Şüpheli bulunan içerik yayından kaldırılıp yönetici incelemesine alınabilir; yönetici içeriği yayına geri alabilir veya silebilir. Otomatik kontrol hatasız değildir; karar için insan incelemesi talep edebilirsiniz ({{EMAIL}}).</li>
<li><b>Bildirim ve kaldırma.</b> Kurallara aykırı içeriği video altındaki şikayet düğmesi veya {{EMAIL}} ile bildirebilirsiniz. İçerik bildirim üzerine veya kendiliğinden kaldırılabilir; tekrarlayan ihlallerde içerik üreticisi hesabı kapatılır. Ayrıntılar için <a href="{{URL}}/yasal.php?s=icerik-kurallari">Topluluk ve İçerik Kuralları</a>.</li>
</ul>

<h2>6. Token ve Premium</h2>
<p>Token; reklam izleyerek veya görevlerle kazanılan sanal bir puandır. <b>Parasal karşılığı yoktur</b>, nakde çevrilemez ve zorunlu tüketici mevzuatı aksini gerektirmedikçe iade edilemez veya hesaplar arasında devredilemez (Premium hediyesi hariç). Premium şu an <b>{{PRICE}} token</b> karşılığında <b>{{DAYS}} gün</b> sürelidir; güncel fiyat ve indirimler Mağaza sayfasında gösterilir. Gizli ücret yoktur. Kuralları ihlal ederek (bot, otomasyon, çoklu hesap vb.) kazanılan tokenler ve Premium iptal edilebilir. Ayrıntılar: <a href="{{URL}}/yasal.php?s=iade">14 Gün İade Politikası</a>.</p>

<h2>7. Kabul edilebilir kullanım</h2>
<p>Hizmeti kullanarak veya başkalarının kullanmasına yardım ederek şunları yapamazsınız:</p>
<ul>
<li>yasaları, telif, gizlilik, kişilik veya sözleşmeden doğan hakları ihlal etmek;</li>
<li>cinsel içerik, çocukları istismar eden veya riske atan içerik, şiddet, terör, nefret, taciz veya yasa dışı faaliyetleri özendiren içerik paylaşmak;</li>
<li>kötü amaçlı yazılım, kimlik avı sayfaları, spam veya yanıltıcı başlık/kapak yaymak;</li>
<li>Hizmete saldırmak, güvenlik açığı aramak (önceden yazılı izin olmadan), aşırı otomatik istek göndermek, başkalarının hesaplarına yetkisiz erişmek;</li>
<li>bot, otomasyon, sahte hesap veya hile ile token kazanmak, sahte yorum/puan/beğeni/izlenme üretmek, ödül karşılığı yorum yazdırmak;</li>
<li>başkasını taklit etmek, kısıtlamaları veya askıyı aşmak, izleme ve güvenlik kontrollerine müdahale etmek.</li>
</ul>
<p>Şüpheli kötüye kullanımı inceleyebilir ve gerekirse yetkili makamlarla iş birliği yapabiliriz.</p>

<h2>8. Discord topluluğu ve botlar</h2>
<p>NeonTV Discord sunucusunda; karşılama, seviye, doğrulama, ticket, öneri/şikayet, yapay zekâ sohbet ve yönetim (moderasyon) botları çalışabilir. Sunucudaki kurallara uymak zorundasınız. Bota yazdığınız mesajlar yanıt üretmek için yapay zekâ sağlayıcısına gönderilebilir; botlara şifre, ödeme bilgisi veya başka gizli bilgi yazmayın. Hesap bağlama, yalnızca kendi hesap bilgilerinizi bot üzerinden görmenizi sağlar. Yetkililer, bota verilen yönetim yetkileriyle (ör. kullanıcıyı kısıtlama, token/Premium verme) işlem yapabilir ve bu işlemler denetim amacıyla kaydedilir.</p>

<h2>9. Bir kişi, bir hesap</h2>
<p>Ödüller ve limitler kişi başına geçerlidir. Sınırları, askıyı, oyları, ödülleri veya token kazanımını aşmak için ek hesap açamaz veya kullanamazsınız. Şüpheli durumlarda otomatik sistemler hesapları ilişkilendirebilir; kararlar sonuçlanmadan kısıtlama yapılmaz, itirazlarınız {{EMAIL}} üzerinden bir kişi tarafından incelenir.</p>

<h2>10. Askıya alma ve sonlandırma</h2>
<p>Hizmeti dilediğiniz an bırakabilir, hesabınızı Profilim → Hesabı sil bölümünden kalıcı olarak silebilirsiniz. Güvenlik, kötüye kullanımın önlenmesi, hukuki yükümlülük, tekrarlayan ihlaller veya altyapının korunması için erişimi kısıtlayabilir, askıya alabilir veya sonlandırabiliriz. Mümkün ve güvenli olduğunda önceden bildirim yaparız; acil durumlarda bildirimsiz işlem yapılabilir. Hesap veya içerik silindiğinde ilişkili veriler geri döndürülemez biçimde silinebilir.</p>

<h2>11. Süreklilik, değişiklikler ve yedekler</h2>
<p>Hizmet “olduğu gibi” ve “mevcut haliyle” sunulur. Kesintisiz, hatasız veya belirli bir performansta çalışacağını, içeriklerin süresiz saklanacağını taahhüt etmeyiz. Bakım, arıza, üçüncü taraf kesintileri ve güvenlik olayları erişimi etkileyebilir. İçerik yedeklerinizi kendiniz alın.</p>

<h2>12. Garanti ve sorumluluk</h2>
<p>Hizmet, yasaların izin verdiği azami ölçüde açık veya zımni garanti olmaksızın sunulur. Yasaların izin verdiği ölçüde dolaylı, arızi, sonuç olarak doğan zararlardan, veri, kâr veya itibar kaybından sorumlu değiliz. Zorunlu tüketici hakları, kast ve ağır kusurdan doğan sorumluluk gibi yasal olarak sınırlanamayacak haklarınız saklıdır.</p>

<h2>13. Uygulanacak hukuk ve uyuşmazlıklar</h2>
<p>Bu Koşullara Türk hukuku uygulanır. Resmî başvurudan önce {{EMAIL}} adresinden bize ulaşmanızı rica ederiz. Tüketici işlemlerinde Tüketici Hakem Heyetleri ve Tüketici Mahkemeleri, diğer uyuşmazlıklarda Türkiye mahkemeleri ve icra daireleri yetkilidir; zorunlu tüketici koruma hükümleri saklıdır.</p>

<h2>14. Koşullardaki değişiklikler</h2>
<p>Hizmet, mevzuat veya uygulamalarımız değiştikçe bu Koşulları güncelleyebiliriz. Yeni sürümü ve yürürlük tarihini burada yayımlarız; önemli değişiklikleri sitede duyururuz. Değişiklik sonrası Hizmeti kullanmaya devam etmek güncel Koşulları kabul ettiğiniz anlamına gelir. Katılmıyorsanız Hizmeti kullanmayı bırakın. Bir hüküm uygulanamaz bulunursa yalnızca gerekli ölçüde sınırlanır, diğer hükümler geçerliliğini korur.</p>

<h2>15. İletişim</h2>
<p>Hukuki bildirimler, telif/içerik kaldırma, kötüye kullanım bildirimi, hesap güvenliği, gizlilik ve diğer tüm konular için: <b>{{EMAIL}}</b>. Bu adrese kişisel bilgi veya şifre yazmayın.</p>
T];

    // ================= TÜRKÇE — GİZLİLİK POLİTİKASI =================
    $d['tr']['gizlilik'] = ['Gizlilik Politikası', <<<'T'
<p class="text-xs text-gray-500">Yürürlük ve son güncelleme: 28 Kasım 2026 · Sürüm {{VERSION}}</p>
<p>Bu Politika, hangi kişisel verileri neden işlediğimizi özetler. KVKK kapsamındaki ayrıntılı bilgi için <a href="{{URL}}/yasal.php?s=kvkk">KVKK Aydınlatma Metni</a>'ne de bakın.</p>
<h2>1. Veri sorumlusu</h2>
{{SELLER}}
<p>Gizlilik soruları ve veri talepleri için: <b>{{EMAIL}}</b>. Bu adrese şifre veya kişisel bilgi yazmayın.</p>

<h2>2. Kapsam</h2>
<p>Bu Politika; NeonTV sitesini ziyaret ettiğinizde, hesap oluşturduğunuzda, içerik izlediğinizde veya paylaştığınızda, Discord hesabınızı bağladığınızda ve bizimle iletişime geçtiğinizde geçerlidir. Üçüncü tarafların hizmetleri kendi politikalarına tabidir. Kişisel verilerinizi <b>satmayız</b> ve pazarlama amacıyla üçüncü kişilerle paylaşmayız. Kredi kartı veya banka bilgisi toplamayız (Premium yalnızca token ile alınır).</p>

<h2>3. Topladığımız veriler</h2>
<h3>Sizin verdikleriniz</h3>
<ul>
<li>Hesap: e-posta adresi, kullanıcı adı, şifre (yalnızca geri döndürülemez özet olarak), isteğe bağlı profil fotoğrafı, kapak ve biyografi.</li>
<li>Kullanım: izleme geçmişi, daha sonra izle listesi, yorum, puan, beğeni, takip, abonelik, oynatma listeleri, token hareketleri, Premium durumu ve bildirim tercihleri.</li>
<li>İçerik üreticileri: yüklediğiniz Flicks, Nets ve Circs; kapak görseli, başlık, açıklama, etiket, süre ayarı, izlenme ve beğeni sayıları.</li>
<li>İletişim: iletişim formuna veya e-postayla bize yazdığınız ad, e-posta ve mesaj.</li>
</ul>
<h3>Discord'dan gelenler</h3>
<p>Discord hesabınızı bağlarsanız yalnızca Discord kullanıcı kimliğinizi (ID) ve bağlantı zamanını saklarız. Bağlantı, 10 dakika geçerli tek kullanımlık bir kodla yapılır. Discord topluluk botları sunucudaki seviye/XP, rol, boost ve ticket kayıtlarını Discord kullanıcı kimliğine bağlı tutar.</p>
<h3>Otomatik toplananlar</h3>
<ul>
<li>IP adresinin tek yönlü özeti (hash), ülke bilgisi, tarayıcı/cihaz bilgisi ve yönlendiren sayfa; güvenlik ve kötüye kullanımı önleme amaçlıdır. Şehir ve servis sağlayıcı gibi gereksiz bilgileri tutmayız.</li>
<li>Oturum, çerez ve tarayıcı depolaması (bölüm 8) ile hata ve performans kayıtları.</li>
<li>Tarayıcı bildirimine izin verirseniz bildirim uç noktası bilgisi.</li>
</ul>
<h3>Yapay zekâ kullanımı</h3>
<ul>
<li><b>İçerik güvenliği kontrolü:</b> Flicks/Nets yüklendiğinde başlık, açıklama ve videodan alınan birkaç ekran görüntüsü, otomatik güvenlik kontrolü için Google Gemini'ye gönderilir. Şüpheli bulunan içerik yönetici incelemesine alınır.</li>
<li><b>Altyazı ve özet:</b> Yapay zekâ altyazı/özet özelliklerinde video sesi veya metni işlenir.</li>
<li><b>Sohbet ve asistanlar:</b> Site asistanına ve Discord botlarına yazdığınız mesajlar yanıt üretmek için yapay zekâ sağlayıcısına gönderilir. Bu mesajlara şifre, ödeme bilgisi veya başka gizli bilgi yazmayın.</li>
</ul>

<h2>4. İşleme amaçları ve hukuki sebepler</h2>
<ul>
<li>Üyelik, hizmetin sunulması, içerik yayınlama, token/Premium işlemleri, destek — <b>sözleşmenin ifası</b> (KVKK m.5/2-c).</li>
<li>Güvenlik, bot/sahte hesap/token suistimalinin önlenmesi, otomatik içerik kontrolü, hata ayıklama, hizmetin işletilmesi — <b>meşru menfaat</b> (m.5/2-f).</li>
<li>Mevzuat yükümlülükleri ve yetkili makam talepleri — <b>hukuki yükümlülük</b> (m.5/2-ç).</li>
<li>Tarayıcı bildirimi, isteğe bağlı tercihler ve Discord hesabı bağlama — <b>açık rıza</b> (m.5/1). Rızanızı dilediğiniz an geri çekebilirsiniz.</li>
</ul>

<h2>5. Verilerin aktarıldığı taraflar</h2>
<p>Verileriniz yalnızca hizmetin sağlanması için gerektiği ölçüde şu hizmet sağlayıcılarla paylaşılabilir:</p>
<ul>
<li><b>Supabase:</b> veritabanı ve kimlik doğrulama.</li>
<li><b>Cloudinary ve kendi CDN sunucumuz, Cloudflare:</b> görsel/video barındırma, dağıtım ve ağ güvenliği.</li>
<li><b>Google (Gemini):</b> yapay zekâ içerik kontrolü, altyazı, özet ve asistan yanıtları.</li>
<li><b>Giphy:</b> GIF arama (yalnızca arama sözcüğü).</li>
<li><b>Discord:</b> topluluk sunucusu ve botlar.</li>
<li><b>Google Fonts, cdnjs, jsDelivr:</b> yazı tipi, simge ve betikler (tarayıcınız bu sunuculara bağlanabilir ve IP adresiniz görünür).</li>
<li>Yetkili yönetici ve destek personeli; yalnızca görevleri için gereken ölçüde.</li>
<li>Hukuka uygun ve gerekli olduğunda yetkili makamlar, mahkemeler, danışmanlar.</li>
</ul>
<p>Kurallara aykırı bulunan içerik ve hesaplar hakkında, kişisel verilerinizi, şifrelerinizi veya gizli bilgilerinizi paylaşmadan topluluk içinde genel bilgi verebiliriz.</p>

<h2>6. Yurt dışına aktarım</h2>
<p>Yukarıdaki sağlayıcıların bir kısmı verileri Türkiye dışında işleyebilir. Aktarımlar, KVKK m.9 uyarınca yeterli koruma kararı, uygun taahhütler veya açık rıza gibi hukuka uygun mekanizmalara dayanır.</p>

<h2>7. Saklama süreleri</h2>
<ul>
<li>Hesap verileri, geçmiş, token/Premium kayıtları: hesap silinene kadar (yasal saklama zorunluluğu varsa o süre boyunca).</li>
<li>Flicks ve Nets: seçtiğiniz yayın süresi sonunda silinir; yönetici incelemesindeki içerik incelemenin sonucuna kadar saklanır.</li>
<li>Ziyaret/güvenlik kayıtları: en fazla 90 gün.</li>
<li>İletişim mesajları: talebin sonuçlanmasından sonra en fazla 2 yıl.</li>
<li>Discord bot kayıtları: sunucuda bulundukça ya da siz silinmesini isteyene kadar; kısa süreli sohbet hafızası dakikalar/günlerle sınırlıdır.</li>
</ul>
<p>Güvenlik, uyuşmazlık veya yasal yükümlülük gerektirdiğinde sınırlı bilgiyi daha uzun tutabiliriz. Veriler kimliğinizi belirleyemeyecek şekilde anonimleştirilebilir.</p>

<h2>8. Çerezler ve yerel depolama</h2>
<p>Zorunlu oturum/giriş, CSRF güvenliği ve tercihler (ör. oynatma hızı, ses, otomatik oynat, çerez tercihi) için çerez ve localStorage kullanırız. Reklam, profil çıkarma veya üçüncü taraf analiz çerezi kullanmayız; ileride eklenirse önce açık rızanız istenir. Ayrıntı: <a href="{{URL}}/yasal.php?s=cerez">Çerez Politikası</a>. Tarayıcı ayarlarından depolamayı silebilirsiniz; zorunlu çerezleri engellemek girişi engeller.</p>

<h2>9. Güvenlik</h2>
<p>TLS (HTTPS), şifre özetleme, yetkilendirme ve erişim kısıtları, hız sınırları ve kayıt tutma gibi önlemler kullanırız. Hiçbir sistem tamamen güvenli değildir; güçlü bir şifre kullanın ve şüpheli durumları bize bildirin.</p>

<h2>10. Haklarınız (KVKK m.11)</h2>
<p>Verilerinizin işlenip işlenmediğini öğrenme, bilgi talep etme, amacına uygun kullanılıp kullanılmadığını öğrenme, aktarıldığı kişileri bilme, düzeltme, silme/yok etme, işlemeye itiraz etme ve zarar halinde tazminat talep etme haklarına sahipsiniz. Verilerinizi Profilim sayfasından indirebilir, hesabınızı kalıcı olarak silebilirsiniz (<a href="{{URL}}/yasal.php?s=veri-silme">Veri Silme Talebi</a>). Başvurular için {{EMAIL}}; en geç 30 gün içinde yanıtlanır. Kişisel Verileri Koruma Kurumu'na şikâyet hakkınız saklıdır. Otomatik içerik kontrolü sonucuna itiraz ederseniz bir kişi yeniden inceler.</p>

<h2>11. Çocuklar</h2>
<p>Hizmet 13 yaşın altındakilere yönelik değildir. Uygun yaşın altındaki bir çocuktan bilerek veri toplamayız; böyle bir durumdan haberdar olan ebeveyn/vasi {{EMAIL}} adresine yazarsa gerekli incelemeyi yapıp uygun olduğunda veriyi sileriz.</p>

<h2>12. Politikadaki değişiklikler</h2>
<p>Hizmet, sağlayıcılar veya mevzuat değiştikçe bu Politikayı güncelleyebiliriz. Güncel sürümü ve tarihini burada yayımlarız; önemli değişiklikler sitede duyurulur.</p>

<h2>13. İletişim</h2>
<p>Gizlilik, KVKK ve diğer hukuki konular için: <b>{{EMAIL}}</b>.</p>
T];

    // ================= ENGLISH — TERMS OF SERVICE =================
    $d['en']['kullanim-kosullari'] = ['Terms of Service', <<<'T'
<p class="text-xs text-gray-500">Effective and last updated: 28 November 2026 · Version {{VERSION}}</p>
<h2>1. Agreement and operator</h2>
<p>These Terms govern your use of the NeonTV website, your account, and the services offered with it: video watching, Flicks, Nets and Circs posting, comments, tokens/Premium, notifications, AI features, and the NeonTV Discord community (together, the “Service”). The Service is operated by (“NeonTV”, “we”, “us”):</p>
{{SELLER}}
<p>By creating an account, signing in, or using the Service, you agree to these Terms and confirm that you have read our <a href="{{URL}}/yasal.php?s=gizlilik&lang=en">Privacy Policy</a>. If you do not agree, do not use the Service.</p>

<h2>2. Eligibility and minors</h2>
<p>You must be at least 13 years old, or older if the law where you live requires a higher minimum age. If you are under 18, a parent or legal guardian must approve a creator account and is responsible for your use. The Service is not directed to children below the applicable minimum age; if we learn that an ineligible child uses it, we may close the account and delete the related personal data.</p>

<h2>3. Accounts and security</h2>
<p>You sign up with an email address, a username and a password. You must provide accurate information and are responsible for your password and sessions. Tell us promptly at {{EMAIL}} if you suspect unauthorized access. Accounts may not be sold, transferred, shared publicly, or used to evade restrictions. You may optionally link your Discord account and unlink it from your profile at any time.</p>

<h2>4. The Service</h2>
<p>On NeonTV you can watch videos, comment, rate, build lists, and, with a creator account, share three kinds of content: <b>Flicks</b> (landscape/long videos), <b>Nets</b> (vertical short videos) and <b>Circs</b> (text and image posts). The Service is free; some features require tokens or Premium (section 6). Features and limits (file size, duration, daily posts) may change. A displayed limit is a maximum, not a promise of constant performance or availability.</p>

<h2>5. Creators and user content</h2>
<ul>
<li><b>Ownership.</b> You keep the rights to what you upload. You grant NeonTV a limited, non-exclusive licence to store, copy, resize, cache and display it only as needed to operate, secure and show the Service.</li>
<li><b>Rights.</b> You confirm you hold all rights needed to publish your content and that it does not infringe anyone's copyright, personality or privacy rights.</li>
<li><b>Temporary publishing.</b> Flicks and Nets are automatically deleted from the site and our content server after the period you choose at upload (24 hours to 30 days); aggregate statistics such as views remain in our records. Circs stay until you delete them or your account is deleted. Do not use the Service as your only copy.</li>
<li><b>Publishing without pre-approval, with automated checks.</b> Flicks and Nets go live without prior approval. After upload, automated systems check the title, description and a few screenshots taken from the video (start, middle and end) for safety. Content that looks suspicious may be taken offline and queued for administrator review, who may restore or delete it. Automated checks are not perfect; you may request human review at {{EMAIL}}.</li>
<li><b>Reporting and removal.</b> Report content with the report button under a video or at {{EMAIL}}. Content may be removed after a report or on our own initiative; repeated violations close the creator account. See the <a href="{{URL}}/yasal.php?s=icerik-kurallari">Community and Content Rules</a> (Turkish).</li>
</ul>

<h2>6. Tokens and Premium</h2>
<p>Tokens are virtual points earned by watching ads or completing tasks. They have <b>no cash value</b>, cannot be exchanged for money, and, except where mandatory consumer law requires otherwise, cannot be refunded or transferred between accounts (except Premium gifts). Premium currently costs <b>{{PRICE}} tokens</b> for <b>{{DAYS}} days</b>; current prices and discounts are shown in the Store. There are no hidden fees. Tokens and Premium obtained through rule violations (bots, automation, multiple accounts, etc.) may be cancelled. See the <a href="{{URL}}/yasal.php?s=iade">14-day refund policy</a> (Turkish).</p>

<h2>7. Acceptable use</h2>
<p>You must not use, or help others use, the Service to:</p>
<ul>
<li>break the law or infringe copyright, privacy, personality or contractual rights;</li>
<li>post sexual content, content that exploits or endangers minors, violence, terrorism, hate, harassment, or content promoting illegal activity;</li>
<li>spread malware, phishing, spam, or misleading titles/thumbnails;</li>
<li>attack the Service, probe for vulnerabilities (without prior written permission), send excessive automated requests, or access other people's accounts;</li>
<li>earn tokens with bots, automation, fake accounts or cheating; create fake comments, ratings, likes or views; pay for reviews;</li>
<li>impersonate others, evade restrictions or suspensions, or interfere with monitoring and security controls.</li>
</ul>
<p>We may investigate suspected abuse and cooperate with lawful authorities where required.</p>

<h2>8. Discord community and bots</h2>
<p>The NeonTV Discord server may run welcome, levelling, verification, ticket, suggestion/complaint, AI chat and moderation bots. You must follow the server rules. Messages you send to a bot may be passed to an AI provider to generate a reply; never send passwords, payment details or other secrets to a bot. Account linking only lets you see your own account information through the bot. Staff may use the bot's moderation powers (for example restricting a user, granting tokens or Premium); such actions are logged for audit.</p>

<h2>9. One person, one account</h2>
<p>Rewards and limits apply once per person. You may not create or use extra accounts to evade limits, suspensions, votes, rewards or token earning. Automated systems may link accounts in suspicious cases; no restriction is applied before a review, and you can appeal at {{EMAIL}} to be reviewed by a person.</p>

<h2>10. Suspension and termination</h2>
<p>You may stop using the Service at any time and permanently delete your account under Profile → Delete account. We may restrict, suspend or terminate access for security, abuse prevention, legal compliance, repeated violations or infrastructure protection. Where practical and safe we give notice first; urgent action may happen without notice. When an account or content is deleted, related data may be erased without recovery.</p>

<h2>11. Availability, changes and backups</h2>
<p>The Service is provided “as is” and “as available”. We do not promise uninterrupted or error-free service, particular performance, or permanent storage of content. Maintenance, incidents, third-party failures and security events may interrupt access. Keep your own backups.</p>

<h2>12. Warranties and liability</h2>
<p>To the maximum extent permitted by law, the Service is provided without express or implied warranties. To the maximum extent permitted by law, we are not liable for indirect, incidental or consequential loss, or loss of data, profit or reputation. Nothing here limits liability that cannot lawfully be limited, including mandatory consumer rights and liability for wilful misconduct or gross negligence.</p>

<h2>13. Governing law and disputes</h2>
<p>These Terms are governed by Turkish law. Please contact us at {{EMAIL}} before starting formal proceedings. For consumer matters, the Consumer Arbitration Committees and Consumer Courts are competent; for other disputes, the courts and enforcement offices of Türkiye. Mandatory consumer protections remain unaffected.</p>

<h2>14. Changes to these Terms</h2>
<p>We may update these Terms as the Service, the law or our practices change. We publish the new version and its effective date here and announce material changes on the site. Continuing to use the Service after a change means you accept the current Terms; if you disagree, stop using the Service. If a provision is unenforceable, it is limited only as far as necessary and the rest remains in force.</p>

<h2>15. Contact</h2>
<p>For legal notices, copyright and content removal, abuse reports, account security, privacy and anything else: <b>{{EMAIL}}</b>. Do not send passwords or personal data in public channels.</p>
T];

    // ================= ENGLISH — PRIVACY POLICY =================
    $d['en']['gizlilik'] = ['Privacy Policy', <<<'T'
<p class="text-xs text-gray-500">Effective and last updated: 28 November 2026 · Version {{VERSION}}</p>
<p>This Policy summarizes which personal data we process and why. It follows the Turkish Personal Data Protection Law (KVKK); the detailed notice is the <a href="{{URL}}/yasal.php?s=kvkk">KVKK Disclosure Text</a> (Turkish).</p>
<h2>1. Who controls your data</h2>
{{SELLER}}
<p>For privacy questions and data requests: <b>{{EMAIL}}</b>. Never send passwords or personal data in a public channel.</p>

<h2>2. Scope</h2>
<p>This Policy applies when you visit NeonTV, create an account, watch or share content, link Discord, or contact us. Third-party services are covered by their own policies. We <b>do not sell</b> personal data or share it for marketing. We do not collect card or bank details (Premium is bought with tokens only).</p>

<h2>3. Data we collect</h2>
<h3>Data you provide</h3>
<ul>
<li>Account: email address, username, password (stored only as an irreversible hash), optional avatar, cover and bio.</li>
<li>Usage: watch history, watch-later list, comments, ratings, likes, follows, subscriptions, playlists, token activity, Premium status and notification preferences.</li>
<li>Creators: the Flicks, Nets and Circs you upload; thumbnails, titles, descriptions, tags, expiry settings, view and like counts.</li>
<li>Contact: your name, email and message when you write to us.</li>
</ul>
<h3>Data from Discord</h3>
<p>If you link Discord we store only your Discord user ID and the link time. Linking uses a single-use code valid for 10 minutes. Our community bots keep server levels/XP, roles, boosts and tickets tied to your Discord user ID.</p>
<h3>Data collected automatically</h3>
<ul>
<li>A one-way hash of your IP address, country, browser/device details and referring page, for security and abuse prevention. We do not keep city or ISP.</li>
<li>Session, cookie and browser storage data (section 8), plus error and performance logs.</li>
<li>A push-notification endpoint if you allow browser notifications.</li>
</ul>
<h3>AI use</h3>
<ul>
<li><b>Content safety check:</b> when you upload a Flick or Net, its title, description and a few screenshots from the video are sent to Google Gemini for an automated safety check. Content that looks suspicious is queued for administrator review.</li>
<li><b>Subtitles and summaries:</b> AI subtitle/summary features process video audio or text.</li>
<li><b>Chat and assistants:</b> messages you write to the site assistant or Discord bots are sent to an AI provider to produce replies. Do not send passwords, payment details or other secrets.</li>
</ul>

<h2>4. Why we process data</h2>
<ul>
<li>Account, service delivery, publishing, tokens/Premium, support — <b>performance of a contract</b> (KVKK art. 5/2-c).</li>
<li>Security, preventing bots/fake accounts/token abuse, automated content checks, debugging and operating the Service — <b>legitimate interests</b> (art. 5/2-f).</li>
<li>Legal duties and lawful requests from authorities — <b>legal obligation</b> (art. 5/2-ç).</li>
<li>Browser notifications, optional preferences and linking Discord — <b>explicit consent</b> (art. 5/1), which you can withdraw at any time.</li>
</ul>

<h2>5. Who receives data</h2>
<p>We share data only as needed to run the Service, with:</p>
<ul>
<li><b>Supabase:</b> database and authentication.</li>
<li><b>Cloudinary, our own CDN server, Cloudflare:</b> image/video hosting, delivery and network security.</li>
<li><b>Google (Gemini):</b> AI content checks, subtitles, summaries and assistant replies.</li>
<li><b>Giphy:</b> GIF search (search term only).</li>
<li><b>Discord:</b> the community server and bots.</li>
<li><b>Google Fonts, cdnjs, jsDelivr:</b> fonts, icons and scripts (your browser may connect to them and your IP address is visible).</li>
<li>Authorized administrators and support staff, only as their duties require.</li>
<li>Authorities, courts and advisers where lawful and necessary.</li>
</ul>
<p>When content or accounts are flagged for abuse, we may talk about the case in our community in general terms, but never publish your personal data, passwords or secrets.</p>

<h2>6. International transfers</h2>
<p>Some of the providers above may process data outside Türkiye. Transfers rely on lawful mechanisms under KVKK art. 9, such as an adequacy decision, appropriate safeguards or explicit consent.</p>

<h2>7. How long we keep data</h2>
<ul>
<li>Account data, history, token/Premium records: until you delete the account (or for any legally required retention period).</li>
<li>Flicks and Nets: deleted when your chosen publishing period ends; content under administrator review is kept until the review is decided.</li>
<li>Visit/security logs: up to 90 days.</li>
<li>Contact messages: up to 2 years after the request is resolved.</li>
<li>Discord bot records: while you are in the server or until you ask for deletion; short-term chat memory is limited to minutes or days.</li>
</ul>
<p>We may keep limited information longer when needed for security, disputes or legal duties, and may anonymize data so it can no longer identify you.</p>

<h2>8. Cookies and local storage</h2>
<p>We use cookies and localStorage for essential session/sign-in, CSRF protection and preferences (such as playback speed, volume, autoplay and cookie choice). We do not use advertising, profiling or third-party analytics cookies; if that changes we will ask for your explicit consent first. See the <a href="{{URL}}/yasal.php?s=cerez">Cookie Policy</a> (Turkish). You can clear storage in your browser; blocking essential cookies prevents sign-in.</p>

<h2>9. Security</h2>
<p>We use TLS (HTTPS), password hashing, access controls, rate limits and logging. No system is completely secure: use a strong password and report anything suspicious.</p>

<h2>10. Your rights (KVKK art. 11)</h2>
<p>You may learn whether your data is processed, request information, learn the purpose and whether it is used accordingly, know the recipients, request correction, erasure or destruction, object to processing, and claim compensation for damage. You can download your data from your Profile and permanently delete your account (<a href="{{URL}}/yasal.php?s=veri-silme">Data deletion request</a>, Turkish). Send requests to {{EMAIL}}; we answer within 30 days. You may complain to the Personal Data Protection Authority (KVKK). If you contest an automated content-check result, a person will review it again.</p>

<h2>11. Children</h2>
<p>The Service is not for anyone under 13. We do not knowingly collect data from an ineligible child. A parent or guardian who believes this occurred should write to {{EMAIL}} so we can investigate and delete the data where appropriate.</p>

<h2>12. Changes to this Policy</h2>
<p>We may update this Policy as the Service, providers or the law change. We publish the current version and date here and announce material changes on the site.</p>

<h2>13. Contact</h2>
<p>For privacy, KVKK and other legal matters: <b>{{EMAIL}}</b>.</p>
T];

    $out = $d[$lang] ?? $d['tr'];
    $rep = ['{{SELLER}}' => $sellerHtml, '{{EMAIL}}' => '<a href="mailto:' . LEGAL_CONTACT_EMAIL . '">' . LEGAL_CONTACT_EMAIL . '</a>', '{{VERSION}}' => LEGAL_VERSION, '{{PRICE}}' => (string)$price, '{{DAYS}}' => (string)$days, '{{URL}}' => APP_URL];
    foreach ($out as $k => $doc) $out[$k] = [$doc[0], strtr($doc[1], $rep)];
    return $out;
}
