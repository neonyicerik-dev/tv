<?php
// NeonTV - İçerik Üreticisi Stüdyosu: Genel · Flicks · Net · Circ sekmeleri (her içerik türü ayrı sekmede)
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'İçerik Üreticisi Stüdyosu'; $metaDesc = 'Flicks, Net ve Circ paylaş.'; $pageRobots = 'noindex,nofollow';
include __DIR__ . '/components/header.php';
?>
<style>
.st-card{background:#13131f;border:1px solid rgba(255,255,255,.08);border-radius:20px;padding:20px}
.st-in{width:100%;padding:10px 14px;border-radius:12px;background:rgba(0,0,0,.4);border:1px solid rgba(255,255,255,.12);color:#fff;font-size:14px;outline:none}
.st-in:focus{border-color:#00f5ff}.st-lb{display:block;font-size:11px;color:#8b8fa3;margin:10px 0 4px;font-weight:600}
.st-btn{padding:11px 22px;border-radius:12px;font-weight:800;font-size:14px;color:#000;background:linear-gradient(135deg,#00f5ff,#7df9ff);border:0;cursor:pointer}.st-btn:disabled{opacity:.5;cursor:default}
.st-pill{font-size:11px;font-weight:700;padding:2px 9px;border-radius:99px}
.st-row{display:flex;gap:12px;align-items:center;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.06)}
.st-th{width:112px;aspect-ratio:16/9;border-radius:10px;object-fit:cover;background:#0b0b14;flex:none}
.st-th.v{width:64px;aspect-ratio:9/16}
.st-tabs{display:flex;gap:6px;margin-bottom:18px;background:#0e0e18;border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:5px;position:sticky;top:64px;z-index:20}
.st-tab{flex:1;text-align:center;padding:10px 6px;border-radius:12px;font-weight:700;font-size:14px;color:#9ca3af;cursor:pointer;border:0;background:transparent;white-space:nowrap}
.st-tab.on{background:linear-gradient(135deg,#00f5ff,#7df9ff);color:#000}
.yt{max-width:560px;margin:0 auto;background:#0f0f0f;border:1px solid rgba(255,255,255,.08);border-radius:20px;overflow:hidden}
.yt-prev{position:relative;background:#000;display:flex;align-items:center;justify-content:center;overflow:hidden}
.yt-prev.land{aspect-ratio:16/9}.yt-prev.port{aspect-ratio:9/16;max-height:62vh;margin:0 auto}
.yt-prev video{width:100%;height:100%;object-fit:contain;background:#000}
.yt-empty{display:flex;flex-direction:column;gap:10px;align-items:center;justify-content:center;padding:24px;text-align:center;color:#9ca3af;font-size:13px}
.yt-pick{display:inline-flex;align-items:center;gap:8px;padding:11px 18px;border-radius:99px;background:#272727;color:#fff;font-weight:700;font-size:14px;border:0;cursor:pointer}
.yt-pick.rec{background:#dc2626}
.yt-edit{position:absolute;left:12px;top:12px;width:44px;height:44px;border-radius:50%;background:rgba(20,10,30,.85);color:#fff;border:0;cursor:pointer;z-index:2}
.yt-body{padding:16px}
.yt-who{display:flex;align-items:center;gap:12px;padding-bottom:14px;border-bottom:1px solid rgba(255,255,255,.1)}
.yt-av{width:44px;height:44px;border-radius:50%;background:#0d9488;color:#fff;font-weight:800;display:flex;align-items:center;justify-content:center;overflow:hidden;flex:none}
.yt-av img{width:100%;height:100%;object-fit:cover}
.yt-title{width:100%;background:transparent;border:0;border-bottom:1px solid rgba(255,255,255,.1);color:#fff;font-size:20px;padding:16px 0;outline:none;resize:none;min-height:84px}
.yt-title::placeholder{color:#6b7280}
.yt-opt{display:flex;align-items:center;gap:14px;padding:14px 0;color:#fff}
.yt-opt small{display:block;color:#9ca3af;font-size:12px}.yt-opt b{font-size:16px}
.yt-opt select{background:transparent;color:#fff;border:0;font-size:16px;font-weight:700;outline:none;padding:0}
.yt-opt select option{background:#1b1b1b}
.yt-more{width:100%;padding:12px;border-radius:99px;background:#272727;color:#fff;font-weight:700;border:0;cursor:pointer;margin:6px 0 10px}
.yt-go{width:100%;padding:14px;border-radius:99px;background:#f1f1f1;color:#0f0f0f;font-weight:800;font-size:16px;border:0;cursor:pointer}.yt-go:disabled{opacity:.5}
.yt-note{font-size:12px;color:#9ca3af;margin:10px 0}
.yt-bar{height:8px;border-radius:99px;background:rgba(255,255,255,.1);overflow:hidden;margin-top:12px}.yt-bar>div{height:100%;width:0;background:linear-gradient(90deg,#00f5ff,#bf00ff);transition:width .2s}
.yt-cam{position:absolute;inset:0;background:#000;display:flex;flex-direction:column}
.yt-cam video{flex:1;min-height:0;width:100%;object-fit:cover;transform:scaleX(-1)}.yt-cam video.back{transform:none}
.yt-camb{display:flex;align-items:center;justify-content:center;gap:18px;padding:12px;background:rgba(0,0,0,.7)}
.yt-rec{width:60px;height:60px;border-radius:50%;border:4px solid #fff;background:#dc2626;cursor:pointer}.yt-rec.on{border-radius:14px;width:52px;height:52px;margin:4px}
.yt-ic{width:44px;height:44px;border-radius:50%;background:#272727;color:#fff;border:0;cursor:pointer}
</style>
<div class="max-w-3xl mx-auto px-4 sm:px-6 py-6" id="st-root">
  <h1 class="text-2xl font-bold text-white mb-1"><i class="fa-solid fa-clapperboard mr-2" style="color:#00f5ff"></i>İçerik Üreticisi Stüdyosu</h1>
  <p class="text-sm text-gray-400 mb-5">Flicks'lerin, Net'lerin ve Circ'lerin seçtiğin süre boyunca yayında kalır. İzlenme sayın profilinde durur.</p>
  <div id="st-msg" class="text-gray-500 text-sm py-10 text-center">Yükleniyor...</div>
  <div id="st-body" style="display:none"></div>
</div>
<script>
window.addEventListener('load', async function () {
  const BASE = <?= json_encode(APP_URL) ?>, CLOUD = <?= json_encode(CLOUDINARY_CLOUD_NAME) ?>, msg = document.getElementById('st-msg'), body = document.getElementById('st-body');
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let tok = null; try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}
  if (!tok) { msg.innerHTML = 'Bu sayfa için <a class="text-cyan-400 underline" href="' + BASE + '/auth.php">giriş yap</a>.'; return; }
  const H = { 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok };
  const api = (p, o) => fetch(BASE + '/api/' + p + (p.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(tok), Object.assign({ headers: Object.assign({ 'Content-Type': 'application/json' }, H) }, o || {})).then(r => r.json());
  const ST = { published: ['Yayında', '#22c55e'], pending: ['İncelemede', '#f59e0b'], rejected: ['Reddedildi', '#ef4444'], expired: ['Süresi doldu', '#9ca3af'], private: ['Gizli', '#9ca3af'], draft: ['Taslak', '#9ca3af'], scheduled: ['Zamanlandı', '#3b82f6'] };
  const left = e => { if (!e) return ''; const d = (new Date(e).getTime() - Date.now()) / 3600000; return d <= 0 ? 'süre doldu' : d < 48 ? Math.ceil(d) + ' saat kaldı' : Math.ceil(d / 24) + ' gün kaldı'; };
  const $ = id => document.getElementById(id);
  const TABS = [['genel', 'Genel', 'fa-chart-simple'], ['video', 'Flicks', 'fa-film'], ['net', 'Net', 'fa-bolt'], ['circ', 'Circ', 'fa-comment-dots']];
  const files = {};          // sekme -> seçilen/çekilen video dosyası
  let info = null, tab = 'genel', cam = null;

  const hashTab = () => { const h = location.hash.replace('#', ''); return h === 'gonderi' ? 'circ' : (TABS.some(t => t[0] === h) ? h : 'genel'); };

  async function render() {
    const j = await api('creator.php'); if (!j.success) { msg.textContent = j.message || 'Hata'; return; } info = j.data; msg.style.display = 'none'; body.style.display = 'block';
    if (info.banned) { body.innerHTML = '<div class="st-card" style="color:#fca5a5">İçerik üreticisi hesabın kapatıldı. Bilgi için <a class="underline" href="' + BASE + '/iletisim.php">iletişime geç</a>.</div>'; return; }
    if (!info.is_creator) {
      body.innerHTML = '<div class="st-card"><h2 class="text-lg font-bold text-white mb-2">İçerik üreticisi ol</h2>' +
        '<p class="text-sm text-gray-300 mb-3">Hesabını içerik üreticisine çevirerek Flicks, Net ve Circ paylaşabilirsin. Kendi kanalın otomatik açılır, onay beklemezsin.</p>' +
        '<ul class="text-sm text-gray-400 mb-4" style="list-style:disc;padding-left:20px;line-height:1.7"><li>Her içerik, seçtiğin süre (24 saat – 30 gün) sonunda otomatik kaldırılır.</li><li>En fazla ' + info.limits.mb + ' MB ve ' + info.limits.minutes + ' dakikalık videolar yüklenebilir.</li><li>İçerikler onay beklemeden yayınlanır; yapay zeka başlık ve kareleri kontrol eder, şüpheli görürse içeriği yönetici incelemesine alır.</li></ul>' +
        '<label class="flex items-start gap-2 text-sm text-gray-300 mb-4"><input type="checkbox" id="st-acc" class="mt-1"><span><a class="text-cyan-400 underline" href="' + BASE + '/yasal.php?s=icerik-kurallari" target="_blank">Topluluk ve İçerik Kuralları</a>\'nı okudum, kabul ediyorum; yüklediğim içeriğin haklarına sahibim.</span></label>' +
        '<button class="st-btn" id="st-en">İçerik üreticisi hesabı oluştur</button> <span id="st-em" class="text-sm text-red-300 ml-2"></span></div>';
      $('st-en').onclick = async function () {
        const em = $('st-em'); em.textContent = '';
        if (!$('st-acc').checked) { em.textContent = 'Kuralları kabul etmelisin.'; return; }
        this.disabled = true; const r = await api('creator.php', { method: 'POST', body: JSON.stringify({ action: 'enable', accept: true }) });
        if (r.success) render(); else { em.textContent = r.message || 'Hata'; this.disabled = false; }
      }; return;
    }
    const s = info.stats || {}, L = info.limits;
    body.innerHTML = '<div class="st-tabs">' + TABS.map(t => '<button class="st-tab" data-t="' + t[0] + '"><i class="fa-solid ' + t[2] + ' mr-1.5"></i>' + t[1] + '</button>').join('') + '</div>' +
      '<section data-p="genel"><div class="grid grid-cols-3 gap-3 mb-5">' + [['Toplam izlenme', (s.total_views || 0).toLocaleString('tr-TR')], ['Aktif içerik', (s.active || 0) + '/' + L.active], ['Toplam video', s.total_videos || 0]].map(x => '<div class="st-card text-center"><div class="text-2xl font-black text-white">' + x[1] + '</div><div class="text-[11px] text-gray-500">' + x[0] + '</div></div>').join('') + '</div>' +
      '<div class="st-card text-sm text-gray-300" style="line-height:1.8"><b class="text-white">Neyi nerede paylaşırsın?</b><br>• <b>Flicks:</b> yatay, en fazla ' + L.minutes + ' dakika<br>• <b>Net:</b> dikey kısa video, en fazla ' + L.short_sec + ' saniye, kamerayla da çekebilirsin<br>• <b>Circ:</b> metin ve resim, günde ' + L.post_daily + ' paylaşım<br><span class="text-gray-500">Günde ' + L.daily + ' video/Net yükleyebilirsin. Dosya sınırı ' + L.mb + ' MB.</span></div></section>' +
      '<section data-p="video" style="display:none">' + uploadView('video') + '</section>' +
      '<section data-p="net" style="display:none">' + uploadView('short') + '</section>' +
      '<section data-p="circ" style="display:none">' + circView() + '</section>';
    body.querySelectorAll('.st-tab').forEach(b => b.onclick = () => { location.hash = b.dataset.t; });
    bindUpload('video'); bindUpload('short'); bindCirc(); showTab(hashTab());
  }
  function showTab(t) {
    tab = t; stopCam();
    body.querySelectorAll('.st-tab').forEach(b => b.classList.toggle('on', b.dataset.t === t));
    body.querySelectorAll('section[data-p]').forEach(sec => sec.style.display = sec.dataset.p === t ? 'block' : 'none');
    if (t === 'video') loadList('video'); if (t === 'net') loadList('short'); if (t === 'circ') loadPosts();
  }
  window.addEventListener('hashchange', () => { if (info && info.is_creator) showTab(hashTab()); });

  // ---------- Video / Net yükleme ekranı ("Ayrıntı ekleme")
  const pf = k => k === 'short' ? 'n' : 'v';
  function authorRow() {
    const n = info.name || 'Kanal', av = info.avatar ? '<img src="' + esc(info.avatar) + '" alt="">' : esc(n.charAt(0).toUpperCase());
    return '<div class="yt-who"><div class="yt-av">' + av + '</div><div><div class="text-white font-bold" style="font-size:17px">' + esc(n) + '</div><div class="text-gray-400 text-sm">Kanalına yüklenecek</div></div></div>';
  }
  function uploadView(k) {
    const p = pf(k), L = info.limits, short = k === 'short';
    return '<div class="yt"><div class="yt-prev ' + (short ? 'port' : 'land') + '" id="' + p + '-prev"></div>' +
      '<div class="yt-body">' + authorRow() +
      '<textarea id="' + p + '-title" class="yt-title" maxlength="100" placeholder="' + (short ? 'Net için başlık oluşturun' : 'Başlık oluşturun') + '"></textarea>' +
      '<div class="yt-opt"><i class="fa-solid fa-globe text-xl"></i><div><small>Görünürlük</small><b>Herkese açık</b></div></div>' +
      '<div class="yt-opt"><i class="fa-regular fa-clock text-xl"></i><div><small>Yayında kalma süresi</small><select id="' + p + '-days">' + Object.entries(info.days).map(([d, l]) => '<option value="' + d + '"' + (d == 7 ? ' selected' : '') + '>' + l + '</option>').join('') + '</select></div></div>' +
      '<button type="button" class="yt-more" id="' + p + '-more">Daha fazla göster <i class="fa-solid fa-chevron-down ml-1"></i></button>' +
      '<div id="' + p + '-extra" style="display:none"><label class="st-lb">Açıklama (isteğe bağlı)</label><textarea id="' + p + '-desc" rows="3" maxlength="1000" class="st-in"></textarea><label class="st-lb">Etiketler (virgülle, en çok 5)</label><input id="' + p + '-tags" class="st-in" placeholder="komedi, gündem"></div>' +
      '<p class="yt-note">' + (short ? 'En fazla ' + L.short_sec + ' saniye, dikey (veya kare). ' : 'En fazla ' + L.minutes + ' dakika. ') + 'Yüklemeyle <a class="underline" href="' + BASE + '/yasal.php?s=icerik-kurallari" target="_blank">içerik kurallarını</a> kabul etmiş olursun. Yapay zeka başlık ve kareleri otomatik kontrol eder.</p>' +
      '<div id="' + p + '-prog" style="display:none"><div class="yt-bar"><div id="' + p + '-bar"></div></div><div id="' + p + '-pt" class="text-xs text-gray-400 mt-1"></div></div>' +
      '<div id="' + p + '-um" class="text-sm my-2"></div>' +
      '<button class="yt-go" id="' + p + '-up">Yükle</button></div></div>' +
      '<div class="st-card mt-5" style="max-width:560px;margin-left:auto;margin-right:auto"><h2 class="text-base font-bold text-white mb-1">' + (short ? 'Net\'lerim' : 'Flicks\'lerim') + '</h2><div id="' + p + '-list" class="text-sm text-gray-500">Yükleniyor…</div></div>' +
      '<input type="file" id="' + p + '-file" accept="video/mp4,video/quicktime,video/webm,.mp4,.mov,.webm,.m4v" style="display:none">' +
      '<input type="file" id="' + p + '-cap" accept="video/*" capture="user" style="display:none">';
  }
  function emptyPrev(k) {
    const p = pf(k), short = k === 'short';
    $(p + '-prev').innerHTML = '<div class="yt-empty"><i class="fa-solid ' + (short ? 'fa-bolt' : 'fa-film') + '" style="font-size:36px;color:#00f5ff"></i><div>' + (short ? 'Dikey kısa video seç ya da kamerayla çek' : 'Video dosyası seç') + '</div>' +
      '<div class="flex flex-wrap gap-2 justify-center"><button type="button" class="yt-pick" id="' + p + '-pickbtn"><i class="fa-solid fa-folder-open"></i> Dosya seç</button>' + (short ? '<button type="button" class="yt-pick rec" id="' + p + '-recbtn"><i class="fa-solid fa-video"></i> Kamerayla çek</button>' : '') + '</div></div>';
    $(p + '-pickbtn').onclick = () => $(p + '-file').click();
    if (short) $(p + '-recbtn').onclick = () => startCam(k);
  }
  function setFile(k, f) {
    const p = pf(k); files[k] = f; stopCam();
    const u = URL.createObjectURL(f);
    $(p + '-prev').innerHTML = '<button type="button" class="yt-edit" id="' + p + '-chg" title="Değiştir"><i class="fa-solid fa-pen"></i></button><video src="' + u + '" controls playsinline muted></video>';
    $(p + '-chg').onclick = () => { files[k] = null; emptyPrev(k); };
  }
  function bindUpload(k) {
    const p = pf(k); emptyPrev(k);
    $(p + '-file').onchange = e => { if (e.target.files[0]) setFile(k, e.target.files[0]); e.target.value = ''; };
    $(p + '-cap').onchange = e => { if (e.target.files[0]) setFile(k, e.target.files[0]); e.target.value = ''; };
    $(p + '-more').onclick = () => { const x = $(p + '-extra'); x.style.display = x.style.display === 'none' ? 'block' : 'none'; };
    $(p + '-up').onclick = () => upload(k);
  }

  // ---------- Kamerayla çekme (Net)
  function stopCam() { if (cam) { try { cam.rec && cam.rec.state !== 'inactive' && (cam.discard = true, cam.rec.stop()); } catch (e) {} try { cam.stream.getTracks().forEach(t => t.stop()); } catch (e) {} clearInterval(cam.timer); cam = null; } }
  async function startCam(k, facing) {
    const p = pf(k), prev = $(p + '-prev');
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) { $(p + '-cap').click(); return; }   // https yok / eski tarayıcı: cihaz kamerası uygulaması
    stopCam(); facing = facing || 'user';
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: facing, width: { ideal: 720 }, height: { ideal: 1280 } }, audio: true }); }
    catch (e) { $(p + '-cap').click(); return; }
    const maxS = info.limits.short_sec;
    prev.innerHTML = '<div class="yt-cam"><video autoplay muted playsinline class="' + (facing === 'user' ? '' : 'back') + '"></video><div class="yt-camb"><button type="button" class="yt-ic" id="' + p + '-flip" title="Kamerayı çevir"><i class="fa-solid fa-camera-rotate"></i></button><button type="button" class="yt-rec" id="' + p + '-rec" title="Kaydı başlat"></button><span id="' + p + '-t" class="text-white text-sm" style="min-width:64px">0 / ' + maxS + ' sn</span><button type="button" class="yt-ic" id="' + p + '-x" title="İptal"><i class="fa-solid fa-xmark"></i></button></div></div>';
    prev.querySelector('video').srcObject = stream;
    cam = { stream: stream, rec: null, chunks: [], timer: null, t0: 0 };
    $(p + '-x').onclick = () => { stopCam(); emptyPrev(k); };
    $(p + '-flip').onclick = () => startCam(k, facing === 'user' ? 'environment' : 'user');
    $(p + '-rec').onclick = () => {
      if (cam.rec && cam.rec.state === 'recording') { cam.rec.stop(); return; }
      const types = ['video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'], mt = types.find(t => MediaRecorder.isTypeSupported(t)) || '';
      const c = cam; c.chunks = []; c.rec = new MediaRecorder(stream, mt ? { mimeType: mt } : undefined);
      c.rec.ondataavailable = e => { if (e.data && e.data.size) c.chunks.push(e.data); };
      c.rec.onstop = () => {
        clearInterval(c.timer);
        if (c.discard) return;
        const type = (c.rec.mimeType || mt || 'video/webm').split(';')[0], ext = type.indexOf('mp4') >= 0 ? 'mp4' : 'webm';
        const f = new File([new Blob(c.chunks, { type: type })], 'kamera_' + Date.now() + '.' + ext, { type: type });
        setFile(k, f);
      };
      c.rec.start(500); c.t0 = Date.now(); $(p + '-rec').classList.add('on'); $(p + '-flip').style.display = 'none';
      c.timer = setInterval(() => { const s = Math.floor((Date.now() - c.t0) / 1000); const t = $(p + '-t'); if (t) t.textContent = s + ' / ' + maxS + ' sn'; if (s >= maxS && c.rec.state === 'recording') c.rec.stop(); }, 250);
    };
  }

  async function grabFrames(f) {   // Yapay zeka kontrolü için 5 kare: ilk 5 sn'den 2, ortadan 1, son 5 sn'den 2
    const u = URL.createObjectURL(f), v = document.createElement('video'); v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = u;
    try {
      await new Promise((res, rej) => { v.onloadedmetadata = res; v.onerror = rej; setTimeout(rej, 15000); });
      const d = isFinite(v.duration) && v.duration > 0 ? v.duration : 10, ts = [Math.min(1, d / 4), Math.min(3.5, d / 2), d / 2, Math.max(d - 3.5, d / 2), Math.max(d - 1, 0.5)], out = [];
      const c = document.createElement('canvas'), k = Math.min(1, 640 / (v.videoWidth || 640)); c.width = Math.round((v.videoWidth || 640) * k); c.height = Math.round((v.videoHeight || 360) * k);
      for (const t of ts) {
        try {
          await new Promise((res, rej) => { v.onseeked = res; v.onerror = rej; setTimeout(res, 6000); v.currentTime = Math.min(t, Math.max(0, d - 0.1)); });
          c.getContext('2d').drawImage(v, 0, 0, c.width, c.height); const j = c.toDataURL('image/jpeg', 0.7); if (j.length > 2000) out.push(j);
        } catch (e) {}
      }
      return out;
    } catch (e) { return []; } finally { URL.revokeObjectURL(u); }
  }

  async function upload(kind) {
    const p = pf(kind), f = files[kind], um = $(p + '-um'), btn = $(p + '-up');
    const title = $(p + '-title').value.trim(), days = +$(p + '-days').value; um.style.color = '#fca5a5'; um.textContent = '';
    if (!f) { um.textContent = 'Önce bir video seç' + (kind === 'short' ? ' ya da kamerayla çek.' : '.'); return; } if (title.length < 3) { um.textContent = 'Başlık en az 3 karakter olmalı.'; return; }
    if (f.size > info.limits.mb * 1048576) { um.textContent = 'Dosya ' + info.limits.mb + ' MB sınırını aşıyor.'; return; }
    btn.disabled = true; $(p + '-prog').style.display = 'block'; const bar = $(p + '-bar'), pt = $(p + '-pt');
    try {
      const meta = await new Promise(res => { const v = document.createElement('video'), u = URL.createObjectURL(f); v.preload = 'metadata'; v.onloadedmetadata = () => { res({ d: v.duration, w: v.videoWidth, h: v.videoHeight }); URL.revokeObjectURL(u); }; v.onerror = () => { res(null); URL.revokeObjectURL(u); }; v.src = u; });
      if (meta && isFinite(meta.d)) {
        if (kind === 'short' && meta.d > info.limits.short_sec + 1) throw new Error('Net en fazla ' + info.limits.short_sec + ' saniye olabilir.');
        if (kind === 'short' && meta.w > meta.h * 1.05) throw new Error('Net dikey (veya kare) olmalı.');
        if (kind === 'video' && meta.d > info.limits.minutes * 60 + 1) throw new Error('Flicks en fazla ' + info.limits.minutes + ' dakika olabilir.');
      }
      const sg = await api('creator_sign.php?kind=' + kind + '&days=' + days); if (sg.error || sg.success === false) throw new Error(sg.message || 'İmza alınamadı');
      const base = { title: title, description: $(p + '-desc').value, tags: $(p + '-tags').value, days: days, kind: kind };
      let reqBody;
      if (sg.cdn) {                                   // tarayıcı -> kendi CDN'imiz (parçalı, devam edebilir)
        const cx = (a, o, raw) => fetch(sg.endpoint + '?a=' + a, Object.assign({ method: 'POST', headers: Object.assign({ 'X-Up-Token': sg.token }, raw ? {} : { 'Content-Type': 'application/json' }) }, o)).then(r => r.json());
        const ini = await cx('init', { body: JSON.stringify({ filename: f.name, size: f.size }) }); if (!ini.upload_id) throw new Error(ini.error || 'CDN yüklemesi başlatılamadı');
        const CH = Math.min(ini.chunk || 8388608, 8388608); let off = 0, fail = 0;
        while (off < f.size) {
          const end = Math.min(off + CH, f.size); pt.textContent = 'Yükleniyor… ' + Math.round(off / f.size * 100) + '%'; bar.style.width = Math.round(off / f.size * 95) + '%';
          let r; try { r = await fetch(sg.endpoint + '?a=chunk&id=' + ini.upload_id + '&offset=' + off, { method: 'POST', headers: { 'X-Up-Token': sg.token, 'Content-Type': 'application/octet-stream' }, body: f.slice(off, end) }).then(x => x.json()); } catch (e) { r = { error: 'ağ' }; }
          if (r.offset !== undefined && r.ok !== false) { off = r.offset; fail = 0; } else if (r.offset !== undefined) { off = r.offset; } else { if (++fail > 4) throw new Error(r.error || 'Yükleme kesildi'); await new Promise(z => setTimeout(z, 1500 * fail)); }
        }
        pt.textContent = 'İşleniyor…'; bar.style.width = '97%';
        const fin = await cx('finish', { body: JSON.stringify({ id: ini.upload_id }) }); if (!fin.url) throw new Error(fin.error || 'Video işlenemedi');
        reqBody = Object.assign(base, { cdn_url: fin.url, thumb_url: fin.thumb, duration: fin.duration || Math.round(meta && meta.d || 0) });
      } else {                                         // yedek: Cloudinary
        const CH = 6 * 1048576, n = Math.max(1, Math.ceil(f.size / CH)), uid = 'ntu_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10); let res = null;
        for (let i = 0; i < n; i++) {
          const a = i * CH, b = Math.min(a + CH, f.size), fd = new FormData();
          fd.append('file', f.slice(a, b)); fd.append('timestamp', sg.timestamp); fd.append('signature', sg.signature); fd.append('api_key', sg.api_key); fd.append('folder', sg.folder); fd.append('allowed_formats', sg.allowed_formats);
          pt.textContent = 'Yükleniyor… ' + Math.round(i / n * 100) + '%'; bar.style.width = Math.round(i / n * 95) + '%';
          const r = await (await fetch('https://api.cloudinary.com/v1_1/' + CLOUD + '/video/upload', { method: 'POST', headers: { 'X-Unique-Upload-Id': uid, 'Content-Range': 'bytes ' + a + '-' + (b - 1) + '/' + f.size }, body: fd })).json();
          if (r.error) throw new Error(r.error.message || 'Yükleme hatası'); if (r.secure_url) res = r;
        }
        if (!res) throw new Error('Video adresi alınamadı'); reqBody = Object.assign(base, { video_url: res.secure_url, cloudinary_public_id: res.public_id, duration: Math.round(res.duration || 0) });
      }
      bar.style.width = '98%'; pt.textContent = 'Kaydediliyor…';
      const sv = await api('creator_videos.php', { method: 'POST', body: JSON.stringify(reqBody) });
      if (!sv.success) throw new Error(sv.message || 'Kaydedilemedi');
      bar.style.width = '99%'; pt.textContent = 'İçerik kontrol ediliyor…';
      let flagged = false, mtxt = '';
      try {
        const fr = await grabFrames(f), mr = await api('creator_moderate.php', { method: 'POST', body: JSON.stringify({ id: sv.data.id, frames: fr }) });
        if (mr.success && mr.data && mr.data.flagged) { flagged = true; mtxt = mr.message; }
      } catch (e) {}
      bar.style.width = '100%'; pt.textContent = ''; um.style.color = flagged ? '#fbbf24' : '#4ade80'; um.textContent = flagged ? mtxt : (kind === 'short' ? 'Net\'in yayında!' : 'Videon yayında!');
      files[kind] = null; $(p + '-title').value = ''; $(p + '-desc').value = ''; $(p + '-tags').value = ''; emptyPrev(kind);
      setTimeout(() => { $(p + '-prog').style.display = 'none'; bar.style.width = '0'; btn.disabled = false; loadList(kind); }, 1200);
    } catch (e) { um.textContent = e.message || 'Hata'; btn.disabled = false; $(p + '-prog').style.display = 'none'; }
  }

  async function loadList(kind) {
    const p = pf(kind), el = $(p + '-list'); if (!el) return;
    const j = await api('creator_videos.php'); if (!j.success) { el.textContent = j.message || 'Hata'; return; }
    const it = j.data.items.filter(v => !!v.is_short === (kind === 'short')); if (!it.length) { el.textContent = kind === 'short' ? 'Henüz Net yüklemedin.' : 'Henüz video yüklemedin.'; return; }
    el.innerHTML = it.map(v => { const st = ST[v.status] || [v.status, '#9ca3af'], gone = v.status === 'expired';
      return '<div class="st-row"><img class="st-th' + (kind === 'short' ? ' v' : '') + '" src="' + esc(gone ? '' : v.thumbnail_url) + '" alt="" onerror="this.style.visibility=\'hidden\'"><div style="min-width:0;flex:1"><div class="text-white font-semibold truncate">' + esc(v.title) + '</div>' +
        '<div class="text-xs text-gray-400 mt-0.5"><span class="st-pill" style="background:' + st[1] + '22;color:' + st[1] + '">' + st[0] + '</span> · ' + (v.views || 0).toLocaleString('tr-TR') + ' izlenme' + (!gone && v.expires_at ? ' · ' + left(v.expires_at) : '') + '</div>' +
        (v.status === 'rejected' && v.reject_reason ? '<div class="text-xs text-red-300 mt-0.5">Sebep: ' + esc(v.reject_reason) + '</div>' : '') + (v.status === 'pending' ? '<div class="text-xs text-amber-300 mt-0.5">Otomatik kontrolde şüpheli bulundu, yönetici inceliyor.</div>' : '') + '</div>' +
        (v.status === 'published' ? '<a class="text-cyan-400 text-xs underline" href="' + BASE + (v.is_short ? '/shorts.php?v=' : '/video.php?id=') + v.id + '">Aç</a>' : '') +
        (!gone ? '<button class="text-red-400 text-xs" data-del="' + v.id + '">Kaldır</button>' : '') + '</div>'; }).join('');
    el.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { if (!confirm('Hemen kaldırılsın mı? Bu geri alınamaz; izlenme sayın kalır.')) return; await api('creator_videos.php?id=' + b.dataset.del, { method: 'DELETE' }); loadList(kind); });
  }

  // ---------- Circ (metin + resim; telefonda kamerayla fotoğraf çekilebilir)
  function circView() {
    return '<div class="yt"><div class="yt-prev land" id="c-prev" style="display:none"></div><div class="yt-body">' + authorRow() +
      '<textarea id="po-body" class="yt-title" maxlength="1000" placeholder="Circ\'inde ne var? Takipçilerine bir şey söyle…"></textarea>' +
      '<div class="flex flex-wrap gap-2 my-3"><button type="button" class="yt-pick" id="c-pick"><i class="fa-regular fa-image"></i> Resim ekle</button><button type="button" class="yt-pick rec" id="c-cam"><i class="fa-solid fa-camera"></i> Kamerayla çek</button></div>' +
      '<p class="yt-note">En çok 5 MB. Günde ' + info.limits.post_daily + ' Circ paylaşabilirsin.</p><div id="po-m" class="text-sm my-2"></div>' +
      '<button class="yt-go" id="po-send">Paylaş</button></div></div>' +
      '<div class="st-card mt-5" style="max-width:560px;margin-left:auto;margin-right:auto"><h2 class="text-base font-bold text-white mb-1">Circ\'lerim</h2><div id="po-list" class="text-sm text-gray-500">Yükleniyor…</div></div>' +
      '<input type="file" id="po-img" accept="image/jpeg,image/png,image/webp,image/gif" style="display:none"><input type="file" id="po-cam" accept="image/*" capture="environment" style="display:none">';
  }
  let circFile = null;
  function setCirc(f) {
    circFile = f; const pv = $('c-prev'); if (!f) { pv.style.display = 'none'; pv.innerHTML = ''; return; }
    pv.style.display = 'flex'; pv.innerHTML = '<button type="button" class="yt-edit" id="c-chg" title="Kaldır"><i class="fa-solid fa-xmark"></i></button><img src="' + URL.createObjectURL(f) + '" alt="" style="width:100%;height:100%;object-fit:contain">';
    $('c-chg').onclick = () => setCirc(null);
  }
  function bindCirc() {
    $('c-pick').onclick = () => $('po-img').click(); $('c-cam').onclick = () => $('po-cam').click();
    $('po-img').onchange = e => { if (e.target.files[0]) setCirc(e.target.files[0]); e.target.value = ''; };
    $('po-cam').onchange = e => { if (e.target.files[0]) setCirc(e.target.files[0]); e.target.value = ''; };
    $('po-send').onclick = sendPost;
  }
  async function sendPost() {
    const m = $('po-m'), btn = $('po-send'), txt = $('po-body').value.trim(), f = circFile; m.style.color = '#fca5a5'; m.textContent = '';
    if (!txt && !f) { m.textContent = 'Bir şeyler yaz veya resim ekle.'; return; } if (f && f.size > 5 * 1048576) { m.textContent = 'Resim en fazla 5 MB olabilir.'; return; } btn.disabled = true;
    try {
      let img = '';
      if (f) { const fd = new FormData(); fd.append('image', f); const r = await (await fetch(BASE + '/api/post_image.php', { method: 'POST', headers: H, body: fd })).json(); if (!r.success) throw new Error(r.message || 'Resim yüklenemedi'); img = r.data.url; }
      const r = await api('posts.php', { method: 'POST', body: JSON.stringify({ action: 'create', body: txt, image_url: img }) }); if (!r.success) throw new Error(r.message || 'Paylaşılamadı');
      $('po-body').value = ''; setCirc(null); m.style.color = '#4ade80'; m.textContent = r.message || 'Paylaşıldı'; loadPosts();
    } catch (e) { m.textContent = e.message || 'Hata'; } btn.disabled = false;
  }
  async function loadPosts() {
    const el = $('po-list'); if (!el) return; const r = await api('posts.php?limit=20&author=' + info.uid); const it = (r.data && r.data.items) || [];
    el.innerHTML = it.length ? it.map(p => '<div class="st-row"><div style="flex:1;min-width:0" class="text-gray-300">' + esc((p.body || '(resim)').slice(0, 90)) + '<div class="text-[11px] text-gray-500">' + (p.likes_count || 0) + ' beğeni</div></div><button class="text-red-400 text-xs" data-pd="' + p.id + '">Sil</button></div>').join('') : 'Henüz hiç Circ yok.';
    el.querySelectorAll('[data-pd]').forEach(b => b.onclick = async () => { if (!confirm('Circ silinsin mi?')) return; await api('posts.php?id=' + b.dataset.pd, { method: 'DELETE' }); loadPosts(); });
  }
  render();
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
