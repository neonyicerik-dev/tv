<?php
// NeonTV - Yasal metinler: yasal.php?s=kvkk|gizlilik|kullanim-kosullari|cerez|mesafeli-satis|on-bilgilendirme|iade|veri-silme
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/legal.php';
$lang = (string)($_GET['lang'] ?? ($_COOKIE['neontv_lang'] ?? 'tr')); $lang = $lang === 'en' ? 'en' : 'tr';
if (isset($_GET['lang']) && !headers_sent()) setcookie('neontv_lang', $lang, ['expires' => time() + 31536000, 'path' => '/', 'samesite' => 'Lax']);
$docs = legalDocs($lang); $s = (string)($_GET['s'] ?? '');
$EN = $lang === 'en'; $enDocs = ['kullanim-kosullari', 'gizlilik'];
$langSw = '<div class="flex gap-2 text-xs mb-4"><a href="' . APP_URL . '/yasal.php' . ($s !== '' ? '?s=' . e($s) . '&lang=tr' : '?lang=tr') . '" class="px-3 py-1 rounded-full ' . (!$EN ? 'bg-cyan-500 text-black font-bold' : 'bg-white/10 text-gray-300') . '">Türkçe</a><a href="' . APP_URL . '/yasal.php' . ($s !== '' ? '?s=' . e($s) . '&lang=en' : '?lang=en') . '" class="px-3 py-1 rounded-full ' . ($EN ? 'bg-cyan-500 text-black font-bold' : 'bg-white/10 text-gray-300') . '">English</a></div>';
if (!isset($docs[$s])) {
    $pageTitle = 'Yasal Bilgiler'; include __DIR__ . '/components/header.php';
    echo '<div class="max-w-screen-md mx-auto px-4 py-10"><h1 class="text-xl font-bold text-white mb-4">' . ($EN ? 'Legal' : 'Yasal Bilgiler') . '</h1>' . $langSw . '<ul class="space-y-2">';
    foreach ($docs as $k => $d) echo '<li><a class="text-cyan-400 hover:underline" href="' . APP_URL . '/yasal.php?s=' . e($k) . '&lang=' . $lang . '">' . e($d[0]) . '</a></li>';
    echo '</ul></div>'; include __DIR__ . '/components/footer.php'; exit;
}
$pageTitle = $docs[$s][0]; $metaDesc = $docs[$s][0] . ' - NeonTV';
include __DIR__ . '/components/header.php'; ?>
<style>.lg h2{font-size:1.05rem;font-weight:700;color:#fff;margin:1.4rem 0 .5rem}.lg p,.lg li{color:#cbd5e1;font-size:.9rem;line-height:1.65}.lg ul{list-style:disc;padding-left:1.3rem;margin:.4rem 0}.lg a{color:#00f5ff}.lg-t{width:100%;border-collapse:collapse;margin:.6rem 0;font-size:.85rem}.lg-t td,.lg-t th{border:1px solid rgba(255,255,255,.1);padding:7px 10px;color:#cbd5e1;text-align:left;vertical-align:top}.lg-t td:first-child{color:#9ca3af;width:32%}</style>
<div class="max-w-screen-md mx-auto px-4 sm:px-6 py-8 lg">
  <?= $langSw ?>
  <?php if ($EN && !in_array($s, $enDocs, true)): ?><p class="text-xs text-amber-400 mb-3">This document is available in Turkish only.</p><?php endif; ?>
  <h1 class="text-2xl font-bold text-white mb-1"><?= e($docs[$s][0]) ?></h1>
  <p class="text-xs text-gray-500 mb-4"><?= $EN ? 'Version' : 'Sürüm' ?>: <?= e(LEGAL_VERSION) ?></p>
  <?= $docs[$s][1] ?>
  <p class="mt-8 text-xs text-gray-500"><a href="<?= APP_URL ?>/yasal.php"><?= $EN ? 'All legal documents' : 'Tüm yasal metinler' ?></a></p>
</div>
<?php include __DIR__ . '/components/footer.php'; ?>
